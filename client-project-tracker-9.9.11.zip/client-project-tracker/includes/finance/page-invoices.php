<?php
if (!defined('ABSPATH')) exit;

/**
 * Invoices (فاکتورها) — v9.2.56 (فاز ۲ از نقشه‌ی طرف‌حساب)
 *
 * این صفحه یک «لایه‌ی سند» روی دفتر مالی موجود است:
 *  - فاکتورها (پیش‌فاکتور، فروش، خرید، برگشتی‌ها) برای شخص/پروژه صادر می‌شوند
 *  - «تسویه‌ی تخصیصی» یک سند دریافت/پرداخت معمولی در همان دفتر می‌سازد و مبلغش
 *    را بین فاکتورهای باز تقسیم می‌کند؛ بنابراین مانده‌ها/گزارش‌های قبلی دست‌نخورده
 *    و از همان منابع رسمی خوانده می‌شوند (هیچ دوبل‌کاری در حساب‌ها رخ نمی‌دهد).
 *  - وضعیت فاکتور (صادرشده/جزئی/تسویه‌شده/باطل) خودکار از مجموع تخصیص‌ها حساب می‌شود.
 */

if (!function_exists('cpttf_invoice_person_options')) {
	function cpttf_invoice_person_options($selected = 0){
		$selected = (int)$selected;
		$out = '<option value="0">— انتخاب شخص —</option>';
		foreach (CPTT_Finance::get_person_options_list() as $p) {
			$out .= '<option value="' . (int)$p['id'] . '"' . selected($selected, (int)$p['id'], false) . '>' . esc_html($p['label']) . '</option>';
		}
		return $out;
	}
}

if (!function_exists('cpttf_invoice_project_options')) {
	function cpttf_invoice_project_options($selected = 0, $person_id = 0){
		$selected = (int)$selected; $person_id = (int)$person_id;
		$out = '<option value="0">— بدون پروژه —</option>';
		$args = ['post_type' => 'cptt_project', 'post_status' => 'any', 'numberposts' => 400, 'orderby' => 'date', 'order' => 'DESC'];
		foreach (get_posts($args) as $p) {
			$cid = (int)get_post_meta($p->ID, '_cptt_client_user_id', true);
			if ($person_id > 0 && $cid !== $person_id) continue;
			$t = get_the_title($p) ?: ('#' . $p->ID);
			$out .= '<option value="' . (int)$p->ID . '" data-person="' . $cid . '"' . selected($selected, $p->ID, false) . '>' . esc_html($t) . '</option>';
		}
		return $out;
	}
}

/** تاریخ شمسی «فقط روز» برای اینپوت‌ها/نمایش */
if (!function_exists('cpttf_jdate_only')) {
	function cpttf_jdate_only($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		$full = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($ts) : date('Y-m-d H:i', $ts);
		$parts = preg_split('/\s+/', (string)$full);
		return (string)($parts[0] ?? $full);
	}
}

if (!function_exists('cpttf_invoice_status_chip')) {
	function cpttf_invoice_status_chip($status){
		$v = CPTT_Finance::invoice_status_vocab();
		$status = (string)$status;
		$label = isset($v[$status]) ? $v[$status] : $status;
		return '<span class="cpttf-inv-status cpttf-inv-status--' . esc_attr($status) . '">' . esc_html($label) . '</span>';
	}
}

/**
 * بدنه‌ی مشترک رندر «ردیف‌های فاکتور» (+ جزئیات تخصیص)
 * $invoices: ردیف‌های کامل جدول فاکتورها (با فیلدهای name/project_title از قبل حل‌شده)
 */
if (!function_exists('cpttf_invoice_rows_html')) {
	function cpttf_invoice_rows_html($invoices, $allocs_by_inv, $opts = []){
		$cur = CPTT_Finance::currency_label();
		$vocab = CPTT_Finance::invoice_kind_vocab();
		$compact = !empty($opts['compact']);
		$now = (int)current_time('timestamp', true);
		ob_start();
		foreach ($invoices as $inv) {
			$remain = max(0.0, (float)$inv->amount - (float)$inv->settled);
			$open = !in_array((string)$inv->status, ['settled','cancelled','draft'], true);
			$overdue = $open && (int)$inv->due_ts > 0 && (int)$inv->due_ts < $now;
			$dir = CPTT_Finance::invoice_settle_dir((string)$inv->kind);
			?>
			<tr class="<?php echo $overdue ? 'is-overdue' : ''; echo (string)$inv->status === 'cancelled' ? ' is-cancelled' : ''; ?>">
				<?php if (!$compact): ?><td style="text-align:center;"><input type="checkbox" class="cpttf-inv-pick" data-id="<?php echo (int)$inv->id; ?>" title="انتخاب برای تسویه دسته‌جمعی / چاپ گروهی"></td><?php endif; ?>
				<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($inv->invoice_no); ?></b>
					<?php if (!empty($allocs_by_inv[(int)$inv->id])): ?>
						<details class="cpttf-inv-allocs"><summary>🔗 <?php echo count($allocs_by_inv[(int)$inv->id]); ?> تخصیص</summary>
							<ul>
							<?php foreach ($allocs_by_inv[(int)$inv->id] as $al): ?>
								<li>
									<span class="cpttf-inv-alloc-no"><?php echo esc_html((string)($al->voucher_no ?: ('#' . (int)$al->ledger_id))); ?></span>
									<span><?php echo CPTT_Finance::fmt((float)$al->amount); ?></span>
									<?php if (!$compact): ?><button type="button" class="cpttf-inv-alloc-del" data-cpttf-inv-alloc-del="<?php echo (int)$al->id; ?>" title="حذف تخصیص (سند در دفتر می‌ماند)">×</button><?php endif; ?>
								</li>
							<?php endforeach; ?>
							</ul>
						</details>
					<?php endif; ?>
				</td>
				<td><?php echo esc_html($vocab[(string)$inv->kind] ?? $inv->kind); ?>
					<small style="display:block;color:#94a3b8;"><?php echo $dir === 'receipt' ? '📥 دریافتنی' : '📤 پرداختنی'; ?></small>
				</td>
				<?php if (!$compact): ?><td><?php echo esc_html($inv->person_name); ?></td><?php endif; ?>
				<td><?php echo $inv->project_title !== '' ? esc_html($inv->project_title) : '<span style="color:#94a3b8;">—</span>'; ?></td>
				<td><?php echo esc_html(cpttf_jdate_only((int)$inv->issue_ts)); ?></td>
				<td style="<?php echo $overdue ? 'color:#dc2626;font-weight:700;' : ''; ?>"><?php echo esc_html(cpttf_jdate_only((int)$inv->due_ts)); ?><?php echo $overdue ? ' ⚠' : ''; ?></td>
				<td><b><?php echo CPTT_Finance::fmt((float)$inv->amount); ?></b></td>
				<td class="cpttf-text-success"><?php echo (float)$inv->settled > 0 ? CPTT_Finance::fmt((float)$inv->settled) : '—'; ?></td>
				<td class="<?php echo $remain > 0.005 ? 'cpttf-text-danger' : 'cpttf-text-success'; ?>"><b><?php echo CPTT_Finance::fmt($remain); ?></b></td>
				<td><?php echo cpttf_invoice_status_chip((string)$inv->status); ?></td>
				<td class="cpttf-inv-actions">
					<?php if ($compact): ?>
						<?php if ($open): ?><a class="cpttf-btn cpttf-btn--sm cpttf-btn--success" href="<?php echo esc_url(add_query_arg(['settle' => (int)$inv->id], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">✅ تسویه</a><?php endif; ?>
						<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson' => (int)$inv->person_id], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">↗</a>
						<input type="checkbox" class="cpttf-inv-pick" data-id="<?php echo (int)$inv->id; ?>" title="انتخاب برای تسویه دسته‌جمعی / چاپ گروهی" style="margin-left:4px;vertical-align:middle;"><a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" target="_blank" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&invprint=' . (int)$inv->id)); ?>" title="چاپ فاکتور">🖨</a>
					<?php else: ?>
					<?php if ($open): ?>
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--success" data-cpttf-inv-settle="<?php echo (int)$inv->id; ?>">✅ تسویه</button>
					<?php endif; ?>
					<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" target="_blank" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&invprint=' . (int)$inv->id)); ?>" title="چاپ فاکتور">🖨</a>
					<?php if ((string)$inv->status !== 'cancelled'): ?>
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" data-cpttf-inv-edit="<?php echo (int)$inv->id; ?>"
							data-kind="<?php echo esc_attr((string)$inv->kind); ?>"
							data-person="<?php echo (int)$inv->person_id; ?>"
							data-project="<?php echo (int)$inv->project_id; ?>"
							data-amount="<?php echo esc_attr(number_format((float)$inv->amount, 0, '.', ',')); ?>"
							data-issue="<?php echo esc_attr(cpttf_jdate_only((int)$inv->issue_ts)); ?>"
							data-due="<?php echo (int)$inv->due_ts > 0 ? esc_attr(cpttf_jdate_only((int)$inv->due_ts)) : ''; ?>"
							data-note="<?php echo esc_attr((string)$inv->note); ?>"
							data-status="<?php echo esc_attr((string)$inv->status); ?>">✏️</button>
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--danger" data-cpttf-inv-cancel="<?php echo (int)$inv->id; ?>" data-no="<?php echo esc_attr($inv->invoice_no); ?>">🚫</button>
					<?php endif; ?>
					<?php endif; ?>
				</td>
			</tr>
			<?php
		}
		return ob_get_clean();
	}
}

/** حل نام شخص/پروژه برای فهرست فاکتورها */
if (!function_exists('cpttf_invoice_hydrate')) {
	function cpttf_invoice_hydrate($invoices){
		$uids = []; $pids = [];
		foreach ((array)$invoices as $inv) { $uids[(int)$inv->person_id] = true; if ((int)$inv->project_id > 0) $pids[(int)$inv->project_id] = true; }
		$names = [];
		foreach (array_keys($uids) as $uid) { $u = get_user_by('id', $uid); $names[$uid] = $u ? $u->display_name : ('#' . $uid); }
		$titles = [];
		foreach (array_keys($pids) as $pid) { $t = get_the_title($pid); $titles[$pid] = $t !== '' ? $t : ('#' . $pid); }
		foreach ((array)$invoices as $inv) {
			$inv->person_name = isset($names[(int)$inv->person_id]) ? $names[(int)$inv->person_id] : ('#' . (int)$inv->person_id);
			$inv->project_title = isset($titles[(int)$inv->project_id]) ? $titles[(int)$inv->project_id] : '';
		}
		return $invoices;
	}
}

/** واکشی تخصیص‌های گروهی فاکتورها با شماره‌ی سند */
if (!function_exists('cpttf_invoice_allocs_map')) {
	function cpttf_invoice_allocs_map($invoice_ids){
		global $wpdb;
		$invoice_ids = array_values(array_filter(array_map('intval', (array)$invoice_ids)));
		if (empty($invoice_ids)) return [];
		$in = implode(',', $invoice_ids);
		$t_al = CPTT_Finance::tbl_invoice_allocs(); $t_l = CPTT_Finance::tbl_ledger();
		$rows = $wpdb->get_results("SELECT a.*, l.voucher_no FROM $t_al a LEFT JOIN $t_l l ON l.id = a.ledger_id WHERE a.invoice_id IN ($in) ORDER BY a.id ASC");
		$out = [];
		foreach ((array)$rows as $r) $out[(int)$r->invoice_id][] = $r;
		return $out;
	}
}

/* ── بلوک فاکتورهای یک شخص (برای تب «فاکتورها» در پرونده) ── */
if (!function_exists('cpttf_person_invoices_block')) {
	function cpttf_person_invoices_block($pid){
		global $wpdb;
		$pid = (int)$pid;
		$t_inv = CPTT_Finance::tbl_invoices();
		$invoices = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t_inv WHERE person_id = %d ORDER BY issue_ts DESC, id DESC LIMIT 100", $pid)) ?: [];
		$base_inv = admin_url('admin.php?page=cptt-finance-invoices');
		$open_sum = 0.0; $open_n = 0;
		foreach ($invoices as $inv) {
			if (in_array((string)$inv->status, ['settled','cancelled','draft'], true)) continue;
			$open_sum += max(0.0, (float)$inv->amount - (float)$inv->settled); $open_n++;
		}
		?>
		<section class="cpttf-card">
			<header class="cpttf-card__head cpttf-card__head--actions">
				<div>
					<h2>🧾 فاکتورها</h2>
					<small style="color:#64748b;font-size:12px;"><?php echo $open_n > 0 ? ($open_n . ' فاکتور باز — مجموع مانده: ' . CPTT_Finance::fmt($open_sum)) : 'فاکتور بازی وجود ندارد'; ?></small>
				</div>
				<div class="cpttf-card__actions">
					<a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new' => 1, 'person' => $pid], $base_inv)); ?>">+ فاکتور جدید برای این شخص</a>
					<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson' => $pid], $base_inv)); ?>">همه در صفحه فاکتورها</a>
				</div>
			</header>
			<div class="cpttf-card__body">
				<?php if (empty($invoices)): ?>
					<p class="cpttf-empty">هنوز فاکتوری برای این شخص صادر نشده است.</p>
				<?php else: ?>
				<table class="cpttf-table">
					<thead><tr><th>شماره</th><th>نوع</th><th>پروژه</th><th>صدور</th><th>سررسید</th><th>مبلغ</th><th>تسویه‌شده</th><th>مانده</th><th>وضعیت</th><th style="width:90px">عملیات</th></tr></thead>
					<tbody><?php echo cpttf_invoice_rows_html(cpttf_invoice_hydrate($invoices), cpttf_invoice_allocs_map(wp_list_pluck($invoices, 'id')), ['compact' => true]); ?></tbody>
				</table>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}

/* ── صفحه‌ی اصلی فاکتورها ── */
function cpttf_render_invoices(){
	global $wpdb;
	$cur = CPTT_Finance::currency_label();
	$t_inv = CPTT_Finance::tbl_invoices();

	/* فیلترها */
	$f_kind   = isset($_GET['fkind'])   ? sanitize_key($_GET['fkind']) : '';
	$f_status = isset($_GET['fstatus']) ? sanitize_key($_GET['fstatus']) : '';
	$f_person = isset($_GET['fperson']) ? (int)$_GET['fperson'] : 0;
	$f_over   = !empty($_GET['foverdue']);
	$f_q      = isset($_GET['fq']) ? sanitize_text_field(wp_unslash($_GET['fq'])) : '';
	$kv = array_keys(CPTT_Finance::invoice_kind_vocab());
	if ($f_kind !== '' && !in_array($f_kind, $kv, true)) $f_kind = '';

	$where = "status != 'cancelled'"; $args = [];
	if ($f_status === 'open') $where .= " AND status IN ('issued','partial')";
	elseif (in_array($f_status, ['draft','issued','partial','settled','cancelled'], true)) { $where = "status = %s"; $args[] = $f_status; }
	if ($f_person > 0) { $where .= " AND person_id = %d"; $args[] = $f_person; }
	if ($f_kind !== '')  { $where .= " AND kind = %s"; $args[] = $f_kind; }
	if ($f_over)         { $where .= " AND status IN ('issued','partial') AND due_ts > 0 AND due_ts < " . (int)current_time('timestamp', true); }
	if ($f_q !== '')     { $where .= " AND (invoice_no LIKE %s OR note LIKE %s)"; $like = '%' . $wpdb->esc_like($f_q) . '%'; $args[] = $like; $args[] = $like; }

	// v9.9.5 — صفحه‌بندی فاکتورها (۵۰ ردیف در هر صفحه؛ شمارش کل با همان فیلتر)
	$per    = isset($_GET['fperpage']) ? (int)$_GET['fperpage'] : 10; // v9.9.6 — ۱۰/۲۵/۵۰/۱۰۰
	if (!in_array($per, [10, 25, 50, 100], true)) $per = 10;
	$fpaged = isset($_GET['fpaged']) ? max(1, (int)$_GET['fpaged']) : 1;
	$csql   = "SELECT COUNT(*) FROM $t_inv WHERE $where";
	$total  = (int)($args ? $wpdb->get_var($wpdb->prepare($csql, $args)) : $wpdb->get_var($csql));
	$pages  = max(1, (int)ceil(max($total, 1) / $per));
	$fpaged = min($fpaged, $pages);
	$off    = ($fpaged - 1) * $per;
	$sql = "SELECT * FROM $t_inv WHERE $where ORDER BY issue_ts DESC, id DESC LIMIT %d OFFSET %d";
	$invoices = $wpdb->get_results($wpdb->prepare($sql, array_merge($args, [$per, $off])));
	$invoices = cpttf_invoice_hydrate($invoices ?: []);
	$allocs = cpttf_invoice_allocs_map(wp_list_pluck($invoices, 'id'));

	/* KPI: روی همه‌ی فاکتورها (بدون فیلتر) */
	$k = $wpdb->get_row("SELECT
		COALESCE(SUM(CASE WHEN status IN ('issued','partial') THEN amount - settled ELSE 0 END),0) AS open_sum,
		COALESCE(SUM(CASE WHEN status IN ('issued','partial') AND due_ts > 0 AND due_ts < " . (int)current_time('timestamp', true) . " THEN amount - settled ELSE 0 END),0) AS over_sum,
		SUM(CASE WHEN status IN ('issued','partial') THEN 1 ELSE 0 END) AS open_n,
		SUM(CASE WHEN status IN ('issued','partial') AND due_ts > 0 AND due_ts < " . (int)current_time('timestamp', true) . " THEN 1 ELSE 0 END) AS over_n,
		COALESCE(SUM(CASE WHEN status = 'settled' THEN amount ELSE 0 END),0) AS settled_sum
		FROM $t_inv WHERE 1");
	$open_sum = (float)($k->open_sum ?? 0); $over_sum = (float)($k->over_sum ?? 0);
	$open_n = (int)($k->open_n ?? 0); $over_n = (int)($k->over_n ?? 0); $settled_sum = (float)($k->settled_sum ?? 0);

	/* گروه‌های تسویه: فاکتورهای بازِ «صادرشده/جزئی» به تفکیک شخص+جهت */
	$open_rows = $wpdb->get_results("SELECT * FROM $t_inv WHERE status IN ('issued','partial') ORDER BY due_ts ASC, id ASC LIMIT 400") ?: [];
	$open_rows = cpttf_invoice_hydrate($open_rows);
	$groups = [];
	foreach ($open_rows as $inv) {
		$d = CPTT_Finance::invoice_settle_dir((string)$inv->kind);
		$gkey = (int)$inv->person_id . '_' . $d;
		if (!isset($groups[$gkey])) $groups[$gkey] = ['person' => (int)$inv->person_id, 'name' => $inv->person_name, 'dir' => $d, 'items' => []];
		$groups[$gkey]['items'][] = $inv;
	}

	$accounts = CPTT_Finance::get_accounts(true);
	$q_new    = !empty($_GET['new']);
	$q_person = isset($_GET['person']) ? (int)$_GET['person'] : 0;
	$q_project= isset($_GET['project']) ? (int)$_GET['project'] : 0;
	$q_amount = isset($_GET['amount']) ? (float)CPTT_Finance::parse_amount($_GET['amount']) : 0;
	$q_settle = isset($_GET['settle']) ? (int)$_GET['settle'] : 0;
	?>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4">
		<div class="cpttf-kpi" style="--c:#f59e0b">
			<div class="cpttf-kpi__icon">🧾</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">مانده‌ی فاکتورهای باز</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($open_sum); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub"><?php echo (int)$open_n; ?> فاکتور باز</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#ef4444">
			<div class="cpttf-kpi__icon">⚠️</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">سررسید گذشته</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($over_sum); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub"><?php echo (int)$over_n; ?> فاکتور</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#16a34a">
			<div class="cpttf-kpi__icon">✅</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع فاکتورهای تسویه‌شده</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($settled_sum); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">از ابتدا تاکنون</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#0ea5e9">
			<div class="cpttf-kpi__icon">💡</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">چطور کار می‌کند؟</span>
				<small class="cpttf-kpi__sub" style="line-height:1.8;display:block;">فاکتور صادر کنید؛ بعد با «تسویه» یک سند دریافت/پرداخت واقعی ثبت می‌شود و مبلغش بین فاکتورها تقسیم می‌گردد — مانده‌ها از همان دفتر قبلی خوانده می‌شوند.</small></div>
		</div>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>🧾 فاکتورها</h2>
				<small style="color:#64748b;font-size:12px;">پیش‌فاکتور/فاکتور فروش و برگشتی = از شخص دریافت می‌کنیم · خرید و برگشت از خرید = به شخص پرداخت می‌کنیم</small>
			</div>
			<div class="cpttf-card__actions">
				<button class="cpttf-btn cpttf-btn--ghost" type="button" data-cpttf-inv-gen-open>⚡ صدور فاکتور از پروژه‌ها</button>
				<button class="cpttf-btn cpttf-btn--ghost" type="button" data-cpttf-inv-allocall title="پرداخت‌های موجود پروژه‌ها را به فاکتورهای باز نسبت می‌دهد">🔗 تخصیص خودکار اسناد</button>
				<button class="cpttf-btn cpttf-btn--primary" type="button" data-cpttf-inv-new>+ فاکتور جدید</button>
				<button class="cpttf-btn cpttf-btn--success" type="button" data-cpttf-inv-bulksettle title="تسویه‌ی یکجای فاکتورهای بازِ انتخاب‌شده (به‌تفکیک شخص، یک سند)">✅ تسویه انتخاب‌شده‌ها</button>
			</div>
		</header>
		<div class="cpttf-card__body">
			<form class="cpttf-filters" method="get" action="">
				<input type="hidden" name="page" value="cptt-finance-invoices">
				<label><span>جستجو</span><input type="search" name="fq" value="<?php echo esc_attr($f_q); ?>" placeholder="شماره فاکتور یا شرح…"></label>
				<label><span>نوع</span>
					<select name="fkind">
						<option value="">همه</option>
						<?php foreach (CPTT_Finance::invoice_kind_vocab() as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>" <?php selected($f_kind, $kk); ?>><?php echo esc_html($ll); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label><span>وضعیت</span>
					<select name="fstatus">
						<option value="">فعال‌ها (همه به‌جز باطل)</option>
						<option value="open" <?php selected($f_status, 'open'); ?>>فقط بازها</option>
						<?php foreach (CPTT_Finance::invoice_status_vocab() as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>" <?php selected($f_status, $kk); ?>><?php echo esc_html($ll); ?></option><?php endforeach; ?>
					</select>
				</label>
								<?php CPTT_Finance::render_person_combo($f_person); // v9.9.0 — کمبوی جستجوی اشخاص ?>
				<label class="cpttf-checkline"><input type="checkbox" name="foverdue" value="1" <?php checked($f_over); ?>> <span>فقط سررسید گذشته</span></label>
				<div class="cpttf-filters__actions">
					<button class="cpttf-btn cpttf-btn--primary" type="submit">فیلتر</button>
					<button type="button" class="cpttf-btn cpttf-btn--ghost" id="cpttf-inv-bulkprint" disabled title="ابتدا با تیکِ ستون اول جدول، فاکتورهای موردنظر را انتخاب کنید">🖨 چاپ انتخاب‌شده‌ها</button>
					<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices')); ?>">پاک‌سازی</a>
				</div>
			</form>
		<?php CPTT_Finance::person_combo_assets(); // v9.9.0 ?>

			<?php if (empty($invoices)): ?>
				<p class="cpttf-empty">فاکتوری مطابق فیلتر یافت نشد. با «+ فاکتور جدید» اولین فاکتور را صادر کنید.</p>
			<?php else: ?>
			<table class="cpttf-table">
				<thead><tr><th style="width:30px;text-align:center;"><input type="checkbox" id="cpttf-inv-checkall" title="انتخاب همه (تسویه دسته‌جمعی / چاپ گروهی)" aria-label="انتخاب همه"></th><th>شماره</th><th>نوع</th><th>شخص</th><th>پروژه</th><th>صدور</th><th>سررسید</th><th>مبلغ</th><th>تسویه‌شده</th><th>مانده</th><th>وضعیت</th><th style="width:150px">عملیات</th></tr></thead>
				<tbody><?php echo cpttf_invoice_rows_html($invoices, $allocs); ?></tbody>
			</table>
			<?php echo CPTT_Finance::pager_html('cptt-finance-invoices', $total, $per, $fpaged, ['fkind' => $f_kind, 'fstatus' => $f_status, 'fperson' => $f_person, 'foverdue' => $f_over ? 1 : '', 'fq' => $f_q]); // v9.9.5 ?>
			<?php endif; ?>
		</div>
	</section>

	<?php /* ── مدال ساخت/ویرایش فاکتور ── */ ?>
	<div class="cpttf-modal" id="cpttf-inv-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-inv-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3 id="cpttf-inv-modal-title">+ فاکتور جدید</h3>
				<button type="button" class="cpttf-modal__close" data-cpttf-inv-close>×</button>
			</header>
			<form id="cpttf-inv-form" class="cpttf-modal__body">
				<input type="hidden" name="id" id="cpttf-inv-id" value="0">
				<div class="cpttf-form-grid">
					<label><span>نوع فاکتور *</span>
						<select name="kind" id="cpttf-inv-kind">
							<?php foreach (CPTT_Finance::invoice_kind_vocab() as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>"><?php echo esc_html($ll); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label><span>وضعیت</span>
						<select name="status" id="cpttf-inv-status">
							<option value="issued">صادر شده</option>
							<option value="draft">پیش‌نویس</option>
						</select>
					</label>
					<label class="cpttf-full"><span>شخص (طرف حساب) *</span>
						<select name="person_id" id="cpttf-inv-person"><?php echo cpttf_invoice_person_options($q_person); ?></select>
					</label>
					<label class="cpttf-full"><span>پروژه (اختیاری)</span>
						<select name="project_id" id="cpttf-inv-project"><?php echo cpttf_invoice_project_options($q_project); ?></select>
					</label>
					<label><span>مبلغ (<?php echo esc_html($cur); ?>) *</span><input type="text" inputmode="numeric" name="amount" id="cpttf-inv-amount" class="cpttf-money" required></label>
					<label><span>تاریخ صدور</span><input type="text" name="issue_date" id="cpttf-inv-issue" class="cpttf-jdate" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
					<label><span>تاریخ سررسید</span><input type="text" name="due_date" id="cpttf-inv-due" class="cpttf-jdate" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
					<label class="cpttf-full"><span>شرح / اقلام</span><textarea name="note" id="cpttf-inv-note" rows="2" placeholder="مثلاً: بابت مرحله‌ی اول — طراحی رابط"></textarea></label>
				</div>
				<span class="cpttf-inv-msg" id="cpttf-inv-msg" style="display:block;margin-top:8px;font-size:12px;"></span>
			</form>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-inv-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--primary" data-cpttf-inv-save>💾 صدور / ذخیره فاکتور</button>
			</footer>
		</div>
	</div>

	<?php /* ── مدال تسویه‌ی تخصیصی ── */ ?>
	<div class="cpttf-modal" id="cpttf-inv-settle-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-inv-close></div>
		<div class="cpttf-modal__dialog cpttf-modal__dialog--wide">
			<header class="cpttf-modal__head">
				<h3>✅ تسویه‌ی فاکتور (تخصیص به یک یا چند فاکتور)</h3>
				<button type="button" class="cpttf-modal__close" data-cpttf-inv-close>×</button>
			</header>
			<form id="cpttf-inv-settle-form" class="cpttf-modal__body">
				<div class="cpttf-form-grid" style="margin-bottom:10px;">
					<label><span>تاریخ سند</span><input type="text" name="date_local" class="cpttf-jdate" placeholder="همین حالا" autocomplete="off"></label>
					<label><span>حساب</span>
						<select name="account_id">
							<?php foreach ($accounts as $a): ?><option value="<?php echo (int)$a->id; ?>"><?php echo esc_html($a->icon . ' ' . $a->name); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label class="cpttf-full"><span>شرح سند (اختیاری)</span><input type="text" name="description" placeholder="مثلاً: واریز به کارت …"></label>
				</div>
				<p style="font-size:12px;color:#64748b;margin:0 0 8px;">برای هر فاکتور مبلغ تخصیص را بنویسید؛ جمع اعداد = مبلغ سند دریافت/پرداختی که ثبت می‌شود.</p>
				<?php if (empty($groups)): ?>
					<p class="cpttf-empty">فاکتور بازی برای تسویه وجود ندارد.</p>
				<?php else: foreach ($groups as $gkey => $g): ?>
					<fieldset class="cpttf-inv-settlegrp" data-gkey="<?php echo esc_attr($gkey); ?>" hidden>
						<legend><?php echo esc_html($g['name']); ?> — <?php echo $g['dir'] === 'receipt' ? '📥 دریافت از ایشان' : '📤 پرداخت به ایشان'; ?></legend>
						<?php foreach ($g['items'] as $inv): $remain = max(0.0, (float)$inv->amount - (float)$inv->settled); ?>
							<div class="cpttf-inv-settleline" data-iid="<?php echo (int)$inv->id; ?>" data-remain="<?php echo (float)$remain; ?>">
								<label class="cpttf-checkline" style="min-width:230px;">
									<input type="checkbox" class="cpttf-inv-settlechk">
									<span><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($inv->invoice_no); ?></b>
									<small style="color:#64748b;"> · مانده: <?php echo CPTT_Finance::fmt($remain); ?><?php echo $inv->project_title !== '' ? ' · ' . esc_html($inv->project_title) : ''; ?><?php echo (int)$inv->due_ts > 0 ? ' · سررسید ' . esc_html(cpttf_jdate_only((int)$inv->due_ts)) : ''; ?></small></span>
								</label>
								<input type="text" inputmode="numeric" class="cpttf-money cpttf-inv-settleamt" placeholder="۰" disabled>
							</div>
						<?php endforeach; ?>
					</fieldset>
				<?php endforeach; endif; ?>
				<div class="cpttf-inv-settletotal">جمع تخصیص: <b id="cpttf-inv-settletotal">۰</b> <?php echo esc_html($cur); ?></div>
				<span class="cpttf-inv-msg" id="cpttf-inv-settle-msg" style="display:block;margin-top:8px;font-size:12px;"></span>
			</form>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-inv-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--success" data-cpttf-inv-settle-save>✅ ثبت سند تسویه و تخصیص</button>
			</footer>
		</div>
	</div>

	<?php
	/* v9.4.0 — فهرست پروژه‌های واجد شرایط صدور خودکار فاکتور (بازخورد کاربر: «برای پروژه‌های ساخته‌شده باید فاکتور باشد») */
	global $wpdb;
	$gen_projects = [];
	$_gen_posts = get_posts(['post_type' => 'cptt_project', 'post_status' => 'any', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC']);
	foreach ((array)$_gen_posts as $_gp) {
		$_gc = (int)get_post_meta($_gp->ID, '_cptt_client_user_id', true);
		if ($_gc <= 0) continue;
		$_gcost = 0.0;
		$_gsteps = get_post_meta($_gp->ID, '_cptt_steps', true);
		if (is_array($_gsteps)) {
			foreach ($_gsteps as $_gst) {
				$_gcost += (float)($_gst['cost'] ?? 0);
				if (!empty($_gst['extra_finance']) && is_array($_gst['extra_finance'])) {
					foreach ($_gst['extra_finance'] as $_gef) $_gcost += (float)($_gef['cost'] ?? 0);
				}
			}
		}
		if ($_gcost <= 0) continue;
		$_gpaid = 0.0;
		if (is_array($_gsteps)) {
			foreach ($_gsteps as $_gst) {
				$_gpaid += (float)($_gst['paid'] ?? 0);
				if (!empty($_gst['extra_finance']) && is_array($_gst['extra_finance'])) {
					foreach ($_gst['extra_finance'] as $_gef) $_gpaid += (float)($_gef['paid'] ?? 0);
				}
			}
		}
		$_gremain = max(0.0, $_gcost - $_gpaid);
		$_gpay_status = $_gpaid <= 0.005 ? 'unpaid' : ($_gremain > 0.005 ? 'partial' : 'settled');
		$_ginv = $wpdb->get_row($wpdb->prepare(
			"SELECT id,status,settled,amount FROM " . CPTT_Finance::tbl_invoices() . " WHERE project_id=%d AND person_id=%d AND status != 'cancelled' ORDER BY id DESC LIMIT 1",
			(int)$_gp->ID, $_gc
		));
		$_ghas = $_ginv ? 1 : 0;
		$_ginv_status = $_ginv ? (string)$_ginv->status : 'none';
		$_gu = get_user_by('id', $_gc);
		$gen_projects[] = [
			'id' => (int)$_gp->ID, 'title' => (string)get_the_title($_gp->ID),
			'client' => $_gu ? (string)$_gu->display_name : ('#' . $_gc),
			'cost' => $_gcost, 'paid' => $_gpaid, 'remain' => $_gremain, 'pay_status' => $_gpay_status, 'invoice_status' => $_ginv_status, 'has' => $_ghas > 0,
		];
	}
	?>
	<div class="cpttf-modal" id="cpttf-invgen-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-invgen-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3>⚡ صدور فاکتور از پروژه‌ها</h3>
				<button type="button" class="cpttf-modal__close" data-cpttf-invgen-close>×</button>
			</header>
			<div class="cpttf-modal__body">
				<p style="font-size:12px;color:#64748b;line-height:1.9;margin-top:0;">برای هر پروژه‌ی انتخاب‌شده یک «فاکتور فروش» به‌نام مشتری پروژه، به مبلغ جمع هزینه‌ی مراحل، با سررسید ۷ روز بعد صادر می‌شود. اگر پروژه از قبل فاکتور فعال داشته باشد، همان فاکتور به‌روزرسانی می‌شود؛ در غیر این صورت فاکتور جدید صادر می‌شود.</p>
				<?php if (empty($gen_projects)): ?>
					<p class="cpttf-empty">پروژه‌ی واجد شرایطی (دارای مشتری و هزینه‌ی مراحل) یافت نشد.</p>
				<?php else: ?>
					<div class="cpttf-invgen-filters" style="display:grid;grid-template-columns:1.4fr repeat(2,minmax(130px,.8fr));gap:8px;margin-bottom:10px;">
						<input type="search" id="cpttf-invgen-search" placeholder="جستجو پروژه/مشتری..." style="padding:9px;border:1px solid #cbd5e1;border-radius:10px;">
						<select id="cpttf-invgen-pay-filter" style="padding:9px;border:1px solid #cbd5e1;border-radius:10px;"><option value="">وضعیت تسویه پروژه: همه</option><option value="open">تسویه‌نشده + جزئی</option><option value="unpaid">فقط تسویه‌نشده</option><option value="partial">فقط تسویه جزئی</option><option value="settled">تسویه‌شده</option></select>
						<select id="cpttf-invgen-inv-filter" style="padding:9px;border:1px solid #cbd5e1;border-radius:10px;"><option value="">وضعیت فاکتور: همه</option><option value="none">بدون فاکتور</option><option value="issued">فاکتور تسویه‌نشده</option><option value="partial">فاکتور تسویه جزئی</option><option value="open_invoice">فاکتور باز: تسویه‌نشده + جزئی</option></select>
					</div>
					<div style="display:flex;gap:10px;align-items:center;margin-bottom:6px;">
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" data-cpttf-invgen-all>انتخاب همه‌ی همین فیلتر</button>
						<small style="color:#64748b;"><span id="cpttf-invgen-visible-count"><?php echo (int)count($gen_projects); ?></span> پروژه نمایش‌داده‌شده — <?php echo (int)count(array_filter($gen_projects, function($g){ return !$g['has']; })); ?> پروژه بدون فاکتور</small>
					</div>
					<div class="cpttf-table-wrap" style="max-height:320px;overflow:auto;">
						<table class="cpttf-table">
							<thead><tr><th style="width:34px;"></th><th>پروژه</th><th>مشتری</th><th class="cpttf-num">مبلغ فاکتور</th><th class="cpttf-num">پرداخت/مانده</th><th>وضعیت</th></tr></thead>
							<tbody>
							<?php foreach ($gen_projects as $g): ?>
								<tr class="cpttf-invgen-row" data-search="<?php echo esc_attr(mb_strtolower($g['title'] . ' ' . $g['client'])); ?>" data-pay="<?php echo esc_attr($g['pay_status']); ?>" data-inv="<?php echo esc_attr($g['invoice_status']); ?>"<?php echo $g['has'] ? ' style="opacity:.55;"' : ''; ?>>
									<td><input type="checkbox" data-cpttf-invgen-pick value="<?php echo (int)$g['id']; ?>" <?php echo $g['has'] ? 'title="به‌روزرسانی فاکتور موجود"' : ''; ?>></td>
									<td><b><?php echo esc_html($g['title']); ?></b></td>
									<td><?php echo esc_html($g['client']); ?></td>
									<td class="cpttf-num"><b><?php echo CPTT_Finance::fmt($g['cost']); ?></b></td>
									<td class="cpttf-num"><small>پرداخت: <?php echo CPTT_Finance::fmt($g['paid']); ?><br>مانده: <?php echo CPTT_Finance::fmt($g['remain']); ?></small></td>
									<td><?php echo $g['has'] ? '<small style="color:#64748b;">دارای فاکتور: ' . esc_html(CPTT_Finance::invoice_status_vocab()[$g['invoice_status']] ?? $g['invoice_status']) . ' ✅</small>' : '<small style="color:#059669;font-weight:700;">قابل صدور</small>'; ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
			</div>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--primary" data-cpttf-invgen-submit <?php echo empty($gen_projects) ? 'disabled' : ''; ?>>صدور فاکتور برای انتخاب‌شده‌ها</button>
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-invgen-close>انصراف</button>
			</footer>
		</div>
	</div>
	<script>
	(function(){
		if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
		function boot(){
			if (window.__cpttfInvGenBound) return; window.__cpttfInvGenBound = true;
			var q = function(s){ return document.querySelector(s); };
			var qa = function(s){ return Array.prototype.slice.call(document.querySelectorAll(s)); };
			function openM(){ var m = q('#cpttf-invgen-modal'); if (m) { m.hidden = false; setTimeout(invgenApplyFilters,20); } }
			function closeM(){ var m = q('#cpttf-invgen-modal'); if (m) m.hidden = true; }
				function invgenApplyFilters(){
					var qv=(q('#cpttf-invgen-search')&&q('#cpttf-invgen-search').value||'').toLowerCase().trim();
					var pay=(q('#cpttf-invgen-pay-filter')&&q('#cpttf-invgen-pay-filter').value||'');
					var inv=(q('#cpttf-invgen-inv-filter')&&q('#cpttf-invgen-inv-filter').value||'');
					var n=0;
					qa('.cpttf-invgen-row').forEach(function(r){
						var ok=true, rp=r.getAttribute('data-pay')||'', ri=r.getAttribute('data-inv')||'';
						if(qv && (r.getAttribute('data-search')||'').indexOf(qv)===-1) ok=false;
						if(pay==='open' && !(rp==='unpaid'||rp==='partial')) ok=false; else if(pay && pay!=='open' && rp!==pay) ok=false;
						if(inv==='open_invoice' && !(ri==='issued'||ri==='partial')) ok=false; else if(inv && inv!=='open_invoice' && ri!==inv) ok=false;
						r.style.display=ok?'':'none'; if(ok)n++;
					});
					var c=q('#cpttf-invgen-visible-count'); if(c)c.textContent=String(n);
				}
				['#cpttf-invgen-search','#cpttf-invgen-pay-filter','#cpttf-invgen-inv-filter'].forEach(function(sel){ var el=q(sel); if(el){ el.addEventListener('input',invgenApplyFilters); el.addEventListener('change',invgenApplyFilters); } });
			/* v9.9.4 — چاپ گروهی: فعال‌سازی دکمه بر اساس تعداد تیک‌ها */
			function cpttfInvBulkprintRefresh(){
				var bp = q('#cpttf-inv-bulkprint'); if (!bp) return;
				var n = qa('input.cpttf-inv-pick:checked').length;
				bp.disabled = n === 0;
				bp.textContent = n > 0 ? ('🖨 چاپ ' + n + ' فاکتور انتخاب‌شده') : '🖨 چاپ انتخاب‌شده‌ها';
			}
			document.addEventListener('change', function(e){
				var t = e.target; if (t && t.classList && t.classList.contains('cpttf-inv-pick')) cpttfInvBulkprintRefresh();
			});
			cpttfInvBulkprintRefresh();
			document.addEventListener('click', function(e){
				var t = e.target; if (!t || !t.closest) return;
				if (t.closest('[data-cpttf-inv-gen-open]')) { e.preventDefault(); openM(); return; }
				if (t.closest('[data-cpttf-invgen-close]')) { e.preventDefault(); closeM(); return; }
				if (t.closest('[data-cpttf-invgen-all]')) {
					e.preventDefault();
					qa('.cpttf-invgen-row').forEach(function(row){ if(row.style.display==='none') return; var cb=row.querySelector('input[data-cpttf-invgen-pick]'); if(cb) cb.checked = true; });
					return;
				}
				var allocBtn = t.closest('[data-cpttf-inv-allocall]'); /* v9.5.0 — تخصیص خودکار اسناد موجود */
				if (allocBtn && !allocBtn.disabled) {
					e.preventDefault();
					allocBtn.disabled = true;
					var fda = new FormData();
					fda.append('action', 'cptt_fin_invoice_auto_alloc_all');
					fda.append('nonce', (window.CPTT_FIN && window.CPTT_FIN.nonce) ? window.CPTT_FIN.nonce : '');
					fetch((window.CPTT_FIN && window.CPTT_FIN.ajax) ? window.CPTT_FIN.ajax : (window.ajaxurl || 'admin-ajax.php'), { method: 'POST', credentials: 'same-origin', body: fda })
						.then(function(r){ return r.json(); })
						.then(function(j){
							allocBtn.disabled = false;
							var m = (j && j.data && j.data.msg) ? j.data.msg : 'انجام شد';
							if (window.cpttfToast) window.cpttfToast(m, 'success'); else alert(m);
							if (j && j.success && j.data && j.data.done > 0 && window.cpttfReload) { window.cpttfReload(); }
						})
						.catch(function(){ allocBtn.disabled = false; alert('خطای ارتباط'); });
					return;
				}
				var bulk = t.closest('[data-cpttf-inv-bulksettle]'); /* v9.6.0 — تسویه‌ی یکجا */
				if (bulk && !bulk.disabled) {
					e.preventDefault();
					var picks = [];
					document.querySelectorAll('input.cpttf-inv-pick:checked').forEach(function(cb){ picks.push(cb.getAttribute('data-id')); });
					if (!picks.length) { alert('ابتدا حداقل یک فاکتور باز را تیک بزنید'); return; }
					if (!confirm(picks.length + ' فاکتور انتخاب شد. برای هر شخص یک سند تسویه ثبت می‌شود. ادامه می‌دهید؟')) return;
					bulk.disabled = true;
					var fdb = new FormData();
					fdb.append('action', 'cptt_fin_invoice_bulk_settle');
					fdb.append('nonce', (window.CPTT_FIN && window.CPTT_FIN.nonce) ? window.CPTT_FIN.nonce : '');
					picks.forEach(function(id){ fdb.append('invoice_ids[]', id); });
					fetch((window.CPTT_FIN && window.CPTT_FIN.ajax) ? window.CPTT_FIN.ajax : (window.ajaxurl || 'admin-ajax.php'), { method: 'POST', credentials: 'same-origin', body: fdb })
						.then(function(r){ return r.json(); })
						.then(function(j){
							bulk.disabled = false;
							var m = (j && j.data && j.data.msg) ? j.data.msg : 'انجام شد';
							if (window.cpttfToast) window.cpttfToast(m, j && j.success ? 'success' : 'error'); else if (!(j && j.success)) alert(m);
							if (j && j.success) { if (window.cpttfReload) window.cpttfReload(); else location.reload(); }
						})
						.catch(function(){ bulk.disabled = false; alert('خطای ارتباط'); });
					return;
				}
				if (t.closest('#cpttf-inv-checkall')) {
					var ma = document.getElementById('cpttf-inv-checkall');
					document.querySelectorAll('input.cpttf-inv-pick').forEach(function(cb){ cb.checked = ma.checked; });
					return;
				}
				if (t.closest('#cpttf-inv-bulkprint')) { /* v9.9.4 — چاپ گروهی فاکتورها */
					e.preventDefault();
					var pp = [];
					document.querySelectorAll('input.cpttf-inv-pick:checked').forEach(function(cb){ pp.push(cb.getAttribute('data-id')); });
					if (!pp.length) { alert('ابتدا با تیکِ ستون اول جدول، فاکتورها را انتخاب کنید'); return; }
					if (pp.length > 40 && !confirm(pp.length + ' فاکتور انتخاب شده‌اند؛ چاپ هم‌زمان همه ممکن است کمی طول بکشد. ادامه می‌دهید؟')) return;
					window.open('<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices')); ?>' + '&invbulkprint=1&ids=' + pp.join(','), '_blank');
					return;
				}
				var sub = t.closest('[data-cpttf-invgen-submit]');
				if (sub && !sub.disabled) {
					e.preventDefault();
					var ids = qa('input[data-cpttf-invgen-pick]:checked').map(function(cb){ return cb.value; });
					if (!ids.length) { alert('حداقل یک پروژه را انتخاب کنید'); return; }
					sub.disabled = true;
					var fd = new FormData();
					fd.append('action', 'cptt_fin_invoice_gen_projects');
					fd.append('nonce', (window.CPTT_FIN && window.CPTT_FIN.nonce) ? window.CPTT_FIN.nonce : '');
					ids.forEach(function(id){ fd.append('project_ids[]', id); });
					fetch((window.CPTT_FIN && window.CPTT_FIN.ajax) ? window.CPTT_FIN.ajax : (window.ajaxurl || 'admin-ajax.php'), { method: 'POST', credentials: 'same-origin', body: fd })
						.then(function(r){ return r.json(); })
						.then(function(j){
							sub.disabled = false;
							if (j && j.success) {
								if (window.cpttfToast) window.cpttfToast((j.data && j.data.msg) ? j.data.msg : 'انجام شد', 'success');
								if (window.cpttfReload) { window.cpttfReload(); return; }
								location.reload();
							} else {
								var msg = 'خطا در صدور فاکتور';
								if (j && j.data) msg = (typeof j.data === 'string') ? j.data : (j.data.msg || msg);
								alert(msg);
							}
						})
						.catch(function(){ sub.disabled = false; alert('خطای ارتباط'); });
				}
			});
		}
	})();
	</script>
	<script>
	(function(){
		function ready(fn){ if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }
		ready(function(){
			if (window.__cpttfInvBound) return; window.__cpttfInvBound = true;
			var CFG = window.CPTT_FIN || { ajax:'', nonce:'' };
			function post(action, data, cb){
				var fd = new FormData();
				fd.append('action', action); fd.append('nonce', CFG.nonce);
				for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) fd.append(k, data[k]);
				var x = new XMLHttpRequest(); x.open('POST', CFG.ajax);
				x.onload = function(){ var r = null; try{ r = JSON.parse(x.responseText); }catch(e){} cb(r); };
				x.onerror = function(){ cb(null); };
				x.send(fd);
			}
			function reload(){ if (window.cpttfReload) window.cpttfReload(); else window.location.reload(); }
			function msg(el, t, ok){ var n = document.getElementById(el); if(!n) return; n.textContent = t; n.style.color = ok ? '#16a34a' : '#dc2626'; }
			function openModal(id){ var m = document.getElementById(id); if (m) m.hidden = false; }
			function closeModal(m){ if (m) m.hidden = true; }
			function money(v){ return String(v||'').replace(/[^\d]/g,''); }

			/* باز/بسته کردن مدال‌ها */
			document.addEventListener('click', function(e){
				var c = e.target.closest('[data-cpttf-inv-close]');
				if (c){ e.preventDefault(); var m = c.closest('.cpttf-modal'); closeModal(m); return; }
				if (e.target.closest('[data-cpttf-inv-new]')){ e.preventDefault(); window.CPTTFInvOpenNew(); return; }
				var ed = e.target.closest('[data-cpttf-inv-edit]');
				if (ed){ e.preventDefault(); window.CPTTFInvOpenEdit(ed); return; }
				var st = e.target.closest('[data-cpttf-inv-settle]');
				if (st){ e.preventDefault(); window.CPTTFInvOpenSettle(parseInt(st.getAttribute('data-cpttf-inv-settle'),10) || 0); return; }
				var cn = e.target.closest('[data-cpttf-inv-cancel]');
				if (cn){
					e.preventDefault();
					if (!window.confirm('فاکتور ' + (cn.getAttribute('data-no')||'') + ' باطل شود؟ (فقط فاکتور بدون تخصیص قابل ابطال است)')) return;
					post('cptt_fin_invoice_cancel', { id: cn.getAttribute('data-cpttf-inv-cancel') }, function(r){
						if (r && r.success){ reload(); } else window.alert((r && r.data) ? r.data : 'خطا در ابطال');
					});
					return;
				}
				var ad = e.target.closest('[data-cpttf-inv-alloc-del]');
				if (ad){
					e.preventDefault();
					if (!window.confirm('این تخصیص حذف شود؟ سند مالی در دفتر می‌ماند و فقط پیوندش با فاکتور قطع می‌شود.')) return;
					post('cptt_fin_invoice_alloc_delete', { id: ad.getAttribute('data-cpttf-inv-alloc-del') }, function(r){
						if (r && r.success){ reload(); } else window.alert((r && r.data) ? r.data : 'خطا در حذف تخصیص');
					});
					return;
				}
				if (e.target.closest('[data-cpttf-inv-save]')){
					e.preventDefault();
					var f = document.getElementById('cpttf-inv-form'); if(!f) return;
					var d = {
						id: f.querySelector('[name=id]').value,
						kind: f.querySelector('[name=kind]').value,
						status: f.querySelector('[name=status]').value,
						person_id: f.querySelector('[name=person_id]').value,
						project_id: f.querySelector('[name=project_id]').value,
						amount: money(f.querySelector('[name=amount]').value),
						issue_date: f.querySelector('[name=issue_date]').value,
						due_date: f.querySelector('[name=due_date]').value,
						note: f.querySelector('[name=note]').value
					};
					if (!d.person_id || d.person_id === '0'){ msg('cpttf-inv-msg','لطفاً شخص را انتخاب کنید.', false); return; }
					if (!d.amount || d.amount === '0'){ msg('cpttf-inv-msg','مبلغ فاکتور را بنویسید.', false); return; }
					msg('cpttf-inv-msg','در حال ذخیره…', true);
					post('cptt_fin_invoice_save', d, function(r){
						if (r && r.success){ reload(); } else msg('cpttf-inv-msg', (r && r.data) ? r.data : 'خطا در ذخیره فاکتور', false);
					});
					return;
				}
				if (e.target.closest('[data-cpttf-inv-settle-save]')){
					e.preventDefault();
					var sf = document.getElementById('cpttf-inv-settle-form'); if(!sf) return;
					var grp = sf.querySelector('.cpttf-inv-settlegrp:not([hidden])');
					if (!grp){ msg('cpttf-inv-settle-msg','گروه تسویه انتخاب نشده است.', false); return; }
					var parts = [];
					grp.querySelectorAll('.cpttf-inv-settleline').forEach(function(ln){
						var chk = ln.querySelector('.cpttf-inv-settlechk');
						var amt = money(ln.querySelector('.cpttf-inv-settleamt').value);
						if (chk && chk.checked && amt && amt !== '0') parts.push('alloc[' + ln.getAttribute('data-iid') + ']=' + amt);
					});
					if (!parts.length){ msg('cpttf-inv-settle-msg','هیچ مبلغی برای تخصیص وارد نشده است.', false); return; }
					msg('cpttf-inv-settle-msg','در حال ثبت سند تسویه…', true);
					var fd = new FormData();
					fd.append('action','cptt_fin_invoice_settle'); fd.append('nonce', CFG.nonce);
					fd.append('date_local', sf.querySelector('[name=date_local]').value || '');
					fd.append('account_id', sf.querySelector('[name=account_id]').value || '0');
					fd.append('description', sf.querySelector('[name=description]').value || '');
					parts.forEach(function(p){ var kv = p.split('='); fd.append(kv[0], kv[1]); });
					var x = new XMLHttpRequest(); x.open('POST', CFG.ajax);
					x.onload = function(){ var r = null; try{ r = JSON.parse(x.responseText); }catch(e){}
						if (r && r.success){ reload(); } else msg('cpttf-inv-settle-msg', (r && r.data) ? r.data : 'خطا در ثبت تسویه', false);
					};
					x.onerror = function(){ msg('cpttf-inv-settle-msg','خطای ارتباط', false); };
					x.send(fd);
					return;
				}
				/* چک‌باکس ردیف تسویه: فعال‌سازی اینپوت + پرکردن با مانده */
				var chk = e.target.closest('.cpttf-inv-settlechk');
				if (chk){
					var ln = chk.closest('.cpttf-inv-settleline');
					var inp = ln ? ln.querySelector('.cpttf-inv-settleamt') : null;
					if (inp){
						inp.disabled = !chk.checked;
						if (chk.checked && !inp.value) inp.value = Number(ln.getAttribute('data-remain')||0).toLocaleString('en-US');
						if (!chk.checked) inp.value = '';
						window.CPTTFInvRecalc();
					}
				}
			});
			document.addEventListener('input', function(e){
				if (e.target.classList && e.target.classList.contains('cpttf-inv-settleamt')) window.CPTTFInvRecalc();
			});

			window.CPTTFInvRecalc = function(){
				var sf = document.getElementById('cpttf-inv-settle-form'); if(!sf) return;
				var t = 0;
				sf.querySelectorAll('.cpttf-inv-settlegrp:not([hidden]) .cpttf-inv-settleline').forEach(function(ln){
					var chk = ln.querySelector('.cpttf-inv-settlechk');
					if (chk && chk.checked) t += parseFloat(money(ln.querySelector('.cpttf-inv-settleamt').value) || '0') || 0;
				});
				var n = document.getElementById('cpttf-inv-settletotal');
				if (n) n.textContent = t.toLocaleString('en-US');
			};

			window.CPTTFInvOpenNew = function(pre){
				pre = pre || {};
				var f = document.getElementById('cpttf-inv-form'); if(!f) return;
				f.reset();
				f.querySelector('[name=id]').value = '0';
				document.getElementById('cpttf-inv-modal-title').textContent = '+ فاکتور جدید';
				if (pre.person)  f.querySelector('[name=person_id]').value = String(pre.person);
				if (pre.project) f.querySelector('[name=project_id]').value = String(pre.project);
				if (pre.amount)  f.querySelector('[name=amount]').value = Number(pre.amount).toLocaleString('en-US');
				msg('cpttf-inv-msg','', true);
				openModal('cpttf-inv-modal');
			};

			window.CPTTFInvOpenEdit = function(btn){
				var f = document.getElementById('cpttf-inv-form'); if(!f) return;
				f.reset();
				f.querySelector('[name=id]').value = btn.getAttribute('data-cpttf-inv-edit') || '0';
				f.querySelector('[name=kind]').value = btn.getAttribute('data-kind') || 'sale';
				f.querySelector('[name=status]').value = (btn.getAttribute('data-status') === 'draft') ? 'draft' : 'issued';
				f.querySelector('[name=person_id]').value = btn.getAttribute('data-person') || '0';
				f.querySelector('[name=project_id]').value = btn.getAttribute('data-project') || '0';
				f.querySelector('[name=amount]').value = btn.getAttribute('data-amount') || '';
				f.querySelector('[name=issue_date]').value = btn.getAttribute('data-issue') || '';
				f.querySelector('[name=due_date]').value = btn.getAttribute('data-due') || '';
				f.querySelector('[name=note]').value = btn.getAttribute('data-note') || '';
				document.getElementById('cpttf-inv-modal-title').textContent = '✏️ ویرایش فاکتور';
				msg('cpttf-inv-msg','', true);
				openModal('cpttf-inv-modal');
			};

			window.CPTTFInvOpenSettle = function(invoiceId){
				var sf = document.getElementById('cpttf-inv-settle-form'); if(!sf) return;
				/* گروه مربوط به فاکتور را پیدا و نمایش بده */
				var targetGrp = null, targetLine = null;
				sf.querySelectorAll('.cpttf-inv-settleline').forEach(function(ln){
					if (parseInt(ln.getAttribute('data-iid'),10) === invoiceId){
						targetLine = ln; targetGrp = ln.closest('.cpttf-inv-settlegrp');
					}
				});
				sf.querySelectorAll('.cpttf-inv-settlegrp').forEach(function(g){
					g.hidden = !(targetGrp && g === targetGrp);
				});
				sf.querySelectorAll('.cpttf-inv-settleamt').forEach(function(i){ i.value=''; i.disabled = true; });
				sf.querySelectorAll('.cpttf-inv-settlechk').forEach(function(c){ c.checked = false; });
				if (targetLine){
					var chk = targetLine.querySelector('.cpttf-inv-settlechk');
					var inp = targetLine.querySelector('.cpttf-inv-settleamt');
					if (chk) chk.checked = true;
					if (inp){ inp.disabled = false; inp.value = Number(targetLine.getAttribute('data-remain')||0).toLocaleString('en-US'); }
				}
				window.CPTTFInvRecalc();
				msg('cpttf-inv-settle-msg','', true);
				openModal('cpttf-inv-settle-modal');
			};

			/* باز کردن خودکار از روی کوئری (new=1 / settle=ID) */
			<?php if ($q_new): ?>
			window.CPTTFInvOpenNew({ person: <?php echo (int)$q_person; ?>, project: <?php echo (int)$q_project; ?>, amount: <?php echo (float)$q_amount; ?> });
			<?php endif; ?>
			<?php if ($q_settle > 0): ?>
			window.CPTTFInvOpenSettle(<?php echo (int)$q_settle; ?>);
			<?php endif; ?>
		});
	})();
	</script>
	<?php
}

/* ════════ چاپ اختصاصی فاکتور — v9.6.0 ════════
 * تمپلیت هم‌خوان با «فاکتور داشبورد کارشناس» + برندینگ/تاگل‌های invoice_show_*
 * پارامتر show_history=0 → نسخه‌ی بدون تاریخچه‌ی اسناد تسویه
 */
function cpttf_invoice_print($invoice_id){
	global $wpdb;
	require_once CPTT_PATH . 'includes/finance/print-brand.php';
	$brand = cpttf_brand();
	$id  = (int)$invoice_id;
	$inv = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CPTT_Finance::tbl_invoices() . " WHERE id=%d", $id));
	if (!$inv) wp_die('invoice_not_found');
	$paper = (isset($_GET['paper']) && sanitize_key($_GET['paper']) === 'a5') ? 'a5' : 'a4';
	$show_history = !isset($_GET['show_history']) || (string)$_GET['show_history'] !== '0'; // v9.6.0
	$tog = ['invoice_show_logo'=>'1','invoice_show_client'=>'1','invoice_show_dates'=>'1','invoice_show_sign_stamp'=>'1','invoice_show_step_breakdown'=>'1'];
	if (class_exists('CPTT_Settings')) { $_t = CPTT_Settings::get_branding_toggles(); if (is_array($_t)) $tog = array_merge($tog, $_t); }
	$cur = CPTT_Finance::currency_label();
	$kv  = CPTT_Finance::invoice_kind_vocab();
	$sv  = CPTT_Finance::invoice_status_vocab();
	$u = get_user_by('id', (int)$inv->person_id);
	$pname  = $u ? (string)$u->display_name : ('#' . (int)$inv->person_id);
	$pphone = $u ? (string)get_user_meta($u->ID, 'billing_phone', true) : '';
	if ($pphone === '' && $u) $pphone = (string)get_user_meta($u->ID, 'cptt_phone', true);
	$pemail = ($u && !empty($u->user_email)) ? (string)$u->user_email : '';
	$proj   = (int)$inv->project_id > 0 ? get_the_title((int)$inv->project_id) : '';
	$amount = (float)$inv->amount; $settled = (float)$inv->settled; $remain = max(0.0, $amount - $settled);
	$t_al = CPTT_Finance::tbl_invoice_allocs(); $t_lg = CPTT_Finance::tbl_ledger();
	$allocs = $wpdb->get_results($wpdb->prepare(
		"SELECT a.amount, a.created_at, l.voucher_no, l.date_fa FROM $t_al a LEFT JOIN $t_lg l ON l.id = a.ledger_id WHERE a.invoice_id = %d ORDER BY a.id ASC", $id
	)) ?: [];
	$cancel = ((string)$inv->status === 'cancelled');
	$kind_l = isset($kv[(string)$inv->kind]) ? $kv[(string)$inv->kind] : 'فاکتور';
	$color  = $brand['primary_color'];
	// جزئیات مراحل پروژه (مثل فاکتور داشبورد)
	$steps_rows = [];
	if ((int)$inv->project_id > 0) {
		$_st = get_post_meta((int)$inv->project_id, '_cptt_steps', true);
		if (is_array($_st)) {
			$_si = 1;
			foreach ($_st as $_ss) {
				$_t = trim((string)($_ss['title'] ?? ''));
				$steps_rows[] = ['title' => $_t !== '' ? $_t : ('مرحله ' . $_si), 'cost' => (float)($_ss['cost'] ?? 0), 'paid' => (float)($_ss['paid'] ?? 0)];
				if (!empty($_ss['extra_finance']) && is_array($_ss['extra_finance'])) {
					foreach ($_ss['extra_finance'] as $_ef) $steps_rows[] = ['title' => '↳ ' . (string)($_ef['title'] ?? ($_ef['label'] ?? ('اقلام مالی مرحله ' . $_si))), 'cost' => (float)($_ef['cost'] ?? 0), 'paid' => (float)($_ef['paid'] ?? 0)];
				}
				$_si++;
			}
		}
	}
	$meta = 'شماره: <b style="font-family:ui-monospace,monospace;">' . esc_html((string)$inv->invoice_no) . '</b>'
		. ($tog['invoice_show_dates'] === '1' ? ('<br>صدور: ' . esc_html(cpttf_jdate_only((int)$inv->issue_ts)) . ' · سررسید: ' . esc_html((int)$inv->due_ts > 0 ? cpttf_jdate_only((int)$inv->due_ts) : '—')) : '');
	?><!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo esc_html($kind_l . ' ' . $inv->invoice_no); ?></title>
<style><?php echo cpttf_print_core_css($paper); ?><?php echo cpttf_brand_block_css(); ?>
.piv-title{display:flex;justify-content:space-between;align-items:center;background:<?php echo esc_attr($color); ?>;color:#fff;border-radius:12px;padding:10px 16px;margin-top:12px;}
.piv-title b{font-size:17px;}
.piv-title .no{font-family:ui-monospace,monospace;font-weight:700;background:rgba(255,255,255,.18);padding:2px 12px;border-radius:8px;}
.piv-party{display:flex;gap:12px;margin-top:12px;}
.piv-party>div{flex:1;border:1px solid #cbd5e1;border-radius:10px;padding:8px 12px;line-height:2;}
.piv-party h3{margin:0 0 4px;font-size:11px;color:#64748b;font-weight:700;}
.piv-status{display:inline-block;padding:1px 10px;border-radius:999px;background:rgba(255,255,255,.2);font-size:.8em;font-weight:700;}
.piv-tot{display:flex;gap:8px;margin-top:12px;}
.piv-tot>div{flex:1;border:1.5px solid <?php echo esc_attr($color); ?>;border-radius:10px;padding:6px 10px;text-align:center;}
.piv-tot small{display:block;color:#64748b;font-size:.82em;}
.piv-tot b{font-size:1.2em;color:<?php echo esc_attr($color); ?>;}
.piv-cancel{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:1;}
.piv-cancel span{font-size:64px;font-weight:700;color:rgba(220,38,38,.13);transform:rotate(-18deg);border:6px solid rgba(220,38,38,.13);border-radius:18px;padding:8px 30px;}
</style></head>
<body class="<?php echo esc_attr($paper); ?>">
<?php if ($cancel): ?><div class="piv-cancel"><span>باطل</span></div><?php endif; ?>
<div class="no-print">
	<form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
		<input type="hidden" name="page" value="cptt-finance-invoices">
		<input type="hidden" name="invprint" value="<?php echo (int)$id; ?>">
		<label>کاغذ
			<select name="paper" onchange="this.form.submit()">
				<option value="a4" <?php selected($paper, 'a4'); ?>>A4</option>
				<option value="a5" <?php selected($paper, 'a5'); ?>>A5</option>
			</select>
		</label>
		<label>نمایش
			<select name="show_history" onchange="this.form.submit()">
				<option value="1" <?php selected($show_history, true); ?>>با تاریخچه‌ی اسناد</option>
				<option value="0" <?php selected($show_history, false); ?>>بدون تاریخچه‌ی اسناد</option>
			</select>
		</label>
		<noscript><button type="submit" class="ghost">اعمال</button></noscript>
		<button type="button" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
		<button type="button" class="ghost" onclick="window.close()">بستن</button>
	</form>
</div>

<?php echo $tog['invoice_show_logo'] === '1' ? cpttf_brand_head_html($brand, $kind_l, $meta) : cpttf_brand_head_html($brand, $kind_l, $meta); ?>

<div class="piv-title">
	<b><?php echo esc_html($kind_l); ?> <span class="piv-status"><?php echo esc_html(isset($sv[(string)$inv->status]) ? $sv[(string)$inv->status] : (string)$inv->status); ?></span></b>
	<span class="no"><?php echo esc_html((string)$inv->invoice_no); ?></span>
</div>

<?php if ($tog['invoice_show_client'] === '1'): ?>
<div class="piv-party">
	<div>
		<h3>طرف حساب (خریدار)</h3>
		<b><?php echo esc_html($pname); ?></b>
		<?php if ($pphone !== ''): ?> · <span dir="ltr"><?php echo esc_html($pphone); ?></span><?php endif; ?>
		<?php if ($pemail !== ''): ?> · <span dir="ltr" style="font-size:.85em;"><?php echo esc_html($pemail); ?></span><?php endif; ?>
		<?php if ($proj !== ''): ?><br>پروژه: <b><?php echo esc_html($proj); ?></b><?php endif; ?>
	</div>
	<div>
		<h3>صادرکننده (فروشنده)</h3>
		<b><?php echo esc_html($brand['brand_name']); ?></b>
		<?php if (trim($brand['manager_name'] . $brand['manager_title']) !== ''): ?><br><?php echo esc_html(trim($brand['manager_name'] . ' — ' . $brand['manager_title'], ' —')); ?><?php endif; ?>
	</div>
</div>
<?php endif; ?>

<?php if ($tog['invoice_show_step_breakdown'] === '1' && !empty($steps_rows)): ?>
<h2>جزئیات مراحل پروژه</h2>
<table>
	<thead><tr><th style="width:30px;">#</th><th>مرحله / بخش</th><th class="num">مبلغ</th><th class="num">پرداختی</th><th class="num">مانده</th></tr></thead>
	<tbody>
	<?php $_tc = 0; $_tp = 0; $_i = 1; foreach ($steps_rows as $_sr): $_tc += $_sr['cost']; $_tp += $_sr['paid']; ?>
		<tr>
			<td><?php echo $_i++; ?></td>
			<td><?php echo esc_html($_sr['title']); ?></td>
			<td class="num"><b><?php echo CPTT_Finance::fmt($_sr['cost']); ?></b></td>
			<td class="num"><?php echo $_sr['paid'] > 0 ? CPTT_Finance::fmt($_sr['paid']) : '—'; ?></td>
			<td class="num"><b style="color:<?php echo ($_sr['cost'] - $_sr['paid']) > 0.005 ? '#dc2626' : '#059669'; ?>;"><?php echo CPTT_Finance::fmt(max(0, $_sr['cost'] - $_sr['paid'])); ?></b></td>
		</tr>
	<?php endforeach; ?>
	<tr class="tot"><td colspan="2">جمع</td><td class="num"><b><?php echo CPTT_Finance::fmt($_tc); ?></b></td><td class="num"><b><?php echo CPTT_Finance::fmt($_tp); ?></b></td><td class="num"><b><?php echo CPTT_Finance::fmt(max(0, $_tc - $_tp)); ?></b></td></tr>
	</tbody>
</table>
<?php endif; ?>

<div class="piv-tot">
	<div><small>مبلغ <?php echo esc_html($kind_l); ?></small><b><?php echo CPTT_Finance::fmt($amount); ?></b> <small><?php echo esc_html($cur); ?></small></div>
	<div><small>تسویه‌شده</small><b style="color:#059669;"><?php echo CPTT_Finance::fmt($settled); ?></b> <small><?php echo esc_html($cur); ?></small></div>
	<div><small>مانده</small><b style="color:<?php echo $remain > 0.005 ? '#dc2626' : '#059669'; ?>;"><?php echo CPTT_Finance::fmt($remain); ?></b> <small><?php echo esc_html($cur); ?></small></div>
</div>

<?php if (trim((string)$inv->note) !== ''): ?>
<p style="margin:10px 0 0;font-size:.92em;color:#475569;"><b>شرح:</b> <?php echo nl2br(esc_html((string)$inv->note)); ?></p>
<?php endif; ?>

<?php if ($show_history && !empty($allocs)): ?>
<h2>تاریخچه‌ی تسویه (اسناد)</h2>
<table>
	<thead><tr><th>شماره سند</th><th>تاریخ</th><th class="num">مبلغ تخصیص</th></tr></thead>
	<tbody>
	<?php foreach ($allocs as $a): ?>
		<tr>
			<td style="font-family:ui-monospace,monospace;"><b><?php echo esc_html((string)($a->voucher_no ?? '—')); ?></b></td>
			<td><?php echo esc_html((string)($a->date_fa ?? '')); ?></td>
			<td class="num"><b><?php echo CPTT_Finance::fmt((float)$a->amount); ?></b></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<?php endif; ?>

<?php
	echo cpttf_brand_bank_html($brand);
	if ($tog['invoice_show_sign_stamp'] === '1') { echo cpttf_brand_signfoot_html($brand); }
	else if ($brand['footer_text'] !== '') { echo '<div class="pb-footer">' . esc_html($brand['footer_text']) . '</div>'; }
?>
</body></html><?php
}

/**
 * v9.9.4 — چاپ گروهی فاکتورها: چند فاکتور انتخاب‌شده پشت سر هم در یک سند چاپی.
 * هر فاکتور با همان قالب چاپ تکی (cpttf_invoice_print) رندر می‌شود؛ استایلِ سند
 * اول به‌عنوان استایل مشترک استخراج و بدنه‌ی هر سند داخل <section class="cptt-bulk-doc">
 * قرار می‌گیرد تا هر فاکتور از صفحه‌ی جدید چاپ شود. کاملاً افزایشی است (فقط خواندنی).
 */
function cpttf_invoices_bulk_print($ids){
	global $wpdb;
	require_once CPTT_PATH . 'includes/finance/print-brand.php';
	$ids = array_values(array_filter(array_map('intval', (array)$ids)));
	if (!$ids) wp_die('no_invoices_selected');
	// فقط فاکتورهای موجود — یک آی‌دی خراب نباید کل چاپ را متوقف کند
	$t  = CPTT_Finance::tbl_invoices();
	$in = implode(',', $ids);
	$found = $wpdb->get_col("SELECT id FROM $t WHERE id IN ($in)") ?: [];
	$order = array_flip($ids);
	usort($found, function($a, $b) use ($order){ return ($order[(int)$a] ?? 9999) <=> ($order[(int)$b] ?? 9999); });
	if (!$found) wp_die('no_invoices_found');
	$style = ''; $docs = [];
	foreach ($found as $fid) {
		ob_start();
		cpttf_invoice_print((int)$fid);
		$html = (string)ob_get_clean();
		if ($style === '' && preg_match('/<style[^>]*>(.*?)<\/style>/is', $html, $m1)) $style = $m1[1];
		$body = '';
		if (preg_match('/<body[^>]*>(.*?)<\/body>/is', $html, $m2)) $body = $m2[1];
		if (trim($body) !== '') $docs[] = $body;
	}
	if (!$docs) wp_die('bulk_render_failed');
	$paper = (isset($_GET['paper']) && sanitize_key($_GET['paper']) === 'a5') ? 'a5' : 'a4';
	$show_history = !isset($_GET['show_history']) || (string)$_GET['show_history'] !== '0';
	$ids_csv = implode(',', array_map('intval', $found));
	?><!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo sprintf('چاپ گروهی %d فاکتور', count($docs)); ?></title>
<style><?php echo $style; /* استایل مشترک استخراج‌شده از قالب چاپ تکی */ ?>
/* v9.9.4 — اصلاحات چاپ گروهی */
.cptt-bulk-doc{position:relative;page-break-after:always;break-after:page;padding-bottom:8mm;}
.cptt-bulk-doc .no-print{display:none!important;}
.cptt-bulk-doc .piv-cancel{position:absolute!important;}
@media print{
	.cptt-bulk-doc{page-break-after:always;break-after:page;padding-bottom:0;}
	.cptt-bulk-doc:last-of-type{page-break-after:auto;break-after:auto;}
	.cptt-bulk-doc .piv-cancel{position:absolute!important;}
}
</style></head>
<body class="<?php echo esc_attr($paper); ?>">
<div class="no-print">
	<form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
		<input type="hidden" name="page" value="cptt-finance-invoices">
		<input type="hidden" name="invbulkprint" value="1">
		<input type="hidden" name="ids" value="<?php echo esc_attr($ids_csv); ?>">
		<label>کاغذ
			<select name="paper" onchange="this.form.submit()">
				<option value="a4" <?php selected($paper, 'a4'); ?>>A4</option>
				<option value="a5" <?php selected($paper, 'a5'); ?>>A5</option>
			</select>
		</label>
		<label>نمایش
			<select name="show_history" onchange="this.form.submit()">
				<option value="1" <?php selected($show_history, true); ?>>با تاریخچه‌ی اسناد</option>
				<option value="0" <?php selected($show_history, false); ?>>بدون تاریخچه‌ی اسناد</option>
			</select>
		</label>
		<noscript><button type="submit" class="ghost">اعمال</button></noscript>
		<button type="button" onclick="window.print()">🖨 چاپ همه (<?php echo count($docs); ?> فاکتور) / ذخیره PDF</button>
		<button type="button" class="ghost" onclick="window.close()">بستن</button>
	</form>
</div>
<?php foreach ($docs as $ix => $body_html): ?>
<section class="cptt-bulk-doc" data-ix="<?php echo (int)$ix; ?>"><?php echo $body_html; ?></section>
<?php endforeach; ?>
</body></html><?php
}
