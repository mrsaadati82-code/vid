import { sections, totalQuestions, totalRequired } from "../data/formData";
import type { Answers } from "../types/answers";
import { isEmptyAnswer } from "../types/answers";
import { cn } from "../utils/cn";

interface Props {
  answers: Answers;
  activeSection: string;
  onJump: (id: string) => void;
}

export default function StickyProgress({ answers, activeSection, onJump }: Props) {
  const answeredCount = sections
    .flatMap((s) => s.questions)
    .filter((q) => !isEmptyAnswer(answers[q.id])).length;

  const requiredAnswered = sections
    .flatMap((s) => s.questions)
    .filter((q) => q.required && !isEmptyAnswer(answers[q.id])).length;

  const percent = Math.round((answeredCount / totalQuestions) * 100);

  return (
    <div className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur-md">
      <div className="mx-auto max-w-5xl px-4 py-2.5 sm:px-8">
        <div className="mb-2 flex items-center justify-between text-[11px] font-medium text-slate-500 sm:text-xs">
          <span>
            {answeredCount} از {totalQuestions} پرسش پاسخ داده شده
          </span>
          <span className="text-amber-600">
            {requiredAnswered} از {totalRequired} ضروری تکمیل شد
          </span>
        </div>
        <div className="mb-2.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-gradient-to-l from-amber-400 to-amber-500 transition-all duration-500"
            style={{ width: `${percent}%` }}
          />
        </div>
        <div className="scrollbar-none flex gap-1.5 overflow-x-auto pb-1">
          {sections.map((s) => {
            const sectionAnswered = s.questions.filter(
              (q) => !isEmptyAnswer(answers[q.id]),
            ).length;
            const complete = sectionAnswered === s.questions.length;
            const partial = sectionAnswered > 0 && !complete;
            return (
              <button
                key={s.id}
                onClick={() => onJump(s.id)}
                type="button"
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition sm:text-xs",
                  activeSection === s.id
                    ? "border-slate-800 bg-slate-800 text-white"
                    : complete
                      ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                      : partial
                        ? "border-amber-200 bg-amber-50 text-amber-700"
                        : "border-slate-200 bg-white text-slate-500 hover:border-slate-300",
                )}
              >
                <span
                  className={cn(
                    "flex h-4 w-4 items-center justify-center rounded-full text-[9px]",
                    activeSection === s.id
                      ? "bg-amber-500 text-slate-900"
                      : complete
                        ? "bg-emerald-500 text-white"
                        : "bg-slate-200 text-slate-600",
                  )}
                >
                  {complete ? "✓" : s.number}
                </span>
                <span className="hidden md:inline">{s.title}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
