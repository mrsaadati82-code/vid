import type { Question } from "../data/formData";
import type { AnswerValue } from "../types/answers";
import { isEmptyAnswer } from "../types/answers";
import QuestionField from "./QuestionField";
import { cn } from "../utils/cn";

interface Props {
  question: Question;
  sectionNumber: number;
  value: AnswerValue | undefined;
  onChange: (value: AnswerValue) => void;
  attemptedSubmit: boolean;
}

export default function QuestionItem({
  question,
  sectionNumber,
  value,
  onChange,
  attemptedSubmit,
}: Props) {
  const showError = Boolean(
    attemptedSubmit && question.required && isEmptyAnswer(value),
  );

  return (
    <div
      id={question.id}
      className={cn(
        "scroll-mt-28 rounded-2xl border border-slate-100 bg-white/60 p-4 transition sm:p-5",
        showError && "border-rose-200 bg-rose-50/40",
      )}
    >
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-start gap-2.5">
          <span className="mt-0.5 flex h-6 min-w-6 items-center justify-center rounded-md bg-slate-800 px-1.5 text-[11px] font-bold text-white">
            {sectionNumber}.{question.number}
          </span>
          <p className="text-[15px] font-medium leading-7 text-slate-800 sm:text-base">
            {question.text}
          </p>
        </div>
        {question.required && (
          <span className="shrink-0 rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-bold text-amber-700">
            ضروری
          </span>
        )}
      </div>

      {question.note && (
        <p className="mb-3 mr-8 rounded-lg bg-slate-50 px-3 py-2 text-xs leading-6 text-slate-500 sm:text-[13px]">
          {question.note}
        </p>
      )}

      <div className="mr-0 sm:mr-8">
        <QuestionField
          question={question}
          value={value}
          onChange={onChange}
          showError={showError}
        />
        {showError && (
          <p className="mt-2 text-xs font-medium text-rose-500">
            پاسخ به این پرسش برای شروع فاز اول ضروری است.
          </p>
        )}
      </div>
    </div>
  );
}
