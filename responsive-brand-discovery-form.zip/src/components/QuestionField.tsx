import { useRef, useState } from "react";
import type { Question } from "../data/formData";
import type { AnswerValue } from "../types/answers";
import { cn } from "../utils/cn";

interface Props {
  question: Question;
  value: AnswerValue | undefined;
  onChange: (value: AnswerValue) => void;
  showError: boolean;
}

const inputBase =
  "w-full rounded-xl border bg-white px-4 py-3 text-[15px] text-slate-800 placeholder:text-slate-400 shadow-sm outline-none transition focus:ring-4 focus:ring-amber-400/20 focus:border-amber-500";

export default function QuestionField({ question, value, onChange, showError }: Props) {
  const errorClass = showError ? "border-rose-400 ring-4 ring-rose-100" : "border-slate-200";
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileNames, setFileNames] = useState<string[]>(
    Array.isArray(value) ? value : [],
  );

  switch (question.type) {
    case "short": {
      const v = typeof value === "string" ? value : "";
      return (
        <input
          type="text"
          dir="rtl"
          className={cn(inputBase, errorClass)}
          placeholder={question.placeholder ?? "پاسخ کوتاه شما..."}
          value={v}
          onChange={(e) => onChange(e.target.value)}
        />
      );
    }

    case "number": {
      const v = typeof value === "string" ? value : "";
      return (
        <input
          type="text"
          inputMode="numeric"
          dir="rtl"
          className={cn(inputBase, errorClass, "sm:max-w-[220px]")}
          placeholder={question.placeholder ?? "عدد را وارد کنید"}
          value={v}
          onChange={(e) => onChange(e.target.value)}
        />
      );
    }

    case "long": {
      const v = typeof value === "string" ? value : "";
      return (
        <textarea
          dir="rtl"
          rows={4}
          className={cn(inputBase, errorClass, "resize-y leading-7")}
          placeholder={question.placeholder ?? "پاسخ تشریحی خود را بنویسید..."}
          value={v}
          onChange={(e) => onChange(e.target.value)}
        />
      );
    }

    case "single": {
      const v = typeof value === "string" ? value : "";
      return (
        <div
          className={cn(
            "grid gap-2.5 rounded-xl p-1",
            showError && "ring-2 ring-rose-200 rounded-xl",
          )}
        >
          {question.options?.map((opt) => {
            const checked = v === opt;
            return (
              <label
                key={opt}
                className={cn(
                  "flex cursor-pointer items-start gap-3 rounded-xl border px-4 py-3 text-[15px] transition",
                  checked
                    ? "border-amber-500 bg-amber-50/70 text-slate-900"
                    : "border-slate-200 bg-white text-slate-700 hover:border-amber-300 hover:bg-amber-50/30",
                )}
              >
                <span
                  className={cn(
                    "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition",
                    checked ? "border-amber-500" : "border-slate-300",
                  )}
                >
                  {checked && <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />}
                </span>
                <input
                  type="radio"
                  className="sr-only"
                  name={question.id}
                  checked={checked}
                  onChange={() => onChange(opt)}
                />
                <span>{opt}</span>
              </label>
            );
          })}
        </div>
      );
    }

    case "multi": {
      const v = Array.isArray(value) ? value : [];
      const toggle = (opt: string) => {
        if (v.includes(opt)) {
          onChange(v.filter((o) => o !== opt));
        } else {
          onChange([...v, opt]);
        }
      };
      return (
        <div
          className={cn(
            "grid gap-2.5 sm:grid-cols-2 rounded-xl p-1",
            showError && "ring-2 ring-rose-200",
          )}
        >
          {question.options?.map((opt) => {
            const checked = v.includes(opt);
            return (
              <label
                key={opt}
                className={cn(
                  "flex cursor-pointer items-start gap-3 rounded-xl border px-4 py-3 text-[15px] transition",
                  checked
                    ? "border-amber-500 bg-amber-50/70 text-slate-900"
                    : "border-slate-200 bg-white text-slate-700 hover:border-amber-300 hover:bg-amber-50/30",
                )}
              >
                <span
                  className={cn(
                    "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition",
                    checked ? "border-amber-500 bg-amber-500" : "border-slate-300 bg-white",
                  )}
                >
                  {checked && (
                    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-white" fill="none" stroke="currentColor" strokeWidth={3}>
                      <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </span>
                <input
                  type="checkbox"
                  className="sr-only"
                  checked={checked}
                  onChange={() => toggle(opt)}
                />
                <span>{opt}</span>
              </label>
            );
          })}
        </div>
      );
    }

    case "scale": {
      const v = typeof value === "string" ? value : "";
      const nums = [1, 2, 3, 4, 5, 6, 7];
      return (
        <div className={cn("rounded-xl p-1", showError && "ring-2 ring-rose-200")}>
          <div className="flex flex-wrap items-center justify-between gap-2 sm:flex-nowrap sm:gap-3">
            {nums.map((n) => {
              const checked = v === String(n);
              return (
                <button
                  type="button"
                  key={n}
                  onClick={() => onChange(String(n))}
                  className={cn(
                    "flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 text-base font-semibold transition sm:h-14 sm:w-14",
                    checked
                      ? "border-amber-500 bg-amber-500 text-white shadow-md shadow-amber-200"
                      : "border-slate-200 bg-white text-slate-500 hover:border-amber-300",
                  )}
                >
                  {n}
                </button>
              );
            })}
          </div>
          {question.scaleLabels && (
            <div className="mt-3 flex items-center justify-between text-xs text-slate-500 sm:text-sm">
              <span className="max-w-[45%] text-right">{question.scaleLabels[0]}</span>
              <span className="max-w-[45%] text-left">{question.scaleLabels[1]}</span>
            </div>
          )}
        </div>
      );
    }

    case "file": {
      return (
        <div className={cn("rounded-xl", showError && "ring-2 ring-rose-200 rounded-xl p-1")}>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50/60 px-4 py-8 text-slate-500 transition hover:border-amber-400 hover:bg-amber-50/40"
          >
            <svg viewBox="0 0 24 24" className="h-8 w-8 text-slate-400" fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M12 16V4m0 0L7 9m5-5l5 5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="text-sm">برای انتخاب فایل کلیک کنید یا فایل را بکشید و رها کنید</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = e.target.files ? Array.from(e.target.files).map((f) => f.name) : [];
              const merged = Array.from(new Set([...fileNames, ...files]));
              setFileNames(merged);
              onChange(merged);
            }}
          />
          {fileNames.length > 0 && (
            <ul className="mt-3 flex flex-wrap gap-2">
              {fileNames.map((name) => (
                <li
                  key={name}
                  className="flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-1.5 text-xs text-slate-600"
                >
                  <span>📎 {name}</span>
                  <button
                    type="button"
                    className="text-slate-400 hover:text-rose-500"
                    onClick={() => {
                      const next = fileNames.filter((n) => n !== name);
                      setFileNames(next);
                      onChange(next);
                    }}
                  >
                    ×
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      );
    }

    default:
      return null;
  }
}
