import type { Section } from "../data/formData";
import type { Answers } from "../types/answers";
import QuestionItem from "./QuestionItem";

interface Props {
  section: Section;
  answers: Answers;
  onChange: (id: string, value: Answers[string]) => void;
  attemptedSubmit: boolean;
}

export default function SectionCard({ section, answers, onChange, attemptedSubmit }: Props) {
  const requiredCount = section.questions.filter((q) => q.required).length;

  return (
    <section
      id={section.id}
      className="scroll-mt-24 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm"
    >
      <header className="relative overflow-hidden bg-gradient-to-l from-slate-900 via-slate-800 to-slate-900 px-5 py-6 text-white sm:px-8 sm:py-7">
        <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="relative flex flex-col gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500 text-sm font-extrabold text-slate-900 shadow shadow-amber-900/30">
              {section.number}
            </span>
            <h2 className="text-lg font-bold sm:text-xl">{section.title}</h2>
            <span className="rounded-full bg-white/10 px-3 py-1 text-[11px] font-medium text-slate-200">
              {section.questions.length} پرسش
              {requiredCount > 0 ? ` · ${requiredCount} ضروری` : ""}
            </span>
          </div>
          <p className="max-w-3xl text-sm leading-7 text-slate-300">{section.description}</p>
          <p className="w-fit rounded-lg bg-amber-500/10 px-3 py-1.5 text-xs font-medium text-amber-300">
            {section.reference}
          </p>
        </div>
      </header>

      <div className="flex flex-col gap-4 p-4 sm:p-6">
        {section.questions.map((q) => (
          <QuestionItem
            key={q.id}
            question={q}
            sectionNumber={section.number}
            value={answers[q.id]}
            onChange={(value) => onChange(q.id, value)}
            attemptedSubmit={attemptedSubmit}
          />
        ))}
      </div>
    </section>
  );
}
