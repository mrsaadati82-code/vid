import { projectMeta, totalQuestions, totalRequired } from "../data/formData";

interface Props {
  answeredCount: number;
  onEdit: () => void;
  onReset: () => void;
  onDownload: () => void;
}

export default function SuccessScreen({ answeredCount, onEdit, onReset, onDownload }: Props) {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center px-5 py-16 text-center">
      <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100">
        <svg viewBox="0 0 24 24" className="h-10 w-10 text-emerald-600" fill="none" stroke="currentColor" strokeWidth={2.5}>
          <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <h2 className="text-2xl font-extrabold text-slate-900 sm:text-3xl">
        پرسش‌نامه با موفقیت تکمیل شد
      </h2>
      <p className="mt-3 max-w-lg leading-8 text-slate-500">
        سپاس از وقتی که برای شناخت عمیق کمپانی تاج گذاشتید. پاسخ‌های شما مبنای تدوین سند
        استراتژی برند، جایگاه‌سازی و طراحی وب‌سایت کمپانی تاج قرار خواهد گرفت.
      </p>

      <div className="mt-8 grid w-full grid-cols-2 gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <p className="text-2xl font-extrabold text-slate-900">{answeredCount}</p>
          <p className="mt-1 text-xs text-slate-500">پرسش پاسخ داده‌شده</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <p className="text-2xl font-extrabold text-slate-900">{totalQuestions}</p>
          <p className="mt-1 text-xs text-slate-500">مجموع پرسش‌ها</p>
        </div>
        <div className="col-span-2 rounded-2xl border border-amber-200 bg-amber-50 p-4 sm:col-span-1">
          <p className="text-2xl font-extrabold text-amber-700">{totalRequired}</p>
          <p className="mt-1 text-xs text-amber-700">پرسش ضروری پوشش داده شد</p>
        </div>
      </div>

      <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={onDownload}
          type="button"
          className="rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800"
        >
          دانلود پاسخ‌ها (JSON)
        </button>
        <button
          onClick={onEdit}
          type="button"
          className="rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-400"
        >
          بازگشت و ویرایش پاسخ‌ها
        </button>
        <button
          onClick={onReset}
          type="button"
          className="rounded-xl px-5 py-3 text-sm font-semibold text-rose-500 transition hover:bg-rose-50"
        >
          شروع دوباره فرم
        </button>
      </div>

      <p className="mt-10 text-xs text-slate-400">{projectMeta.title}</p>
    </div>
  );
}
