import { projectMeta } from "../data/formData";

const metaItems = [
  { label: "کارفرما", value: projectMeta.employer, icon: "👤" },
  { label: "مجریان", value: projectMeta.executors, icon: "🛠️" },
  { label: "مدت پروژه", value: projectMeta.duration, icon: "⏳" },
  { label: "مبنای تدوین", value: projectMeta.basis, icon: "📄" },
];

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-900 text-white">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 right-1/4 h-96 w-96 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-amber-400/10 blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)",
            backgroundSize: "42px 42px",
          }}
        />
      </div>

      <div className="relative mx-auto max-w-5xl px-5 pb-10 pt-14 sm:px-8 sm:pb-14 sm:pt-20">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-2xl font-black text-slate-900 shadow-lg shadow-amber-900/30">
            ت
          </div>
          <div>
            <p className="text-sm font-semibold text-amber-400">کمپانی تاج</p>
            <p className="text-xs text-slate-400">راهکارهای امنیتی هوشمند</p>
          </div>
        </div>

        <h1 className="text-2xl font-extrabold leading-relaxed sm:text-4xl">
          {projectMeta.title}
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-8 text-slate-300 sm:text-base">
          {projectMeta.subtitle}
        </p>
        <p className="mt-4 max-w-3xl rounded-xl border border-amber-500/20 bg-amber-500/5 px-4 py-3 text-xs leading-7 text-amber-200 sm:text-sm">
          {projectMeta.intro}
        </p>

        <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {metaItems.map((item) => (
            <div
              key={item.label}
              className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 backdrop-blur-sm"
            >
              <div className="mb-1 flex items-center gap-2 text-xs text-slate-400">
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </div>
              <p className="text-sm font-semibold leading-6 text-white">{item.value}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 flex flex-wrap gap-3 text-xs text-slate-300 sm:text-sm">
          <span className="rounded-full bg-white/10 px-4 py-2">
            {projectMeta.sectionsCount} بخش
          </span>
          <span className="rounded-full bg-white/10 px-4 py-2">
            {projectMeta.questionsCount} پرسش
          </span>
          <span className="rounded-full bg-amber-500/20 px-4 py-2 text-amber-300">
            {projectMeta.requiredCount} پرسش ضروری برای فاز اول
          </span>
        </div>
      </div>
    </div>
  );
}
