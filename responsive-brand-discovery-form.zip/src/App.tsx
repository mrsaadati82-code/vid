import { useEffect, useMemo, useRef, useState } from "react";
import Hero from "./components/Hero";
import StickyProgress from "./components/StickyProgress";
import SectionCard from "./components/SectionCard";
import SuccessScreen from "./components/SuccessScreen";
import { projectMeta, sections, totalQuestions } from "./data/formData";
import type { Answers } from "./types/answers";
import { isEmptyAnswer } from "./types/answers";

const STORAGE_KEY = "taj-questionnaire-v1";

interface StoredState {
  answers: Answers;
  respondent: { name: string; role: string; date: string };
}

function loadInitial(): StoredState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as StoredState;
  } catch {
    /* ignore corrupt storage */
  }
  return { answers: {}, respondent: { name: "", role: "", date: "" } };
}

export default function App() {
  const initial = useMemo(loadInitial, []);
  const [answers, setAnswers] = useState<Answers>(initial.answers);
  const [respondent, setRespondent] = useState(initial.respondent);
  const [attemptedSubmit, setAttemptedSubmit] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [activeSection, setActiveSection] = useState(sections[0].id);
  const [saveHint, setSaveHint] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ answers, respondent }));
    setSaveHint(true);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => setSaveHint(false), 1500);
  }, [answers, respondent]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: "-30% 0px -60% 0px", threshold: 0 },
    );
    sections.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const handleChange = (id: string, value: Answers[string]) => {
    setAnswers((prev) => ({ ...prev, [id]: value }));
  };

  const handleJump = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const y = el.getBoundingClientRect().top + window.scrollY - 96;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  const missingRequired = useMemo(() => {
    return sections
      .flatMap((s) => s.questions)
      .filter((q) => q.required && isEmptyAnswer(answers[q.id]));
  }, [answers]);

  const answeredCount = useMemo(
    () =>
      sections
        .flatMap((s) => s.questions)
        .filter((q) => !isEmptyAnswer(answers[q.id])).length,
    [answers],
  );

  const handleSubmit = () => {
    setAttemptedSubmit(true);
    if (missingRequired.length > 0) {
      const first = missingRequired[0];
      requestAnimationFrame(() => {
        const el = document.getElementById(first.id);
        if (el) {
          const y = el.getBoundingClientRect().top + window.scrollY - 110;
          window.scrollTo({ top: y, behavior: "smooth" });
        }
      });
      return;
    }
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleReset = () => {
    if (!confirm("آیا مطمئن هستید؟ همه پاسخ‌های ثبت‌شده پاک خواهد شد.")) return;
    setAnswers({});
    setRespondent({ name: "", role: "", date: "" });
    setAttemptedSubmit(false);
    setSubmitted(false);
    localStorage.removeItem(STORAGE_KEY);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDownload = () => {
    const payload = {
      project: projectMeta.title,
      respondent,
      submittedAt: new Date().toISOString(),
      sections: sections.map((s) => ({
        section: `${s.number}. ${s.title}`,
        questions: s.questions.map((q) => ({
          id: q.id,
          question: q.text,
          answer: answers[q.id] ?? "",
          required: Boolean(q.required),
        })),
      })),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "پرسشنامه-کمپانی-تاج.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (submitted) {
    return (
      <div dir="rtl" className="min-h-screen bg-slate-50 font-[Vazirmatn]">
        <SuccessScreen
          answeredCount={answeredCount}
          onEdit={() => setSubmitted(false)}
          onReset={handleReset}
          onDownload={handleDownload}
        />
      </div>
    );
  }

  return (
    <div dir="rtl" lang="fa" className="min-h-screen bg-slate-50 font-[Vazirmatn] text-slate-800">
      <Hero />

      <StickyProgress answers={answers} activeSection={activeSection} onJump={handleJump} />

      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-8 sm:py-10">
        {/* respondent info */}
        <div className="mb-8 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
          <h3 className="mb-1 text-base font-bold text-slate-900 sm:text-lg">
            مشخصات تکمیل‌کننده فرم
          </h3>
          <p className="mb-4 text-xs text-slate-500 sm:text-sm">
            این بخش اختیاری است و صرفاً برای پیگیری بهتر پاسخ‌ها استفاده می‌شود.
          </p>
          <div className="grid gap-3 sm:grid-cols-3">
            <input
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-amber-500 focus:ring-4 focus:ring-amber-400/20"
              placeholder="نام و نام خانوادگی"
              value={respondent.name}
              onChange={(e) => setRespondent((p) => ({ ...p, name: e.target.value }))}
            />
            <input
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-amber-500 focus:ring-4 focus:ring-amber-400/20"
              placeholder="سمت / نقش در پروژه"
              value={respondent.role}
              onChange={(e) => setRespondent((p) => ({ ...p, role: e.target.value }))}
            />
            <input
              className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-amber-500 focus:ring-4 focus:ring-amber-400/20"
              placeholder="تاریخ تکمیل فرم"
              value={respondent.date}
              onChange={(e) => setRespondent((p) => ({ ...p, date: e.target.value }))}
            />
          </div>
        </div>

        <div className="flex flex-col gap-8">
          {sections.map((section) => (
            <SectionCard
              key={section.id}
              section={section}
              answers={answers}
              onChange={handleChange}
              attemptedSubmit={attemptedSubmit}
            />
          ))}
        </div>

        {/* submit bar */}
        <div className="mt-10 rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-sm sm:p-8">
          {attemptedSubmit && missingRequired.length > 0 && (
            <div className="mb-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-600">
              {missingRequired.length} پرسش ضروری هنوز بدون پاسخ مانده است. لطفاً پیش از ارسال
              نهایی، آن‌ها را تکمیل کنید.
            </div>
          )}
          <h3 className="text-lg font-bold text-slate-900 sm:text-xl">
            آماده ارسال پرسش‌نامه هستید؟
          </h3>
          <p className="mx-auto mt-2 max-w-lg text-sm leading-7 text-slate-500">
            پاسخ شما تا این لحظه به‌صورت خودکار روی همین مرورگر ذخیره می‌شود. با ارسال نهایی،
            پاسخ‌ها برای تدوین اسناد استراتژی برند کمپانی تاج مورد استفاده قرار می‌گیرد.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleSubmit}
              type="button"
              className="rounded-xl bg-gradient-to-l from-amber-500 to-amber-600 px-8 py-3.5 text-sm font-bold text-slate-900 shadow-lg shadow-amber-200 transition hover:from-amber-400 hover:to-amber-500 sm:text-base"
            >
              ارسال نهایی پرسش‌نامه
            </button>
            <button
              onClick={handleDownload}
              type="button"
              className="rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-sm font-semibold text-slate-700 transition hover:border-slate-400"
            >
              دانلود پیش‌نویس پاسخ‌ها
            </button>
            <button
              onClick={handleReset}
              type="button"
              className="rounded-xl px-6 py-3.5 text-sm font-semibold text-rose-500 transition hover:bg-rose-50"
            >
              پاک کردن فرم
            </button>
          </div>
          <p
            className={`mt-4 text-xs text-emerald-600 transition-opacity ${
              saveHint ? "opacity-100" : "opacity-0"
            }`}
          >
            پیش‌نویس شما ذخیره شد ✓
          </p>
        </div>

        <p className="mt-8 text-center text-xs text-slate-400">
          {projectMeta.title} · {answeredCount} از {totalQuestions} پرسش تکمیل شده
        </p>
      </main>
    </div>
  );
}
