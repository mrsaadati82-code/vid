export type AnswerValue = string | string[];
export type Answers = Record<string, AnswerValue>;

export function isEmptyAnswer(value: AnswerValue | undefined): boolean {
  if (value === undefined || value === null) return true;
  if (Array.isArray(value)) return value.length === 0;
  return value.trim().length === 0;
}
