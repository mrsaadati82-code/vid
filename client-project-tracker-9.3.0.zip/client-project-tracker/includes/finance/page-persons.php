<?php
if (!defined('ABSPATH')) exit;

/**
 * Persons (طرف‌های حساب) — v9.2.54
 *
 * هدف: برای «هر شخص» (مشتری، کارشناس، یا هر کاربر که در دفتر مالی سند دارد)
 * یک کارت حساب یکجا ببینیم:
 *   - جمع هزینه‌ها / دریافتی روی مراحل (هم‌خوان با صفحه‌ی مطالبات)
 *   - جمع واریزی‌های سندمحور (اسناد دریافتیِ زنده‌ی مرتبط با هر پروژه)
 *   - تراز نهایی به روش «طرف حساب»:
 *       تراز = Σ(هزینه‌ی پروژه − واریزی‌های اسناد همان پروژه)
 *              − واریزی‌های بدون پروژه + پرداختی‌های بدون پروژه
 *     مثبت = او به ما بدهکار · منفی = ما به او بدهکاریم (مثلاً مازاد پرداخت)
 *   - ثبت سریع سند دریافتی/پرداختی برای همان شخص
 *   - پرش به اسناد آن شخص در صفحه‌ی درآمد/هزینه (فیلتر اشخاص)
 *
 * نکته‌ی مهم: این صفحه فقط خواندنی است و هیچ داده‌ای را تغییر نمی‌دهد؛
 * جمع‌ها دقیقاً از همان منابع صفحات مطالبات/گردش حساب و همان فرمولِ
 * «واریزی زنده‌ی سندمحور» سمت کارشناس خوانده می‌شوند تا حساب و کتاب به‌هم نریزد.
 */
if (!function_exists('cpttf_party_role_vocab')) {
	function cpttf_party_role_vocab(){
		return ['مشتری','تأمین‌کننده','پیمانکار','پرسنل','شریک','کارشناس','سرمایه‌گذار','نماینده','همکار','سایر'];
	}
}

function cpttf_render_persons(){
	// v9.2.55 — پرونده‌ی اختصاصی شخص (داشبورد مالی + دفتر معین + پروفایل طرف‌حساب)
	$_pid = isset($_GET['pid']) ? (int)$_GET['pid'] : 0;
	if ($_pid > 0) {
		require_once CPTT_PATH . 'includes/finance/page-person.php';
		cpttf_render_person($_pid);
		return;
	}
	global $wpdb;
	$cur = CPTT_Finance::currency_label();
	$t_lgr = CPTT_Finance::tbl_ledger();

	$people = []; // key = user_id

	$mk = function($uid) use (&$people) {
		$uid = (int)$uid;
		if (!isset($people[$uid])) {
			$people[$uid] = [
				'id' => $uid, 'name' => '', 'phone' => '', 'exists' => true,
				'is_customer' => false, 'is_expert' => false,
				'cost' => 0.0, 'paid' => 0.0, 'live' => 0.0,
				'projects' => [],
				'l_in' => 0.0, 'l_out' => 0.0, 'l_n' => 0, 'last_ts' => 0,
				'np_in' => 0.0, 'np_out' => 0.0,
				'payout_total' => 0.0,
				'vouchers' => [],
				'np_vouchers' => [], // v9.2.56 — اسناد فعال بدون پروژه (برای تفکیک مانده)
			];
		}
		return $uid;
	};

	/* ── ۱) واریزی زنده‌ی سندمحور به‌ازای هر پروژه (همان فرمول سمت کارشناس) ── */
	$live_map = [];
	$ACT = CPTT_Finance::sql_active_cond('l'); // v9.3.0 — فقط اسناد مؤثر (برگشتی/برگشت‌خورده اصلاً حساب نمی‌شوند)
	$live_rows = $wpdb->get_results(
		"SELECT l.project_id, SUM(l.amount * l.direction) AS live
		 FROM $t_lgr l
		 WHERE l.project_id > 0 AND l.type = 'income' AND l.voucher_kind = 'receipt'
		   AND $ACT
		 GROUP BY l.project_id"
	);
	if (is_array($live_rows)) {
		foreach ($live_rows as $lr) $live_map[(int)$lr->project_id] = (float)$lr->live;
	}

	/* ── ۲) تجمیع از پروژه‌ها (منبع رسمی حساب مشتری) ── */
	$projects = get_posts(['post_type' => 'cptt_project', 'post_status' => 'any', 'numberposts' => -1]);
	foreach ($projects as $p) {
		$cid = (int) get_post_meta($p->ID, '_cptt_client_user_id', true);
		if (!$cid) continue;
		$steps = get_post_meta($p->ID, '_cptt_steps', true);
		$cost = 0.0; $paid = 0.0;
		if (is_array($steps)) {
			foreach ($steps as $st) {
				if (!is_array($st)) continue;
				$cost += (float)($st['cost'] ?? 0);
				$paid += (float)($st['paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) {
						if (!is_array($ef)) continue;
						$cost += (float)($ef['cost'] ?? 0);
						$paid += (float)($ef['paid'] ?? 0);
					}
				}
			}
		}
		$live = isset($live_map[$p->ID]) ? (float)$live_map[$p->ID] : 0.0;
		$key = $mk($cid);
		$people[$key]['is_customer'] = true;
		$people[$key]['cost'] += $cost;
		$people[$key]['paid'] += $paid;
		$people[$key]['live'] += $live;
		$people[$key]['projects'][] = [
			'id' => $p->ID, 'title' => get_the_title($p) ?: ('#' . $p->ID),
			'cost' => $cost, 'paid' => $paid, 'live' => $live,
			'bal' => $cost - $live, // تراز سندمحور: منفی = مازاد پرداخت (ما بدهکار)
		];
	}

	/* ── ۳) تجمیع گردش نقدی از دفتر مالی (برگشت‌ها به صورت خودکار خنثی می‌شوند) ── */
	$agg = $wpdb->get_results(
		"SELECT l.customer_id, l.expert_id, l.type,
			SUM(CASE WHEN l.direction > 0 THEN l.amount ELSE 0 END) AS tin,
			SUM(CASE WHEN l.direction < 0 THEN l.amount ELSE 0 END) AS tout,
			COUNT(*) AS n, MAX(l.date_at) AS last_ts
		 FROM $t_lgr l
		 WHERE $ACT AND (l.customer_id > 0 OR l.expert_id > 0)
		 GROUP BY l.customer_id, l.expert_id, l.type"
	);
	if (is_array($agg)) {
		foreach ($agg as $a) {
			foreach ([['c', (int)$a->customer_id], ['e', (int)$a->expert_id]] as $pair) {
				$kind = $pair[0]; $uid = $pair[1];
				if ($uid <= 0) continue;
				$key = $mk($uid);
				$people[$key]['l_in']  += (float)$a->tin;
				$people[$key]['l_out'] += (float)$a->tout;
				$people[$key]['l_n']   += (int)$a->n;
				$people[$key]['last_ts'] = max((int)$people[$key]['last_ts'], (int)$a->last_ts);
				if ($kind === 'e' && (string)$a->type === 'expert_payout') {
					$people[$key]['is_expert'] = true;
					$people[$key]['payout_total'] += (float)$a->tout;
				}
			}
		}
	}

	/* ── ۳ب) گردش‌های «بدون پروژه» (واریز/پرداخت مستقیم به نام شخص)
	 * v9.2.56 — فقط اسناد «فعال» لحاظ می‌شوند؛ جفت‌های برگشت/برگشت‌خورده خنثی‌اند.
	 * (با جفت سالم، نتیجه با قبلی یکی است؛ برای داده‌ی نیمه‌جفت هم خطا رخ نمی‌دهد.) ── */
	$np_rows = $wpdb->get_results(
		"SELECT l.customer_id, l.expert_id,
			SUM(CASE WHEN l.direction > 0 THEN l.amount ELSE 0 END) AS tin,
			SUM(CASE WHEN l.direction < 0 THEN l.amount ELSE 0 END) AS tout
		 FROM $t_lgr l
		 WHERE $ACT AND (l.project_id = 0 OR l.project_id IS NULL)
		   AND (l.customer_id > 0 OR l.expert_id > 0)
		 GROUP BY l.customer_id, l.expert_id"
	);
	if (is_array($np_rows)) {
		foreach ($np_rows as $a) {
			foreach ([(int)$a->customer_id, (int)$a->expert_id] as $uid) {
				if ($uid <= 0) continue;
				$key = $mk($uid);
				$people[$key]['np_in']  += (float)$a->tin;
				$people[$key]['np_out'] += (float)$a->tout;
			}
		}
	}

	/* ── ۳ج) اسناد «فعالِ بدون پروژه» هر شخص (برای جعبه‌ی تفکیک مانده + ابزار انتساب) ── */
	$np_docs = $wpdb->get_results(
		"SELECT l.id, l.customer_id, l.expert_id, l.voucher_no, l.voucher_kind, l.direction, l.amount, l.date_fa, l.description
		 FROM $t_lgr l
		 WHERE $ACT AND (l.project_id = 0 OR l.project_id IS NULL)
		   AND (l.customer_id > 0 OR l.expert_id > 0)
		 ORDER BY l.date_at DESC, l.id DESC LIMIT 500"
	);
	if (is_array($np_docs)) {
		foreach ($np_docs as $r) {
			foreach ([(int)$r->customer_id, (int)$r->expert_id] as $uid) {
				if ($uid <= 0) continue;
				$key = $mk($uid);
				$people[$key]['np_vouchers'][] = $r;
			}
		}
	}

	/* ── ۴) آخرین اسناد هر شخص (تا ۱۲ سند) ── */
	$recent = $wpdb->get_results(
		"SELECT id, customer_id, expert_id, voucher_no, voucher_kind, type, direction, amount, status, reversed_by, date_fa, project_id, description
		 FROM $t_lgr
		 WHERE status IN ('posted','reversed','reversal') AND (customer_id > 0 OR expert_id > 0)
		 ORDER BY date_at DESC, id DESC LIMIT 600"
	);
	if (is_array($recent)) {
		foreach ($recent as $r) {
			$keys = [];
			if ((int)$r->customer_id > 0) $keys[] = (int)$r->customer_id;
			if ((int)$r->expert_id > 0 && !in_array((int)$r->expert_id, $keys, true)) $keys[] = (int)$r->expert_id;
			foreach ($keys as $uid) {
				if (!isset($people[$uid])) continue;
				if (count($people[$uid]['vouchers']) < 12) $people[$uid]['vouchers'][] = $r;
			}
		}
	}

	/* ── ۵) غنای نام/تلفن/نقش ── */
	foreach ($people as $uid => &$pr) {
		$u = get_user_by('id', $uid);
		if ($u) {
			$pr['name'] = (string)$u->display_name;
			$roles = (array)$u->roles;
			if (in_array('cptt_expert', $roles, true)) { $pr['is_expert'] = true; }
			$pr['phone'] = (string)get_user_meta($uid, 'billing_phone', true);
			if ($pr['phone'] === '') $pr['phone'] = (string)get_user_meta($uid, 'cptt_phone', true);
			if ($pr['phone'] === '') $pr['phone'] = (string)get_user_meta($uid, 'mobile', true);
		} else {
			$pr['name'] = 'کاربر حذف‌شده #' . $uid;
			$pr['exists'] = false;
		}
		// v9.2.55 — نقش‌های طرف‌حساب (چندگانه، دستی) مقدم بر نقش‌های مشتق‌شده
		$prj = (string)get_user_meta($uid, 'cptt_party_roles', true);
		$pr_roles = $prj !== '' ? json_decode($prj, true) : [];
		if (!is_array($pr_roles)) $pr_roles = [];
		$pr['party_roles'] = $pr_roles;
		$pr['active'] = (int)(get_user_meta($uid, 'cptt_party_active', true) !== '' ? get_user_meta($uid, 'cptt_party_active', true) : 1);
	}
	unset($pr);

	/* ── ۶) تراز به روش «طرف حساب» + KPI ── */
	$claims = 0.0; $debts = 0.0;
	foreach ($people as &$pr) {
		// تراز = (هزینه‌ها − واریزی‌های اسنادِ پروژه‌ها) − واریزی‌های بدون پروژه + پرداختی‌های بدون پروژه
		$pr['delta'] = round(((float)$pr['cost'] - (float)$pr['live']) - (float)$pr['np_in'] + (float)$pr['np_out'], 2);
		$pr['steps_remain'] = round((float)$pr['cost'] - (float)$pr['paid'], 2); // مانده‌ی روی مراحل (مثل صفحه‌ی مطالبات)
		$pr['turnover'] = (float)$pr['l_in'] + (float)$pr['l_out'];
		if ($pr['delta'] > 0) $claims += $pr['delta'];
		elseif ($pr['delta'] < 0) $debts += -$pr['delta'];
	}
	unset($pr);

	// سورت پیش‌فرض: بزرگ‌ترین |تراز|، بعد جدیدترین گردش
	uasort($people, function($a, $b){
		$d = abs($b['delta']) <=> abs($a['delta']);
		if ($d !== 0) return $d;
		return ((int)$b['last_ts'] <=> (int)$a['last_ts']);
	});

	$base_tx = admin_url('admin.php?page=cptt-finance-transactions');
	?>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4">
		<div class="cpttf-kpi" style="--c:#f59e0b">
			<div class="cpttf-kpi__icon">📥</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع طلب ما از اشخاص</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($claims); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">مانده‌ای که هنوز نپرداخته‌اند</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#8b5cf6">
			<div class="cpttf-kpi__icon">📤</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع بدهی ما به اشخاص</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($debts); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">مازاد پرداخت‌شده توسط مشتری (به او بدهکاریم)</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#06b6d4">
			<div class="cpttf-kpi__icon">⚖️</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">تراز خالص با اشخاص</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($claims - $debts); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">طلب − بدهی</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#64748b">
			<div class="cpttf-kpi__icon">🪪</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">اشخاص دارای حساب</span>
				<strong class="cpttf-kpi__value" data-plain="1"><?php echo CPTT_Finance::fmt(count($people)); ?></strong>
				<small class="cpttf-kpi__sub">مشتری، کارشناس و طرف‌های اسناد</small></div>
		</div>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>🪪 اشخاص و تراز حساب</h2>
				<small style="color:#64748b;font-size:12px;">تراز = (جمع هزینه‌ی پروژه‌ها − جمع واریزی‌های اسناد) − واریزی‌های بدون پروژه + پرداختی‌های بدون پروژه · مثبت: به ما بدهکار · منفی: به او بدهکاریم</small>
			</div>
			<div class="cpttf-card__actions">
				<button class="cpttf-btn cpttf-btn--primary" type="button" data-cpttf-person-create="1">+ شخص جدید</button>
				<button class="cpttf-btn cpttf-btn--ghost" type="button" data-cpttf-person-new="income">+ سند دریافتی جدید</button>
			</div>
		</header>
		<div class="cpttf-recv-toolbar">
			<div class="cpttf-recv-search-wrap">
				<span class="cpttf-recv-search-icon" aria-hidden="true">🔍</span>
				<input type="search" id="cpttf-persons-search" class="cpttf-recv-search" placeholder="جستجو در نام یا شماره تماس…">
			</div>
			<label class="cpttf-recv-field">
				<span>مرتب‌سازی:</span>
				<select id="cpttf-persons-sort" class="cpttf-recv-select">
					<option value="abs-desc">بزرگ‌ترین تراز</option>
					<option value="debt-desc">بدهکاران به ما (زیاد به کم)</option>
					<option value="credit-desc">طرف‌هایی که به آن‌ها بدهکاریم</option>
					<option value="turnover-desc">بیشترین گردش دفتر</option>
					<option value="last-desc">جدیدترین گردش</option>
					<option value="name-asc">نام (الفبا)</option>
				</select>
			</label>
			<label class="cpttf-recv-field">
				<span>فیلتر:</span>
				<select id="cpttf-persons-filter" class="cpttf-recv-select">
					<option value="all">همه</option>
					<option value="debt">فقط بدهکار به ما</option>
					<option value="credit">فقط بدهکار ما به ایشان</option>
					<option value="even">تسویه‌شده‌ها با گردش</option>
					<option value="customer">فقط مشتریان</option>
					<option value="expert">فقط کارشناسان</option>
				</select>
			</label>
			<label class="cpttf-recv-field">
				<span>نقش:</span>
				<select id="cpttf-persons-role" class="cpttf-recv-select">
					<option value="">همه نقش‌ها</option>
					<?php foreach (cpttf_party_role_vocab() as $vr): ?><option value="<?php echo esc_attr($vr); ?>"><?php echo esc_html($vr); ?></option><?php endforeach; ?>
				</select>
			</label>
		</div>
		<div class="cpttf-card__body">
			<?php if (empty($people)): ?>
				<p class="cpttf-empty">هنوز شخصی با حساب باز یا گردش سند وجود ندارد.</p>
			<?php else: ?>
				<div id="cpttf-persons-count" style="font-size:12.5px;color:#64748b;margin-bottom:8px;"></div>
				<ul class="cpttf-debtor-list cpttf-persons-list" id="cpttf-persons-list">
					<?php foreach ($people as $pr):
						$delta = (float)$pr['delta'];
						$kind = $delta > 0.005 ? 'debt' : ($delta < -0.005 ? 'credit' : 'even');
						$role_bits = [];
						if ($pr['is_customer']) $role_bits[] = 'مشتری';
						if ($pr['is_expert']) $role_bits[] = 'کارشناس';
						if (!$role_bits) $role_bits[] = 'طرف اسناد';
						// v9.2.55 — نقش‌های چندگانه‌ی طرف‌حساب مقدم‌اند
						$disp_roles = !empty($pr['party_roles']) ? $pr['party_roles'] : $role_bits;
						$all_roles = array_values(array_unique(array_merge($disp_roles, $role_bits)));
						$search = mb_strtolower($pr['name'] . ' ' . $pr['phone']);
					?>
					<li class="cpttf-debtor cpttf-person"
						data-search="<?php echo esc_attr($search); ?>"
						data-delta="<?php echo (float)$delta; ?>"
						data-abs="<?php echo (float)abs($delta); ?>"
						data-turnover="<?php echo (float)$pr['turnover']; ?>"
						data-last="<?php echo (int)$pr['last_ts']; ?>"
						data-name="<?php echo esc_attr(mb_strtolower($pr['name'])); ?>"
						data-kind="<?php echo esc_attr($kind); ?>"
						data-roles="<?php echo esc_attr(implode(',', $all_roles)); ?>"
						data-cust="<?php echo $pr['is_customer'] ? '1' : '0'; ?>"
						data-exp="<?php echo $pr['is_expert'] ? '1' : '0'; ?>">
						<button type="button" class="cpttf-debtor__head">
							<div class="cpttf-debtor__avatar"><?php echo esc_html(mb_substr($pr['name'], 0, 1)); ?></div>
							<div class="cpttf-debtor__title">
								<strong><?php echo esc_html($pr['name']); ?><?php if (!$pr['active']): ?> <span class="cpttf-chip cpttf-chip--muted" style="font-size:9.5px;">غیرفعال</span><?php endif; ?></strong>
								<small><?php echo esc_html(implode(' · ', $disp_roles)); ?><?php echo $pr['phone'] ? ' · ' . esc_html($pr['phone']) : ''; ?><?php echo $pr['projects'] ? ' · ' . count($pr['projects']) . ' پروژه' : ''; ?><?php echo $pr['l_n'] ? ' · ' . (int)$pr['l_n'] . ' سند' : ''; ?></small>
							</div>
							<span class="cpttf-person__go" data-url="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$pr['id'])); ?>" title="پرونده کامل مالی">🗂 پرونده</span>
							<div class="cpttf-person__delta cpttf-person__delta--<?php echo esc_attr($kind); ?>">
								<?php if ($kind === 'debt'): ?>
									<small>به ما بدهکار</small><b><?php echo CPTT_Finance::fmt($delta); ?></b>
								<?php elseif ($kind === 'credit'): ?>
									<small>به ایشان بدهکاریم</small><b><?php echo CPTT_Finance::fmt(-$delta); ?></b>
								<?php else: ?>
									<small>تسویه</small><b>۰</b>
								<?php endif; ?>
							</div>
							<svg class="cpttf-debtor__chevron" width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="5 8 10 13 15 8"/></svg>
						</button>
						<div class="cpttf-debtor__projects" hidden>
							<div class="cpttf-person__stats">
								<div><span>جمع هزینه پروژه‌ها</span><b><?php echo CPTT_Finance::fmt($pr['cost']); ?></b></div>
								<div><span>دریافت‌شده روی مراحل (مثل مطالبات)</span><b><?php echo CPTT_Finance::fmt($pr['paid']); ?></b></div>
								<div><span>جمع واریزی‌های اسناد پروژه‌ها</span><b><?php echo CPTT_Finance::fmt($pr['live']); ?></b></div>
								<div><span>گردش دفتر (واریز/برداشت)</span><b><?php echo CPTT_Finance::fmt($pr['l_in']); ?> / <?php echo CPTT_Finance::fmt($pr['l_out']); ?></b></div>
								<?php if ($pr['payout_total'] > 0): ?><div><span>تسویه‌های پرداخت‌شده به کارشناس</span><b><?php echo CPTT_Finance::fmt($pr['payout_total']); ?></b></div><?php endif; ?>
								<div><span>آخرین گردش</span><b><?php echo esc_html(CPTT_Finance::fa_date($pr['last_ts'])); ?></b></div>
							</div>

							<div class="cpttf-person__actions">
								<a class="cpttf-btn cpttf-btn--sm cpttf-btn--warn" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$pr['id'])); ?>">🗂 پرونده کامل</a>
								<a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new' => 'income', 'person' => (int)$pr['id']], $base_tx)); ?>">+ سند دریافتی</a>
								<a class="cpttf-btn cpttf-btn--sm cpttf-btn--danger" href="<?php echo esc_url(add_query_arg(['new' => 'expense', 'person' => (int)$pr['id']], $base_tx)); ?>">+ سند پرداختی</a>
								<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson' => (int)$pr['id']], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">🧾 فاکتورها</a>
								<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson' => (int)$pr['id']], $base_tx)); ?>">📄 همه اسناد این شخص</a>
							</div>

							<?php
							// v9.2.56 — تفکیک مانده: چرا عدد نهایی همین است + ابزار انتساب اسناد بدون پروژه
							require_once CPTT_PATH . 'includes/finance/page-person.php';
							$_npdocs = array();
							foreach ((array)$pr['np_vouchers'] as $_nv) {
								$_npdocs[] = array(
									'id'      => (int)$_nv->id,
									'vno'     => (string)((string)$_nv->voucher_no !== '' ? $_nv->voucher_no : ('#' . (int)$_nv->id)),
									'date_fa' => (string)$_nv->date_fa,
									'dir'     => (int)$_nv->direction >= 0 ? 1 : -1,
									'amount'  => (float)$_nv->amount,
									'desc'    => (string)$_nv->description,
								);
							}
							cpttf_balance_breakdown_html(array(
								'proj_bal'    => (float)$pr['cost'] - (float)$pr['live'],
								'np_in'       => (float)$pr['np_in'],
								'np_out'      => (float)$pr['np_out'],
								'delta'       => (float)$delta,
								'np_vouchers' => $_npdocs,
								'projects'    => array_values(array_map(function($pj){ return array('id'=>(int)$pj['id'],'title'=>(string)$pj['title']); }, (array)$pr['projects'])),
							));
							?>

							<?php if (!empty($pr['projects'])): ?>
								<h4 class="cpttf-person__sect">📁 پروژه‌ها</h4>
								<table class="cpttf-table">
									<thead><tr><th>پروژه</th><th>مبلغ کل</th><th>دریافتی روی مراحل</th><th>واریزی (اسناد)</th><th>تراز</th><th style="width:150px">سند</th></tr></thead>
									<tbody>
									<?php foreach ($pr['projects'] as $pj): ?>
										<tr>
											<td><a href="<?php echo esc_url(get_edit_post_link($pj['id'])); ?>" target="_blank"><?php echo esc_html($pj['title']); ?></a></td>
											<td><?php echo CPTT_Finance::fmt($pj['cost']); ?></td>
											<td><?php echo CPTT_Finance::fmt($pj['paid']); ?></td>
											<td><?php echo CPTT_Finance::fmt($pj['live']); ?></td>
											<td class="<?php echo $pj['bal'] > 0.005 ? 'cpttf-text-danger' : ($pj['bal'] < -0.005 ? 'cpttf-text-warn' : 'cpttf-text-success'); ?>"><b><?php echo CPTT_Finance::fmt($pj['bal']); ?></b><?php if ($pj['bal'] < -0.005): ?><br><small style="font-weight:700;">مازاد پرداخت</small><?php endif; ?></td>
											<td><a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new' => 'income', 'person' => (int)$pr['id'], 'project_id' => (int)$pj['id']], $base_tx)); ?>">💵 سند دریافتی</a></td>
										</tr>
									<?php endforeach; ?>
									</tbody>
								</table>
							<?php endif; ?>

							<?php if (!empty($pr['vouchers'])): ?>
								<h4 class="cpttf-person__sect">📄 آخرین اسناد (۱۲ مورد اخیر)</h4>
								<table class="cpttf-table">
									<thead><tr><th>شماره سند</th><th>تاریخ</th><th>نوع</th><th>واریز</th><th>برداشت</th><th>وضعیت</th></tr></thead>
									<tbody>
									<?php foreach ($pr['vouchers'] as $v):
										$vd = (int)$v->direction >= 0 ? 1 : -1;
										$vst = (string)($v->status ?: 'posted');
										$vnt = CPTT_Finance::is_row_neutral($v); // v9.3.0 — خنثی‌سازی جفت‌آگاه برگشت
										$vno = (string)$v->voucher_no !== '' ? $v->voucher_no : ('#' . (int)$v->id);
									?>
										<tr class="<?php echo $vnt ? 'is-reversed' : ''; ?>">
											<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($vno); ?></b></td>
											<td><?php echo esc_html($v->date_fa); ?></td>
											<td><?php echo esc_html(CPTT_Finance::voucher_label($v)); ?></td>
											<td class="cpttf-text-success"><?php echo $vd > 0 ? '<b>' . CPTT_Finance::fmt($v->amount) . '</b>' : '—'; ?></td>
											<td class="cpttf-text-danger"><?php echo $vd < 0 ? '<b>' . CPTT_Finance::fmt($v->amount) . '</b>' : '—'; ?></td>
											<td><?php echo $vnt ? ($vst === 'reversed' ? '↩️ برگشت‌خورده · خنثی' : ($vst === 'reversal' ? '↩️ سند برگشت · خنثی' : '⚪ خنثی (جفت برگشت دارد)')) : 'فعال'; ?></td>
										</tr>
									<?php endforeach; ?>
									</tbody>
								</table>
							<?php endif; ?>
						</div>
					</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</section>

	<?php // v9.2.55 — مدال ساخت شخص جدید (ثبت طرف‌حساب بدون نیاز به پروژه) ?>
	<div class="cpttf-modal" id="cpttf-person-create-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-create-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3>+ شخص جدید</h3>
				<button class="cpttf-modal__close" data-cpttf-create-close>×</button>
			</header>
			<form id="cpttf-person-create-form" class="cpttf-modal__body">
				<div class="cpttf-form-grid">
					<label><span>نام و نام خانوادگی / نام شرکت *</span><input type="text" name="name" required></label>
					<label><span>موبایل</span><input type="text" name="phone" dir="ltr"></label>
					<label><span>نوع شخص</span>
						<select name="type"><option value="real">شخص حقیقی</option><option value="legal">شخص حقوقی (شرکت)</option></select>
					</label>
					<label><span>وضعیت</span>
						<select name="active"><option value="1">فعال</option><option value="0">غیرفعال</option></select>
					</label>
					<fieldset class="cpttf-full cpttf-party-roles">
						<legend>نقش‌ها <small style="font-weight:500;color:#64748b;">(چندگانه مجاز است)</small></legend>
						<?php foreach (cpttf_party_role_vocab() as $vr): ?>
							<label class="cpttf-party-role"><input type="checkbox" name="roles[]" value="<?php echo esc_attr($vr); ?>" <?php checked($vr === 'مشتری'); ?>> <span><?php echo esc_html($vr); ?></span></label>
						<?php endforeach; ?>
					</fieldset>
					<label class="cpttf-full"><span>توضیحات</span><textarea name="note" rows="2"></textarea></label>
				</div>
				<span class="cpttf-party-msg" style="display:block;margin-top:8px;font-size:12px;"></span>
			</form>
			<footer class="cpttf-modal__foot">
				<button class="cpttf-btn cpttf-btn--ghost" data-cpttf-create-close>انصراف</button>
				<button class="cpttf-btn cpttf-btn--primary" type="submit" form="cpttf-person-create-form">✚ ساخت شخص و باز کردن پرونده</button>
			</footer>
		</div>
	</div>

	<script>
	(function(){
		function $(s,c){ return (c||document).querySelector(s); }
		function $$(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); }
		var list = $('#cpttf-persons-list'); if(!list) return;
		var search = $('#cpttf-persons-search'), sort = $('#cpttf-persons-sort'), filter = $('#cpttf-persons-filter'), counter = $('#cpttf-persons-count');

		function norm(s){ return String(s||'').toLowerCase().replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/‌/g,' ').trim(); }
		function items(){ return $$('.cpttf-person', list); }

		var roleSel = $('#cpttf-persons-role');
		function apply(){
			var q = norm(search && search.value);
			var f = filter ? filter.value : 'all';
			var roleNeed = roleSel ? String(roleSel.value||'') : '';
			var shown = 0;
			items().forEach(function(li){
				var ok = true;
				if (q && norm(li.dataset.search).indexOf(q) === -1) ok = false;
				if (ok && f !== 'all'){
					var d = parseFloat(li.dataset.delta||'0');
					if (f === 'debt' && d <= 0.005) ok = false;
					if (f === 'credit' && d >= -0.005) ok = false;
					if (f === 'even' && (Math.abs(d) > 0.005 || parseFloat(li.dataset.turnover||'0') <= 0)) ok = false;
					if (f === 'customer' && li.dataset.cust !== '1') ok = false;
					if (f === 'expert' && li.dataset.exp !== '1') ok = false;
				}
				if (ok && roleNeed){
					var rl = ',' + (li.dataset.roles || '') + ',';
					if (rl.indexOf(',' + roleNeed + ',') === -1) ok = false;
				}
				li.style.display = ok ? '' : 'none';
				if (ok) shown++;
			});
			if (counter) counter.textContent = shown + ' شخص نمایش داده می‌شود';

			var mode = sort ? sort.value : 'abs-desc';
			var arr = items().slice();
			arr.sort(function(a,b){
				if (mode === 'debt-desc') return parseFloat(b.dataset.delta) - parseFloat(a.dataset.delta);
				if (mode === 'credit-desc') return parseFloat(a.dataset.delta) - parseFloat(b.dataset.delta);
				if (mode === 'turnover-desc') return parseFloat(b.dataset.turnover) - parseFloat(a.dataset.turnover);
				if (mode === 'last-desc') return parseInt(b.dataset.last,10) - parseInt(a.dataset.last,10);
				if (mode === 'name-asc') return String(a.dataset.name||'').localeCompare(String(b.dataset.name||''), 'fa');
				return parseFloat(b.dataset.abs) - parseFloat(a.dataset.abs);
			});
			arr.forEach(function(li){ list.appendChild(li); });
		}

		['input','change'].forEach(function(ev){
			if (search) search.addEventListener(ev, apply);
			if (filter) filter.addEventListener(ev, apply);
			if (sort) sort.addEventListener(ev, apply);
			if (roleSel) roleSel.addEventListener(ev, apply);
		});

		/* v9.2.54 — باز/بسته‌شدن کارت شخص فقط توسط finance.js (bindAccordion)
		   انجام می‌شود؛ شنونده‌ی تکراری اینجا حذف شد (باگ «باز نمی‌شود» دو بار
		   تاگل می‌کرد). */

		// ناوبری شناخته‌شده با پنل توکار
		function goTo(url, slug, query){
			if (window.cpttBridgeLoadFinance && document.getElementById('cptt-admin-bridge-content')){
				window.cpttBridgeLoadFinance(slug, query); return;
			}
			window.location.href = url;
		}
		// دکمه‌ی سند جدید: داخل پنل توکار از طریق پل، در پیشخوان با ناوبری معمولی
		document.addEventListener('click', function(e){
			var b = e.target.closest('[data-cpttf-person-new]');
			if (!b) return;
			e.preventDefault();
			var mode = b.getAttribute('data-cpttf-person-new') || 'income';
			goTo('<?php echo esc_js($base_tx); ?>&new=' + encodeURIComponent(mode), 'cptt-finance-transactions', 'new=' + encodeURIComponent(mode));
		});
		// v9.2.55 — رفتن به پرونده‌ی کامل شخص (بدون تاگل آکاردئون)
		document.addEventListener('click', function(e){
			var g = e.target.closest('.cpttf-person__go');
			if (!g) return;
			e.preventDefault(); e.stopPropagation();
			var url = g.getAttribute('data-url') || '';
			var pid = 0; try { var u = new URL(url, window.location.href); pid = u.searchParams.get('pid') || 0; } catch(_){ var m = url.match(/pid=(\d+)/); if (m) pid = m[1]; }
			goTo(url, 'cptt-finance-persons', 'pid=' + pid);
		});
		// v9.2.55 — مدال «شخص جدید»
		var createModal = $('#cpttf-person-create-modal');
		document.addEventListener('click', function(e){
			var openB = e.target.closest('[data-cpttf-person-create]');
			if (openB && createModal){ e.preventDefault(); createModal.hidden = false; var ni = createModal.querySelector('[name="name"]'); if (ni) ni.focus(); return; }
			if (e.target.closest('[data-cpttf-create-close]') && createModal){ createModal.hidden = true; }
		});
		var createForm = $('#cpttf-person-create-form');
		if (createForm){
			createForm.addEventListener('submit', function(e){
				e.preventDefault();
				if (!window.CPTT_FIN) return;
				var btn = createForm.querySelector('[type="submit"]'), msg = createForm.querySelector('.cpttf-party-msg');
				btn.disabled = true;
				var fd = new FormData(createForm);
				fd.append('action', 'cptt_fin_person_save');
				fd.append('nonce', CPTT_FIN.nonce);
				fd.append('new_person', '1');
				fetch(CPTT_FIN.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
					.then(function(r){ return r.json(); })
					.then(function(j){
						btn.disabled = false;
						if (j && j.success && j.data && j.data.user_id){
							var npid = j.data.user_id;
							goTo('<?php echo esc_js(admin_url('admin.php?page=cptt-finance-persons')); ?>&pid=' + npid, 'cptt-finance-persons', 'pid=' + npid);
						} else if (msg){ msg.style.color = '#dc2626'; msg.textContent = (j && j.data) ? j.data : 'خطا در ساخت شخص'; }
					})
					.catch(function(){ btn.disabled = false; if (msg){ msg.style.color = '#dc2626'; msg.textContent = 'خطای ارتباط با سرور'; } });
			});
		}

		// v9.2.56 — انتساب سند «بدون پروژه» به پروژه (اصلاح داده بدون به‌هم‌ریختن جمع حساب)
		if (!window.__cpttfVAssignBound) {
			window.__cpttfVAssignBound = true;
			document.addEventListener('click', function(e){
				var b = e.target.closest('[data-cpttf-vassign]');
				if (!b) return;
				e.preventDefault(); e.stopPropagation();
				var id = b.getAttribute('data-cpttf-vassign');
				var sel = document.querySelector('select[data-cpttf-vassign-for="' + id + '"]');
				var pid = sel ? (parseInt(sel.value, 10) || 0) : 0;
				if (!pid) { window.alert('ابتدا پروژه را انتخاب کنید.'); return; }
				if (!window.confirm('سند به پروژه انتخاب‌شده پیوند بخورد؟ مانده‌ی مراحل پروژه همزمان همگام می‌شود (جمع کل حساب شخص تغییر نمی‌کند).')) return;
				var CFG = window.CPTT_FIN || { ajax:'', nonce:'' };
				var fd = new FormData();
				fd.append('action','cptt_fin_voucher_assign'); fd.append('nonce', CFG.nonce);
				fd.append('id', id); fd.append('project_id', pid);
				var x = new XMLHttpRequest(); x.open('POST', CFG.ajax);
				b.disabled = true;
				x.onload = function(){ var r = null; try{ r = JSON.parse(x.responseText); }catch(_){}
					if (r && r.success) { if (window.cpttfReload) window.cpttfReload(); else window.location.reload(); }
					else { b.disabled = false; window.alert((r && r.data) ? r.data : 'خطا در انتساب'); }
				};
				x.onerror = function(){ b.disabled = false; window.alert('خطای ارتباط'); };
				x.send(fd);
			}, true);
		}

		apply();
	})();
	</script>
	<?php
}
