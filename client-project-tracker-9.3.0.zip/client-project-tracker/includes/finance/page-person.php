<?php
if (!defined('ABSPATH')) exit;

/**
 * Person Dossier (پرونده شخص) — v9.2.55
 *
 * ساختار طرف‌حساب (Party) روی زیرساخت موجود:
 *  - هر شخص = یک کاربر وردپرس (همان لینک‌بندی با پروژه‌ها/دفتر حفظ می‌شود)
 *  - پروفایل طرف‌حساب در user_meta (cptt_party_*) ذخیره می‌شود
 *  - نقش‌ها «چندگانه» هستند: یک شخص می‌تواند همزمان مشتری + تأمین‌کننده + … باشد
 *
 * قرارداد بدهکار/بستانکار در دفتر معین (از دید ما):
 *  - بدهکار  → چیزی که طلب ما را از شخص زیاد می‌کند: هزینه‌ی قرارداد پروژه‌ها،
 *              پرداختی‌های ما به شخص (حواله/برگشت/تسویه کارشناس)، اسناد برگشت دریافتی
 *  - بستانکار → چیزی که طلب ما را کم می‌کند: واریزی‌های شخص (اسناد دریافتی)
 *  - مانده‌ی مثبت = او به ما بدهکار · مانده‌ی منفی = ما به او بدهکاریم
 *  - مانده‌ی پایان دوره دقیقاً برابر «تراز» صفحه‌ی اشخاص است (حساب‌ها به‌هم نمی‌ریزد).
 */

/* ── واژگان نقش‌ها (قابل توسعه) ── */
if (!function_exists('cpttf_party_role_vocab')) {
	function cpttf_party_role_vocab(){
		return ['مشتری','تأمین‌کننده','پیمانکار','پرسنل','شریک','کارشناس','سرمایه‌گذار','نماینده','همکار','سایر'];
	}
}

/* ── v9.2.56 — تاریخ شمسی فقط روز (برای چاپ/اینپوت‌ها) ── */
if (!function_exists('cpttf_person_jdate_only')) {
	function cpttf_person_jdate_only($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		$full = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($ts) : date('Y-m-d H:i', $ts);
		$parts = preg_split('/\s+/', (string)$full);
		return (string)($parts[0] ?? $full);
	}
}

/* ── v9.2.56 — KPI فاکتورهای شخص (باز + سررسیدگذشته) ── */
if (!function_exists('cpttf_person_invoice_kpi')) {
	function cpttf_person_invoice_kpi($pid){
		global $wpdb;
		$out = ['n' => 0, 'remain' => 0.0, 'over_n' => 0, 'over_remain' => 0.0];
		$t = CPTT_Finance::tbl_invoices();
		$now = (int)current_time('timestamp', true);
		$r = $wpdb->get_row($wpdb->prepare(
			"SELECT COUNT(*) AS n,
				COALESCE(SUM(amount - settled),0) AS remain,
				SUM(CASE WHEN due_ts > 0 AND due_ts < %d THEN 1 ELSE 0 END) AS over_n,
				COALESCE(SUM(CASE WHEN due_ts > 0 AND due_ts < %d THEN amount - settled ELSE 0 END),0) AS over_remain
			 FROM $t WHERE person_id = %d AND status IN ('issued','partial')",
			$now, $now, (int)$pid
		));
		if ($r) {
			$out['n'] = (int)$r->n; $out['remain'] = (float)$r->remain;
			$out['over_n'] = (int)$r->over_n; $out['over_remain'] = (float)$r->over_remain;
		}
		return $out;
	}
}

/* ── v9.2.56 — جعبه‌ی «تفکیک مانده» (مشترک بین لیست اشخاص و پرونده) ──
 * علت دقیق عدد مانده را به سه جزء می‌شکند تا هیچ رقم «نامرئی» باعث سوتفاهم نشود:
 *   مانده نهایی = (هزینه‌ی پروژه‌ها − واریزی اسناد پروژه‌ها) − واریزی‌های «بدون پروژه» + پرداختی‌های «بدون پروژه»
 * جفت اسناد برگشت/برگشت‌خورده همیشه خنثی‌اند و جزو مانده نیستند. */
if (!function_exists('cpttf_balance_breakdown_html')) {
	function cpttf_balance_breakdown_html($args){
		$proj_bal = (float)($args['proj_bal'] ?? 0);
		$np_in    = (float)($args['np_in'] ?? 0);
		$np_out   = (float)($args['np_out'] ?? 0);
		$delta    = isset($args['delta']) ? (float)$args['delta'] : ($proj_bal - $np_in + $np_out);
		$np_docs  = (array)($args['np_vouchers'] ?? []);
		$projects = (array)($args['projects'] ?? []);
		$n_in = 0; $n_out = 0;
		foreach ($np_docs as $d) { if ((int)($d['dir'] ?? 1) > 0) $n_in++; else $n_out++; }
		$sg = function($v){ return $v < -0.005 ? ('−' . CPTT_Finance::fmt(abs($v))) : CPTT_Finance::fmt($v); };
		$has_np = ($np_in > 0.005 || $np_out > 0.005);
		?>
		<div class="cpttf-balance-breakdown<?php echo $has_np ? ' has-np' : ''; ?>">
			<div class="cpttf-bbd__line">
				<span class="cpttf-bbd__title">🧮 تفکیک مانده:</span>
				<span class="cpttf-bbd__seg">تراز اسناد پروژه‌ها <b dir="ltr"><?php echo $sg($proj_bal); ?></b></span>
				<span class="cpttf-bbd__op">−</span>
				<span class="cpttf-bbd__seg <?php echo $np_in > 0.005 ? 'is-warn' : ''; ?>">واریزی‌های فعال بدون پروژه <b dir="ltr"><?php echo CPTT_Finance::fmt($np_in); ?></b><?php echo $n_in ? ' <small>(' . $n_in . ' سند)</small>' : ''; ?></span>
				<span class="cpttf-bbd__op">+</span>
				<span class="cpttf-bbd__seg <?php echo $np_out > 0.005 ? 'is-info' : ''; ?>">پرداختی‌های فعال بدون پروژه <b dir="ltr"><?php echo CPTT_Finance::fmt($np_out); ?></b><?php echo $n_out ? ' <small>(' . $n_out . ' سند)</small>' : ''; ?></span>
				<span class="cpttf-bbd__op">=</span>
				<span class="cpttf-bbd__seg cpttf-bbd__seg--total">مانده نهایی <b dir="ltr"><?php echo $sg($delta); ?></b> <small><?php echo $delta > 0.005 ? '(او به ما بدهکار)' : ($delta < -0.005 ? '(ما به او بدهکاریم)' : '(تسویه)'); ?></small></span>
			</div>
			<div class="cpttf-bbd__hint">ℹ️ اسناد «برگشت‌خورده» و «سند برگشت» خودکار خنثی می‌شوند و در مانده بی‌اثرند؛ مانده فقط از اسناد فعال و قراردادها حساب می‌شود.</div>
			<?php if (!empty($np_docs)): ?>
				<details class="cpttf-bbd__npdocs">
					<summary>📄 اسناد بدون پروژه (<?php echo count($np_docs); ?>) — این اسناد مستقیم روی مانده‌ی شخص می‌نشینند</summary>
					<ul>
						<?php foreach ($np_docs as $d): ?>
							<li class="cpttf-bbd__npdoc">
								<span class="cpttf-bbd__npdoc-main">
									<b style="font-family:ui-monospace,monospace;"><?php echo esc_html((string)($d['vno'] ?? '')); ?></b>
									<small style="color:#64748b;"><?php echo esc_html((string)($d['date_fa'] ?? '')); ?></small>
									<span class="<?php echo (int)$d['dir'] > 0 ? 'cpttf-text-success' : 'cpttf-text-danger'; ?>"><?php echo (int)$d['dir'] > 0 ? 'واریز' : 'برداشت'; ?> <b><?php echo CPTT_Finance::fmt((float)$d['amount']); ?></b></span>
									<?php if (!empty($d['desc'])): ?><small class="cpttf-bbd__npdoc-desc"><?php echo esc_html(mb_strimwidth((string)$d['desc'], 0, 70, '…')); ?></small><?php endif; ?>
								</span>
								<?php if (!empty($projects)): ?>
								<span class="cpttf-bbd__npdoc-assign">
									<select data-cpttf-vassign-for="<?php echo (int)$d['id']; ?>">
										<option value="0">انتساب به پروژه…</option>
										<?php foreach ($projects as $pj): ?><option value="<?php echo (int)$pj['id']; ?>"><?php echo esc_html($pj['title']); ?></option><?php endforeach; ?>
									</select>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" data-cpttf-vassign="<?php echo (int)$d['id']; ?>">↪ انتساب</button>
								</span>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</details>
			<?php endif; ?>
		</div>
		<?php
	}
}

/* ── جمع‌آوری داده‌های طرف‌حساب: پروژه‌ها + دفتر معین ── */
function cpttf_person_collect($pid){
	global $wpdb;
	$pid = (int)$pid;
	$t_lgr = CPTT_Finance::tbl_ledger();

	$out = [
		'projects' => [],        // ['id','title','cost','paid','live','bal','ts']
		'cost' => 0.0, 'paid' => 0.0, 'live' => 0.0,
		'rows' => [],            // ledger rows (real + virtual contract)
		'np_in' => 0.0, 'np_out' => 0.0,
	];

	/* پروژه‌های مشتری */
	$live_map = [];
	$t = $t_lgr;
	$ACT = CPTT_Finance::sql_active_cond('l'); // v9.3.0 — فقط اسناد مؤثر
	$lr = $wpdb->get_results(
		"SELECT l.project_id, SUM(l.amount * l.direction) AS live FROM $t l
		 WHERE l.project_id > 0 AND l.type='income' AND l.voucher_kind='receipt' AND $ACT
		 GROUP BY l.project_id"
	);
	if (is_array($lr)) foreach ($lr as $r) $live_map[(int)$r->project_id] = (float)$r->live;

	$pids = [];
	$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
	foreach ($projects as $p) {
		if ((int)get_post_meta($p->ID, '_cptt_client_user_id', true) !== $pid) continue;
		$steps = get_post_meta($p->ID, '_cptt_steps', true);
		$cost = 0.0; $paid = 0.0; $steps_detail = [];
		if (is_array($steps)) foreach ($steps as $st) {
			if (!is_array($st)) continue;
			$sc = (float)($st['cost'] ?? 0); $sp = (float)($st['paid'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance']))
				foreach ($st['extra_finance'] as $ef) { if (is_array($ef)) { $sc += (float)($ef['cost'] ?? 0); $sp += (float)($ef['paid'] ?? 0); } }
			$cost += $sc; $paid += $sp;
			$steps_detail[] = ['sid'=>(string)($st['id'] ?? ''), 'title'=>(string)($st['title'] ?? ($st['name'] ?? '')), 'cost'=>$sc]; // v9.3.0
		}
		$live = isset($live_map[$p->ID]) ? (float)$live_map[$p->ID] : 0.0;
		$ts = strtotime($p->post_date_gmt ?: $p->post_date);
		$pids[] = $p->ID;
		$row = ['id'=>$p->ID,'title'=>get_the_title($p) ?: ('#'.$p->ID),'cost'=>$cost,'paid'=>$paid,'live'=>$live,'bal'=>$cost-$live,'ts'=>$ts,'steps_detail'=>$steps_detail];
		$out['projects'][] = $row;
		$out['cost'] += $cost; $out['paid'] += $paid; $out['live'] += $live;
	}

	/* ردیف‌های دفتری به نام شخص */
	$rows = $wpdb->get_results($wpdb->prepare(
		"SELECT * FROM $t WHERE status IN ('posted','reversed','reversal') AND (customer_id = %d OR expert_id = %d) ORDER BY date_at ASC, id ASC",
		$pid, $pid
	)) ?: [];
	$by_id = [];
	foreach ($rows as $r) $by_id[(int)$r->id] = $r;

	/* ردیف‌های دریافتیِ مرتبط با پروژه‌های او (حتی اگر customer_id خالی باشد) */
	if (!empty($pids)) {
		$in = implode(',', array_map('intval', $pids));
		$rowsJ = $wpdb->get_results(
			"SELECT * FROM $t WHERE status IN ('posted','reversed','reversal') AND type='income' AND project_id IN ($in) ORDER BY date_at ASC, id ASC"
		) ?: [];
		foreach ($rowsJ as $r) $by_id[(int)$r->id] = $r;
	}
	$rows = array_values($by_id);
	usort($rows, function($a,$b){ $d = (int)$a->date_at <=> (int)$b->date_at; return $d ?: ((int)$a->id <=> (int)$b->id); });

	/* ردیف‌های مجازی «قرارداد / هزینه پروژه» به‌عنوان بدهی اولیه
	 * v9.3.0 — به‌تفکیک هر مرحله (عنوان مرحله در صورت‌حساب «بدون جزئیات» نمایش داده می‌شود) */
	foreach ($out['projects'] as $pj) {
		if ($pj['cost'] <= 0) continue;
		$sds = array_values(array_filter((array)($pj['steps_detail'] ?? []), function($sd){ return (float)$sd['cost'] > 0 && (string)$sd['sid'] !== ''; }));
		if (empty($sds)) $sds = [['sid'=>'','title'=>'','cost'=>(float)$pj['cost']]];
		foreach ($sds as $sd) {
			$stitle = trim((string)$sd['title']);
			$out['rows'][] = [
				'virtual' => true, 'id' => 'C' . $pj['id'] . ($sd['sid'] !== '' ? ('-' . $sd['sid']) : ''), 'ts' => $pj['ts'],
				'kind' => 'contract',
				'label' => $stitle !== ''
					? ('🧾 قرارداد / مرحله «' . $stitle . '» — پروژه «' . $pj['title'] . '»')
					: ('🧾 قرارداد / هزینه پروژه «' . $pj['title'] . '»'),
				'desc' => 'ثبت بدهی بابت قرارداد پروژه',
				'vno' => '—',
				'debit' => (float)$sd['cost'], 'credit' => 0.0,
				'project_id' => $pj['id'], 'project_title' => $pj['title'],
				'step_id' => (string)$sd['sid'],
				'status' => 'posted', 'neutral' => false,
			];
		}
	}

	/* ردیف‌های واقعی دفتر */
	foreach ($rows as $r) {
		$dir = (int)$r->direction >= 0 ? 1 : -1;
		$kind = (string)($r->voucher_kind ?: $r->type);
		if ((string)$r->type === 'expert_payout') $kind = 'expert_payout';
		$ptitle = '';
		if (!empty($r->project_id)) { $pp = get_post((int)$r->project_id); $ptitle = $pp ? get_the_title($pp) : ('#' . (int)$r->project_id); }
		$out['rows'][] = [
			'virtual' => false, 'id' => (int)$r->id, 'ts' => (int)$r->date_at,
			'kind' => $kind,
			'label' => CPTT_Finance::voucher_label($r),
			'desc' => (string)$r->description,
			'vno' => (string)($r->voucher_no ?: '#' . (int)$r->id),
			'debit' => $dir < 0 ? (float)$r->amount : 0.0,
			'credit' => $dir > 0 ? (float)$r->amount : 0.0,
			'project_id' => (int)$r->project_id, 'project_title' => $ptitle,
			'step_id' => (string)($r->step_id ?? ''),
			'status' => (string)($r->status ?: 'posted'),
			'neutral' => CPTT_Finance::is_row_neutral($r), // v9.3.0 — خنثی‌سازی جفت‌آگاه
		];
		// v9.2.55 — طرف حسابداریِ «سهم کارشناس»: پرداخت‌های تسویه‌ی کارشناس که
		// به پروژه پیوند دارند بدون ردیف مقابل می‌مانند و مانده‌ی معین را نادرست
		// بدهکار نشان می‌دهند؛ پس ردیف مجازیِ خنثی‌کننده (به همان مبلغ و جهت برعکس)
		// درست قبل از سند تسویه درج می‌شود. (فقط نمایشی؛ دفتر اصلی دست نمی‌خورد.)
		if ($kind === 'expert_payout' && (int)$r->project_id > 0) {
			$out['rows'][] = [
				'virtual' => true, 'id' => 'S' . (int)$r->id, 'ts' => (int)$r->date_at - 1,
				'kind' => 'expert_share',
				'label' => '👤 سهم کارشناس از پروژه «' . ($ptitle ?: ('#' . (int)$r->project_id)) . '»',
				'desc' => 'ثبت بدهی سهم کارشناس (هم‌زمان با تسویه)',
				'vno' => (string)($r->voucher_no ?: '#' . (int)$r->id),
				'debit' => $dir > 0 ? (float)$r->amount : 0.0,   // آینه‌ی سند تسویه
				'credit' => $dir < 0 ? (float)$r->amount : 0.0,
				'project_id' => (int)$r->project_id, 'project_title' => $ptitle,
				'step_id' => (string)($r->step_id ?? ''),
				'status' => (string)($r->status ?: 'posted'),
				'neutral' => CPTT_Finance::is_row_neutral($r),
			];
		}
	}

	/* سورت نهایی: تاریخ، قرارداد قبل از اسناد همان روز، بعد شناسه */
	usort($out['rows'], function($a,$b){
		$d = (int)$a['ts'] <=> (int)$b['ts']; if ($d) return $d;
		$va = $a['virtual'] ? 0 : 1; $vb = $b['virtual'] ? 0 : 1; if ($va !== $vb) return $va <=> $vb;
		return strcmp((string)$a['id'], (string)$b['id']);
	});
	return $out;
}

/* ── فیلتر و مانده‌ی متحرک برای دفتر معین ── */
function cpttf_person_ledger_filtered($collect){
	$f_from = isset($_GET['ffrom']) ? sanitize_text_field(wp_unslash($_GET['ffrom'])) : '';
	$f_to   = isset($_GET['fto'])   ? sanitize_text_field(wp_unslash($_GET['fto']))   : '';
	$f_kind = isset($_GET['fkind']) ? sanitize_key($_GET['fkind']) : '';
	$f_type = isset($_GET['ftype2'])? sanitize_key($_GET['ftype2']) : '';
	$f_q    = isset($_GET['fq'])    ? sanitize_text_field(wp_unslash($_GET['fq']))    : '';

	$ts_from = $f_from !== '' ? CPTT_Finance::parse_jalali_local($f_from) : 0;
	$ts_to   = $f_to   !== '' ? CPTT_Finance::parse_jalali_local($f_to . ' 23:59') : 0;

	$opening = 0.0;
	$shown = [];
	foreach ($collect['rows'] as $row) {
		// مانده‌ی اول دوره = جمع همه‌ی ردیف‌های قبل از «از تاریخ»
		// v9.3.0 — ردیف‌های خنثی (جفت برگشت) نه در مانده نه در جمع‌ها حساب می‌شوند (فقط نمایش)
		if ($ts_from && (int)$row['ts'] < $ts_from) { if (empty($row['neutral'])) $opening += $row['debit'] - $row['credit']; continue; }
		if ($ts_from && (int)$row['ts'] < $ts_from) continue;
		if ($ts_to && (int)$row['ts'] > $ts_to) continue;
		if ($f_kind === 'debit'  && $row['debit']  <= 0) { if (!$ts_from) continue; continue; }
		if ($f_kind === 'credit' && $row['credit'] <= 0) continue;
		if ($f_type !== '' && $f_type !== 'all') {
			$k = $row['kind'];
			$ok = ($f_type === 'contract' && $k === 'contract')
			   || ($f_type === 'receipt'  && $k === 'receipt')
			   || ($f_type === 'payment'  && in_array($k, ['payment','expert_payout'], true));
			if (!$ok) { continue; }
		}
		if ($f_q !== '') {
			$hay = function_exists('norm_key') ? norm_key($row['label'] . ' ' . $row['desc'] . ' ' . $row['vno'] . ' ' . $row['project_title']) : mb_strtolower($row['label'] . ' ' . $row['desc'] . ' ' . $row['vno'] . ' ' . $row['project_title']);
			$nd  = function_exists('norm_key') ? norm_key($f_q) : mb_strtolower($f_q);
			if (mb_strpos($hay, $nd) === false) continue;
		}
		$shown[] = $row;
	}

	$run = $opening; $td = 0.0; $tc = 0.0;
	foreach ($shown as &$row) {
		if (!empty($row['neutral'])) { $row['running'] = $run; continue; } // خنثی: مانده را تغییر نمی‌دهد
		$run += $row['debit'] - $row['credit'];
		$row['running'] = $run;
		$td += $row['debit']; $tc += $row['credit'];
	}
	unset($row);

	return [
		'rows' => $shown, 'opening' => $opening, 'closing' => $run,
		'total_debit' => $td, 'total_credit' => $tc,
		'filters' => ['ffrom'=>$f_from,'fto'=>$f_to,'fkind'=>$f_kind,'ftype2'=>$f_type,'fq'=>$f_q],
	];
}

/* ── خروجی CSV صورتحساب (در admin_init و قبل از هر خروجی صدا زده می‌شود) ── */
function cpttf_person_statement_csv($pid){
	$pid = (int)$pid;
	$u = get_user_by('id', $pid);
	if (!$u) { wp_die('person_not_found'); }
	$collect = cpttf_person_collect($pid);
	$L = cpttf_person_ledger_filtered($collect);
	$profile = CPTT_Finance::get_party_profile($pid);

	$fname = 'statement-' . $pid . '-' . date('Ymd-Hi') . '.csv';
	nocache_headers();
	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename="' . $fname . '"');
	$out = fopen('php://output', 'w');
	fwrite($out, "\xEF\xBB\xBF"); // BOM برای Excel
	fputcsv($out, ['صورتحساب طرف حساب: ' . $u->display_name . ' (' . $profile['code'] . ')']);
	if ($L['filters']['ffrom'] || $L['filters']['fto'])
		fputcsv($out, ['بازه: ' . ($L['filters']['ffrom'] ?: '…') . ' تا ' . ($L['filters']['fto'] ?: '…')]);
	fputcsv($out, []);
	fputcsv($out, ['تاریخ', 'شرح', 'مرجع/سند', 'پروژه', 'بدهکار', 'بستانکار', 'مانده']);
	if ($L['opening'] != 0) fputcsv($out, ['', 'مانده اول دوره', '', '', '', '', (string)(int)$L['opening']]);
	foreach ($L['rows'] as $r) {
		if (!empty($r['neutral'])) continue; // v9.3.0 — اسناد برگشتی/برگشت‌خورده در صورتحساب نمی‌آیند
		fputcsv($out, [
			CPTT_Finance::fa_date($r['ts']),
			trim($r['label'] . ' — ' . $r['desc'], ' —'),
			$r['vno'], $r['project_title'],
			$r['debit'] > 0 ? (string)(int)$r['debit'] : '',
			$r['credit'] > 0 ? (string)(int)$r['credit'] : '',
			(string)(int)$r['running'],
		]);
	}
	fputcsv($out, []);
	fputcsv($out, ['', 'جمع', '', '', (string)(int)$L['total_debit'], (string)(int)$L['total_credit'], '']);
	fputcsv($out, ['', 'مانده پایان دوره', '', '', '', '', (string)(int)$L['closing'] . ($L['closing'] > 0 ? ' (بدهکار)' : ($L['closing'] < 0 ? ' (بستانکار)' : ''))]);
	fclose($out);
	exit;
}

/* ── صورتحساب چاپی v2 (v9.2.56) — دو حالت «با جزئیات / بدون جزئیات»، A4/A5، فونت وزیرمتن ── */
function cpttf_person_statement_print($pid){
	$pid = (int)$pid;
	$u = get_user_by('id', $pid);
	if (!$u) { wp_die('person_not_found'); }
	$collect = cpttf_person_collect($pid);
	$L = cpttf_person_ledger_filtered($collect);
	$profile = CPTT_Finance::get_party_profile($pid);
	$cur = CPTT_Finance::currency_label();
	$layout = (isset($_GET['layout']) && sanitize_key($_GET['layout']) === 'summary') ? 'summary' : 'detail';
	$paper  = (isset($_GET['paper'])  && sanitize_key($_GET['paper'])  === 'a5') ? 'a5' : 'a4';
	$dir_txt  = $L['closing'] > 0 ? 'بدهکار' : ($L['closing'] < 0 ? 'بستانکار' : 'تسویه');
	$badge_cls = $L['closing'] > 0 ? 'debt' : ($L['closing'] < 0 ? 'credit' : 'even');
	$f = $L['filters'];
	$period = ($f['ffrom'] || $f['fto']) ? ('بازه: ' . ($f['ffrom'] ?: '…') . ' تا ' . ($f['fto'] ?: '…')) : 'کل دوره';
	$fonts = CPTT_URL . 'assets/fonts/';

	/* تجمیع «بدون جزئیات»: به تفکیک هر پروژه + سطر «بدون پروژه» */
	$grp = [];
	if ($layout === 'summary') {
		// v9.3.0 — گروه‌بندی به‌تفکیک «پروژه — مرحله» (فقط عنوان مرحله/پروژه در شرح می‌آید)
		// و حذف کامل اسناد برگشتی/برگشت‌خورده (خنثی) از صورتحساب
		$step_titles = [];
		foreach ((array)$collect['projects'] as $pj) {
			foreach ((array)($pj['steps_detail'] ?? []) as $sd) {
				$step_titles[(int)$pj['id'] . '|' . (string)$sd['sid']] = (string)$sd['title'];
			}
		}
		foreach ($L['rows'] as $r) {
			if (!empty($r['neutral'])) continue;
			$pid = (int)$r['project_id'];
			$sid = $pid > 0 ? (string)($r['step_id'] ?? '') : '';
			$key = $pid > 0 ? ('p' . $pid . '|' . $sid) : 'np';
			if (!isset($grp[$key])) {
				if ($pid > 0) {
					$pt = (string)$r['project_title'] !== '' ? (string)$r['project_title'] : ('#' . $pid);
					$st = ($sid !== '' && isset($step_titles[$pid . '|' . $sid])) ? trim($step_titles[$pid . '|' . $sid]) : '';
					$title = $st !== '' ? ($pt . ' — ' . $st) : $pt;
				} else {
					$title = '— اسناد بدون پروژه —';
				}
				$grp[$key] = ['title' => $title, 'debit' => 0.0, 'credit' => 0.0];
			}
			$grp[$key]['debit']  += (float)$r['debit'];
			$grp[$key]['credit'] += (float)$r['credit'];
		}
	}
	?><!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>صورتحساب — <?php echo esc_html($u->display_name); ?></title>
<style>
@font-face{font-family:'Vazirmatn';font-style:normal;font-weight:400;font-display:swap;src:url('<?php echo esc_url($fonts . 'Vazirmatn-Regular.woff2'); ?>') format('woff2');}
@font-face{font-family:'Vazirmatn';font-style:normal;font-weight:500;font-display:swap;src:url('<?php echo esc_url($fonts . 'Vazirmatn-Medium.woff2'); ?>') format('woff2');}
@font-face{font-family:'Vazirmatn';font-style:normal;font-weight:700;font-display:swap;src:url('<?php echo esc_url($fonts . 'Vazirmatn-Bold.woff2'); ?>') format('woff2');}
@page{size:<?php echo $paper === 'a5' ? 'A5 portrait' : 'A4 portrait'; ?>;margin:<?php echo $paper === 'a5' ? '8mm' : '11mm'; ?>;}
*{box-sizing:border-box;}
body{font-family:'Vazirmatn',Tahoma,Arial,sans-serif;color:#0f172a;margin:14px auto;max-width:<?php echo $paper === 'a5' ? '140mm' : '190mm'; ?>;font-size:<?php echo $paper === 'a5' ? '9px' : '10.5px'; ?>;line-height:1.7;background:#fff;}
h1{font-size:<?php echo $paper === 'a5' ? '14px' : '18px'; ?>;margin:0 0 4px;font-weight:700;}
.st-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;border-bottom:2.5px solid #1e293b;padding-bottom:10px;margin-bottom:10px;}
.st-meta{font-size:.9em;color:#475569;line-height:1.9;}
table{width:100%;border-collapse:collapse;margin-top:6px;table-layout:fixed;}
th,td{border:1px solid #cbd5e1;padding:3px 5px;text-align:right;vertical-align:top;overflow-wrap:anywhere;}
th{background:#f1f5f9;font-size:.9em;font-weight:700;}
td{line-height:1.55;}
td.num,th.num{text-align:left;direction:ltr;white-space:nowrap;font-variant-numeric:tabular-nums;}
tr.tot td{font-weight:700;background:#f8fafc;}
tr.khane{color:#94a3b8;}
.khane-chip{display:inline-block;background:#f1f5f9;color:#94a3b8;border-radius:6px;padding:0 6px;font-size:.8em;font-weight:500;}
.desc{display:block;font-size:.85em;color:#64748b;line-height:1.5;}
.badge{display:inline-block;padding:1px 10px;border-radius:999px;font-size:.88em;font-weight:700;}
.badge.debt{background:#fef3c7;color:#b45309;} .badge.credit{background:#ede9fe;color:#6d28d9;} .badge.even{background:#ecfdf5;color:#059669;}
.st-cards{display:flex;gap:8px;margin:8px 0 4px;}
.st-card{flex:1;border:1px solid #cbd5e1;border-radius:10px;padding:5px 8px;text-align:center;}
.st-card>small{display:block;color:#64748b;font-size:.8em;}
.st-card b{font-size:1.12em;}
.st-note{font-size:.8em;color:#94a3b8;margin-top:6px;}
.st-foot{display:flex;justify-content:space-between;gap:24px;margin-top:32px;font-size:.9em;color:#334155;}
.st-sign{flex:1;border-top:1px dashed #94a3b8;padding-top:8px;text-align:center;}
.no-print{position:sticky;top:0;background:#fff;border-bottom:1px solid #e2e8f0;padding:8px 0 12px;margin-bottom:12px;z-index:5;}
.no-print form{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end;}
.no-print label{font-size:.82em;color:#475569;display:flex;flex-direction:column;gap:3px;font-weight:500;}
.no-print select,.no-print input{font-family:inherit;font-size:.95em;padding:5px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;}
.no-print button{font-family:inherit;padding:7px 16px;border-radius:8px;border:1.5px solid #1e293b;background:#1e293b;color:#fff;cursor:pointer;font-weight:700;font-size:.92em;}
.no-print button.ghost{background:#fff;color:#1e293b;}
@media print{ .no-print{display:none!important;} body{margin:0 auto;max-width:none;} }
</style></head>
<body class="<?php echo esc_attr($paper . ' ' . $layout); ?>">
<div class="no-print">
	<form method="get" action="">
		<input type="hidden" name="page" value="cptt-finance-persons">
		<input type="hidden" name="pid" value="<?php echo (int)$pid; ?>">
		<input type="hidden" name="stmt" value="print">
		<?php foreach (['ffrom','fto','fkind','ftype2','fq'] as $qk): if (!empty($f[$qk])): ?><input type="hidden" name="<?php echo esc_attr($qk); ?>" value="<?php echo esc_attr($f[$qk]); ?>"><?php endif; endforeach; ?>
		<label>نوع صورتحساب
			<select name="layout" onchange="this.form.submit()">
				<option value="detail" <?php selected($layout, 'detail'); ?>>با جزئیات (سند‌به‌سند)</option>
				<option value="summary" <?php selected($layout, 'summary'); ?>>بدون جزئیات (خلاصه)</option>
			</select>
		</label>
		<label>کاغذ
			<select name="paper" onchange="this.form.submit()">
				<option value="a4" <?php selected($paper, 'a4'); ?>>A4</option>
				<option value="a5" <?php selected($paper, 'a5'); ?>>A5</option>
			</select>
		</label>
		<noscript><button type="submit" class="ghost">اعمال</button></noscript>
		<button type="button" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
		<button type="button" class="ghost" onclick="window.close()">بستن</button>
	</form>
</div>

<div class="st-head">
	<div>
		<h1>صورتحساب گردش طرف حساب<?php echo $layout === 'summary' ? ' (خلاصه)' : ''; ?></h1>
		<div class="st-meta">
			نام: <b><?php echo esc_html($u->display_name); ?></b> · کد: <?php echo esc_html($profile['code']); ?> · <?php echo $profile['type'] === 'legal' ? 'شخص حقوقی' : 'شخص حقیقی'; ?><?php if (!empty($profile['roles'])): ?> · نقش‌ها: <?php echo esc_html(implode('، ', $profile['roles'])); ?><?php endif; ?><br>
			<?php if (!empty($profile['phone'])): ?>تلفن: <?php echo esc_html($profile['phone']); ?> · <?php endif; ?>مانده حساب: <span class="badge <?php echo esc_attr($badge_cls); ?>"><?php echo CPTT_Finance::fmt(abs($L['closing'])) . ' ' . esc_html($cur) . ' ' . $dir_txt; ?></span>
		</div>
	</div>
	<div class="st-meta" style="text-align:left;flex-shrink:0;">
		تاریخ صدور: <?php echo esc_html(CPTT_Finance::fa_date(time())); ?><br>
		<?php echo esc_html($period); ?> · کاغذ <?php echo strtoupper($paper); ?>
	</div>
</div>

<?php if ($layout === 'summary'): ?>
	<div class="st-cards">
		<div class="st-card"><small>مانده اول دوره</small><b><?php echo CPTT_Finance::fmt($L['opening']); ?></b></div>
		<div class="st-card"><small>جمع بدهکار (گردش دوره)</small><b><?php echo CPTT_Finance::fmt($L['total_debit']); ?></b></div>
		<div class="st-card"><small>جمع بستانکار (گردش دوره)</small><b><?php echo CPTT_Finance::fmt($L['total_credit']); ?></b></div>
		<div class="st-card"><small>مانده پایان دوره</small><b><?php echo CPTT_Finance::fmt($L['closing']); ?> <small><?php echo esc_html($dir_txt); ?></small></b></div>
	</div>
	<table>
		<thead><tr><th style="width:30px;">#</th><th>بخش حساب</th><th class="num" style="width:100px;">بدهکار</th><th class="num" style="width:100px;">بستانکار</th><th class="num" style="width:100px;">خالص</th></tr></thead>
		<tbody>
		<?php $i = 1; foreach ($grp as $g): $net = (float)$g['debit'] - (float)$g['credit']; ?>
			<tr>
				<td><?php echo $i++; ?></td>
				<td><?php echo esc_html($g['title']); ?></td>
				<td class="num"><?php echo $g['debit'] > 0 ? CPTT_Finance::fmt($g['debit']) : ''; ?></td>
				<td class="num"><?php echo $g['credit'] > 0 ? CPTT_Finance::fmt($g['credit']) : ''; ?></td>
				<td class="num"><?php echo CPTT_Finance::fmt($net); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if (empty($grp)): ?><tr><td colspan="5" style="text-align:center;color:#94a3b8;">گردشی در این محدوده نیست.</td></tr><?php endif; ?>
			<tr class="tot"><td colspan="2">جمع گردش دوره</td><td class="num"><?php echo CPTT_Finance::fmt($L['total_debit']); ?></td><td class="num"><?php echo CPTT_Finance::fmt($L['total_credit']); ?></td><td class="num"></td></tr>
			<tr class="tot"><td colspan="2">مانده اول دوره</td><td class="num" colspan="2"></td><td class="num"><?php echo CPTT_Finance::fmt($L['opening']); ?></td></tr>
			<tr class="tot"><td colspan="2"><b>مانده پایان دوره (<?php echo esc_html($dir_txt); ?>)</b></td><td class="num" colspan="2"></td><td class="num"><b><?php echo CPTT_Finance::fmt($L['closing']); ?></b></td></tr>
		</tbody>
	</table>
<?php else: ?>
	<table>
		<thead><tr>
			<th style="width:24px;">#</th><th style="width:74px;">تاریخ</th><th>شرح</th><th style="width:86px;">سند</th>
			<th class="num" style="width:82px;">بدهکار</th><th class="num" style="width:82px;">بستانکار</th><th class="num" style="width:82px;">مانده</th>
		</tr></thead>
		<tbody>
		<?php if ($L['opening'] != 0): ?>
			<tr><td></td><td colspan="5"><b>مانده اول دوره</b></td><td class="num"><b><?php echo CPTT_Finance::fmt($L['opening']); ?></b></td></tr>
		<?php endif; ?>
		<?php
		// v9.3.0 — اسناد برگشتی/برگشت‌خورده (خنثی) اصلاً در صورتحساب چاپی نمی‌آیند
		$prows = array_values(array_filter($L['rows'], function($r){ return empty($r['neutral']); }));
		$i = 1; foreach ($prows as $r):
			$kh = false;
			$desc = (string)$r['desc'];
			$cut = mb_strpos($desc, ' | اصل:');
			if ($cut !== false) $desc = mb_substr($desc, 0, $cut);
			$desc = mb_strimwidth(trim($desc), 0, 110, '…');
		?>
			<tr<?php echo $kh ? ' class="khane"' : ''; ?>>
				<td><?php echo $i++; ?></td>
				<td><?php echo esc_html(cpttf_person_jdate_only($r['ts'])); ?></td>
				<td>
					<?php echo esc_html($r['label']); ?><?php echo $kh ? ' <span class="khane-chip">خنثی</span>' : ''; ?>
					<?php if (!$r['virtual'] && $desc !== ''): ?><span class="desc"><?php echo esc_html($desc); ?></span><?php endif; ?>
					<?php if ((string)$r['project_title'] !== ''): ?><span class="desc">📁 <?php echo esc_html($r['project_title']); ?></span><?php endif; ?>
				</td>
				<td style="font-family:ui-monospace,monospace;font-size:.85em;"><?php echo esc_html($r['vno']); ?></td>
				<td class="num"><?php echo $r['debit'] > 0 ? CPTT_Finance::fmt($r['debit']) : ''; ?></td>
				<td class="num"><?php echo $r['credit'] > 0 ? CPTT_Finance::fmt($r['credit']) : ''; ?></td>
				<td class="num"><?php echo CPTT_Finance::fmt($r['running']); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if (empty($prows)): ?><tr><td colspan="7" style="text-align:center;color:#94a3b8;">ردیفی در این محدوده نیست.</td></tr><?php endif; ?>
			<tr class="tot"><td colspan="4">جمع</td><td class="num"><?php echo CPTT_Finance::fmt($L['total_debit']); ?></td><td class="num"><?php echo CPTT_Finance::fmt($L['total_credit']); ?></td><td class="num"></td></tr>
			<tr class="tot"><td colspan="4"><b>مانده پایان دوره (<?php echo esc_html($dir_txt); ?>)</b></td><td class="num" colspan="2"></td><td class="num"><b><?php echo CPTT_Finance::fmt($L['closing']); ?></b></td></tr>
		</tbody>
	</table>
<?php endif; ?>
<p class="st-note">اسناد «برگشت‌خورده» و «سند برگشت» در این صورتحساب لحاظ نشده‌اند (نه در ردیف‌ها نه در جمع‌ها) · ارقام به <?php echo esc_html($cur); ?> است.</p>
<div class="st-foot">
	<div class="st-sign">مهر و امضای صادرکننده</div>
	<div class="st-sign">امضای طرف حساب (مبنی بر تایید صورتحساب)</div>
</div>
</body></html><?php
	exit;
}

/* ── رندر پرونده شخص (۴ تب) ── */
function cpttf_render_person($pid){
	$pid = (int)$pid;
	$u = get_user_by('id', $pid);
	$back = admin_url('admin.php?page=cptt-finance-persons');
	$base = admin_url('admin.php?page=cptt-finance-persons&pid=' . $pid);
	if (!$u) {
		echo '<div class="cpttf-card" style="padding:20px;"><p>شخص یافت نشد.</p><a class="cpttf-btn cpttf-btn--ghost" href="' . esc_url($back) . '">↩ بازگشت به لیست اشخاص</a></div>';
		return;
	}
	$profile = CPTT_Finance::get_party_profile($pid);
	$collect = cpttf_person_collect($pid);
	// گردش‌های «بدون پروژه» از روی همان ردیف‌های دفتر (هم‌خوان با لیست اشخاص)
	// v9.2.56 — فقط اسناد «فعال» لحاظ می‌شوند؛ جفت‌های برگشت/برگشت‌خورده خنثی‌اند
	// (خنثی‌سازی جفت سالم نتیجه را عوض نمی‌کند، اما برای داده‌ی نیمه‌جفت هم خطایی رخ نمی‌دهد)
	$np_in = 0.0; $np_out = 0.0;
	foreach ($collect['rows'] as $__r) {
		if (!empty($__r['virtual'])) continue;
		if ((int)$__r['project_id'] > 0) continue;
		if ((string)($__r['status'] ?? 'posted') !== 'posted') continue;
		if (!empty($__r['neutral'])) continue; // v9.3.0
		$np_in += (float)$__r['credit']; $np_out += (float)$__r['debit'];
	}
	$delta = round(($collect['cost'] - $collect['live']) - $np_in + $np_out, 2);
	$kind = $delta > 0.005 ? 'debt' : ($delta < -0.005 ? 'credit' : 'even');
	$cur = CPTT_Finance::currency_label();
	$ptab = isset($_GET['ptab']) ? sanitize_key($_GET['ptab']) : 'overview';
	$tx_base = admin_url('admin.php?page=cptt-finance-transactions');

	$tab_link = function($t) use ($base, $ptab) {
		$href = add_query_arg(['ptab' => $t], $base);
		return '<a class="cpttf-app__tab cpttf-ptab' . ($ptab === $t ? ' is-active' : '') . '" href="' . esc_url($href) . '">';
	};
	?>
	<section class="cpttf-card cpttf-personhead">
		<div class="cpttf-personhead__main">
			<div class="cpttf-debtor__avatar" style="width:52px;height:52px;font-size:20px;"><?php echo esc_html(mb_substr($u->display_name, 0, 1)); ?></div>
			<div>
				<h2 style="margin:0;"><?php echo esc_html($u->display_name); ?> <?php if (!$profile['active']): ?><span class="cpttf-chip cpttf-chip--muted">غیرفعال</span><?php endif; ?></h2>
				<div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:6px;">
					<span class="cpttf-tag" style="background:#eef2ff;color:#4338ca;">🆔 <?php echo esc_html($profile['code']); ?></span>
					<span class="cpttf-tag" style="background:#f1f5f9;color:#475569;"><?php echo $profile['type']==='legal' ? '🏢 شخص حقوقی' : '👤 شخص حقیقی'; ?></span>
					<?php foreach ($profile['roles'] as $rl): ?><span class="cpttf-tag" style="background:#ecfdf5;color:#059669;"><?php echo esc_html($rl); ?></span><?php endforeach; ?>
					<?php if ($profile['phone']): ?><span class="cpttf-tag" style="background:#f8fafc;color:#64748b;">📞 <?php echo esc_html($profile['phone']); ?></span><?php endif; ?>
				</div>
			</div>
		</div>
		<div class="cpttf-personhead__side">
			<div class="cpttf-person__delta cpttf-person__delta--<?php echo esc_attr($kind); ?>" style="min-width:170px;">
				<?php if ($kind === 'debt'): ?><small>به ما بدهکار</small><?php elseif ($kind === 'credit'): ?><small>به ایشان بدهکاریم</small><?php else: ?><small>تسویه</small><?php endif; ?>
				<b><?php echo CPTT_Finance::fmt(abs($delta)); ?> <small style="font-size:10px;"><?php echo esc_html($cur); ?></small></b>
			</div>
			<div class="cpttf-person__actions" style="margin:10px 0 0;justify-content:flex-end;">
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new'=>'income','person'=>$pid], $tx_base)); ?>">+ دریافت</a>
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--danger" href="<?php echo esc_url(add_query_arg(['new'=>'expense','person'=>$pid], $tx_base)); ?>">+ پرداخت</a>
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['new'=>1,'person'=>$pid], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">+ فاکتور</a>
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="#" data-stmt-link data-url="<?php echo esc_url(add_query_arg(['stmt'=>'print'], $base)); ?>">🖨 صدور صورتحساب</a>
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url($back); ?>">↩ لیست</a>
			</div>
		</div>
	</section>

	<nav class="cpttf-ptabs">
		<?php echo $tab_link('overview'); ?>📊 نمای کلی</a>
		<?php echo $tab_link('invoices'); ?>🧾 فاکتورها</a>
		<?php echo $tab_link('ledger'); ?>📒 دفتر معین</a>
		<?php echo $tab_link('projects'); ?>📁 پروژه‌ها</a>
		<?php echo $tab_link('profile'); ?>🪪 اطلاعات شخص</a>
	</nav>

	<?php
	// v9.2.57 — باگ‌فیکس حیاتی: در سینتکس جایگزین (colon) نمی‌توان قبل از elseif
	// یک if تو‌داخل داشت (گرامر PHP، elseif را به if داخلی می‌چسباند)؛ نسخه‌ی براکتی امن است.
	if ($ptab === 'ledger') {
		cpttf_person_tab_ledger($pid, $u, $collect, $base);
	} elseif ($ptab === 'invoices') {
		require_once CPTT_PATH . 'includes/finance/page-invoices.php';
		if (function_exists('cpttf_person_invoices_block')) cpttf_person_invoices_block($pid);
	} elseif ($ptab === 'projects') {
		cpttf_person_tab_projects($pid, $u, $collect);
	} elseif ($ptab === 'profile') {
		cpttf_person_tab_profile($pid, $u, $profile);
	} else {
		cpttf_person_tab_overview($pid, $u, $collect, $profile, $delta);
	}
	?>

	<script>
	(function(){
		function $$(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); }
		/* دکمه‌های چاپ/CSV: با window.open در تب جدید باز می‌شوند تا پنل توکار حفظ شود */
		$$('[data-stmt-link]').forEach(function(a){
			a.addEventListener('click', function(e){
				e.preventDefault();
				e.stopPropagation();
				var url = a.getAttribute('data-url') || '';
				/* فیلترهای جاری دفتر معین را به صورتحساب منتقل کن */
				try {
					var u = new URL(url, window.location.href);
					var ps = new URLSearchParams(window.location.search);
					['ffrom','fto','fkind','ftype2','fq','layout','paper'].forEach(function(k){ if (ps.get(k)) u.searchParams.set(k, ps.get(k)); });
					url = u.toString();
				} catch(_){}
				window.open(url, '_blank');
			});
		});
		/* v9.2.56 — انتساب سند «بدون پروژه» به پروژه */
		if (!window.__cpttfVAssignBound) {
			window.__cpttfVAssignBound = true;
			document.addEventListener('click', function(e){
				var b = e.target.closest('[data-cpttf-vassign]');
				if (!b) return;
				e.preventDefault(); e.stopPropagation();
				var id = b.getAttribute('data-cpttf-vassign');
				var sel = document.querySelector('select[data-cpttf-vassign-for="' + id + '"]');
				var pid = sel ? (parseInt(sel.value, 10) || 0) : 0;
				if (!pid) { window.alert('ابتدا پروژه را انتخاب کنید.'); return; }
				if (!window.confirm('سند به پروژه انتخاب‌شده پیوند بخورد؟ مانده‌ی مراحل پروژه همزمان همگام می‌شود (جمع کل حساب شخص تغییر نمی‌کند).')) return;
				var CFG = window.CPTT_FIN || { ajax:'', nonce:'' };
				var fd = new FormData();
				fd.append('action','cptt_fin_voucher_assign'); fd.append('nonce', CFG.nonce);
				fd.append('id', id); fd.append('project_id', pid);
				var x = new XMLHttpRequest(); x.open('POST', CFG.ajax);
				b.disabled = true;
				x.onload = function(){ var r = null; try{ r = JSON.parse(x.responseText); }catch(_){}
					if (r && r.success) { if (window.cpttfReload) window.cpttfReload(); else window.location.reload(); }
					else { b.disabled = false; window.alert((r && r.data) ? r.data : 'خطا در انتساب'); }
				};
				x.onerror = function(){ b.disabled = false; window.alert('خطای ارتباط'); };
				x.send(fd);
			}, true);
		}
	})();
	</script>
	<?php
}

/* ── تب نمای کلی ── */
function cpttf_person_tab_overview($pid, $u, $collect, $profile, $delta){
	$cur = CPTT_Finance::currency_label();
	$tx_base = admin_url('admin.php?page=cptt-finance-transactions');
	// مجموع دریافت/پرداخت واقعی از ردیف‌های دفتر
	$in = 0.0; $out = 0.0; $n = 0; $last = 0;
	foreach ($collect['rows'] as $r) {
		if (!empty($r['virtual'])) continue;
		if (!empty($r['neutral'])) continue; // v9.3.0 — برگشتی‌ها در کارت‌های «مجموع دریافت/پرداخت» حساب نمی‌شوند
		$in  += $r['credit']; $out += $r['debit']; $n++;
		if ((int)$r['ts'] > $last) $last = (int)$r['ts'];
	}
	$open_projects = array_values(array_filter($collect['projects'], function($pj){ return $pj['bal'] > 0.005; }));
	$over_projects = array_values(array_filter($collect['projects'], function($pj){ return $pj['bal'] < -0.005; }));
	$k = function($icon,$label,$value,$color='',$sub=''){
		return '<div class="cpttf-kpi" style="--c:' . esc_attr($color ?: '#64748b') . '"><div class="cpttf-kpi__icon">' . $icon . '</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">' . esc_html($label) . '</span><strong class="cpttf-kpi__value">' . $value . '</strong>' . ($sub !== '' ? '<small class="cpttf-kpi__sub">' . esc_html($sub) . '</small>' : '') . '</div></div>';
	};
	?>
	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4" style="margin-bottom:14px;">
		<?php
		echo $k('🧾','جمع بدهی ایجادشده (قراردادها + پرداختی‌ها)', CPTT_Finance::fmt($collect['cost'] + $out) . ' <small>' . esc_html($cur) . '</small>', '#f59e0b');
		echo $k('📥','مجموع دریافت‌ها', CPTT_Finance::fmt($in) . ' <small>' . esc_html($cur) . '</small>', '#16a34a');
		echo $k('📤','مجموع پرداخت‌ها به ایشان', CPTT_Finance::fmt($out) . ' <small>' . esc_html($cur) . '</small>', '#ef4444');
		echo $k('⚖️','مانده حساب', ($delta > 0.005 ? CPTT_Finance::fmt($delta) . ' <small>بدهکار</small>' : ($delta < -0.005 ? CPTT_Finance::fmt(-$delta) . ' <small>بستانکار</small>' : '۰ <small>تسویه</small>')), $delta > 0.005 ? '#b45309' : ($delta < -0.005 ? '#6d28d9' : '#059669'));
		echo $k('📄','تعداد اسناد مالی', CPTT_Finance::fmt($n), '#0ea5e9');
		echo $k('📁','تعداد پروژه‌ها', CPTT_Finance::fmt(count($collect['projects'])), '#8b5cf6');
		echo $k('🕐','آخرین تراکنش', '<small style="font-size:13px;">' . esc_html(CPTT_Finance::fa_date($last)) . '</small>', '#64748b');
		echo $k('🏦','شبا / حساب', '<small style="font-size:12px;direction:ltr;">' . esc_html($profile['iban'] !== '' ? $profile['iban'] : ($profile['bank_account'] !== '' ? $profile['bank_account'] : '—')) . '</small>', '#06b6d4');
		$invk = cpttf_person_invoice_kpi($pid); // v9.2.56
		echo $k('🧾','فاکتورهای باز', CPTT_Finance::fmt($invk['n']) . ' <small>فاکتور</small>', '#7c3aed', 'مانده: ' . CPTT_Finance::fmt($invk['remain']) . ' ' . $cur);
		echo $k('⏰','سررسید گذشته', CPTT_Finance::fmt($invk['over_n']) . ' <small>فاکتور</small>', $invk['over_n'] > 0 ? '#dc2626' : '#94a3b8', $invk['over_n'] > 0 ? ('مانده: ' . CPTT_Finance::fmt($invk['over_remain']) . ' ' . $cur) : 'موردی نیست');
	?>
	</div>

	<?php
	// v9.2.56 — تفکیک مانده: علت دقیق عدد نهایی + اسناد بدون پروژه + ابزار انتساب
	$_np_docs = [];
	foreach ($collect['rows'] as $__r) {
		if (!empty($__r['virtual'])) continue;
		if ((int)$__r['project_id'] > 0) continue;
		if ((string)($__r['status'] ?? 'posted') !== 'posted') continue;
		if (!empty($__r['neutral'])) continue; // v9.3.0
		$_amt = $__r['credit'] > 0 ? (float)$__r['credit'] : (float)$__r['debit'];
		$_np_docs[] = [
			'id' => (int)$__r['id'], 'vno' => (string)$__r['vno'],
			'date_fa' => CPTT_Finance::fa_date($__r['ts']),
			'dir' => $__r['credit'] > 0 ? 1 : -1, 'amount' => $_amt,
			'desc' => (string)$__r['desc'],
		];
	}
	$_np_docs = array_reverse($_np_docs);
	$_np_in2 = 0.0; $_np_out2 = 0.0;
	foreach ($_np_docs as $__d) { if ($__d['dir'] > 0) $_np_in2 += (float)$__d['amount']; else $_np_out2 += (float)$__d['amount']; }
	cpttf_balance_breakdown_html([
		'proj_bal'    => (float)$collect['cost'] - (float)$collect['live'],
		'np_in'       => $_np_in2,
		'np_out'      => $_np_out2,
		'delta'       => (float)$delta,
		'np_vouchers' => $_np_docs,
		'projects'    => array_values(array_map(function($pj){ return ['id'=>(int)$pj['id'],'title'=>(string)$pj['title']]; }, (array)$collect['projects'])),
	]);
	?>

	<section class="cpttf-card">
		<header class="cpttf-card__head"><h2>⚡ عملیات مالی</h2></header>
		<div class="cpttf-card__body">
			<div class="cpttf-person__actions">
				<a class="cpttf-btn cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new'=>'income','person'=>$pid], $tx_base)); ?>">💵 دریافت وجه (سند دریافتی)</a>
				<a class="cpttf-btn cpttf-btn--danger" href="<?php echo esc_url(add_query_arg(['new'=>'expense','person'=>$pid], $tx_base)); ?>">💳 پرداخت وجه (سند پرداختی)</a>
				<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson'=>$pid], $tx_base)); ?>">📄 همه اسناد در دفتر مالی</a>
				<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['new'=>1,'person'=>$pid], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">🧾 صدور فاکتور</a>
				<?php if (abs($delta) > 0.005):
					$st_type = $delta > 0 ? 'income' : 'expense';
					$st_amt  = abs($delta);
				?>
				<a class="cpttf-btn cpttf-btn--success" href="<?php echo esc_url(add_query_arg(['new'=>$st_type,'person'=>$pid,'amount'=>$st_amt], $tx_base)); ?>">✨ تسویه‌ی خالص کل حساب — <?php echo $delta > 0 ? 'دریافت' : 'پرداخت'; ?> <?php echo CPTT_Finance::fmt($st_amt); ?> <?php echo esc_html($cur); ?></a>
				<?php endif; ?>
			</div>

			<?php if (!empty($open_projects)): ?>
			<h4 class="cpttf-person__sect">🤝 تسویه حساب — پروژه‌های با مانده باز</h4>
			<table class="cpttf-table">
				<thead><tr><th>پروژه</th><th>مانده بدهی</th><th style="width:220px">عملیات</th></tr></thead>
				<tbody>
				<?php foreach ($open_projects as $pj): ?>
					<tr>
						<td><?php echo esc_html($pj['title']); ?></td>
						<td class="cpttf-text-danger"><b><?php echo CPTT_Finance::fmt($pj['bal']); ?> <?php echo esc_html($cur); ?></b></td>
						<td><a class="cpttf-btn cpttf-btn--sm cpttf-btn--success" href="<?php echo esc_url(add_query_arg(['new'=>'income','person'=>$pid,'project_id'=>(int)$pj['id'],'amount'=>(float)$pj['bal']], $tx_base)); ?>">✅ ثبت دریافتِ تسویه کامل (<?php echo CPTT_Finance::fmt($pj['bal']); ?>)</a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>

			<?php if (!empty($over_projects)): ?>
			<h4 class="cpttf-person__sect">🔁 مازاد پرداخت (قابل عودت)</h4>
			<table class="cpttf-table">
				<thead><tr><th>پروژه</th><th>مازاد (بدهی ما)</th><th style="width:220px">عملیات</th></tr></thead>
				<tbody>
				<?php foreach ($over_projects as $pj): ?>
					<tr>
						<td><?php echo esc_html($pj['title']); ?></td>
						<td class="cpttf-text-warn"><b><?php echo CPTT_Finance::fmt(-$pj['bal']); ?> <?php echo esc_html($cur); ?></b></td>
						<td><a class="cpttf-btn cpttf-btn--sm cpttf-btn--warn" href="<?php echo esc_url(add_query_arg(['new'=>'expense','person'=>$pid,'amount'=>(float)-$pj['bal']], $tx_base)); ?>">↩ ثبت عودت وجه (<?php echo CPTT_Finance::fmt(-$pj['bal']); ?>)</a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>

			<?php if (empty($open_projects) && empty($over_projects)): ?>
				<p class="cpttf-empty" style="margin:8px 0 0;">✅ مانده‌ی بازی روی پروژه‌های این شخص وجود ندارد.</p>
			<?php endif; ?>
		</div>
	</section>

	<?php
	// آخرین اسناد (۸ مورد)
	$recent = array_values(array_filter($collect['rows'], function($r){ return empty($r['virtual']); }));
	$recent = array_slice(array_reverse($recent), 0, 8);
	if (!empty($recent)):
	?>
	<section class="cpttf-card" style="margin-top:14px;">
		<header class="cpttf-card__head"><h2>🕐 آخرین اسناد</h2></header>
		<div class="cpttf-card__body">
			<table class="cpttf-table">
				<thead><tr><th>شماره سند</th><th>تاریخ</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th><th>وضعیت</th></tr></thead>
				<tbody>
				<?php foreach ($recent as $r): ?>
					<tr>
						<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($r['vno']); ?></b></td>
						<td><?php echo esc_html(CPTT_Finance::fa_date($r['ts'])); ?></td>
						<td><?php echo esc_html($r['label']); ?><?php echo $r['desc'] !== '' ? ' <small style="color:#64748b;">— ' . esc_html(mb_strimwidth($r['desc'],0,60,'…')) . '</small>' : ''; ?></td>
						<td class="cpttf-text-danger"><?php echo $r['debit'] > 0 ? '<b>' . CPTT_Finance::fmt($r['debit']) . '</b>' : '—'; ?></td>
						<td class="cpttf-text-success"><?php echo $r['credit'] > 0 ? '<b>' . CPTT_Finance::fmt($r['credit']) . '</b>' : '—'; ?></td>
						<td><?php echo $r['status'] === 'reversed' ? '↩️ برگشت‌خورده' : ($r['status'] === 'reversal' ? '↩️ سند برگشت' : 'فعال'); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</section>
	<?php endif;
}

/* ── تب دفتر معین ── */
function cpttf_person_tab_ledger($pid, $u, $collect, $base){
	$L = cpttf_person_ledger_filtered($collect);
	$f = $L['filters'];
	$cur = CPTT_Finance::currency_label();
	?>
	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>📒 دفتر معین — <?php echo esc_html($u->display_name); ?></h2>
				<small style="color:#64748b;font-size:12px;">مانده‌ی مثبت = او به ما بدهکار · ردیف‌های قرارداد، بدهی اولیه‌ی هر پروژه هستند · ردیف‌های خاکستری «برگشت/برگشت‌خورده» خودکار خنثی می‌شوند</small>
			</div>
			<div class="cpttf-card__actions">
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="#" data-stmt-link data-url="<?php echo esc_url(add_query_arg(['stmt'=>'csv','ptab'=>'ledger','ffrom'=>$f['ffrom'],'fto'=>$f['fto'],'fkind'=>$f['fkind'],'ftype2'=>$f['ftype2'],'fq'=>$f['fq']], $base)); ?>">⬇ خروجی Excel (CSV)</a>
				<a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="#" data-stmt-link data-url="<?php echo esc_url(add_query_arg(['stmt'=>'print','ptab'=>'ledger','ffrom'=>$f['ffrom'],'fto'=>$f['fto'],'fkind'=>$f['fkind'],'ftype2'=>$f['ftype2'],'fq'=>$f['fq']], $base)); ?>">🖨 چاپ / صدور صورتحساب</a>
			</div>
		</header>
		<div class="cpttf-card__body">
			<form class="cpttf-filters" method="get" action="">
				<input type="hidden" name="page" value="cptt-finance-persons">
				<input type="hidden" name="pid" value="<?php echo (int)$pid; ?>">
				<input type="hidden" name="ptab" value="ledger">
				<label><span>جستجو در شرح</span><input type="search" name="fq" value="<?php echo esc_attr($f['fq']); ?>" placeholder="شرح، شماره سند، پروژه…"></label>
				<label><span>نوع ردیف</span>
					<select name="fkind">
						<option value="">همه</option>
						<option value="debit" <?php selected($f['fkind'],'debit'); ?>>فقط بدهکار</option>
						<option value="credit" <?php selected($f['fkind'],'credit'); ?>>فقط بستانکار</option>
					</select>
				</label>
				<label><span>نوع تراکنش</span>
					<select name="ftype2">
						<option value="">همه</option>
						<option value="contract" <?php selected($f['ftype2'],'contract'); ?>>قرارداد/هزینه پروژه</option>
						<option value="receipt" <?php selected($f['ftype2'],'receipt'); ?>>دریافت‌ها</option>
						<option value="payment" <?php selected($f['ftype2'],'payment'); ?>>پرداخت‌ها (از جمله تسویه کارشناس)</option>
					</select>
				</label>
				<label><span>از تاریخ</span><input type="text" class="cpttf-jdate" name="ffrom" value="<?php echo esc_attr($f['ffrom']); ?>" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
				<label><span>تا تاریخ</span><input type="text" class="cpttf-jdate" name="fto" value="<?php echo esc_attr($f['fto']); ?>" placeholder="۱۴۰۵/۱۲/۲۹" autocomplete="off"></label>
				<div class="cpttf-filters__actions">
					<button type="submit" class="cpttf-btn cpttf-btn--primary">اعمال فیلتر</button>
					<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['ptab'=>'ledger'], $base)); ?>">↺ پاک‌کردن</a>
				</div>
			</form>

			<div class="cpttf-table-wrap" style="margin-top:12px;">
				<table class="cpttf-table cpttf-moein">
					<thead><tr>
						<th style="width:36px">#</th><th>تاریخ</th><th>شرح</th><th>سند/مرجع</th>
						<th>بدهکار</th><th>بستانکار</th><th>مانده</th><th style="width:80px">پیوند</th>
					</tr></thead>
					<tbody>
					<?php if ($L['opening'] != 0): ?>
						<tr style="background:#f8fafc;"><td colspan="6"><b>مانده اول دوره</b></td><td><b><?php echo CPTT_Finance::fmt($L['opening']); ?></b></td><td></td></tr>
					<?php endif; ?>
					<?php if (empty($L['rows'])): ?>
						<tr><td colspan="8" class="cpttf-empty">ردیفی در این محدوده یافت نشد.</td></tr>
					<?php else: $i = 1; foreach ($L['rows'] as $r):
						$stl = (!$r['virtual'] && !empty($r['neutral'])) ? ' style="color:#94a3b8;"' : '';
						$stmt_k = $r['running'] > 0.005 ? 'cpttf-text-danger' : ($r['running'] < -0.005 ? 'cpttf-text-warn' : '');
					?>
						<tr<?php echo $stl; ?>>
							<td><?php echo $i++; ?></td>
							<td style="white-space:nowrap;"><?php echo esc_html(CPTT_Finance::fa_date($r['ts'])); ?></td>
							<td>
								<div style="font-weight:800;font-size:12px;"><?php echo esc_html($r['label']); ?></div>
								<?php if ($r['desc'] !== ''): ?><div style="font-size:11px;color:#64748b;"><?php echo esc_html($r['desc']); ?></div><?php endif; ?>
								<?php if ($r['project_title']): ?><div style="font-size:11px;color:#94a3b8;">📁 <?php echo esc_html($r['project_title']); ?></div><?php endif; ?>
							</td>
							<td><b style="font-family:ui-monospace,monospace;font-size:11px;"><?php echo esc_html($r['vno']); ?></b></td>
							<td class="cpttf-text-danger"><?php echo $r['debit'] > 0 ? '<b>' . CPTT_Finance::fmt($r['debit']) . '</b>' : ''; ?></td>
							<td class="cpttf-text-success"><?php echo $r['credit'] > 0 ? '<b>' . CPTT_Finance::fmt($r['credit']) . '</b>' : ''; ?></td>
							<td class="<?php echo $stmt_k; ?>" style="white-space:nowrap;"><b><?php echo CPTT_Finance::fmt($r['running']); ?></b></td>
							<td style="white-space:nowrap;">
								<?php if (!$r['virtual']): ?>
									<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson'=>$pid,'fq'=>$r['vno']], admin_url('admin.php?page=cptt-finance-transactions'))); ?>" title="مشاهده در دفتر مالی">سند</a>
								<?php elseif (!empty($r['project_id'])):
									$pl = get_edit_post_link((int)$r['project_id']);
									if ($pl): ?><a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url($pl); ?>" target="_blank" title="مشاهده پروژه">پروژه</a><?php endif; ?>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; endif; ?>
					</tbody>
					<?php if (!empty($L['rows'])): ?>
					<tfoot>
						<tr style="background:#f8fafc;font-weight:900;">
							<td colspan="4">جمع دوره</td>
							<td class="cpttf-text-danger"><?php echo CPTT_Finance::fmt($L['total_debit']); ?></td>
							<td class="cpttf-text-success"><?php echo CPTT_Finance::fmt($L['total_credit']); ?></td>
							<td colspan="2"></td>
						</tr>
						<tr style="background:#eef4ff;font-weight:900;">
							<td colspan="4">مانده پایان دوره <?php echo $L['closing'] > 0 ? '(به ما بدهکار)' : ($L['closing'] < 0 ? '(به ایشان بدهکاریم)' : '(تسویه)'); ?></td>
							<td colspan="2"></td>
							<td><b><?php echo CPTT_Finance::fmt($L['closing']); ?> <?php echo esc_html($cur); ?></b></td>
							<td></td>
						</tr>
					</tfoot>
					<?php endif; ?>
				</table>
			</div>
		</div>
	</section>
	<?php
}

/* ── تب پروژه‌ها ── */
function cpttf_person_tab_projects($pid, $u, $collect){
	$tx_base = admin_url('admin.php?page=cptt-finance-transactions');
	?>
	<section class="cpttf-card">
		<header class="cpttf-card__head"><h2>📁 پروژه‌های <?php echo esc_html($u->display_name); ?></h2></header>
		<div class="cpttf-card__body">
			<?php if (empty($collect['projects'])): ?>
				<p class="cpttf-empty">این شخص هنوز مشتریِ هیچ پروژه‌ای نیست.</p>
			<?php else: ?>
			<table class="cpttf-table">
				<thead><tr><th>پروژه</th><th>مبلغ کل</th><th>دریافتی روی مراحل</th><th>واریزی (اسناد)</th><th>تراز</th><th style="width:170px">عملیات</th></tr></thead>
				<tbody>
				<?php foreach ($collect['projects'] as $pj): ?>
					<tr>
						<td><a href="<?php echo esc_url(get_edit_post_link($pj['id'])); ?>" target="_blank"><?php echo esc_html($pj['title']); ?></a></td>
						<td><?php echo CPTT_Finance::fmt($pj['cost']); ?></td>
						<td><?php echo CPTT_Finance::fmt($pj['paid']); ?></td>
						<td><?php echo CPTT_Finance::fmt($pj['live']); ?></td>
						<td class="<?php echo $pj['bal'] > 0.005 ? 'cpttf-text-danger' : ($pj['bal'] < -0.005 ? 'cpttf-text-warn' : 'cpttf-text-success'); ?>">
							<b><?php echo CPTT_Finance::fmt($pj['bal']); ?></b>
							<?php if ($pj['bal'] < -0.005): ?><br><small style="font-weight:700;">مازاد پرداخت</small><?php endif; ?>
						</td>
						<td>
							<div style="display:flex;gap:6px;flex-wrap:wrap;">
								<a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new'=>'income','person'=>$pid,'project_id'=>(int)$pj['id']], $tx_base)); ?>">💵 سند دریافتی</a>
							</div>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/* ── تب اطلاعات شخص (پروفایل طرف‌حساب) ── */
function cpttf_person_tab_profile($pid, $u, $profile){
	$vocab = cpttf_party_role_vocab();
	?>
	<section class="cpttf-card">
		<header class="cpttf-card__head"><h2>🪪 اطلاعات طرف حساب</h2></header>
		<div class="cpttf-card__body">
			<form id="cpttf-party-form" class="cpttf-form-grid" data-pid="<?php echo (int)$pid; ?>">
				<label><span>نام و نام خانوادگی / نام شرکت</span><input type="text" name="display_name" value="<?php echo esc_attr($u->display_name); ?>"></label>
				<label><span>نوع شخص</span>
					<select name="type">
						<option value="real" <?php selected($profile['type'],'real'); ?>>شخص حقیقی</option>
						<option value="legal" <?php selected($profile['type'],'legal'); ?>>شخص حقوقی (شرکت)</option>
					</select>
				</label>
				<label><span>کد شخص</span><input type="text" name="code" value="<?php echo esc_attr($profile['code']); ?>" dir="ltr" placeholder="PRS-<?php echo (int)$pid; ?>"></label>
				<label><span>موبایل</span><input type="text" name="phone" value="<?php echo esc_attr($profile['phone']); ?>" dir="ltr"></label>
				<label><span>ایمیل</span><input type="text" value="<?php echo esc_attr($u->user_email); ?>" disabled></label>
				<label><span>وضعیت</span>
					<select name="active">
						<option value="1" <?php selected($profile['active'], 1); ?>>فعال</option>
						<option value="0" <?php selected($profile['active'], 0); ?>>غیرفعال</option>
					</select>
				</label>
				<label class="cpttf-full"><span>نشانی</span><input type="text" name="address" value="<?php echo esc_attr($profile['address']); ?>"></label>
				<label><span>بانک</span><input type="text" name="bank" value="<?php echo esc_attr($profile['bank']); ?>" placeholder="مثلاً ملی، ملت…"></label>
				<label><span>شماره حساب</span><input type="text" name="bank_account" value="<?php echo esc_attr($profile['bank_account']); ?>" dir="ltr"></label>
				<label><span>شبا</span><input type="text" name="iban" value="<?php echo esc_attr($profile['iban']); ?>" dir="ltr" placeholder="IR…"></label>
				<label><span>شماره کارت</span><input type="text" name="card" value="<?php echo esc_attr($profile['card']); ?>" dir="ltr"></label>
				<label><span>برچسب‌ها (با ویرگول)</span><input type="text" name="tags" value="<?php echo esc_attr(implode('، ', $profile['tags'])); ?>" placeholder="VIP، قدیمی، پروژه دولتی…"></label>
				<label class="cpttf-full"><span>توضیحات</span><textarea name="note" rows="2"><?php echo esc_textarea($profile['note']); ?></textarea></label>
				<fieldset class="cpttf-full cpttf-party-roles">
					<legend>نقش‌ها <small style="font-weight:500;color:#64748b;">(می‌تواند چند نقش همزمان داشته باشد — نیازی به ساخت شخص جدا برای هر نقش نیست)</small></legend>
					<?php foreach ($vocab as $rl): ?>
						<label class="cpttf-party-role"><input type="checkbox" name="roles[]" value="<?php echo esc_attr($rl); ?>" <?php checked(in_array($rl, $profile['roles'], true)); ?>> <span><?php echo esc_html($rl); ?></span></label>
					<?php endforeach; ?>
				</fieldset>
				<div class="cpttf-full" style="display:flex;gap:8px;align-items:center;">
					<button type="submit" class="cpttf-btn cpttf-btn--primary">💾 ذخیره اطلاعات</button>
					<span class="cpttf-party-msg" style="font-size:12px;color:#64748b;"></span>
				</div>
			</form>
			<div style="margin-top:12px;font-size:11.5px;color:#64748b;line-height:2;">
				تاریخ ایجاد کاربر: <?php echo esc_html(CPTT_Finance::fa_date(strtotime($u->user_registered))); ?>
				<?php if ($profile['created_by_name']): ?> · ثبت پرونده توسط: <?php echo esc_html($profile['created_by_name']); ?><?php endif; ?>
				· شناسه کاربری: <?php echo (int)$pid; ?>
			</div>
		</div>
	</section>

	<script>
	(function(){
		var form = document.getElementById('cpttf-party-form');
		if (!form || !window.CPTT_FIN) return;
		form.addEventListener('submit', function(e){
			e.preventDefault();
			var msg = form.querySelector('.cpttf-party-msg');
			var btn = form.querySelector('[type="submit"]');
			btn.disabled = true;
			var fd = new FormData(form);
			fd.append('action', 'cptt_fin_person_save');
			fd.append('nonce', CPTT_FIN.nonce);
			fd.append('user_id', form.dataset.pid || '0');
			fetch(CPTT_FIN.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function(r){ return r.json(); })
				.then(function(j){
					btn.disabled = false;
					if (j && j.success){ if (msg){ msg.style.color = '#059669'; msg.textContent = '✅ ذخیره شد.'; } if (window.cpttfReload) setTimeout(cpttfReload, 350); }
					else { if (msg){ msg.style.color = '#dc2626'; msg.textContent = (j && j.data) ? j.data : 'خطا در ذخیره'; } }
				})
				.catch(function(){ btn.disabled = false; if (msg){ msg.style.color = '#dc2626'; msg.textContent = 'خطای ارتباط با سرور'; } });
		});
	})();
	</script>
	<?php
}
