<?php
if (!defined('ABSPATH')) exit;

/**
 * Invoices (فاکتورها) — v9.2.56 (فاز ۲ از نقشه‌ی طرف‌حساب)
 *
 * این صفحه یک «لایه‌ی سند» روی دفتر مالی موجود است:
 *  - فاکتورها (پیش‌فاکتور، فروش، خرید، برگشتی‌ها) برای شخص/پروژه صادر می‌شوند
 *  - «تسویه‌ی تخصیصی» یک سند دریافت/پرداخت معمولی در همان دفتر می‌سازد و مبلغش
 *    را بین فاکتورهای باز تقسیم می‌کند؛ بنابراین مانده‌ها/گزارش‌های قبلی دست‌نخورده
 *    و از همان منابع رسمی خوانده می‌شوند (هیچ دوبل‌کاری در حساب‌ها رخ نمی‌دهد).
 *  - وضعیت فاکتور (صادرشده/جزئی/تسویه‌شده/باطل) خودکار از مجموع تخصیص‌ها حساب می‌شود.
 */

if (!function_exists('cpttf_invoice_person_options')) {
	function cpttf_invoice_person_options($selected = 0){
		$selected = (int)$selected;
		$out = '<option value="0">— انتخاب شخص —</option>';
		foreach (CPTT_Finance::get_person_options_list() as $p) {
			$out .= '<option value="' . (int)$p['id'] . '"' . selected($selected, (int)$p['id'], false) . '>' . esc_html($p['label']) . '</option>';
		}
		return $out;
	}
}

if (!function_exists('cpttf_invoice_project_options')) {
	function cpttf_invoice_project_options($selected = 0, $person_id = 0){
		$selected = (int)$selected; $person_id = (int)$person_id;
		$out = '<option value="0">— بدون پروژه —</option>';
		$args = ['post_type' => 'cptt_project', 'post_status' => 'any', 'numberposts' => 400, 'orderby' => 'date', 'order' => 'DESC'];
		foreach (get_posts($args) as $p) {
			$cid = (int)get_post_meta($p->ID, '_cptt_client_user_id', true);
			if ($person_id > 0 && $cid !== $person_id) continue;
			$t = get_the_title($p) ?: ('#' . $p->ID);
			$out .= '<option value="' . (int)$p->ID . '" data-person="' . $cid . '"' . selected($selected, $p->ID, false) . '>' . esc_html($t) . '</option>';
		}
		return $out;
	}
}

/** تاریخ شمسی «فقط روز» برای اینپوت‌ها/نمایش */
if (!function_exists('cpttf_jdate_only')) {
	function cpttf_jdate_only($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		$full = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($ts) : date('Y-m-d H:i', $ts);
		$parts = preg_split('/\s+/', (string)$full);
		return (string)($parts[0] ?? $full);
	}
}

if (!function_exists('cpttf_invoice_status_chip')) {
	function cpttf_invoice_status_chip($status){
		$v = CPTT_Finance::invoice_status_vocab();
		$status = (string)$status;
		$label = isset($v[$status]) ? $v[$status] : $status;
		return '<span class="cpttf-inv-status cpttf-inv-status--' . esc_attr($status) . '">' . esc_html($label) . '</span>';
	}
}

/**
 * بدنه‌ی مشترک رندر «ردیف‌های فاکتور» (+ جزئیات تخصیص)
 * $invoices: ردیف‌های کامل جدول فاکتورها (با فیلدهای name/project_title از قبل حل‌شده)
 */
if (!function_exists('cpttf_invoice_rows_html')) {
	function cpttf_invoice_rows_html($invoices, $allocs_by_inv, $opts = []){
		$cur = CPTT_Finance::currency_label();
		$vocab = CPTT_Finance::invoice_kind_vocab();
		$compact = !empty($opts['compact']);
		$now = (int)current_time('timestamp', true);
		ob_start();
		foreach ($invoices as $inv) {
			$remain = max(0.0, (float)$inv->amount - (float)$inv->settled);
			$open = !in_array((string)$inv->status, ['settled','cancelled','draft'], true);
			$overdue = $open && (int)$inv->due_ts > 0 && (int)$inv->due_ts < $now;
			$dir = CPTT_Finance::invoice_settle_dir((string)$inv->kind);
			?>
			<tr class="<?php echo $overdue ? 'is-overdue' : ''; echo (string)$inv->status === 'cancelled' ? ' is-cancelled' : ''; ?>">
				<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($inv->invoice_no); ?></b>
					<?php if (!empty($allocs_by_inv[(int)$inv->id])): ?>
						<details class="cpttf-inv-allocs"><summary>🔗 <?php echo count($allocs_by_inv[(int)$inv->id]); ?> تخصیص</summary>
							<ul>
							<?php foreach ($allocs_by_inv[(int)$inv->id] as $al): ?>
								<li>
									<span class="cpttf-inv-alloc-no"><?php echo esc_html((string)($al->voucher_no ?: ('#' . (int)$al->ledger_id))); ?></span>
									<span><?php echo CPTT_Finance::fmt((float)$al->amount); ?></span>
									<?php if (!$compact): ?><button type="button" class="cpttf-inv-alloc-del" data-cpttf-inv-alloc-del="<?php echo (int)$al->id; ?>" title="حذف تخصیص (سند در دفتر می‌ماند)">×</button><?php endif; ?>
								</li>
							<?php endforeach; ?>
							</ul>
						</details>
					<?php endif; ?>
				</td>
				<td><?php echo esc_html($vocab[(string)$inv->kind] ?? $inv->kind); ?>
					<small style="display:block;color:#94a3b8;"><?php echo $dir === 'receipt' ? '📥 دریافتنی' : '📤 پرداختنی'; ?></small>
				</td>
				<?php if (!$compact): ?><td><?php echo esc_html($inv->person_name); ?></td><?php endif; ?>
				<td><?php echo $inv->project_title !== '' ? esc_html($inv->project_title) : '<span style="color:#94a3b8;">—</span>'; ?></td>
				<td><?php echo esc_html(cpttf_jdate_only((int)$inv->issue_ts)); ?></td>
				<td style="<?php echo $overdue ? 'color:#dc2626;font-weight:700;' : ''; ?>"><?php echo esc_html(cpttf_jdate_only((int)$inv->due_ts)); ?><?php echo $overdue ? ' ⚠' : ''; ?></td>
				<td><b><?php echo CPTT_Finance::fmt((float)$inv->amount); ?></b></td>
				<td class="cpttf-text-success"><?php echo (float)$inv->settled > 0 ? CPTT_Finance::fmt((float)$inv->settled) : '—'; ?></td>
				<td class="<?php echo $remain > 0.005 ? 'cpttf-text-danger' : 'cpttf-text-success'; ?>"><b><?php echo CPTT_Finance::fmt($remain); ?></b></td>
				<td><?php echo cpttf_invoice_status_chip((string)$inv->status); ?></td>
				<td class="cpttf-inv-actions">
					<?php if ($compact): ?>
						<?php if ($open): ?><a class="cpttf-btn cpttf-btn--sm cpttf-btn--success" href="<?php echo esc_url(add_query_arg(['settle' => (int)$inv->id], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">✅ تسویه</a><?php endif; ?>
						<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson' => (int)$inv->person_id], admin_url('admin.php?page=cptt-finance-invoices'))); ?>">↗</a>
					<?php else: ?>
					<?php if ($open): ?>
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--success" data-cpttf-inv-settle="<?php echo (int)$inv->id; ?>">✅ تسویه</button>
					<?php endif; ?>
					<?php if ((string)$inv->status !== 'cancelled'): ?>
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" data-cpttf-inv-edit="<?php echo (int)$inv->id; ?>"
							data-kind="<?php echo esc_attr((string)$inv->kind); ?>"
							data-person="<?php echo (int)$inv->person_id; ?>"
							data-project="<?php echo (int)$inv->project_id; ?>"
							data-amount="<?php echo esc_attr(number_format((float)$inv->amount, 0, '.', ',')); ?>"
							data-issue="<?php echo esc_attr(cpttf_jdate_only((int)$inv->issue_ts)); ?>"
							data-due="<?php echo (int)$inv->due_ts > 0 ? esc_attr(cpttf_jdate_only((int)$inv->due_ts)) : ''; ?>"
							data-note="<?php echo esc_attr((string)$inv->note); ?>"
							data-status="<?php echo esc_attr((string)$inv->status); ?>">✏️</button>
						<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--danger" data-cpttf-inv-cancel="<?php echo (int)$inv->id; ?>" data-no="<?php echo esc_attr($inv->invoice_no); ?>">🚫</button>
					<?php endif; ?>
					<?php endif; ?>
				</td>
			</tr>
			<?php
		}
		return ob_get_clean();
	}
}

/** حل نام شخص/پروژه برای فهرست فاکتورها */
if (!function_exists('cpttf_invoice_hydrate')) {
	function cpttf_invoice_hydrate($invoices){
		$uids = []; $pids = [];
		foreach ((array)$invoices as $inv) { $uids[(int)$inv->person_id] = true; if ((int)$inv->project_id > 0) $pids[(int)$inv->project_id] = true; }
		$names = [];
		foreach (array_keys($uids) as $uid) { $u = get_user_by('id', $uid); $names[$uid] = $u ? $u->display_name : ('#' . $uid); }
		$titles = [];
		foreach (array_keys($pids) as $pid) { $t = get_the_title($pid); $titles[$pid] = $t !== '' ? $t : ('#' . $pid); }
		foreach ((array)$invoices as $inv) {
			$inv->person_name = isset($names[(int)$inv->person_id]) ? $names[(int)$inv->person_id] : ('#' . (int)$inv->person_id);
			$inv->project_title = isset($titles[(int)$inv->project_id]) ? $titles[(int)$inv->project_id] : '';
		}
		return $invoices;
	}
}

/** واکشی تخصیص‌های گروهی فاکتورها با شماره‌ی سند */
if (!function_exists('cpttf_invoice_allocs_map')) {
	function cpttf_invoice_allocs_map($invoice_ids){
		global $wpdb;
		$invoice_ids = array_values(array_filter(array_map('intval', (array)$invoice_ids)));
		if (empty($invoice_ids)) return [];
		$in = implode(',', $invoice_ids);
		$t_al = CPTT_Finance::tbl_invoice_allocs(); $t_l = CPTT_Finance::tbl_ledger();
		$rows = $wpdb->get_results("SELECT a.*, l.voucher_no FROM $t_al a LEFT JOIN $t_l l ON l.id = a.ledger_id WHERE a.invoice_id IN ($in) ORDER BY a.id ASC");
		$out = [];
		foreach ((array)$rows as $r) $out[(int)$r->invoice_id][] = $r;
		return $out;
	}
}

/* ── بلوک فاکتورهای یک شخص (برای تب «فاکتورها» در پرونده) ── */
if (!function_exists('cpttf_person_invoices_block')) {
	function cpttf_person_invoices_block($pid){
		global $wpdb;
		$pid = (int)$pid;
		$t_inv = CPTT_Finance::tbl_invoices();
		$invoices = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t_inv WHERE person_id = %d ORDER BY issue_ts DESC, id DESC LIMIT 100", $pid)) ?: [];
		$base_inv = admin_url('admin.php?page=cptt-finance-invoices');
		$open_sum = 0.0; $open_n = 0;
		foreach ($invoices as $inv) {
			if (in_array((string)$inv->status, ['settled','cancelled','draft'], true)) continue;
			$open_sum += max(0.0, (float)$inv->amount - (float)$inv->settled); $open_n++;
		}
		?>
		<section class="cpttf-card">
			<header class="cpttf-card__head cpttf-card__head--actions">
				<div>
					<h2>🧾 فاکتورها</h2>
					<small style="color:#64748b;font-size:12px;"><?php echo $open_n > 0 ? ($open_n . ' فاکتور باز — مجموع مانده: ' . CPTT_Finance::fmt($open_sum)) : 'فاکتور بازی وجود ندارد'; ?></small>
				</div>
				<div class="cpttf-card__actions">
					<a class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" href="<?php echo esc_url(add_query_arg(['new' => 1, 'person' => $pid], $base_inv)); ?>">+ فاکتور جدید برای این شخص</a>
					<a class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" href="<?php echo esc_url(add_query_arg(['fperson' => $pid], $base_inv)); ?>">همه در صفحه فاکتورها</a>
				</div>
			</header>
			<div class="cpttf-card__body">
				<?php if (empty($invoices)): ?>
					<p class="cpttf-empty">هنوز فاکتوری برای این شخص صادر نشده است.</p>
				<?php else: ?>
				<table class="cpttf-table">
					<thead><tr><th>شماره</th><th>نوع</th><th>پروژه</th><th>صدور</th><th>سررسید</th><th>مبلغ</th><th>تسویه‌شده</th><th>مانده</th><th>وضعیت</th><th style="width:90px">عملیات</th></tr></thead>
					<tbody><?php echo cpttf_invoice_rows_html(cpttf_invoice_hydrate($invoices), cpttf_invoice_allocs_map(wp_list_pluck($invoices, 'id')), ['compact' => true]); ?></tbody>
				</table>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}

/* ── صفحه‌ی اصلی فاکتورها ── */
function cpttf_render_invoices(){
	global $wpdb;
	$cur = CPTT_Finance::currency_label();
	$t_inv = CPTT_Finance::tbl_invoices();

	/* فیلترها */
	$f_kind   = isset($_GET['fkind'])   ? sanitize_key($_GET['fkind']) : '';
	$f_status = isset($_GET['fstatus']) ? sanitize_key($_GET['fstatus']) : '';
	$f_person = isset($_GET['fperson']) ? (int)$_GET['fperson'] : 0;
	$f_over   = !empty($_GET['foverdue']);
	$f_q      = isset($_GET['fq']) ? sanitize_text_field(wp_unslash($_GET['fq'])) : '';
	$kv = array_keys(CPTT_Finance::invoice_kind_vocab());
	if ($f_kind !== '' && !in_array($f_kind, $kv, true)) $f_kind = '';

	$where = "status != 'cancelled'"; $args = [];
	if ($f_status === 'open') $where .= " AND status IN ('issued','partial')";
	elseif (in_array($f_status, ['draft','issued','partial','settled','cancelled'], true)) { $where = "status = %s"; $args[] = $f_status; }
	if ($f_person > 0) { $where .= " AND person_id = %d"; $args[] = $f_person; }
	if ($f_kind !== '')  { $where .= " AND kind = %s"; $args[] = $f_kind; }
	if ($f_over)         { $where .= " AND status IN ('issued','partial') AND due_ts > 0 AND due_ts < " . (int)current_time('timestamp', true); }
	if ($f_q !== '')     { $where .= " AND (invoice_no LIKE %s OR note LIKE %s)"; $like = '%' . $wpdb->esc_like($f_q) . '%'; $args[] = $like; $args[] = $like; }

	$sql = "SELECT * FROM $t_inv WHERE $where ORDER BY issue_ts DESC, id DESC LIMIT 200";
	$invoices = $args ? $wpdb->get_results($wpdb->prepare($sql, $args)) : $wpdb->get_results($sql);
	$invoices = cpttf_invoice_hydrate($invoices ?: []);
	$allocs = cpttf_invoice_allocs_map(wp_list_pluck($invoices, 'id'));

	/* KPI: روی همه‌ی فاکتورها (بدون فیلتر) */
	$k = $wpdb->get_row("SELECT
		COALESCE(SUM(CASE WHEN status IN ('issued','partial') THEN amount - settled ELSE 0 END),0) AS open_sum,
		COALESCE(SUM(CASE WHEN status IN ('issued','partial') AND due_ts > 0 AND due_ts < " . (int)current_time('timestamp', true) . " THEN amount - settled ELSE 0 END),0) AS over_sum,
		SUM(CASE WHEN status IN ('issued','partial') THEN 1 ELSE 0 END) AS open_n,
		SUM(CASE WHEN status IN ('issued','partial') AND due_ts > 0 AND due_ts < " . (int)current_time('timestamp', true) . " THEN 1 ELSE 0 END) AS over_n,
		COALESCE(SUM(CASE WHEN status = 'settled' THEN amount ELSE 0 END),0) AS settled_sum
		FROM $t_inv WHERE 1");
	$open_sum = (float)($k->open_sum ?? 0); $over_sum = (float)($k->over_sum ?? 0);
	$open_n = (int)($k->open_n ?? 0); $over_n = (int)($k->over_n ?? 0); $settled_sum = (float)($k->settled_sum ?? 0);

	/* گروه‌های تسویه: فاکتورهای بازِ «صادرشده/جزئی» به تفکیک شخص+جهت */
	$open_rows = $wpdb->get_results("SELECT * FROM $t_inv WHERE status IN ('issued','partial') ORDER BY due_ts ASC, id ASC LIMIT 400") ?: [];
	$open_rows = cpttf_invoice_hydrate($open_rows);
	$groups = [];
	foreach ($open_rows as $inv) {
		$d = CPTT_Finance::invoice_settle_dir((string)$inv->kind);
		$gkey = (int)$inv->person_id . '_' . $d;
		if (!isset($groups[$gkey])) $groups[$gkey] = ['person' => (int)$inv->person_id, 'name' => $inv->person_name, 'dir' => $d, 'items' => []];
		$groups[$gkey]['items'][] = $inv;
	}

	$accounts = CPTT_Finance::get_accounts(true);
	$q_new    = !empty($_GET['new']);
	$q_person = isset($_GET['person']) ? (int)$_GET['person'] : 0;
	$q_project= isset($_GET['project']) ? (int)$_GET['project'] : 0;
	$q_amount = isset($_GET['amount']) ? (float)CPTT_Finance::parse_amount($_GET['amount']) : 0;
	$q_settle = isset($_GET['settle']) ? (int)$_GET['settle'] : 0;
	?>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4">
		<div class="cpttf-kpi" style="--c:#f59e0b">
			<div class="cpttf-kpi__icon">🧾</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">مانده‌ی فاکتورهای باز</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($open_sum); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub"><?php echo (int)$open_n; ?> فاکتور باز</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#ef4444">
			<div class="cpttf-kpi__icon">⚠️</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">سررسید گذشته</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($over_sum); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub"><?php echo (int)$over_n; ?> فاکتور</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#16a34a">
			<div class="cpttf-kpi__icon">✅</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع فاکتورهای تسویه‌شده</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($settled_sum); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">از ابتدا تاکنون</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#0ea5e9">
			<div class="cpttf-kpi__icon">💡</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">چطور کار می‌کند؟</span>
				<small class="cpttf-kpi__sub" style="line-height:1.8;display:block;">فاکتور صادر کنید؛ بعد با «تسویه» یک سند دریافت/پرداخت واقعی ثبت می‌شود و مبلغش بین فاکتورها تقسیم می‌گردد — مانده‌ها از همان دفتر قبلی خوانده می‌شوند.</small></div>
		</div>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>🧾 فاکتورها</h2>
				<small style="color:#64748b;font-size:12px;">پیش‌فاکتور/فاکتور فروش و برگشتی = از شخص دریافت می‌کنیم · خرید و برگشت از خرید = به شخص پرداخت می‌کنیم</small>
			</div>
			<div class="cpttf-card__actions">
				<button class="cpttf-btn cpttf-btn--primary" type="button" data-cpttf-inv-new>+ فاکتور جدید</button>
			</div>
		</header>
		<div class="cpttf-card__body">
			<form class="cpttf-filters" method="get" action="">
				<input type="hidden" name="page" value="cptt-finance-invoices">
				<label><span>جستجو</span><input type="search" name="fq" value="<?php echo esc_attr($f_q); ?>" placeholder="شماره فاکتور یا شرح…"></label>
				<label><span>نوع</span>
					<select name="fkind">
						<option value="">همه</option>
						<?php foreach (CPTT_Finance::invoice_kind_vocab() as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>" <?php selected($f_kind, $kk); ?>><?php echo esc_html($ll); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label><span>وضعیت</span>
					<select name="fstatus">
						<option value="">فعال‌ها (همه به‌جز باطل)</option>
						<option value="open" <?php selected($f_status, 'open'); ?>>فقط بازها</option>
						<?php foreach (CPTT_Finance::invoice_status_vocab() as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>" <?php selected($f_status, $kk); ?>><?php echo esc_html($ll); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label><span>شخص</span>
					<select name="fperson">
						<option value="0">همه اشخاص</option>
						<?php foreach (CPTT_Finance::get_person_options_list() as $p): ?><option value="<?php echo (int)$p['id']; ?>" <?php selected($f_person, (int)$p['id']); ?>><?php echo esc_html($p['label']); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label class="cpttf-checkline"><input type="checkbox" name="foverdue" value="1" <?php checked($f_over); ?>> <span>فقط سررسید گذشته</span></label>
				<div class="cpttf-filters__actions">
					<button class="cpttf-btn cpttf-btn--primary" type="submit">فیلتر</button>
					<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices')); ?>">پاک‌سازی</a>
				</div>
			</form>

			<?php if (empty($invoices)): ?>
				<p class="cpttf-empty">فاکتوری مطابق فیلتر یافت نشد. با «+ فاکتور جدید» اولین فاکتور را صادر کنید.</p>
			<?php else: ?>
			<table class="cpttf-table">
				<thead><tr><th>شماره</th><th>نوع</th><th>شخص</th><th>پروژه</th><th>صدور</th><th>سررسید</th><th>مبلغ</th><th>تسویه‌شده</th><th>مانده</th><th>وضعیت</th><th style="width:150px">عملیات</th></tr></thead>
				<tbody><?php echo cpttf_invoice_rows_html($invoices, $allocs); ?></tbody>
			</table>
			<p style="color:#94a3b8;font-size:11.5px;">حداکثر ۲۰۰ ردیف اخیر نمایش داده می‌شود؛ برای دقیق‌تر شدن از فیلترها استفاده کنید.</p>
			<?php endif; ?>
		</div>
	</section>

	<?php /* ── مدال ساخت/ویرایش فاکتور ── */ ?>
	<div class="cpttf-modal" id="cpttf-inv-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-inv-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3 id="cpttf-inv-modal-title">+ فاکتور جدید</h3>
				<button type="button" class="cpttf-modal__close" data-cpttf-inv-close>×</button>
			</header>
			<form id="cpttf-inv-form" class="cpttf-modal__body">
				<input type="hidden" name="id" id="cpttf-inv-id" value="0">
				<div class="cpttf-form-grid">
					<label><span>نوع فاکتور *</span>
						<select name="kind" id="cpttf-inv-kind">
							<?php foreach (CPTT_Finance::invoice_kind_vocab() as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>"><?php echo esc_html($ll); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label><span>وضعیت</span>
						<select name="status" id="cpttf-inv-status">
							<option value="issued">صادر شده</option>
							<option value="draft">پیش‌نویس</option>
						</select>
					</label>
					<label class="cpttf-full"><span>شخص (طرف حساب) *</span>
						<select name="person_id" id="cpttf-inv-person"><?php echo cpttf_invoice_person_options($q_person); ?></select>
					</label>
					<label class="cpttf-full"><span>پروژه (اختیاری)</span>
						<select name="project_id" id="cpttf-inv-project"><?php echo cpttf_invoice_project_options($q_project); ?></select>
					</label>
					<label><span>مبلغ (<?php echo esc_html($cur); ?>) *</span><input type="text" inputmode="numeric" name="amount" id="cpttf-inv-amount" class="cpttf-money" required></label>
					<label><span>تاریخ صدور</span><input type="text" name="issue_date" id="cpttf-inv-issue" class="cpttf-jdate" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
					<label><span>تاریخ سررسید</span><input type="text" name="due_date" id="cpttf-inv-due" class="cpttf-jdate" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
					<label class="cpttf-full"><span>شرح / اقلام</span><textarea name="note" id="cpttf-inv-note" rows="2" placeholder="مثلاً: بابت مرحله‌ی اول — طراحی رابط"></textarea></label>
				</div>
				<span class="cpttf-inv-msg" id="cpttf-inv-msg" style="display:block;margin-top:8px;font-size:12px;"></span>
			</form>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-inv-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--primary" data-cpttf-inv-save>💾 صدور / ذخیره فاکتور</button>
			</footer>
		</div>
	</div>

	<?php /* ── مدال تسویه‌ی تخصیصی ── */ ?>
	<div class="cpttf-modal" id="cpttf-inv-settle-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-inv-close></div>
		<div class="cpttf-modal__dialog cpttf-modal__dialog--wide">
			<header class="cpttf-modal__head">
				<h3>✅ تسویه‌ی فاکتور (تخصیص به یک یا چند فاکتور)</h3>
				<button type="button" class="cpttf-modal__close" data-cpttf-inv-close>×</button>
			</header>
			<form id="cpttf-inv-settle-form" class="cpttf-modal__body">
				<div class="cpttf-form-grid" style="margin-bottom:10px;">
					<label><span>تاریخ سند</span><input type="text" name="date_local" class="cpttf-jdate" placeholder="همین حالا" autocomplete="off"></label>
					<label><span>حساب</span>
						<select name="account_id">
							<?php foreach ($accounts as $a): ?><option value="<?php echo (int)$a->id; ?>"><?php echo esc_html($a->icon . ' ' . $a->name); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label class="cpttf-full"><span>شرح سند (اختیاری)</span><input type="text" name="description" placeholder="مثلاً: واریز به کارت …"></label>
				</div>
				<p style="font-size:12px;color:#64748b;margin:0 0 8px;">برای هر فاکتور مبلغ تخصیص را بنویسید؛ جمع اعداد = مبلغ سند دریافت/پرداختی که ثبت می‌شود.</p>
				<?php if (empty($groups)): ?>
					<p class="cpttf-empty">فاکتور بازی برای تسویه وجود ندارد.</p>
				<?php else: foreach ($groups as $gkey => $g): ?>
					<fieldset class="cpttf-inv-settlegrp" data-gkey="<?php echo esc_attr($gkey); ?>" hidden>
						<legend><?php echo esc_html($g['name']); ?> — <?php echo $g['dir'] === 'receipt' ? '📥 دریافت از ایشان' : '📤 پرداخت به ایشان'; ?></legend>
						<?php foreach ($g['items'] as $inv): $remain = max(0.0, (float)$inv->amount - (float)$inv->settled); ?>
							<div class="cpttf-inv-settleline" data-iid="<?php echo (int)$inv->id; ?>" data-remain="<?php echo (float)$remain; ?>">
								<label class="cpttf-checkline" style="min-width:230px;">
									<input type="checkbox" class="cpttf-inv-settlechk">
									<span><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($inv->invoice_no); ?></b>
									<small style="color:#64748b;"> · مانده: <?php echo CPTT_Finance::fmt($remain); ?><?php echo $inv->project_title !== '' ? ' · ' . esc_html($inv->project_title) : ''; ?><?php echo (int)$inv->due_ts > 0 ? ' · سررسید ' . esc_html(cpttf_jdate_only((int)$inv->due_ts)) : ''; ?></small></span>
								</label>
								<input type="text" inputmode="numeric" class="cpttf-money cpttf-inv-settleamt" placeholder="۰" disabled>
							</div>
						<?php endforeach; ?>
					</fieldset>
				<?php endforeach; endif; ?>
				<div class="cpttf-inv-settletotal">جمع تخصیص: <b id="cpttf-inv-settletotal">۰</b> <?php echo esc_html($cur); ?></div>
				<span class="cpttf-inv-msg" id="cpttf-inv-settle-msg" style="display:block;margin-top:8px;font-size:12px;"></span>
			</form>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-inv-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--success" data-cpttf-inv-settle-save>✅ ثبت سند تسویه و تخصیص</button>
			</footer>
		</div>
	</div>

	<script>
	(function(){
		function ready(fn){ if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }
		ready(function(){
			if (window.__cpttfInvBound) return; window.__cpttfInvBound = true;
			var CFG = window.CPTT_FIN || { ajax:'', nonce:'' };
			function post(action, data, cb){
				var fd = new FormData();
				fd.append('action', action); fd.append('nonce', CFG.nonce);
				for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) fd.append(k, data[k]);
				var x = new XMLHttpRequest(); x.open('POST', CFG.ajax);
				x.onload = function(){ var r = null; try{ r = JSON.parse(x.responseText); }catch(e){} cb(r); };
				x.onerror = function(){ cb(null); };
				x.send(fd);
			}
			function reload(){ if (window.cpttfReload) window.cpttfReload(); else window.location.reload(); }
			function msg(el, t, ok){ var n = document.getElementById(el); if(!n) return; n.textContent = t; n.style.color = ok ? '#16a34a' : '#dc2626'; }
			function openModal(id){ var m = document.getElementById(id); if (m) m.hidden = false; }
			function closeModal(m){ if (m) m.hidden = true; }
			function money(v){ return String(v||'').replace(/[^\d]/g,''); }

			/* باز/بسته کردن مدال‌ها */
			document.addEventListener('click', function(e){
				var c = e.target.closest('[data-cpttf-inv-close]');
				if (c){ e.preventDefault(); var m = c.closest('.cpttf-modal'); closeModal(m); return; }
				if (e.target.closest('[data-cpttf-inv-new]')){ e.preventDefault(); window.CPTTFInvOpenNew(); return; }
				var ed = e.target.closest('[data-cpttf-inv-edit]');
				if (ed){ e.preventDefault(); window.CPTTFInvOpenEdit(ed); return; }
				var st = e.target.closest('[data-cpttf-inv-settle]');
				if (st){ e.preventDefault(); window.CPTTFInvOpenSettle(parseInt(st.getAttribute('data-cpttf-inv-settle'),10) || 0); return; }
				var cn = e.target.closest('[data-cpttf-inv-cancel]');
				if (cn){
					e.preventDefault();
					if (!window.confirm('فاکتور ' + (cn.getAttribute('data-no')||'') + ' باطل شود؟ (فقط فاکتور بدون تخصیص قابل ابطال است)')) return;
					post('cptt_fin_invoice_cancel', { id: cn.getAttribute('data-cpttf-inv-cancel') }, function(r){
						if (r && r.success){ reload(); } else window.alert((r && r.data) ? r.data : 'خطا در ابطال');
					});
					return;
				}
				var ad = e.target.closest('[data-cpttf-inv-alloc-del]');
				if (ad){
					e.preventDefault();
					if (!window.confirm('این تخصیص حذف شود؟ سند مالی در دفتر می‌ماند و فقط پیوندش با فاکتور قطع می‌شود.')) return;
					post('cptt_fin_invoice_alloc_delete', { id: ad.getAttribute('data-cpttf-inv-alloc-del') }, function(r){
						if (r && r.success){ reload(); } else window.alert((r && r.data) ? r.data : 'خطا در حذف تخصیص');
					});
					return;
				}
				if (e.target.closest('[data-cpttf-inv-save]')){
					e.preventDefault();
					var f = document.getElementById('cpttf-inv-form'); if(!f) return;
					var d = {
						id: f.querySelector('[name=id]').value,
						kind: f.querySelector('[name=kind]').value,
						status: f.querySelector('[name=status]').value,
						person_id: f.querySelector('[name=person_id]').value,
						project_id: f.querySelector('[name=project_id]').value,
						amount: money(f.querySelector('[name=amount]').value),
						issue_date: f.querySelector('[name=issue_date]').value,
						due_date: f.querySelector('[name=due_date]').value,
						note: f.querySelector('[name=note]').value
					};
					if (!d.person_id || d.person_id === '0'){ msg('cpttf-inv-msg','لطفاً شخص را انتخاب کنید.', false); return; }
					if (!d.amount || d.amount === '0'){ msg('cpttf-inv-msg','مبلغ فاکتور را بنویسید.', false); return; }
					msg('cpttf-inv-msg','در حال ذخیره…', true);
					post('cptt_fin_invoice_save', d, function(r){
						if (r && r.success){ reload(); } else msg('cpttf-inv-msg', (r && r.data) ? r.data : 'خطا در ذخیره فاکتور', false);
					});
					return;
				}
				if (e.target.closest('[data-cpttf-inv-settle-save]')){
					e.preventDefault();
					var sf = document.getElementById('cpttf-inv-settle-form'); if(!sf) return;
					var grp = sf.querySelector('.cpttf-inv-settlegrp:not([hidden])');
					if (!grp){ msg('cpttf-inv-settle-msg','گروه تسویه انتخاب نشده است.', false); return; }
					var parts = [];
					grp.querySelectorAll('.cpttf-inv-settleline').forEach(function(ln){
						var chk = ln.querySelector('.cpttf-inv-settlechk');
						var amt = money(ln.querySelector('.cpttf-inv-settleamt').value);
						if (chk && chk.checked && amt && amt !== '0') parts.push('alloc[' + ln.getAttribute('data-iid') + ']=' + amt);
					});
					if (!parts.length){ msg('cpttf-inv-settle-msg','هیچ مبلغی برای تخصیص وارد نشده است.', false); return; }
					msg('cpttf-inv-settle-msg','در حال ثبت سند تسویه…', true);
					var fd = new FormData();
					fd.append('action','cptt_fin_invoice_settle'); fd.append('nonce', CFG.nonce);
					fd.append('date_local', sf.querySelector('[name=date_local]').value || '');
					fd.append('account_id', sf.querySelector('[name=account_id]').value || '0');
					fd.append('description', sf.querySelector('[name=description]').value || '');
					parts.forEach(function(p){ var kv = p.split('='); fd.append(kv[0], kv[1]); });
					var x = new XMLHttpRequest(); x.open('POST', CFG.ajax);
					x.onload = function(){ var r = null; try{ r = JSON.parse(x.responseText); }catch(e){}
						if (r && r.success){ reload(); } else msg('cpttf-inv-settle-msg', (r && r.data) ? r.data : 'خطا در ثبت تسویه', false);
					};
					x.onerror = function(){ msg('cpttf-inv-settle-msg','خطای ارتباط', false); };
					x.send(fd);
					return;
				}
				/* چک‌باکس ردیف تسویه: فعال‌سازی اینپوت + پرکردن با مانده */
				var chk = e.target.closest('.cpttf-inv-settlechk');
				if (chk){
					var ln = chk.closest('.cpttf-inv-settleline');
					var inp = ln ? ln.querySelector('.cpttf-inv-settleamt') : null;
					if (inp){
						inp.disabled = !chk.checked;
						if (chk.checked && !inp.value) inp.value = Number(ln.getAttribute('data-remain')||0).toLocaleString('en-US');
						if (!chk.checked) inp.value = '';
						window.CPTTFInvRecalc();
					}
				}
			});
			document.addEventListener('input', function(e){
				if (e.target.classList && e.target.classList.contains('cpttf-inv-settleamt')) window.CPTTFInvRecalc();
			});

			window.CPTTFInvRecalc = function(){
				var sf = document.getElementById('cpttf-inv-settle-form'); if(!sf) return;
				var t = 0;
				sf.querySelectorAll('.cpttf-inv-settlegrp:not([hidden]) .cpttf-inv-settleline').forEach(function(ln){
					var chk = ln.querySelector('.cpttf-inv-settlechk');
					if (chk && chk.checked) t += parseFloat(money(ln.querySelector('.cpttf-inv-settleamt').value) || '0') || 0;
				});
				var n = document.getElementById('cpttf-inv-settletotal');
				if (n) n.textContent = t.toLocaleString('en-US');
			};

			window.CPTTFInvOpenNew = function(pre){
				pre = pre || {};
				var f = document.getElementById('cpttf-inv-form'); if(!f) return;
				f.reset();
				f.querySelector('[name=id]').value = '0';
				document.getElementById('cpttf-inv-modal-title').textContent = '+ فاکتور جدید';
				if (pre.person)  f.querySelector('[name=person_id]').value = String(pre.person);
				if (pre.project) f.querySelector('[name=project_id]').value = String(pre.project);
				if (pre.amount)  f.querySelector('[name=amount]').value = Number(pre.amount).toLocaleString('en-US');
				msg('cpttf-inv-msg','', true);
				openModal('cpttf-inv-modal');
			};

			window.CPTTFInvOpenEdit = function(btn){
				var f = document.getElementById('cpttf-inv-form'); if(!f) return;
				f.reset();
				f.querySelector('[name=id]').value = btn.getAttribute('data-cpttf-inv-edit') || '0';
				f.querySelector('[name=kind]').value = btn.getAttribute('data-kind') || 'sale';
				f.querySelector('[name=status]').value = (btn.getAttribute('data-status') === 'draft') ? 'draft' : 'issued';
				f.querySelector('[name=person_id]').value = btn.getAttribute('data-person') || '0';
				f.querySelector('[name=project_id]').value = btn.getAttribute('data-project') || '0';
				f.querySelector('[name=amount]').value = btn.getAttribute('data-amount') || '';
				f.querySelector('[name=issue_date]').value = btn.getAttribute('data-issue') || '';
				f.querySelector('[name=due_date]').value = btn.getAttribute('data-due') || '';
				f.querySelector('[name=note]').value = btn.getAttribute('data-note') || '';
				document.getElementById('cpttf-inv-modal-title').textContent = '✏️ ویرایش فاکتور';
				msg('cpttf-inv-msg','', true);
				openModal('cpttf-inv-modal');
			};

			window.CPTTFInvOpenSettle = function(invoiceId){
				var sf = document.getElementById('cpttf-inv-settle-form'); if(!sf) return;
				/* گروه مربوط به فاکتور را پیدا و نمایش بده */
				var targetGrp = null, targetLine = null;
				sf.querySelectorAll('.cpttf-inv-settleline').forEach(function(ln){
					if (parseInt(ln.getAttribute('data-iid'),10) === invoiceId){
						targetLine = ln; targetGrp = ln.closest('.cpttf-inv-settlegrp');
					}
				});
				sf.querySelectorAll('.cpttf-inv-settlegrp').forEach(function(g){
					g.hidden = !(targetGrp && g === targetGrp);
				});
				sf.querySelectorAll('.cpttf-inv-settleamt').forEach(function(i){ i.value=''; i.disabled = true; });
				sf.querySelectorAll('.cpttf-inv-settlechk').forEach(function(c){ c.checked = false; });
				if (targetLine){
					var chk = targetLine.querySelector('.cpttf-inv-settlechk');
					var inp = targetLine.querySelector('.cpttf-inv-settleamt');
					if (chk) chk.checked = true;
					if (inp){ inp.disabled = false; inp.value = Number(targetLine.getAttribute('data-remain')||0).toLocaleString('en-US'); }
				}
				window.CPTTFInvRecalc();
				msg('cpttf-inv-settle-msg','', true);
				openModal('cpttf-inv-settle-modal');
			};

			/* باز کردن خودکار از روی کوئری (new=1 / settle=ID) */
			<?php if ($q_new): ?>
			window.CPTTFInvOpenNew({ person: <?php echo (int)$q_person; ?>, project: <?php echo (int)$q_project; ?>, amount: <?php echo (float)$q_amount; ?> });
			<?php endif; ?>
			<?php if ($q_settle > 0): ?>
			window.CPTTFInvOpenSettle(<?php echo (int)$q_settle; ?>);
			<?php endif; ?>
		});
	})();
	</script>
	<?php
}
