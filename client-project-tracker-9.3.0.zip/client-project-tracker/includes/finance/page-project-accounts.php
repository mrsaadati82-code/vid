<?php
if (!defined('ABSPATH')) exit;

function cpttf_render_project_accounts(){
    $cur = CPTT_Finance::currency_label();
    $q = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
    $status = isset($_GET['settled']) ? sanitize_key($_GET['settled']) : '';
    $per = isset($_GET['per_page']) ? max(10, min(100, (int)$_GET['per_page'])) : 25;
    $paged = isset($_GET['paged']) ? max(1, (int)$_GET['paged']) : 1;

    $projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
    $rows=[]; $sum_cost=0; $sum_paid=0; $sum_remain=0;
    foreach($projects as $p){
        $steps=get_post_meta($p->ID,'_cptt_steps',true); if(!is_array($steps)) $steps=[];
        $cost=0; $paid=0; $expert=0; $steps_count=0;
        foreach($steps as $st){ if(!is_array($st)) continue; $steps_count++; $cost+=(float)($st['cost']??0); $paid+=(float)($st['paid']??0); $expert+=(float)($st['expert_paid']??0); if(!empty($st['extra_finance'])&&is_array($st['extra_finance'])) foreach($st['extra_finance'] as $ef){ if(is_array($ef)){ $cost+=(float)($ef['cost']??0); $paid+=(float)($ef['paid']??0); } } }
        $remain=max(0,$cost-$paid); $is_settled=($cost>0 && $remain<=0.5);
        $cid=(int)get_post_meta($p->ID,'_cptt_client_user_id',true); $cu=$cid?get_user_by('id',$cid):null;
        $hay=mb_strtolower(get_the_title($p).' '.($cu?$cu->display_name:''));
        if($q!=='' && mb_strpos($hay, mb_strtolower($q))===false) continue;
        if($status==='settled' && !$is_settled) continue;
        if($status==='open' && $is_settled) continue;
        $sum_cost+=$cost; $sum_paid+=$paid; $sum_remain+=$remain;
        $rows[]=['id'=>$p->ID,'title'=>get_the_title($p),'client'=>$cu?$cu->display_name:'—','cost'=>$cost,'paid'=>$paid,'remain'=>$remain,'expert'=>$expert,'profit'=>$paid-$expert,'settled'=>$is_settled,'steps'=>$steps_count,'date'=>get_the_date('Y/m/d',$p)];
    }
    usort($rows,function($a,$b){ return $b['id'] <=> $a['id']; });
    $total=count($rows); $pages=max(1,(int)ceil($total/$per)); if($paged>$pages) $paged=$pages; $slice=array_slice($rows,($paged-1)*$per,$per);
    ?>
    <div class="cpttf-grid cpttf-grid--kpis cpttf-grid--3">
        <div class="cpttf-kpi" style="--c:#6366f1"><div class="cpttf-kpi__icon">🧾</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع صورتحساب</span><strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($sum_cost); ?> <small><?php echo esc_html($cur); ?></small></strong></div></div>
        <div class="cpttf-kpi" style="--c:#16a34a"><div class="cpttf-kpi__icon">💵</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع دریافتی</span><strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($sum_paid); ?> <small><?php echo esc_html($cur); ?></small></strong></div></div>
        <div class="cpttf-kpi" style="--c:#ef4444"><div class="cpttf-kpi__icon">⏳</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع مانده</span><strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($sum_remain); ?> <small><?php echo esc_html($cur); ?></small></strong></div></div>
    </div>
    <section class="cpttf-card">
        <header class="cpttf-card__head"><h2>📒 حساب پروژه‌ها</h2><small><?php echo esc_html($total); ?> پروژه</small></header>
        <div class="cpttf-card__body">
            <form method="get" class="cpttf-filters">
                <input type="hidden" name="page" value="cptt-finance-classic">
                <input type="search" name="s" value="<?php echo esc_attr($q); ?>" placeholder="جستجوی پروژه یا مشتری">
                <select name="settled"><option value="">همه وضعیت‌ها</option><option value="open" <?php selected($status,'open'); ?>>تسویه‌نشده</option><option value="settled" <?php selected($status,'settled'); ?>>تسویه‌شده</option></select>
                <select name="per_page"><option <?php selected($per,25); ?> value="25">۲۵ ردیف</option><option <?php selected($per,50); ?> value="50">۵۰ ردیف</option><option <?php selected($per,100); ?> value="100">۱۰۰ ردیف</option></select>
                <button class="cpttf-btn cpttf-btn--primary">اعمال</button>
            </form>
            <div class="cpttf-table-wrap"><table class="cpttf-table"><thead><tr><th>پروژه</th><th>مشتری</th><th>مراحل</th><th>صورتحساب</th><th>دریافتی</th><th>مانده</th><th>پرداخت کارشناس</th><th>سود</th><th>وضعیت</th></tr></thead><tbody>
            <?php if(!$slice): ?><tr><td colspan="9" class="cpttf-empty">موردی یافت نشد.</td></tr><?php endif; ?>
            <?php foreach($slice as $r): ?><tr><td><b><?php echo esc_html($r['title']); ?></b><small style="display:block;color:#64748b">#<?php echo (int)$r['id']; ?> · <?php echo esc_html($r['date']); ?></small></td><td><?php echo esc_html($r['client']); ?></td><td><?php echo (int)$r['steps']; ?></td><td><?php echo CPTT_Finance::fmt($r['cost']); ?></td><td class="cpttf-text-success"><b><?php echo CPTT_Finance::fmt($r['paid']); ?></b></td><td class="cpttf-text-danger"><b><?php echo CPTT_Finance::fmt($r['remain']); ?></b></td><td><?php echo CPTT_Finance::fmt($r['expert']); ?></td><td><?php echo CPTT_Finance::fmt($r['profit']); ?></td><td><?php echo $r['settled']?'<span class="cpttf-chip cpttf-chip--ok">تسویه‌شده</span>':'<span class="cpttf-chip cpttf-chip--warn">باز</span>'; ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
            <div class="cpttf-pagination" style="display:flex;gap:8px;justify-content:center;margin-top:14px;flex-wrap:wrap;">
            <?php for($i=1;$i<=$pages;$i++): $url=add_query_arg(['page'=>'cptt-finance-classic','s'=>$q,'settled'=>$status,'per_page'=>$per,'paged'=>$i], admin_url('admin.php')); ?><a class="cpttf-btn cpttf-btn--sm <?php echo $i===$paged?'cpttf-btn--primary':''; ?>" href="<?php echo esc_url($url); ?>"><?php echo esc_html($i); ?></a><?php endfor; ?>
            </div>
        </div>
    </section>
    <?php
}
