<?php
if (!defined('ABSPATH')) exit;

/**
 * Receivables page — v9.2.7
 *
 * Improvements over v9.1.x:
 *   - Search + sort controls (most-debt, least-debt, newest, oldest, name)
 *   - Inline "ثبت پرداخت" and "تسویه کامل" modals — no page hop
 *   - Populates project_id automatically so the payment is applied back
 *     onto _cptt_steps (making the debtor disappear from the list)
 *   - Default date = today
 */
function cpttf_render_receivables(){
	$cur = CPTT_Finance::currency_label();
	$accounts = CPTT_Finance::get_accounts(true);
	$cats_in  = CPTT_Finance::get_categories('income');

	// Build debtor map
	$debtors = [];
	$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
	$grand_total = 0; $proj_with_debt = 0;
	foreach ($projects as $p) {
		$steps = get_post_meta($p->ID, '_cptt_steps', true);
		if (!is_array($steps)) continue;
		$cost = 0; $paid = 0;
		foreach ($steps as $st) {
			$cost += (float)($st['cost'] ?? 0);
			$paid += (float)($st['paid'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ef) {
					$cost += (float)($ef['cost'] ?? 0);
					$paid += (float)($ef['paid'] ?? 0);
				}
			}
		}
		$remain = max(0, $cost - $paid);
		if ($remain <= 0) continue;
		$proj_with_debt++;
		$grand_total += $remain;
		$cid = (int) get_post_meta($p->ID, '_cptt_client_user_id', true);
		$cu  = $cid ? get_user_by('id', $cid) : null;
		$cname = $cu ? $cu->display_name : 'مشتری نامشخص';
		if ($cu) {
			$roles = (array) $cu->roles;
			if (in_array('cptt_expert', $roles, true) && !in_array('customer', $roles, true)) {
				$cname .= ' ⚠ (نقش کارشناس)';
			}
		}
		$cphone = $cu ? (string) get_user_meta($cid, 'billing_phone', true) : '';
		if ($cphone === '' && $cu) $cphone = (string) get_user_meta($cid, 'cptt_phone', true);
		if ($cphone === '' && $cu) $cphone = (string) get_user_meta($cid, 'mobile', true);
		$p_ts = strtotime($p->post_date_gmt ?: $p->post_date);
		if (!isset($debtors[$cid])) $debtors[$cid] = [
			'id'=>$cid,'name'=>$cname,'phone'=>$cphone,
			'total_cost'=>0,'total_paid'=>0,'remain'=>0,'projects'=>[],
			'oldest_ts'=>$p_ts, 'newest_ts'=>$p_ts,
		];
		$debtors[$cid]['total_cost'] += $cost;
		$debtors[$cid]['total_paid'] += $paid;
		$debtors[$cid]['remain']     += $remain;
		$debtors[$cid]['oldest_ts']   = min($debtors[$cid]['oldest_ts'], $p_ts);
		$debtors[$cid]['newest_ts']   = max($debtors[$cid]['newest_ts'], $p_ts);
		$debtors[$cid]['projects'][] = [
			'id'=>$p->ID,'title'=>get_the_title($p),
			'cost'=>$cost,'paid'=>$paid,'remain'=>$remain,
			'ts'=>$p_ts,
		];
	}

	// Sort — default: most-debt desc
	uasort($debtors, function($a,$b){ return ($b['remain'] <=> $a['remain']); });

	// Find or auto-detect income category for payments (first income cat)
	$default_income_cat = !empty($cats_in) ? (int)$cats_in[0]->id : 0;
	?>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--3">
		<div class="cpttf-kpi" style="--c:#ef4444">
			<div class="cpttf-kpi__icon">⏳</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">کل مطالبات</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($grand_total); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">از همه‌ی مشتریان</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#f59e0b">
			<div class="cpttf-kpi__icon">👥</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">مشتریان بدهکار</span>
				<strong class="cpttf-kpi__value" data-plain="1"><?php echo CPTT_Finance::fmt(count($debtors)); ?></strong>
				<small class="cpttf-kpi__sub">نفر</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#6366f1">
			<div class="cpttf-kpi__icon">📁</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">پروژه‌های بدهکار</span>
				<strong class="cpttf-kpi__value" data-plain="1"><?php echo CPTT_Finance::fmt($proj_with_debt); ?></strong>
				<small class="cpttf-kpi__sub">نیاز به وصول</small></div>
		</div>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head">
			<h2>👥 لیست بدهکاران</h2>
		</header>
		<div class="cpttf-recv-toolbar">
			<div class="cpttf-recv-search-wrap">
				<span class="cpttf-recv-search-icon" aria-hidden="true">🔍</span>
				<input type="search" id="cpttf-recv-search" class="cpttf-recv-search" placeholder="جستجو در نام یا شماره تماس مشتری…">
			</div>
			<label class="cpttf-recv-field">
				<span>مرتب‌سازی:</span>
				<select id="cpttf-recv-sort" class="cpttf-recv-select">
					<option value="remain-desc">بیشترین بدهی</option>
					<option value="remain-asc">کمترین بدهی</option>
					<option value="oldest">قدیمی‌ترین پروژه</option>
					<option value="newest">جدیدترین پروژه</option>
					<option value="name-asc">نام (الفبا)</option>
					<option value="projects-desc">بیشترین پروژه</option>
				</select>
			</label>
			<label class="cpttf-recv-field">
				<span>فیلتر:</span>
				<select id="cpttf-recv-filter" class="cpttf-recv-select">
					<option value="all">همه</option>
					<option value="phone">فقط با شماره تماس</option>
					<option value="multi">مشتریان با ۲+ پروژه</option>
				</select>
			</label>
		</div>
		<div class="cpttf-card__body">
			<?php if (empty($debtors)): ?>
				<p class="cpttf-empty">🎉 هیچ بدهکاری ندارید — همه چیز تسویه است.</p>
			<?php else: ?>
				<div id="cpttf-recv-count-info" style="font-size:12.5px;color:#64748b;margin-bottom:8px;"></div>
				<ul class="cpttf-debtor-list" id="cpttf-debtor-list">
					<?php foreach ($debtors as $d):
						$search_str = mb_strtolower(($d['name'] ?: '') . ' ' . $d['phone']);
					?>
						<li class="cpttf-debtor"
							data-search="<?php echo esc_attr($search_str); ?>"
							data-remain="<?php echo (float)$d['remain']; ?>"
							data-oldest="<?php echo (int)$d['oldest_ts']; ?>"
							data-newest="<?php echo (int)$d['newest_ts']; ?>"
							data-name="<?php echo esc_attr(mb_strtolower($d['name'])); ?>"
							data-projects="<?php echo count($d['projects']); ?>"
							data-has-phone="<?php echo $d['phone'] ? '1' : '0'; ?>">
							<button type="button" class="cpttf-debtor__head">
								<div class="cpttf-debtor__avatar"><?php echo esc_html(mb_substr($d['name'], 0, 1)); ?></div>
								<div class="cpttf-debtor__title">
									<strong><?php echo esc_html($d['name']); ?></strong>
									<small><?php echo esc_html($d['phone'] ?: 'بدون شماره'); ?> · <?php echo count($d['projects']); ?> پروژه</small>
								</div>
								<div class="cpttf-debtor__amount">
									<b><?php echo CPTT_Finance::fmt($d['remain']); ?></b>
									<small><?php echo esc_html($cur); ?></small>
								</div>
								<svg class="cpttf-debtor__chevron" width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="5 8 10 13 15 8"/></svg>
							</button>
							<div class="cpttf-debtor__projects" hidden>
								<table class="cpttf-table">
									<thead><tr><th>پروژه</th><th>مبلغ کل</th><th>پرداختی</th><th>مانده</th><th style="width:280px;min-width:280px">عملیات</th></tr></thead>
									<tbody>
									<?php foreach ($d['projects'] as $pr): ?>
										<tr>
											<td><a href="<?php echo esc_url(get_edit_post_link($pr['id'])); ?>" target="_blank"><?php echo esc_html($pr['title']); ?></a></td>
											<td><?php echo CPTT_Finance::fmt($pr['cost']); ?></td>
											<td><?php echo CPTT_Finance::fmt($pr['paid']); ?></td>
											<td class="cpttf-text-danger"><b><?php echo CPTT_Finance::fmt($pr['remain']); ?></b></td>
											<td>
												<div class="cpttf-recv-actions">
													<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--primary"
														data-cpttf-recv-pay
														data-project-id="<?php echo (int)$pr['id']; ?>"
														data-customer-id="<?php echo (int)$d['id']; ?>"
														data-project-title="<?php echo esc_attr($pr['title']); ?>"
														data-customer-name="<?php echo esc_attr($d['name']); ?>"
														data-remain="<?php echo (float)$pr['remain']; ?>">💵 ثبت پرداخت</button>
													<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--success"
														data-cpttf-recv-settle
														data-project-id="<?php echo (int)$pr['id']; ?>"
														data-customer-id="<?php echo (int)$d['id']; ?>"
														data-project-title="<?php echo esc_attr($pr['title']); ?>"
														data-customer-name="<?php echo esc_attr($d['name']); ?>"
														data-remain="<?php echo (float)$pr['remain']; ?>">✅ تسویه کامل</button>
												</div>
											</td>
										</tr>
									<?php endforeach; ?>
									</tbody>
								</table>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
		<?php if (!empty($debtors)): ?>
		<footer class="cpttf-recv-pager" id="cpttf-recv-pager">
			<div class="cpttf-recv-pager__info" id="cpttf-recv-pager-info">—</div>
			<div class="cpttf-recv-pager__pages" id="cpttf-recv-pager-pages"></div>
			<label class="cpttf-recv-pager__perpage">
				<span>در هر صفحه:</span>
				<select id="cpttf-recv-perpage">
					<option value="10" selected>۱۰</option>
					<option value="25">۲۵</option>
					<option value="50">۵۰</option>
					<option value="100">۱۰۰</option>
					<option value="0">همه</option>
				</select>
			</label>
		</footer>
		<?php endif; ?>
	</section>

	<?php // ─── Inline modal for ثبت پرداخت / تسویه کامل ─── ?>
	<div class="cpttf-modal" id="cpttf-recv-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3 id="cpttf-recv-modal-title">ثبت پرداخت</h3>
				<button class="cpttf-modal__close" data-cpttf-close>×</button>
			</header>
			<form id="cpttf-recv-form" class="cpttf-modal__body">
				<input type="hidden" name="tx_type" value="income">
				<input type="hidden" name="id" value="0">
				<input type="hidden" name="project_id" value="0">
				<input type="hidden" name="customer_id" value="0">
				<p class="cpttf-recv-context" id="cpttf-recv-context" style="margin:0 0 10px;color:#475569;font-size:12.5px;"></p>
				<div class="cpttf-form-grid">
					<label data-recv-only="pay"><span>تاریخ</span><input type="text" name="date_local" placeholder="۱۴۰۳/۰۱/۰۱ ۱۲:۰۰"></label>
					<label><span>حساب مقصد</span>
						<select name="account_id" required>
							<?php foreach ($accounts as $a): ?><option value="<?php echo (int)$a->id; ?>"><?php echo esc_html($a->icon . ' ' . $a->name); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label data-recv-only="pay"><span>مبلغ (<?php echo esc_html($cur); ?>)</span><input type="text" inputmode="numeric" name="amount" class="cpttf-money"></label>
					<label data-recv-only="pay"><span>دسته درآمد</span>
						<select name="category_id">
							<option value="0">— بدون دسته —</option>
							<?php foreach ($cats_in as $c): ?>
								<option value="<?php echo (int)$c->id; ?>" <?php selected($default_income_cat, $c->id); ?>><?php echo esc_html($c->icon . ' ' . $c->name); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="cpttf-full"><span>توضیحات</span><textarea name="description" rows="2"></textarea></label>
				</div>
			</form>
			<footer class="cpttf-modal__foot">
				<button class="cpttf-btn cpttf-btn--ghost" data-cpttf-close>انصراف</button>
				<button class="cpttf-btn cpttf-btn--primary" data-cpttf-submit="recv-pay">ذخیره</button>
			</footer>
		</div>
	</div>

	<script>
	(function(){
		function $(s,c){ return (c||document).querySelector(s); }
		function $$(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); }
		function fmt(n){ return Math.round(+n||0).toLocaleString('en-US'); }
		function toFa(s){ var f=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return String(s).replace(/[0-9]/g,function(d){return f[+d];}); }

		function openRecvModal(btn, mode){
			var modal = $('#cpttf-recv-modal'); if (!modal) return;
			var form = $('#cpttf-recv-form');
			form.reset();
			var pid    = btn.dataset.projectId;
			var cid    = btn.dataset.customerId;
			var remain = +btn.dataset.remain || 0;
			var pTitle = btn.dataset.projectTitle || '';
			var cName  = btn.dataset.customerName || '';
			form.querySelector('[name="project_id"]').value  = pid;
			form.querySelector('[name="customer_id"]').value = cid;
			form.dataset.mode = mode; // 'pay' or 'settle'

			// Show/hide fields based on mode.
			// settle → account + description only. Amount/date/category are
			// filled automatically on submit (see submit handler below).
			$$('#cpttf-recv-form [data-recv-only]').forEach(function(el){
				var only = el.getAttribute('data-recv-only');
				el.style.display = (only === mode) ? '' : 'none';
			});

			if (mode === 'settle'){
				form.querySelector('[name="amount"]').value = remain; // hidden but used on submit
				form.querySelector('[name="description"]').value = 'تسویه کامل — ' + pTitle;
			} else {
				form.querySelector('[name="amount"]').value = ''; // empty by default (user types)
				form.querySelector('[name="description"]').value = 'ثبت پرداخت — ' + pTitle;
				if (window.__cpttfTodayJalali){ form.querySelector('[name="date_local"]').value = window.__cpttfTodayJalali(); }
			}
			$('#cpttf-recv-modal-title').textContent = mode === 'settle' ? '✅ تسویه کامل' : '💵 ثبت پرداخت';
			$('#cpttf-recv-context').innerHTML = '<b>' + cName + '</b> — ' + pTitle + ' · مانده: <b>' + toFa(fmt(remain)) + '</b>';
			modal.hidden = false;
		}

		document.addEventListener('click', function(e){
			var pay = e.target.closest('[data-cpttf-recv-pay]');
			if (pay){ e.preventDefault(); openRecvModal(pay, 'pay'); return; }
			var set = e.target.closest('[data-cpttf-recv-settle]');
			if (set){ e.preventDefault(); openRecvModal(set, 'settle'); return; }

			var sub = e.target.closest('[data-cpttf-submit="recv-pay"]');
			if (sub){
				e.preventDefault();
				var form = $('#cpttf-recv-form');
				var mode = form.dataset.mode || 'pay';
				// For settle mode, ensure amount + date are filled server-side (they may be hidden)
				if (mode === 'settle'){
					if (window.__cpttfTodayJalali) form.querySelector('[name="date_local"]').value = window.__cpttfTodayJalali();
				} else {
					var amtEl = form.querySelector('[name="amount"]');
					if (!amtEl.value || +String(amtEl.value).replace(/[^\d]/g,'') <= 0){
						alert('مبلغ را وارد کنید'); return;
					}
				}
				var data = new FormData(form);
				data.append('action', 'cptt_fin_tx_save');
				data.append('nonce', (window.CPTT_FIN && CPTT_FIN.nonce) || '');
				sub.disabled = true; sub.textContent = '...';
				var xhr = new XMLHttpRequest();
				xhr.open('POST', (window.CPTT_FIN && CPTT_FIN.ajax) || ajaxurl);
				xhr.onload = function(){
					sub.disabled = false; sub.textContent = 'ذخیره';
					var r = null; try { r = JSON.parse(xhr.responseText); } catch(_){}
					if (r && r.success) (window.cpttfReload ? cpttfReload() : location.reload());
					else alert((r && r.data) ? r.data : 'خطا در ذخیره');
				};
				xhr.onerror = function(){ sub.disabled=false; sub.textContent='ذخیره'; alert('خطای شبکه'); };
				xhr.send(data);
			}
		});

		// Sort / filter (client-side, in-memory)
		// ─── Sort / Filter / Search / Paginate ───
		var state = { page: 1, perPage: 10 };
		function toFaNum(n){ return toFa(String(n)); }

		function passesFilter(li){
			var f = ($('#cpttf-recv-filter') || {}).value || 'all';
			if (f === 'phone') return li.dataset.hasPhone === '1';
			if (f === 'multi') return +li.dataset.projects >= 2;
			return true;
		}
		function passesSearch(li){
			var srch = $('#cpttf-recv-search');
			var q = srch ? srch.value.toLowerCase().trim() : '';
			if (!q) return true;
			return (li.getAttribute('data-search') || '').toLowerCase().indexOf(q) !== -1;
		}
		function sortComparator(a, b){
			var mode = ($('#cpttf-recv-sort') || {}).value || 'remain-desc';
			var av, bv;
			switch(mode){
				case 'remain-asc':    av=+a.dataset.remain;  bv=+b.dataset.remain;  return av-bv;
				case 'oldest':        av=+a.dataset.oldest;  bv=+b.dataset.oldest;  return av-bv;
				case 'newest':        av=+a.dataset.newest;  bv=+b.dataset.newest;  return bv-av;
				case 'name-asc':      return String(a.dataset.name).localeCompare(String(b.dataset.name), 'fa');
				case 'projects-desc': av=+a.dataset.projects;bv=+b.dataset.projects;return bv-av;
				default:              av=+a.dataset.remain;  bv=+b.dataset.remain;  return bv-av;
			}
		}

		function render(){
			var list = $('#cpttf-debtor-list'); if (!list) return;
			var all = $$('.cpttf-debtor', list);

			// filter
			var visible = all.filter(function(li){ return passesFilter(li) && passesSearch(li); });
			// sort
			visible.sort(sortComparator);

			// paginate
			var per = +state.perPage || 10;
			var total = visible.length;
			var pages = (per === 0) ? 1 : Math.max(1, Math.ceil(total / per));
			if (state.page > pages) state.page = pages;
			var start = (per === 0) ? 0 : (state.page - 1) * per;
			var end   = (per === 0) ? total : Math.min(total, start + per);

			// hide all first
			all.forEach(function(li){ li.style.display = 'none'; });
			// re-append & show current page slice in correct order
			for (var i = start; i < end; i++){
				visible[i].style.display = '';
				list.appendChild(visible[i]);
			}

			// Info label
			var info = $('#cpttf-recv-count-info');
			if (info){
				if (total === 0) info.textContent = 'موردی مطابق فیلتر پیدا نشد.';
				else info.innerHTML = 'نمایش <b>' + toFaNum(start+1) + '</b> تا <b>' + toFaNum(end) + '</b> از <b>' + toFaNum(total) + '</b> بدهکار';
			}
			var pInfo = $('#cpttf-recv-pager-info');
			if (pInfo) pInfo.textContent = 'صفحه ' + toFaNum(state.page) + ' از ' + toFaNum(pages);

			// Pager buttons
			var pagesWrap = $('#cpttf-recv-pager-pages');
			if (pagesWrap){
				pagesWrap.innerHTML = '';
				if (pages <= 1){ pagesWrap.style.display = 'none'; }
				else {
					pagesWrap.style.display = '';
					function mkBtn(label, page, opts){
						var b = document.createElement('button');
						b.type = 'button';
						b.className = 'cpttf-recv-pager__btn' + ((opts && opts.active) ? ' is-active' : '');
						b.textContent = label;
						if (opts && opts.disabled) b.disabled = true;
						else b.addEventListener('click', function(){ state.page = page; render(); });
						pagesWrap.appendChild(b);
					}
					mkBtn('›', state.page - 1, { disabled: state.page <= 1 }); // prev (RTL: › points to previous)
					// window of pages
					var win = 5;
					var from = Math.max(1, state.page - Math.floor(win/2));
					var to   = Math.min(pages, from + win - 1);
					from = Math.max(1, to - win + 1);
					if (from > 1){
						mkBtn(toFaNum(1), 1, { active: state.page === 1 });
						if (from > 2){ var e = document.createElement('span'); e.textContent='…'; e.style.padding='0 4px'; e.style.color='#94a3b8'; pagesWrap.appendChild(e); }
					}
					for (var p = from; p <= to; p++){
						mkBtn(toFaNum(p), p, { active: p === state.page });
					}
					if (to < pages){
						if (to < pages - 1){ var e2 = document.createElement('span'); e2.textContent='…'; e2.style.padding='0 4px'; e2.style.color='#94a3b8'; pagesWrap.appendChild(e2); }
						mkBtn(toFaNum(pages), pages, { active: state.page === pages });
					}
					mkBtn('‹', state.page + 1, { disabled: state.page >= pages }); // next
				}
			}
		}

		var sortEl = $('#cpttf-recv-sort');   if (sortEl) sortEl.addEventListener('change', function(){ state.page=1; render(); });
		var fltEl  = $('#cpttf-recv-filter'); if (fltEl)  fltEl.addEventListener('change',  function(){ state.page=1; render(); });
		var srch = $('#cpttf-recv-search');
		if (srch){
			srch.addEventListener('input', function(){ state.page=1; render(); });
		}
		var ppEl = $('#cpttf-recv-perpage');
		if (ppEl) ppEl.addEventListener('change', function(){ state.perPage = +ppEl.value || 0; state.page = 1; render(); });

		// Initial render
		render();
	})();
	</script>
	<?php
}
