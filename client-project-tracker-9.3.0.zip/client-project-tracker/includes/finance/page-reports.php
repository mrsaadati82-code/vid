<?php
if (!defined('ABSPATH')) exit;

/**
 * Reports Center (مرکز گزارشات) — v9.3.0 (فاز ۳)
 *
 * فقط‌خواندنی: همه‌ی اعداد از همان منابع رسمی (دفتر مالی + فاکتورها + چک‌ها) و با
 * همان قانون «خنثی‌سازی جفت‌آگاه برگشت» محاسبه می‌شوند؛ هیچ محاسبه‌ی موازیِ جدیدی
 * معرفی نشده و هیچ داده‌ای تغییر نمی‌کند.
 *  - 📅 گزارش سنی مطالبات (بر پایه‌ی سررسید فاکتورهای فروش باز)
 *  - تراز اشخاص (بدهکاران / بستانکاران)
 *  - چک‌های در راه
 *  - آخرین اسناد دفتر
 */

function cpttf_render_reports(){
	global $wpdb;
	$cur = CPTT_Finance::currency_label();
	$t_lgr = CPTT_Finance::tbl_ledger();
	$now = (int)current_time('timestamp', true);

	/* ── داده‌ها ── */
	$aging  = CPTT_Finance::invoice_aging();
	$people = CPTT_Finance::person_balances();
	$debtors  = array_values(array_filter($people, function($p){ return $p['bal'] > 0.005; }));
	$creditors= array_values(array_filter($people, function($p){ return $p['bal'] < -0.005; }));
	usort($debtors,   function($a,$b){ return $b['bal'] <=> $a['bal']; });
	usort($creditors, function($a,$b){ return $a['bal'] <=> $b['bal']; });
	$sum_receiv = array_sum(array_map(function($p){ return (float)$p['bal']; }, $debtors));
	$sum_payable= -array_sum(array_map(function($p){ return (float)$p['bal']; }, $creditors));

	$chq_kpi = CPTT_Finance::cheque_kpis();
	$A = CPTT_Finance::sql_active_cond('l');
	$recent = $wpdb->get_results(
		"SELECT l.id, l.customer_id, l.expert_id, l.voucher_no, l.voucher_kind, l.type, l.direction, l.amount, l.status, l.reversed_by, l.date_fa, l.description
		 FROM $t_lgr l WHERE l.status IN ('posted','reversed','reversal') AND (l.customer_id > 0 OR l.expert_id > 0)
		 ORDER BY l.date_at DESC, l.id DESC LIMIT 10"
	) ?: [];

	$k = function($icon,$label,$value,$color='',$sub=''){
		return '<div class="cpttf-kpi" style="--c:' . esc_attr($color ?: '#64748b') . '"><div class="cpttf-kpi__icon">' . $icon . '</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">' . esc_html($label) . '</span><strong class="cpttf-kpi__value">' . $value . '</strong>' . ($sub !== '' ? '<small class="cpttf-kpi__sub">' . esc_html($sub) . '</small>' : '') . '</div></div>';
	};
	$bucket_head = '<th class="cpttf-num">سررسید نرسیده</th><th class="cpttf-num">۱–۳۰ روز</th><th class="cpttf-num">۳۱–۶۰ روز</th><th class="cpttf-num">۶۱–۹۰ روز</th><th class="cpttf-num">+۹۰ روز</th>';
	$bucket_cells = function($r) use ($cur){
		$o = '';
		foreach (['cur','b30','b60','b90','b90p'] as $b) {
			$o .= '<td class="cpttf-num">' . ((float)$r[$b] > 0 ? '<b>' . CPTT_Finance::fmt($r[$b]) . '</b>' : '<span style="color:#cbd5e1;">۰</span>') . '</td>';
		}
		return $o;
	};
	?>

	<div class="cpttf-reports-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:4px;">
		<small style="color:#64748b;">گزارش «لحظه‌ای» — <?php echo esc_html(CPTT_Finance::fa_date($now)); ?> · همه‌ی اعداد فقط‌خواندنی و از همان دفتر/فاکتور/چک موجود محاسبه می‌شوند (اسناد برگشتی خنثی‌اند).</small>
		<button type="button" class="cpttf-btn cpttf-btn--ghost no-print" onclick="window.print()">🖨 چاپ گزارش</button>
	</div>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4">
		<?php
		echo $k('📈','جمع مطالبات از اشخاص', CPTT_Finance::fmt($sum_receiv) . ' <small>' . esc_html($cur) . '</small>', '#b45309', count($debtors) . ' شخص بدهکار');
		echo $k('📉','جمع بدهی ما به اشخاص', CPTT_Finance::fmt($sum_payable) . ' <small>' . esc_html($cur) . '</small>', '#6d28d9', count($creditors) . ' شخص بستانکار');
		echo $k('🧾','مانده‌ی فاکتورهای باز', CPTT_Finance::fmt($aging['totals']['total']) . ' <small>' . esc_html($cur) . '</small>', '#7c3aed', count($aging['rows']) . ' طرف‌حساب');
		echo $k('🏦','چک‌های در راه (دریافت − پرداخت)', CPTT_Finance::fmt((float)$chq_kpi['pend_in'] - (float)$chq_kpi['pend_out']) . ' <small>' . esc_html($cur) . '</small>', '#0ea5e9', CPTT_Finance::fmt($chq_kpi['pend_n']) . ' سند در انتظار');
		?>
	</div>

	<?php // ── گزارش سنی مطالبات ── ?>
	<section class="cpttf-card">
		<header class="cpttf-card__head">
			<div>
				<h2>📅 گزارش سنی مطالبات</h2>
				<small style="color:#64748b;font-size:12px;">مانده‌ی فاکتورهای فروشِ باز، به‌تفکیک روزهای گذشته از سررسید — مبنای پیگیری وصول</small>
			</div>
		</header>
		<div class="cpttf-card__body">
			<?php if (empty($aging['rows'])): ?>
				<p class="cpttf-empty">فاکتور فروشِ بازی وجود ندارد 🎉</p>
			<?php else: ?>
			<div class="cpttf-table-wrap">
				<table class="cpttf-table cpttf-aging-table">
					<thead><tr><th>شخص</th><?php echo $bucket_head; ?><th class="cpttf-num">جمع مانده</th></tr></thead>
					<tbody>
					<?php foreach ($aging['rows'] as $r): ?>
						<tr>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$r['person_id'])); ?>"><b><?php echo esc_html($r['name']); ?></b></a></td>
							<?php echo $bucket_cells($r); ?>
							<td class="cpttf-num"><b style="color:#b45309;"><?php echo CPTT_Finance::fmt($r['total']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot>
						<tr style="background:#f8fafc;font-weight:900;">
							<td>جمع کل</td>
							<?php echo $bucket_cells($aging['totals']); ?>
							<td class="cpttf-num"><b><?php echo CPTT_Finance::fmt($aging['totals']['total']); ?> <?php echo esc_html($cur); ?></b></td>
						</tr>
					</tfoot>
				</table>
			</div>
			<?php endif; ?>
		</div>
	</section>

	<div class="cpttf-grid cpttf-grid--2">
		<?php // ── بدهکاران ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>📈 بیشترین بدهکاران</h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($debtors)): ?><p class="cpttf-empty">بدهکاری نیست.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>#</th><th>شخص</th><th class="cpttf-num">مانده (بدهکار)</th></tr></thead>
					<tbody>
					<?php $i = 1; foreach (array_slice($debtors, 0, 10) as $p): ?>
						<tr>
							<td><?php echo $i++; ?></td>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$p['id'])); ?>"><?php echo esc_html($p['name']); ?></a></td>
							<td class="cpttf-num"><b style="color:#b45309;"><?php echo CPTT_Finance::fmt($p['bal']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>

		<?php // ── بستانکاران ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>📉 بیشترین بستانکاران <small style="font-weight:500;color:#64748b;">(مازاد پرداخت — ما بدهکاریم)</small></h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($creditors)): ?><p class="cpttf-empty">بستانکاری نیست.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>#</th><th>شخص</th><th class="cpttf-num">مانده (بستانکار)</th></tr></thead>
					<tbody>
					<?php $i = 1; foreach (array_slice($creditors, 0, 10) as $p): ?>
						<tr>
							<td><?php echo $i++; ?></td>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$p['id'])); ?>"><?php echo esc_html($p['name']); ?></a></td>
							<td class="cpttf-num"><b style="color:#6d28d9;"><?php echo CPTT_Finance::fmt(-$p['bal']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>
	</div>

	<?php // ── آخرین اسناد ── ?>
	<section class="cpttf-card">
		<header class="cpttf-card__head"><h2>📄 آخرین اسناد دفتر</h2></header>
		<div class="cpttf-card__body">
			<?php if (empty($recent)): ?><p class="cpttf-empty">سندی نیست.</p><?php else: ?>
			<div class="cpttf-table-wrap"><table class="cpttf-table">
				<thead><tr><th>شماره سند</th><th>تاریخ</th><th>نوع</th><th class="cpttf-num">واریز</th><th class="cpttf-num">برداشت</th><th>وضعیت</th></tr></thead>
				<tbody>
				<?php foreach ($recent as $v):
					$vd = (int)$v->direction >= 0 ? 1 : -1;
					$vnt = CPTT_Finance::is_row_neutral($v);
					$vno = (string)$v->voucher_no !== '' ? $v->voucher_no : ('#' . (int)$v->id);
				?>
					<tr class="<?php echo $vnt ? 'is-reversed' : ''; ?>">
						<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($vno); ?></b></td>
						<td><?php echo esc_html($v->date_fa); ?></td>
						<td><?php echo esc_html(CPTT_Finance::voucher_label($v)); ?></td>
						<td class="cpttf-num cpttf-text-success"><?php echo $vd > 0 ? '<b>' . CPTT_Finance::fmt($v->amount) . '</b>' : '—'; ?></td>
						<td class="cpttf-num cpttf-text-danger"><?php echo $vd < 0 ? '<b>' . CPTT_Finance::fmt($v->amount) . '</b>' : '—'; ?></td>
						<td><?php echo $vnt ? '⚪ خنثی' : 'فعال'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
			<?php endif; ?>
		</div>
	</section>

	<?php // ── دسترسی سریع ── ?>
	<section class="cpttf-card no-print">
		<header class="cpttf-card__head"><h2>🔗 دسترسی سریع</h2></header>
		<div class="cpttf-card__body" style="display:flex;flex-wrap:wrap;gap:8px;">
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons')); ?>">🪪 اشخاص</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&fstatus=open')); ?>">🧾 فاکتورهای باز</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&foverdue=1')); ?>">⚠️ فاکتورهای سررسید گذشته</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-cheques&fstatus=pending')); ?>">🏦 چک‌های در انتظار</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-ledger')); ?>">📑 گردش حساب</a>
		</div>
	</section>
	<?php
}
