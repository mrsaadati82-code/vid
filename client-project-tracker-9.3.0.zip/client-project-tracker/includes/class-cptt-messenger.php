<?php
if (!defined('ABSPATH')) exit;

/**
 * CPTT_Messenger — پیام‌رسان جدید «هماهنگ» (نسخه 9.2.47)
 *
 * رابط کاربری مدرن پیام‌رسان (React) که به‌طور کامل با زیرساخت چت قبلی
 * افزونه ادغام شده است:
 *  - «گفتگوهای گروهی» = چت پروژه‌ها  → همان متای `_cptt_expert_messages`
 *  - «گفتگوهای شخصی» = چت مستقیم کارشناسان → همان جدول `cptt_expert_chats`
 *  - «پیام‌های ذخیره‌شده» = چت مستقیم با خود کاربر
 *
 * تمام امکانات قبلی حفظ می‌شود: ارسال/حذف پیام، پیوست فایل، اعلان‌ها،
 * حضور آنلاین (cptt_expert_last_seen) و سازگاری با رابط قدیمی (متن پیام
 * پروژه همچنان لینک «دانلود فایل پیوست» را هم در خود دارد).
 * امکانات جدید: پاسخ (ریپلای)، ویرایش، واکنش (ری‌اکشن)، سنجاق پیام،
 * سنجاق/بی‌صدا/بایگانی گفتگو، پیام صوتی واقعی، نشان در حال تایپ،
 * خوانده‌نشده، جستجو، حالت تیره، پنل اطلاعات و گفتگو با خود (ذخیره‌شده‌ها).
 */
class CPTT_Messenger {

	private static $instance = null;

	const DBV_OPTION = 'cptt_msgr_dbv';
	const DBV = '1';
	const READ_META = '_cptt_msgr_read';
	const PREF_META = '_cptt_msgr_prefs';

	public static function instance() {
		if (self::$instance === null) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action('init', [$this, 'register_query_vars']);
		add_action('template_redirect', [$this, 'maybe_render_page'], 1);
		add_action('admin_init', [$this, 'maybe_upgrade_db']);
		add_action('wp_loaded', [$this, 'maybe_upgrade_db']);

		add_action('wp_ajax_cptt_msgr_fetch',  [$this, 'ajax_fetch']);
		add_action('wp_ajax_cptt_msgr_send',   [$this, 'ajax_send']);
		add_action('wp_ajax_cptt_msgr_edit',   [$this, 'ajax_edit']);
		add_action('wp_ajax_cptt_msgr_delete', [$this, 'ajax_delete']);
		add_action('wp_ajax_cptt_msgr_react',  [$this, 'ajax_react']);
		add_action('wp_ajax_cptt_msgr_pin',    [$this, 'ajax_pin']);
		add_action('wp_ajax_cptt_msgr_pref',   [$this, 'ajax_pref']);
		add_action('wp_ajax_cptt_msgr_clear',  [$this, 'ajax_clear']);
		add_action('wp_ajax_cptt_msgr_typing', [$this, 'ajax_typing']);
		add_action('wp_ajax_cptt_msgr_poll',   [$this, 'ajax_poll']);
	}

	public function register_query_vars() {
		add_rewrite_tag('%cptt_messenger%', '1');
	}

	public static function page_url($args = []) {
		return add_query_arg(array_merge(['cptt_messenger' => 1], $args), home_url('/'));
	}

	/* ------------------------------------------------------------------
	 * ارتقای اسکیمای جدول چت مستقیم (ستون‌های قابلیت‌های جدید)
	 * ------------------------------------------------------------------ */
	public function maybe_upgrade_db() {
		if (get_option(self::DBV_OPTION) === self::DBV) return;
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
		if ($exists === $table) {
			$cols = $wpdb->get_col("SHOW COLUMNS FROM {$table}", 0);
			$alters = [];
			if (!in_array('reply_to', $cols, true))  $alters[] = "ADD COLUMN reply_to varchar(64) DEFAULT NULL";
			if (!in_array('edited', $cols, true))    $alters[] = "ADD COLUMN edited tinyint(1) NOT NULL DEFAULT 0";
			if (!in_array('reactions', $cols, true)) $alters[] = "ADD COLUMN reactions text DEFAULT NULL";
			if (!in_array('pinned', $cols, true))    $alters[] = "ADD COLUMN pinned tinyint(1) NOT NULL DEFAULT 0";
			if (!in_array('file_kind', $cols, true)) $alters[] = "ADD COLUMN file_kind varchar(20) DEFAULT NULL";
			if (!in_array('file_name', $cols, true)) $alters[] = "ADD COLUMN file_name varchar(255) DEFAULT NULL";
			if (!in_array('file_size', $cols, true)) $alters[] = "ADD COLUMN file_size varchar(32) DEFAULT NULL";
			if (!in_array('duration', $cols, true))  $alters[] = "ADD COLUMN duration int(11) DEFAULT NULL";
			foreach ($alters as $a) { $wpdb->query("ALTER TABLE {$table} {$a}"); }
		}
		update_option(self::DBV_OPTION, self::DBV, false);
	}

	/* ------------------------------------------------------------------
	 * دسترسی‌ها و ابزارهای پایه
	 * ------------------------------------------------------------------ */
	private function check_access() {
		if (!is_user_logged_in()) wp_send_json_error(['message' => 'ابتدا وارد شوید'], 401);
		check_ajax_referer('cptt_expert_nonce', 'nonce');
	}

	private function can_open_project($project_id, $uid) {
		$project_id = (int)$project_id;
		if (!$project_id || get_post_type($project_id) !== 'cptt_project') return false;
		if (user_can($uid, 'manage_options')) return true;
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'get_project_expert_ids')) {
			return in_array((int)$uid, array_map('intval', (array)CPTT_Core::get_project_expert_ids($project_id)), true);
		}
		return false;
	}

	private function project_expert_ids($project_id) {
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'get_project_expert_ids')) {
			return array_map('intval', (array)CPTT_Core::get_project_expert_ids($project_id));
		}
		return [];
	}

	private function dashboard_url() {
		if (class_exists('CPTT_Expert') && method_exists('CPTT_Expert', 'dashboard_url')) return CPTT_Expert::dashboard_url();
		return home_url('/');
	}

	private function avatar_url($uid, $size = 160) {
		$avatar_id = (int)get_user_meta($uid, 'cptt_expert_avatar_id', true);
		if ($avatar_id) {
			$u = wp_get_attachment_image_url($avatar_id, $size >= 120 ? 'medium' : 'thumbnail');
			if ($u) return $u;
		}
		return get_avatar_url($uid, ['size' => $size]);
	}

	private function color_for($seed) {
		static $palette = [
			'from-rose-400 to-pink-600', 'from-amber-400 to-orange-600',
			'from-emerald-400 to-teal-600', 'from-sky-400 to-blue-600',
			'from-violet-400 to-purple-600', 'from-fuchsia-400 to-pink-600',
			'from-cyan-400 to-sky-600', 'from-lime-400 to-green-600',
			'from-red-400 to-rose-600', 'from-indigo-400 to-blue-700',
		];
		return $palette[absint(is_numeric($seed) ? $seed : crc32((string)$seed)) % count($palette)];
	}

	private function presence($uid) {
		$last = (int)get_user_meta($uid, 'cptt_expert_last_seen', true);
		$now = (int)current_time('timestamp', true);
		$online = $last && ($now - $last) <= 150;
		return ['online' => $online, 'lastSeen' => $last ? $last * 1000 : 0];
	}

	private function participant($uid, $with_bio = true) {
		$u = get_user_by('id', $uid);
		if (!$u) return null;
		$p = $this->presence($uid);
		$out = [
			'id' => 'u' . (int)$uid,
			'name' => $u->display_name ?: $u->user_login,
			'avatarColor' => $this->color_for($uid),
			'avatarUrl' => $this->avatar_url($uid),
			'online' => $p['online'],
			'username' => $u->user_login,
		];
		if (!$p['online'] && $p['lastSeen']) $out['lastSeen'] = $p['lastSeen'];
		if ($with_bio) {
			$bio = get_user_meta($uid, 'cptt_expert_short_bio', true);
			if ($bio) $out['bio'] = $bio;
		}
		/* v9.2.47 — ایموجی «وضعیت روزانه» کاربر (همان ثبت روزانه‌ی ورود به داشبورد) */
		if (function_exists('get_expert_mood_emoji')) {
			$mood = (string)get_expert_mood_emoji((int)$uid);
			if ($mood !== '') $out['mood'] = $mood;
		}
		return $out;
	}

	private function get_read_markers($uid) {
		$m = get_user_meta($uid, self::READ_META, true);
		return is_array($m) ? $m : [];
	}

	private function get_prefs($uid) {
		$p = get_user_meta($uid, self::PREF_META, true);
		return is_array($p) ? $p : [];
	}

	/* ------------------------------------------------------------------
	 * مدل گفتگو: p<ID> = چت پروژه | d<UID> = چت مستقیم با کاربر UID
	 * ------------------------------------------------------------------ */
	private function parse_chat_id($chat) {
		$chat = sanitize_text_field((string)$chat);
		if (preg_match('/^p(\d+)$/', $chat, $m)) return ['kind' => 'project', 'id' => (int)$m[1], 'key' => $chat];
		if (preg_match('/^d(\d+)$/', $chat, $m)) return ['kind' => 'direct', 'id' => (int)$m[1], 'key' => $chat];
		return null;
	}

	private function can_open_chat($c, $uid) {
		if (!$c) return false;
		if ($c['kind'] === 'project') return $this->can_open_project($c['id'], $uid);
		if ($c['id'] <= 0) return false;
		return (bool)get_user_by('id', $c['id']);
	}

	private function my_project_ids($uid) {
		$args = [
			'post_type' => 'cptt_project',
			'posts_per_page' => -1,
			'post_status' => 'any',
			'fields' => 'ids',
			'no_found_rows' => true,
		];
		if (!user_can($uid, 'manage_options')) {
			$args['meta_query'] = [[
				'key' => '_cptt_experts_csv',
				'value' => ',' . (int)$uid . ',',
				'compare' => 'LIKE',
			]];
		}
		$q = new WP_Query($args);
		return array_map('intval', (array)$q->posts);
	}

	private function contact_user_ids($uid, $project_ids) {
		$ids = [];
		foreach ($project_ids as $pid) {
			foreach ($this->project_expert_ids($pid) as $eid) $ids[$eid] = 1;
		}
		/* همه‌ی کارشناسان و مدیران هم قابل گفتگو باشند (مثل لیست «همکاران کارشناس» قبلی) */
		$users = get_users(['role__in' => ['cptt_expert', 'administrator'], 'fields' => 'ID', 'number' => 200]);
		foreach ((array)$users as $id) $ids[(int)$id] = 1;
		unset($ids[(int)$uid]);
		return array_map('intval', array_keys($ids));
	}

	/* ------------------------------------------------------------------
	 * پیام‌های پروژه (متای پست) — نرمال‌سازی به فرمت رابط جدید
	 * ------------------------------------------------------------------ */
	private function get_project_messages_raw($project_id) {
		$m = get_post_meta($project_id, '_cptt_expert_messages', true);
		return is_array($m) ? $m : [];
	}

	private function legacy_file_from_content($content) {
		// قالب قدیمی: متن + لینک «دانلود فایل پیوست» در انتهای content
		if (!is_string($content) || strpos($content, 'cptt-chat-file-link') === false) {
			return [$content, null];
		}
		if (preg_match('#<a[^>]+href="([^"]+)"[^>]*class="[^"]*cptt-chat-file-link[^"]*"[^>]*>.*?</a>#s', $content, $mm)
			|| preg_match('#<a[^>]+class="[^"]*cptt-chat-file-link[^"]*"[^>]+href="([^"]+)"[^>]*>.*?</a>#s', $content, $mm)) {
			$url = esc_url_raw(html_entity_decode($mm[1]));
			$text = trim(str_replace($mm[0], '', $content));
			return [$text, $url];
		}
		return [$content, null];
	}

	private function reaction_list($raw, $uid) {
		$out = [];
		$rx = (is_array($raw) && !empty($raw['reactions']) && is_array($raw['reactions'])) ? $raw['reactions'] : [];
		foreach ($rx as $emoji => $uids) {
			$uids = array_values(array_unique(array_map('intval', (array)$uids)));
			if (!count($uids)) continue;
			$out[] = ['emoji' => (string)$emoji, 'count' => count($uids), 'reactedByMe' => in_array((int)$uid, $uids, true)];
		}
		return $out;
	}

	private function resolve_reply($storage_kind, $storage_id, $reply_id) {
		$reply_id = (string)$reply_id;
		if ($reply_id === '') return null;
		if ($storage_kind === 'project') {
			foreach ($this->get_project_messages_raw($storage_id) as $m) {
				if ((string)($m['id'] ?? '') !== $reply_id) continue;
				return $this->reply_payload('project', $m);
			}
		} else {
			global $wpdb;
			$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}cptt_expert_chats WHERE id = %d", (int)$reply_id), ARRAY_A);
			if ($row) return $this->reply_payload('direct', $row);
		}
		return null;
	}

	private function reply_payload($kind, $m) {
		if ($kind === 'project') {
			$id = (string)($m['id'] ?? '');
			$sender_id = (int)($m['sender_id'] ?? 0);
			list($text, $file) = $this->legacy_file_from_content((string)($m['content'] ?? ''));
			if (!empty($m['file']['url'])) $file = $m['file']['url'];
		} else {
			$id = (string)(int)$m['id'];
			$sender_id = (int)$m['sender_id'];
			$text = (string)$m['message'];
			$file = $m['file_url'] ?? '';
		}
		$u = $sender_id ? get_user_by('id', $sender_id) : null;
		$preview = trim(wp_strip_all_tags((string)$text));
		if ($preview === '' && $file) $preview = 'پیوست';
		if (function_exists('mb_substr')) $preview = mb_substr($preview, 0, 90); else $preview = substr($preview, 0, 90);
		return ['messageId' => $id, 'senderName' => $u ? $u->display_name : 'کاربر', 'preview' => $preview];
	}

	private function normalize_project_message($m, $index, $project_id, $uid, $read_marks_all) {
		$text_raw = (string)($m['content'] ?? '');
		list($text, $legacy_file) = $this->legacy_file_from_content($text_raw);

		$file = (isset($m['file']) && is_array($m['file']) && !empty($m['file']['url'])) ? $m['file'] : null;
		if (!$file && $legacy_file) $file = ['url' => $legacy_file, 'name' => 'پیوست', 'size' => '', 'kind' => 'file'];

		$type = 'text';
		$att = null;
		if ($file) {
			$kind = in_array(($file['kind'] ?? ''), ['image', 'voice', 'file'], true) ? $file['kind'] : 'file';
			$type = $kind;
			$att = ['kind' => $kind, 'url' => $file['url']];
			if (!empty($file['name'])) $att['name'] = $file['name'];
			if (!empty($file['size'])) $att['size'] = $file['size'];
			if (!empty($file['duration'])) $att['duration'] = (int)$file['duration'];
			if ($kind === 'image' && empty($att['name'])) $att['name'] = 'عکس';
		}

		$sender_id = (int)($m['sender_id'] ?? 0);
		$sender = $sender_id ? get_user_by('id', $sender_id) : null;
		$time = (int)($m['time'] ?? 0);

		$status = 'sent';
		if ($sender_id === (int)$uid) {
			$status = 'delivered';
			foreach ($read_marks_all as $other_uid => $mark) {
				if ((int)$other_uid === (int)$uid) continue;
				if ((int)$mark >= $time && $time > 0) { $status = 'read'; break; }
			}
		}

		$replyTo = null;
		if (!empty($m['reply_to'])) $replyTo = $this->resolve_reply('project', $project_id, (string)$m['reply_to']);

		return [
			'id' => (string)($m['id'] ?? ('pm_' . $index)),
			'chatId' => 'p' . (int)$project_id,
			'senderId' => 'u' . $sender_id,
			'senderName' => $sender ? $sender->display_name : 'کاربر',
			'text' => (string)$text,
			'type' => $type,
			'attachment' => $att,
			'createdAt' => $time * 1000,
			'status' => $status,
			'edited' => !empty($m['edited']),
			'reactions' => $this->reaction_list($m, $uid),
			'replyTo' => $replyTo,
			'pinned' => !empty($m['pinned']),
		];
	}

	private function normalize_direct_row($row, $uid, $other_read_mark) {
		$file_url = (string)($row['file_url'] ?? '');
		$kind = in_array(($row['file_kind'] ?? ''), ['image', 'voice', 'file'], true) ? $row['file_kind'] : ($file_url ? 'file' : '');
		$type = $kind ?: 'text';
		$att = null;
		if ($file_url) {
			$att = ['kind' => $kind ?: 'file', 'url' => $file_url];
			if (!empty($row['file_name'])) $att['name'] = $row['file_name'];
			if (!empty($row['file_size'])) $att['size'] = $row['file_size'];
			if (!empty($row['duration'])) $att['duration'] = (int)$row['duration'];
		}
		/* تشخیص عکس از روی پسوند برای پیام‌های قدیمی */
		if ($att && $kind === 'file' && preg_match('/\.(png|jpe?g|gif|webp|bmp)$/i', (string)($att['name'] ?? $file_url))) {
			$att['kind'] = 'image';
			$type = 'image';
		}

		$sender_id = (int)$row['sender_id'];
		$sender = $sender_id ? get_user_by('id', $sender_id) : null;
		$time = strtotime(get_gmt_from_date($row['created_at']));

		$status = 'sent';
		if ($sender_id === (int)$uid) {
			$status = ($time > 0 && (int)$other_read_mark >= $time) ? 'read' : 'delivered';
		}

		$replyTo = null;
		if (!empty($row['reply_to'])) $replyTo = $this->resolve_reply('direct', 0, (string)$row['reply_to']);

		return [
			'id' => (string)(int)$row['id'],
			'chatId' => null, /* بعداً ست می‌شود */
			'senderId' => 'u' . $sender_id,
			'senderName' => ($sender_id === (int)$uid) ? 'شما' : ($sender ? $sender->display_name : 'کاربر'),
			'text' => (string)$row['message'],
			'type' => $type,
			'attachment' => $att,
			'createdAt' => $time * 1000,
			'status' => $status,
			'edited' => !empty($row['edited']),
			'reactions' => $this->reaction_list(['reactions' => json_decode((string)($row['reactions'] ?? ''), true) ?: []], $uid),
			'replyTo' => $replyTo,
			'pinned' => !empty($row['pinned']),
		];
	}

	private function get_direct_rows($uid, $other_id, $after_id = 0, $limit = 0) {
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$sql = "SELECT * FROM {$table} WHERE ((sender_id = %d AND receiver_id = %d) OR (sender_id = %d AND receiver_id = %d))";
		$args = [$uid, $other_id, $other_id, $uid];
		if ($after_id > 0) { $sql .= " AND id > %d"; $args[] = $after_id; }
		$sql .= " ORDER BY id ASC";
		if ($limit > 0) $sql = "SELECT * FROM ({$sql} LIMIT 999999) t ORDER BY id DESC LIMIT %d";
		if ($limit > 0) $args[] = $limit;
		$rows = $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
		if ($limit > 0) $rows = array_reverse((array)$rows);
		return $rows ?: [];
	}

	private function chat_participant_read_marks($chat, $uid) {
		/* نشانه‌های خواندن همه‌ی شرکت‌کنندگان (برای وضعیت «خوانده‌شده») */
		$marks = [];
		$uids = [];
		if ($chat['kind'] === 'project') $uids = $this->project_expert_ids($chat['id']);
		else $uids = [$chat['id']];
		foreach ($uids as $puid) {
			$m = $this->get_read_markers($puid);
			$marks[$puid] = (int)($m[$chat['key']] ?? 0);
		}
		return $marks;
	}

	private function unread_count($chat, $uid) {
		$markers = $this->get_read_markers($uid);
		$has_marker = array_key_exists($chat['key'], $markers);
		$mark = (int)($markers[$chat['key']] ?? 0);
		if ($chat['kind'] === 'project') {
			$msgs = $this->get_project_messages_raw($chat['id']);
			$since = $has_marker ? $mark : (current_time('timestamp', true) - DAY_IN_SECONDS); /* بدون نشانه: فقط ۲۴ ساعت اخیر */
			$n = 0;
			foreach ($msgs as $m) {
				if ((int)($m['sender_id'] ?? 0) === (int)$uid) continue;
				if ((int)($m['time'] ?? 0) > $since) $n++;
			}
			return min($n, 99);
		}
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$since_mysql = $has_marker ? get_date_from_gmt(gmdate('Y-m-d H:i:s', $mark)) : get_date_from_gmt(gmdate('Y-m-d H:i:s', current_time('timestamp', true) - DAY_IN_SECONDS));
		$n = (int)$wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$table} WHERE sender_id = %d AND receiver_id = %d AND created_at > %s",
			$chat['id'], $uid, $since_mysql
		));
		return min($n, 99);
	}

	/* ------------------------------------------------------------------
	 * ساختار گفتگو برای رابط کاربری
	 * ------------------------------------------------------------------ */
	private function chat_payload($chat, $uid) {
		$prefs = $this->get_prefs($uid);
		$p = (isset($prefs[$chat['key']]) && is_array($prefs[$chat['key']])) ? $prefs[$chat['key']] : [];
		$marks = $this->chat_participant_read_marks($chat, $uid);

		if ($chat['kind'] === 'project') {
			$post = get_post($chat['id']);
			if (!$post) return null;
			$experts = $this->project_expert_ids($chat['id']);
			$participants = [];
			foreach ($experts as $eid) {
				if ((int)$eid === (int)$uid) continue;
				$pj = $this->participant($eid, false);
				if ($pj) $participants[] = $pj;
			}
			$msgs = $this->get_project_messages_raw($chat['id']);
			$count = count($msgs);
			$last = $count ? $this->normalize_project_message($msgs[$count - 1], $count - 1, $chat['id'], $uid, $marks) : null;
			return [
				'id' => $chat['key'],
				'type' => 'group',
				'title' => get_the_title($post) ?: ('پروژه #' . $chat['id']),
				'avatarColor' => $this->color_for($chat['id'] * 7 + 3),
				'avatarEmoji' => '📁',
				'participants' => $participants,
				'memberCount' => count($experts),
				'unreadCount' => $this->unread_count($chat, $uid),
				'muted' => !empty($p['muted']),
				'pinned' => !empty($p['pinned']),
				'archived' => !empty($p['archived']),
				'projectId' => (int)$chat['id'],
				'lastMessage' => $last,
				'cursor' => $count,
			];
		}

		/* مستقیم */
		$other = $this->participant($chat['id']);
		if (!$other) return null;
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$last_row = $wpdb->get_row($wpdb->prepare(
			"SELECT * FROM {$table} WHERE (sender_id = %d AND receiver_id = %d) OR (sender_id = %d AND receiver_id = %d) ORDER BY id DESC LIMIT 1",
			$uid, $chat['id'], $chat['id'], $uid
		), ARRAY_A);
		$last = $last_row ? $this->normalize_direct_row($last_row, $uid, (int)($marks[$chat['id']] ?? 0)) : null;
		if ($last) $last['chatId'] = $chat['key'];
		$cursor = $last_row ? (int)$last_row['id'] : 0;
		return [
			'id' => $chat['key'],
			'type' => 'private',
			'title' => $other['name'],
			'avatarColor' => $other['avatarColor'],
			'avatarUrl' => $other['avatarUrl'] ?? '',
			'participants' => [$other],
			'unreadCount' => $this->unread_count($chat, $uid),
			'muted' => !empty($p['muted']),
			'pinned' => !empty($p['pinned']),
			'archived' => !empty($p['archived']),
			'username' => $other['username'] ?? '',
			'bio' => $other['bio'] ?? '',
			'lastMessage' => $last,
			'cursor' => $cursor,
		];
	}

	private function direct_peer_ids_with_history($uid) {
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$ids1 = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT receiver_id FROM {$table} WHERE sender_id = %d", $uid));
		$ids2 = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT sender_id FROM {$table} WHERE receiver_id = %d", $uid));
		$all = array_map('intval', array_merge((array)$ids1, (array)$ids2));
		$all = array_values(array_unique($all));
		return $all;
	}

	/* ------------------------------------------------------------------
	 * رندر صفحه‌ی مستقل پیام‌رسان
	 * ------------------------------------------------------------------ */
	public function maybe_render_page() {
		$is = get_query_var('cptt_messenger') || isset($_GET['cptt_messenger']);
		if (!$is) return;
		if (!is_user_logged_in()) { wp_safe_redirect(wp_login_url(self::page_url())); exit; }
		$this->render_page();
		exit;
	}

	private function render_page() {
		$uid = get_current_user_id();
		nocache_headers();
		show_admin_bar(false);

		/* --- داده‌ی بوت --- */
		$project_ids = $this->my_project_ids($uid);
		$chats = [];
		$cursors = [];
		foreach ($project_ids as $pid) {
			$c = $this->chat_payload(['kind' => 'project', 'id' => $pid, 'key' => 'p' . $pid], $uid);
			if (!$c) continue;
			$chats[] = $c;
			$cursors[$c['id']] = $c['cursor'];
			unset($c['cursor']);
		}
		foreach ($this->direct_peer_ids_with_history($uid) as $peer) {
			$c = $this->chat_payload(['kind' => 'direct', 'id' => $peer, 'key' => 'd' . $peer], $uid);
			if (!$c) continue;
			$chats[] = $c;
			$cursors[$c['id']] = $c['cursor'];
			unset($c['cursor']);
		}

		$me_p = $this->participant($uid);
		$contacts = [];
		foreach ($this->contact_user_ids($uid, $project_ids) as $cid) {
			$cp = $this->participant($cid);
			if ($cp) $contacts[] = $cp;
		}

		$initial = isset($_GET['chat']) ? sanitize_text_field((string)$_GET['chat']) : null;
		if ($initial && !preg_match('/^(p|d)\d+$/', $initial)) $initial = null;

		$boot = [
			'ajax' => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce('cptt_expert_nonce'),
			'me' => $me_p,
			'contacts' => $contacts,
			'chats' => $chats,
			'cursors' => $cursors,
			'initialChat' => $initial,
			'dashboardUrl' => $this->dashboard_url(),
			'savedTitle' => 'پیام‌های ذخیره‌شده',
			'version' => defined('CPTT_VERSION') ? CPTT_VERSION : '',
		];

		$ver = defined('CPTT_VERSION') ? CPTT_VERSION : '1.0.0';
		$js = CPTT_URL . 'assets/messenger/cptt-messenger.js';
		$css = CPTT_URL . 'assets/messenger/cptt-messenger.css';
		?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title>پیام‌رسان هماهنگ</title>
<style>
@font-face{font-family:Vazirmatn;src:url('<?php echo esc_url(CPTT_URL . 'assets/fonts/Vazirmatn-Regular.ttf'); ?>') format('truetype');font-weight:400;font-display:swap}
@font-face{font-family:Vazirmatn;src:url('<?php echo esc_url(CPTT_URL . 'assets/fonts/Vazirmatn-Bold.ttf'); ?>') format('truetype');font-weight:700;font-display:swap}
html,body{margin:0;padding:0;height:100%;font-family:Vazirmatn,ui-sans-serif,system-ui,Tahoma,sans-serif;background:#eef0f5;overflow:hidden}
#root{height:100%}
.cptt-msgr-boot{display:flex;flex-direction:column;gap:14px;align-items:center;justify-content:center;height:100%;color:#94a3b8;font-size:13px}
.cptt-msgr-boot .spin{width:34px;height:34px;border:3px solid #c4b5fd;border-top-color:#7c3aed;border-radius:50%;animation:cpttmsgr-spin .8s linear infinite}
@keyframes cpttmsgr-spin{to{transform:rotate(360deg)}}
/* v9.2.47 — نشان «وضعیت روزانه» کنار آواتارها در پیام‌رسان */
.cptt-msgr-moodBadge{position:absolute;left:-3px;bottom:-3px;z-index:3;display:inline-flex;align-items:center;justify-content:center;min-width:16px;height:16px;padding:0 2px;border-radius:999px;background:#fff;box-shadow:0 2px 8px rgba(15,23,42,.25);font-size:11px;line-height:1;pointer-events:none}
</style>
<link rel="stylesheet" href="<?php echo esc_url($css); ?>?ver=<?php echo esc_attr($ver); ?>">
</head>
<body>
<div id="root"><div class="cptt-msgr-boot"><div class="spin"></div>در حال بارگذاری پیام‌رسان هماهنگ...</div></div>
<script>window.CPTT_MSGR = <?php echo wp_json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP); ?>;</script>
<script>
/* v9.2.47 — تزریق نشان «وضعیت روزانه» کنار آواتار کاربران در پیام‌رسان.
   داده‌ی mood از بوت (participant) خوانده می‌شود و بر اساس آدرس منحصربه‌فرد
   تصویر آواتار به صورت خودکار روی آواتارهای رندرشده‌ی React سوار می‌شود. */
(function(){
	'use strict';
	var MAP = {};
	function addP(p){ if (p && p.avatarUrl && p.mood) MAP[p.avatarUrl] = p.mood; }
	(function(){
		var b = window.CPTT_MSGR || {};
		addP(b.me);
		(b.contacts || []).forEach(addP);
		(b.chats || []).forEach(function(c){ (c.participants || []).forEach(addP); });
	})();
	function decorate(){
		var root = document.getElementById('root');
		if (!root) return;
		var imgs = root.querySelectorAll('img');
		for (var i = 0; i < imgs.length; i++){
			var img = imgs[i];
			if (!img || img.dataset.cpttMoodDone === '1') continue;
			var mood = MAP[img.src] || MAP[img.getAttribute('src') || ''];
			if (!mood) continue;
			var host = img.parentElement;
			if (!host) continue;
			img.dataset.cpttMoodDone = '1';
			if (window.getComputedStyle && getComputedStyle(host).position === 'static') host.style.position = 'relative';
			var badge = document.createElement('span');
			badge.className = 'cptt-msgr-moodBadge';
			badge.textContent = mood;
			badge.title = 'وضعیت امروز';
			host.appendChild(badge);
		}
	}
	var t = null;
	if (window.MutationObserver){
		new MutationObserver(function(){ if (t) clearTimeout(t); t = setTimeout(decorate, 120); })
			.observe(document.body, { childList: true, subtree: true });
	}
	decorate();
	setTimeout(decorate, 800);
	setTimeout(decorate, 2000);
})();
</script>
<script src="<?php echo esc_url($js); ?>?ver=<?php echo esc_attr($ver); ?>" defer></script>
</body>
</html>
		<?php
	}

	/* ------------------------------------------------------------------
	 * AJAX: دریافت پیام‌ها
	 * ------------------------------------------------------------------ */
	public function ajax_fetch() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی به این گفتگو ندارید'], 403);
		$limit = min(300, max(20, absint($_POST['limit'] ?? 120)));

		if ($chat['kind'] === 'project') {
			$msgs = $this->get_project_messages_raw($chat['id']);
			$total = count($msgs);
			$slice = array_slice($msgs, max(0, $total - $limit));
			$marks = $this->chat_participant_read_marks($chat, $uid);
			$out = [];
			foreach (array_values($slice) as $i => $m) $out[] = $this->normalize_project_message($m, $i, $chat['id'], $uid, $marks);
			wp_send_json_success(['messages' => $out, 'cursor' => $total, 'total' => $total]);
		}

		$rows = $this->get_direct_rows($uid, $chat['id'], 0, $limit);
		$marks = $this->get_read_markers($chat['id']);
		$other_mark = (int)($marks[$chat['key']] ?? 0);
		$out = [];
		$cursor = 0;
		foreach ($rows as $row) {
			$nm = $this->normalize_direct_row($row, $uid, $other_mark);
			$nm['chatId'] = $chat['key'];
			$out[] = $nm;
			$cursor = max($cursor, (int)$row['id']);
		}
		wp_send_json_success(['messages' => $out, 'cursor' => $cursor, 'total' => count($rows)]);
	}

	/* ------------------------------------------------------------------
	 * AJAX: ارسال پیام (+ پیوست/ویس/ریپلای)
	 * ------------------------------------------------------------------ */
	private function handle_upload($kind_hint) {
		if (empty($_FILES['chat_file']) || empty($_FILES['chat_file']['name'])) return null;
		require_once ABSPATH . 'wp-admin/includes/file.php';

		/* v9.2.47 — رفع قطعی خطای «شما مجاز به بارگذاری این نوع پرونده نیستید»
		   هنگام ارسال پیام صوتی. علت: wp_check_filetype_and_ext فایل webm را
		   با MIME واقعی «video/webm» تشخیص می‌دهد و چون با «audio/webm»
		   (خروجی MediaRecorder مرورگر) برابر نیست، آپلود را رد می‌کرد.
		   راه‌حل: پسوند فایل را خودمان با لیست سفید بررسی می‌کنیم و خروجی
		   تابع بررسی MIME وردپرس را برای همین درخواست اصلاح می‌کنیم. */
		$mimes = [
			'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'jpe' => 'image/jpeg', 'png' => 'image/png',
			'gif' => 'image/gif', 'webp' => 'image/webp', 'bmp' => 'image/bmp',
			'pdf' => 'application/pdf', 'zip' => 'application/zip', 'rar' => 'application/x-rar',
			'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'txt' => 'text/plain',
			'webm' => 'audio/webm', 'ogg' => 'audio/ogg', 'mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'wav' => 'audio/wav', 'mp4' => 'video/mp4',
		];
		$file_name = (string)$_FILES['chat_file']['name'];
		$ext = strtolower((string)pathinfo($file_name, PATHINFO_EXTENSION));
		/* برخی کلاینت‌ها فایل را بدون پسوند می‌فرستند؛ از MIME مرورگر استنباط می‌کنیم */
		if ($ext === '' || !isset($mimes[$ext])) {
			$browser_mime = strtolower((string)($_FILES['chat_file']['type'] ?? ''));
			$by_mime = [
				'audio/webm' => 'webm', 'video/webm' => 'webm', 'audio/ogg' => 'ogg', 'audio/mpeg' => 'mp3',
				'audio/mp4' => 'm4a', 'audio/x-m4a' => 'm4a', 'audio/m4a' => 'm4a', 'audio/wav' => 'wav', 'audio/x-wav' => 'wav',
			];
			if (isset($by_mime[$browser_mime])) {
				$ext = $by_mime[$browser_mime];
				$_FILES['chat_file']['name'] = $file_name . '.' . $ext;
			}
		}
		if ($ext === '' || !isset($mimes[$ext])) {
			return ['error' => 'نوع این پرونده برای ارسال مجاز نیست.'];
		}
		$mime_fix = function($data) use ($ext, $mimes) {
			if (!is_array($data)) return $data;
			$data['ext']  = $ext;
			$data['type'] = $mimes[$ext];
			return $data;
		};
		add_filter('wp_check_filetype_and_ext', $mime_fix, 999);
		$overrides = [
			'test_form' => false,
			'mimes' => $mimes,
		];
		$up = wp_handle_upload($_FILES['chat_file'], $overrides);
		remove_filter('wp_check_filetype_and_ext', $mime_fix, 999);
		if (!$up || !empty($up['error'])) return ['error' => (string)($up['error'] ?? 'خطا در آپلود فایل')];
		/* MIME نهایی را بر اساس لیست سفید خودمان نگه می‌داریم تا تشخیص voice درست بماند */
		if (empty($up['type']) || strpos((string)$up['type'], 'webm') !== false) $up['type'] = $mimes[$ext];

		$name = sanitize_file_name(basename((string)$_FILES['chat_file']['name']));
		$size = size_format((int)@filesize($up['file']));
		$mime = (string)($up['type'] ?? '');
		$kind = 'file';
		if (strpos($mime, 'image/') === 0) $kind = 'image';
		elseif (strpos($mime, 'audio/') === 0 || strpos($mime, 'video/webm') === 0 || $kind_hint === 'voice') $kind = 'voice';
		if ($kind_hint === 'image' && strpos($mime, 'image/') === 0) $kind = 'image';

		$file = ['url' => $up['url'], 'name' => $name, 'size' => $size, 'kind' => $kind];
		if ($kind === 'voice') $file['duration'] = max(1, absint($_POST['duration'] ?? 1));
		return $file;
	}

	private function legacy_file_link($url) {
		return "\n" . '<a href="' . esc_url($url) . '" target="_blank" class="cptt-chat-file-link">دانلود فایل پیوست</a>';
	}

	public function ajax_send() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی به این گفتگو ندارید'], 403);

		$text = sanitize_textarea_field((string)($_POST['text'] ?? ''));
		$reply_to = sanitize_text_field((string)($_POST['reply_to'] ?? ''));
		$kind_hint = sanitize_text_field((string)($_POST['kind'] ?? ''));
		$file = $this->handle_upload($kind_hint);
		if (is_array($file) && isset($file['error'])) wp_send_json_error(['message' => $file['error']], 400);
		if ($text === '' && !$file) wp_send_json_error(['message' => 'پیام خالی است'], 400);

		$now = (int)current_time('timestamp', true);
		$me = get_user_by('id', $uid);
		$my_mark = $this->get_read_markers($uid);
		$my_mark[$chat['key']] = $now;
		update_user_meta($uid, self::READ_META, $my_mark);

		if ($chat['kind'] === 'project') {
			$pid = $chat['id'];
			$messages = $this->get_project_messages_raw($pid);
			$content = $text;
			if ($file) $content .= $this->legacy_file_link($file['url']); /* سازگاری با رابط قدیمی */
			$msg = [
				'id' => (function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : ('m_' . wp_rand(100000, 999999))),
				'sender_id' => $uid,
				'recipient_id' => 0,
				'time' => $now,
				'content' => $content,
			];
			if ($file) $msg['file'] = $file;
			if ($reply_to !== '') $msg['reply_to'] = $reply_to;
			$messages[] = $msg;
			update_post_meta($pid, '_cptt_expert_messages', $messages);

			/* اعلان به سایر کارشناسان پروژه (با رعایت بی‌صدا)
			   v9.2.47 — متن «یک پیام جدید از طرف …» + لینک مستقیم به همان گفتگو در پیام‌رسان */
			foreach ($this->project_expert_ids($pid) as $eid) {
				if ((int)$eid === (int)$uid) continue;
				$their_prefs = $this->get_prefs($eid);
				if (!empty($their_prefs[$chat['key']]['muted'])) continue;
				if (class_exists('CPTT_Expert')) {
					$inst = CPTT_Expert::instance();
					if (method_exists($inst, 'insert_notification')) {
						$inst->insert_notification(
							$eid,
							'project_chat',
							'💬 یک پیام جدید از طرف ' . ($me ? $me->display_name : 'کارشناس') . ' در چت پروژه «' . get_the_title($pid) . '»',
							$pid,
							self::page_url(['chat' => $chat['key']])
						);
					}
				}
			}

			$marks = $this->chat_participant_read_marks($chat, $uid);
			$out = $this->normalize_project_message($msg, count($messages) - 1, $pid, $uid, $marks);
			wp_send_json_success(['message' => $out, 'cursor' => count($messages)]);
		}

		/* ---- چت مستقیم ---- */
		$receiver_id = $chat['id'];
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$row = [
			'sender_id' => $uid,
			'receiver_id' => $receiver_id,
			'message' => $text,
			'file_url' => $file ? $file['url'] : '',
			'created_at' => current_time('mysql'),
			'reply_to' => ($reply_to !== '' && ctype_digit($reply_to)) ? (string)absint($reply_to) : null,
			'file_kind' => $file ? $file['kind'] : null,
			'file_name' => $file ? $file['name'] : null,
			'file_size' => $file ? $file['size'] : null,
			'duration' => $file && !empty($file['duration']) ? (int)$file['duration'] : null,
		];
		$formats = [];
		foreach ($row as $v) $formats[] = is_int($v) ? '%d' : '%s';
		$wpdb->insert($table, $row, $formats);
		$new_id = (int)$wpdb->insert_id;

		/* اعلان پیام مستقیم (با رعایت بی‌صدا) — همان رفتار قبلی افزونه.
		   توجه: کلید گفتگو از دید طرف مقابل «d + شناسه‌ی من» است */
		$their_prefs = $this->get_prefs($receiver_id);
		$their_key = 'd' . (int)$uid;
		if ((int)$receiver_id !== (int)$uid && empty($their_prefs[$their_key]['muted']) && class_exists('CPTT_Expert')) {
			$inst = CPTT_Expert::instance();
			if (method_exists($inst, 'insert_notification')) {
				$inst->insert_notification(
					$receiver_id,
					'direct_chat',
					'💬 یک پیام جدید از طرف ' . ($me ? $me->display_name : 'کاربر'),
					0,
					self::page_url(['chat' => $their_key])
				);
			}
		}

		$saved = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $new_id), ARRAY_A);
		$out = $this->normalize_direct_row($saved, $uid, 0);
		$out['chatId'] = $chat['key'];
		wp_send_json_success(['message' => $out, 'cursor' => $new_id]);
	}

	/* ------------------------------------------------------------------
	 * AJAX: ویرایش / حذف / واکنش / سنجاق
	 * ------------------------------------------------------------------ */
	private function find_project_message_index($messages, $id) {
		foreach ($messages as $i => $m) {
			if ((string)($m['id'] ?? '') === (string)$id) return $i;
		}
		return -1;
	}

	public function ajax_edit() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی ندارید'], 403);
		$id = sanitize_text_field((string)($_POST['id'] ?? ''));
		$text = sanitize_textarea_field((string)($_POST['text'] ?? ''));
		if ($id === '' ) wp_send_json_error(['message' => 'پیام نامعتبر است'], 400);

		if ($chat['kind'] === 'project') {
			$messages = $this->get_project_messages_raw($chat['id']);
			$i = $this->find_project_message_index($messages, $id);
			if ($i < 0) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
			$m = $messages[$i];
			if ((int)($m['sender_id'] ?? 0) !== (int)$uid && !user_can($uid, 'manage_options')) wp_send_json_error(['message' => 'فقط فرستنده می‌تواند ویرایش کند'], 403);
			$content = $text;
			if (!empty($m['file']['url'])) $content .= $this->legacy_file_link($m['file']['url']);
			$m['content'] = $content;
			$m['edited'] = 1;
			$messages[$i] = $m;
			update_post_meta($chat['id'], '_cptt_expert_messages', $messages);
			wp_send_json_success(['ok' => 1]);
		}

		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$rowm = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int)$id), ARRAY_A);
		if (!$rowm) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
		if ((int)$rowm['sender_id'] !== (int)$uid && !user_can($uid, 'manage_options')) wp_send_json_error(['message' => 'فقط فرستنده می‌تواند ویرایش کند'], 403);
		$wpdb->update($table, ['message' => $text, 'edited' => 1], ['id' => (int)$id], ['%s', '%d'], ['%d']);
		wp_send_json_success(['ok' => 1]);
	}

	public function ajax_delete() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی ندارید'], 403);
		$id = sanitize_text_field((string)($_POST['id'] ?? ''));
		if ($id === '') wp_send_json_error(['message' => 'پیام نامعتبر است'], 400);

		if ($chat['kind'] === 'project') {
			/* قانون قبلی افزونه (v5.7.1): هر عضو پروژه می‌تواند هر پیامی را حذف کند */
			$messages = $this->get_project_messages_raw($chat['id']);
			$i = $this->find_project_message_index($messages, $id);
			if ($i < 0) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
			array_splice($messages, $i, 1);
			update_post_meta($chat['id'], '_cptt_expert_messages', array_values($messages));
			wp_send_json_success(['ok' => 1, 'cursor' => count($messages)]);
		}

		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$rowm = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int)$id), ARRAY_A);
		if (!$rowm) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
		if ((int)$rowm['sender_id'] !== (int)$uid && (int)$rowm['receiver_id'] !== (int)$uid && !user_can($uid, 'manage_options')) {
			wp_send_json_error(['message' => 'دسترسی ندارید'], 403);
		}
		$wpdb->delete($table, ['id' => (int)$id], ['%d']);
		wp_send_json_success(['ok' => 1]);
	}

	public function ajax_react() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی ندارید'], 403);
		$id = sanitize_text_field((string)($_POST['id'] ?? ''));
		$emoji = sanitize_text_field((string)($_POST['emoji'] ?? ''));
		if ($id === '' || $emoji === '') wp_send_json_error(['message' => 'درخواست نامعتبر'], 400);

		if ($chat['kind'] === 'project') {
			$messages = $this->get_project_messages_raw($chat['id']);
			$i = $this->find_project_message_index($messages, $id);
			if ($i < 0) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
			$m = $messages[$i];
			$rx = (isset($m['reactions']) && is_array($m['reactions'])) ? $m['reactions'] : [];
			$uids = array_map('intval', (array)($rx[$emoji] ?? []));
			if (in_array((int)$uid, $uids, true)) $uids = array_values(array_diff($uids, [(int)$uid]));
			else $uids[] = (int)$uid;
			if (count($uids)) $rx[$emoji] = $uids; else unset($rx[$emoji]);
			if (!count($rx)) $m['reactions'] = []; else $m['reactions'] = $rx;
			$messages[$i] = $m;
			update_post_meta($chat['id'], '_cptt_expert_messages', $messages);
			$marks = $this->chat_participant_read_marks($chat, $uid);
			wp_send_json_success(['message' => $this->normalize_project_message($m, $i, $chat['id'], $uid, $marks)]);
		}

		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$rowm = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int)$id), ARRAY_A);
		if (!$rowm) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
		$rx = json_decode((string)($rowm['reactions'] ?? ''), true);
		if (!is_array($rx)) $rx = [];
		$uids = array_map('intval', (array)($rx[$emoji] ?? []));
		if (in_array((int)$uid, $uids, true)) $uids = array_values(array_diff($uids, [(int)$uid]));
		else $uids[] = (int)$uid;
		if (count($uids)) $rx[$emoji] = $uids; else unset($rx[$emoji]);
		$wpdb->update($table, ['reactions' => count($rx) ? wp_json_encode($rx, JSON_UNESCAPED_UNICODE) : null], ['id' => (int)$id], null, ['%d']);
		$rowm['reactions'] = count($rx) ? wp_json_encode($rx, JSON_UNESCAPED_UNICODE) : '';
		$marks = $this->get_read_markers($chat['id']);
		$nm = $this->normalize_direct_row($rowm, $uid, (int)($marks[$chat['key']] ?? 0));
		$nm['chatId'] = $chat['key'];
		wp_send_json_success(['message' => $nm]);
	}

	public function ajax_pin() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی ندارید'], 403);
		$id = sanitize_text_field((string)($_POST['id'] ?? ''));
		if ($id === '') wp_send_json_error(['message' => 'پیام نامعتبر'], 400);

		if ($chat['kind'] === 'project') {
			$messages = $this->get_project_messages_raw($chat['id']);
			$i = $this->find_project_message_index($messages, $id);
			if ($i < 0) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
			$now_on = empty($messages[$i]['pinned']);
			foreach ($messages as $j => $m) $messages[$j]['pinned'] = ($j === $i && $now_on) ? 1 : 0;
			update_post_meta($chat['id'], '_cptt_expert_messages', $messages);
			wp_send_json_success(['pinned' => $now_on ? 1 : 0]);
		}

		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$rowm = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int)$id), ARRAY_A);
		if (!$rowm) wp_send_json_error(['message' => 'پیام یافت نشد'], 404);
		$now_on = empty($rowm['pinned']);
		$wpdb->query($wpdb->prepare(
			"UPDATE {$table} SET pinned = 0 WHERE (sender_id = %d AND receiver_id = %d) OR (sender_id = %d AND receiver_id = %d)",
			$uid, $chat['id'], $chat['id'], $uid
		));
		if ($now_on) $wpdb->update($table, ['pinned' => 1], ['id' => (int)$id], ['%d'], ['%d']);
		wp_send_json_success(['pinned' => $now_on ? 1 : 0]);
	}

	/* ------------------------------------------------------------------
	 * AJAX: ترجیحات گفتگو (سنجاق/بی‌صدا/بایگانی/خوانده‌شده)
	 * ------------------------------------------------------------------ */
	public function ajax_pref() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$chat) wp_send_json_error(['message' => 'گفتگو نامعتبر'], 400);
		$key = sanitize_text_field((string)($_POST['key'] ?? ''));
		$value = (string)($_POST['value'] ?? '');

		if ($key === 'read') {
			$marks = $this->get_read_markers($uid);
			$marks[$chat['key']] = max((int)($marks[$chat['key']] ?? 0), absint($value) ?: (int)current_time('timestamp', true));
			update_user_meta($uid, self::READ_META, $marks);
			wp_send_json_success(['ok' => 1]);
		}

		if (!in_array($key, ['pinned', 'muted', 'archived'], true)) wp_send_json_error(['message' => 'کلید نامعتبر'], 400);
		$prefs = $this->get_prefs($uid);
		if (!isset($prefs[$chat['key']]) || !is_array($prefs[$chat['key']])) $prefs[$chat['key']] = [];
		$prefs[$chat['key']][$key] = ($value === '1' || $value === 'true') ? 1 : 0;
		update_user_meta($uid, self::PREF_META, $prefs);
		wp_send_json_success(['ok' => 1]);
	}

	/* ------------------------------------------------------------------ */
	public function ajax_clear() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی ندارید'], 403);

		if ($chat['kind'] === 'project') {
			update_post_meta($chat['id'], '_cptt_expert_messages', []);
			wp_send_json_success(['ok' => 1, 'cursor' => 0]);
		}
		global $wpdb;
		$table = $wpdb->prefix . 'cptt_expert_chats';
		$wpdb->query($wpdb->prepare(
			"DELETE FROM {$table} WHERE (sender_id = %d AND receiver_id = %d) OR (sender_id = %d AND receiver_id = %d)",
			$uid, $chat['id'], $chat['id'], $uid
		));
		wp_send_json_success(['ok' => 1, 'cursor' => 0]);
	}

	/* ------------------------------------------------------------------ */
	public function ajax_typing() {
		$this->check_access();
		$uid = get_current_user_id();
		$chat = $this->parse_chat_id($_POST['chat'] ?? '');
		if (!$this->can_open_chat($chat, $uid)) wp_send_json_error(['message' => 'دسترسی ندارید'], 403);
		$tkey = 'cptt_msgr_t_' . md5($chat['key']);
		$arr = get_transient($tkey);
		if (!is_array($arr)) $arr = [];
		$arr[$uid] = time() + 6;
		set_transient($tkey, $arr, 30);
		wp_send_json_success(['ok' => 1]);
	}

	private function typing_users($chat, $uid) {
		$tkey = 'cptt_msgr_t_' . md5($chat['key']);
		$arr = get_transient($tkey);
		if (!is_array($arr)) return [];
		$now = time();
		$out = [];
		foreach ($arr as $tuid => $exp) {
			if ((int)$exp < $now || (int)$tuid === (int)$uid) continue;
			$u = get_user_by('id', (int)$tuid);
			if ($u) $out[] = ['id' => 'u' . (int)$tuid, 'name' => $u->display_name];
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * AJAX: Poll سبک زنده — فقط داده‌ی جدید برمی‌گردد
	 * ------------------------------------------------------------------ */
	public function ajax_poll() {
		$this->check_access();
		$uid = get_current_user_id();
		$items = json_decode((string)($_POST['items'] ?? ''), true);
		if (!is_array($items)) $items = [];
		$active = sanitize_text_field((string)($_POST['active'] ?? ''));

		$updates = [];
		$messages = [];
		$cursors = [];

		foreach (array_slice($items, 0, 60) as $it) {
			$chat = $this->parse_chat_id($it['id'] ?? '');
			if (!$chat || !$this->can_open_chat($chat, $uid)) continue;
			$cursor = (int)($it['c'] ?? 0);

			$new_msgs = [];
			$new_cursor = $cursor;
			if ($chat['kind'] === 'project') {
				$msgs = $this->get_project_messages_raw($chat['id']);
				$total = count($msgs);
				if ($total > $cursor) {
					$slice = array_slice($msgs, $cursor);
					$marks = $this->chat_participant_read_marks($chat, $uid);
					foreach (array_values($slice) as $i => $m) $new_msgs[] = $this->normalize_project_message($m, $cursor + $i, $chat['id'], $uid, $marks);
				}
				/* اگر پیامی حذف/پاک شد، کلاینت را همگام نگه می‌داریم */
				$new_cursor = $total;
			} else {
				$rows = $this->get_direct_rows($uid, $chat['id'], $cursor, 0);
				$marks = $this->get_read_markers($chat['id']);
				$other_mark = (int)($marks[$chat['key']] ?? 0);
				foreach ($rows as $row) {
					$nm = $this->normalize_direct_row($row, $uid, $other_mark);
					$nm['chatId'] = $chat['key'];
					$new_msgs[] = $nm;
					$new_cursor = max($new_cursor, (int)$row['id']);
				}
			}

			if (count($new_msgs)) $messages[$chat['key']] = $new_msgs;
			$cursors[$chat['key']] = $new_cursor;
			$updates[] = [
				'id' => $chat['key'],
				'unread' => ($active === $chat['key']) ? 0 : $this->unread_count($chat, $uid),
				'typing' => $this->typing_users($chat, $uid),
				'cursor' => $new_cursor,
			];
		}

		wp_send_json_success([
			'updates' => $updates,
			'messages' => $messages,
			'cursors' => $cursors,
			/* v9.2.47 — مجموع خوانده‌نشده‌ها (برای نشان روی دکمه‌ی پیام‌رسان در داشبورد) */
			'totalUnread' => self::get_total_unread($uid),
		]);
	}

	/* ------------------------------------------------------------------
	 * مجموع تعداد پیام‌های خوانده‌نشده (عمومی — برای نشان دکمه در داشبورد)
	 * ------------------------------------------------------------------ */
	public static function get_total_unread($uid) {
		static $cache = [];
		$uid = (int)$uid;
		if (isset($cache[$uid])) return $cache[$uid];
		$inst = self::instance();
		$total = 0;
		foreach ((array)$inst->my_project_ids($uid) as $pid) {
			$total += $inst->unread_count(['kind' => 'project', 'id' => (int)$pid, 'key' => 'p' . (int)$pid], $uid);
		}
		foreach ((array)$inst->direct_peer_ids_with_history($uid) as $peer) {
			if ((int)$peer === $uid) continue; /* چت با خود (ذخیره‌شده‌ها) خوانده‌نشده ندارد */
			$total += $inst->unread_count(['kind' => 'direct', 'id' => (int)$peer, 'key' => 'd' . (int)$peer], $uid);
		}
		$cache[$uid] = min($total, 99);
		return $cache[$uid];
	}
}
