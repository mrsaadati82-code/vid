<?php
/**
 * CPTT Finance — Modern modular finance subsystem for the Hamahang plugin.
 *
 * v6.4.0 — Phase 1: data model, ledger, 5 standalone admin modules with
 * SaaS-style mobile-first UI.
 *
 * Modules (each has its own admin page + URL + nav):
 *   - cptt-finance               → Financial dashboard (KPIs + charts)
 *   - cptt-finance-receivables   → Customer receivables (debtors)
 *   - cptt-finance-payouts       → Expert payouts (settlements)
 *   - cptt-finance-transactions  → Standalone income/expense register
 *   - cptt-finance-treasury      → Cash & bank accounts + transfers + ledger
 *
 * Design rules:
 *   - Nothing existing is removed; the old "حساب و کتاب" page (CPTT_Admin) stays.
 *   - Every existing financial operation can ALSO write to the unified ledger
 *     (cptt_fin_ledger) via auto-hooks.
 *   - Tables are upgrade-safe (dbDelta) and use a stored version option.
 *   - Currency uses CPTT_Currency where available (toman/rial).
 *   - All UI is responsive, theme-aware, and accessible.
 */

if (!defined('ABSPATH')) exit;

class CPTT_Finance {

	const DB_VERSION = '1.3.0'; // v9.3.0 — جدول چک/سفته (فاز ۳)
	const DB_OPTION  = 'cptt_finance_db_version';
	const NONCE      = 'cptt_finance_nonce';

	private static $instance = null;
	public static function instance(){
		if (self::$instance === null) self::$instance = new self();
		return self::$instance;
	}

	private function __construct(){
		add_action('admin_menu',  [$this, 'register_menus'], 12);
		add_action('admin_init',  [$this, 'maybe_install_tables']);
		add_action('admin_init',  [$this, 'maybe_person_statement_output'], 5); // v9.2.55 — خروجی CSV/چاپ صورتحساب قبل از هر خروجی
		add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
		// v9.2.6 — add cptt-v2-scope to <body> on all finance pages so the
		// font/color rules injected by CPTT_Settings::inject_dynamic_css()
		// apply to every element (same as expert dashboard). Dashicons are
		// restored to their icon font via a targeted override below.
		add_filter('admin_body_class', [$this, 'add_body_class']);

		// AJAX: data CRUD
		add_action('wp_ajax_cptt_fin_account_save',   [$this, 'ajax_account_save']);
		add_action('wp_ajax_cptt_fin_account_delete', [$this, 'ajax_account_delete']);
		add_action('wp_ajax_cptt_fin_cat_save',       [$this, 'ajax_cat_save']);
		add_action('wp_ajax_cptt_fin_cat_delete',     [$this, 'ajax_cat_delete']);
		add_action('wp_ajax_cptt_fin_tx_save',        [$this, 'ajax_tx_save']);
		add_action('wp_ajax_cptt_fin_tx_delete',      [$this, 'ajax_tx_delete']);
		add_action('wp_ajax_cptt_fin_tx_reverse',     [$this, 'ajax_tx_reverse']);
		add_action('wp_ajax_cptt_fin_recv_resync',    [$this, 'ajax_recv_resync']);
		add_action('wp_ajax_cptt_fin_recv_audit',     [$this, 'ajax_recv_audit']);
		add_action('wp_ajax_cptt_fin_recv_project_reset', [$this, 'ajax_recv_project_reset']);
		add_action('wp_ajax_cptt_fin_recv_project_ledger', [$this, 'ajax_recv_project_ledger']);
		add_action('wp_ajax_cptt_fin_transfer',       [$this, 'ajax_transfer']);
		add_action('wp_ajax_cptt_fin_dashboard_data', [$this, 'ajax_dashboard_data']);
		add_action('wp_ajax_cptt_fin_legacy_import', [$this, 'ajax_legacy_import']);
		add_action('wp_ajax_cptt_fin_person_save',   [$this, 'ajax_person_save']); // v9.2.55 — پرونده طرف‌حساب (احراز/جدید)
		add_action('wp_ajax_cptt_fin_invoice_save',   [$this, 'ajax_invoice_save']);         // v9.2.56 — فاکتورها (فاز ۲)
		add_action('wp_ajax_cptt_fin_invoice_settle', [$this, 'ajax_invoice_settle']);
		add_action('wp_ajax_cptt_fin_invoice_cancel', [$this, 'ajax_invoice_cancel']);
		add_action('wp_ajax_cptt_fin_invoice_alloc_delete', [$this, 'ajax_invoice_alloc_delete']);
		add_action('wp_ajax_cptt_fin_voucher_assign', [$this, 'ajax_voucher_assign']);       // v9.2.56 — انتساب سند بدون پروژه به پروژه
		add_action('wp_ajax_cptt_fin_cheque_save',   [$this, 'ajax_cheque_save']);           // v9.3.0 — اسناد و چک‌ها (فاز ۳)
		add_action('wp_ajax_cptt_fin_cheque_status', [$this, 'ajax_cheque_status']);
		add_action('wp_ajax_cptt_fin_cheque_delete', [$this, 'ajax_cheque_delete']);

		// Auto-log existing project finance events into the ledger
		add_action('cptt_after_expert_payout',           [$this, 'log_expert_payout'], 10, 5);
		add_action('cptt_after_manual_expert_payment',   [$this, 'log_manual_payment'], 10, 3);
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Table names
	 * ─────────────────────────────────────────────────────────────────── */
	public static function tbl_accounts(){   global $wpdb; return $wpdb->prefix . 'cptt_fin_accounts'; }
	public static function tbl_categories(){ global $wpdb; return $wpdb->prefix . 'cptt_fin_categories'; }
	public static function tbl_ledger(){     global $wpdb; return $wpdb->prefix . 'cptt_fin_ledger'; }
	public static function tbl_invoices(){   global $wpdb; return $wpdb->prefix . 'cptt_fin_invoices'; }   // v9.2.56
	public static function tbl_invoice_allocs(){ global $wpdb; return $wpdb->prefix . 'cptt_fin_invoice_allocs'; } // v9.2.56
	public static function tbl_cheques(){ global $wpdb; return $wpdb->prefix . 'cptt_fin_cheques'; } // v9.3.0 — اسناد و چک‌ها (فاز ۳)

	/* ───────────────────────────────────────────────────────────────────
	 * Install / upgrade tables
	 * ─────────────────────────────────────────────────────────────────── */
	public function maybe_install_tables(){
		$need = get_option(self::DB_OPTION) !== self::DB_VERSION;
		if (!$need) {
			// ensure voucher columns exist even if option already bumped on partial deploys
			global $wpdb;
			$col = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM " . self::tbl_ledger() . " LIKE %s", 'voucher_no'));
			if (!$col) $need = true;
		}
		if (!$need) return;
		self::install_tables();
		update_option(self::DB_OPTION, self::DB_VERSION);
		// Seed default categories on first install
		self::seed_defaults();
	}

	public static function install_tables(){
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$t_acc = self::tbl_accounts();
		$t_cat = self::tbl_categories();
		$t_lgr = self::tbl_ledger();
		$t_inv = self::tbl_invoices();
		$t_ch = self::tbl_cheques();
		$t_al  = self::tbl_invoice_allocs();

		$sql1 = "CREATE TABLE $t_acc (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			type VARCHAR(20) NOT NULL DEFAULT 'cash',
			bank_name VARCHAR(190) DEFAULT NULL,
			account_number VARCHAR(60) DEFAULT NULL,
			iban VARCHAR(40) DEFAULT NULL,
			card_number VARCHAR(40) DEFAULT NULL,
			initial_balance DECIMAL(20,2) NOT NULL DEFAULT 0,
			currency VARCHAR(10) NOT NULL DEFAULT 'IRT',
			color VARCHAR(20) NOT NULL DEFAULT '#6366f1',
			icon VARCHAR(20) NOT NULL DEFAULT '🏦',
			status TINYINT NOT NULL DEFAULT 1,
			meta LONGTEXT DEFAULT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY type_idx (type),
			KEY status_idx (status)
		) $charset;";

		$sql2 = "CREATE TABLE $t_cat (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			type VARCHAR(20) NOT NULL,
			parent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			color VARCHAR(20) NOT NULL DEFAULT '#64748b',
			icon VARCHAR(20) NOT NULL DEFAULT '🏷',
			sort_order INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY type_idx (type)
		) $charset;";

		$sql3 = "CREATE TABLE $t_lgr (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			account_id BIGINT UNSIGNED NOT NULL,
			type VARCHAR(30) NOT NULL,
			direction TINYINT NOT NULL,
			amount DECIMAL(20,2) NOT NULL DEFAULT 0,
			category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			step_id VARCHAR(64) NOT NULL DEFAULT '',
			customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			expert_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ref_type VARCHAR(40) NOT NULL DEFAULT '',
			ref_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			linked_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			voucher_no VARCHAR(40) NOT NULL DEFAULT '',
			voucher_kind VARCHAR(20) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'posted',
			reversed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			reverses_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			date_at INT NOT NULL,
			date_fa VARCHAR(40) NOT NULL DEFAULT '',
			description TEXT,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY account_idx (account_id),
			KEY type_idx (type),
			KEY date_idx (date_at),
			KEY project_idx (project_id),
			KEY customer_idx (customer_id),
			KEY expert_idx (expert_id),
			KEY voucher_idx (voucher_no),
			KEY status_idx (status),
			KEY reverses_idx (reverses_id)
		) $charset;";

		// v9.2.56 — فاکتورها: لایه‌ی سند بالای دفتر (هیچ فرمول مانده‌ی موجود تغییر نمی‌کند)
		$sql4 = "CREATE TABLE $t_inv (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			invoice_no VARCHAR(40) NOT NULL,
			kind VARCHAR(20) NOT NULL DEFAULT 'sale',
			person_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			issue_ts INT NOT NULL DEFAULT 0,
			due_ts INT NOT NULL DEFAULT 0,
			amount DECIMAL(20,2) NOT NULL DEFAULT 0,
			settled DECIMAL(20,2) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'issued',
			note TEXT,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			updated_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY person_idx (person_id),
			KEY project_idx (project_id),
			KEY status_idx (status),
			KEY due_idx (due_ts),
			KEY no_idx (invoice_no)
		) $charset;";

		$sql5 = "CREATE TABLE $t_al (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			invoice_id BIGINT UNSIGNED NOT NULL,
			ledger_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			amount DECIMAL(20,2) NOT NULL DEFAULT 0,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY invoice_idx (invoice_id),
			KEY ledger_idx (ledger_id)
		) $charset;";

		// v9.3.0 — چک‌ها و سفته‌ها: لایه‌ی نمایشیِ «اسناد در راه»؛ اثر مالی فقط هنگام «وصول/پاس» با ثبت سند واقعی در دفتر ایجاد می‌شود
		$sql6 = "CREATE TABLE $t_ch (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			direction TINYINT NOT NULL DEFAULT 1,
			person_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			cheque_no VARCHAR(60) NOT NULL DEFAULT '',
			bank VARCHAR(120) NOT NULL DEFAULT '',
			branch VARCHAR(120) NOT NULL DEFAULT '',
			due_ts INT NOT NULL DEFAULT 0,
			amount DECIMAL(20,2) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			ledger_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			note TEXT,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			updated_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY person_idx (person_id),
			KEY status_idx (status),
			KEY due_idx (due_ts)
		) $charset;";

		dbDelta($sql1);
		dbDelta($sql2);
		dbDelta($sql3);
		dbDelta($sql4);
		dbDelta($sql5);
		dbDelta($sql6);
	}

	public static function seed_defaults(){
		global $wpdb;
		$t = self::tbl_categories();
		$exists = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t");
		if ($exists > 0) return;
		$rows = [
			['name'=>'فروش پروژه','type'=>'income','color'=>'#16a34a','icon'=>'💼'],
			['name'=>'پیش پرداخت','type'=>'income','color'=>'#22c55e','icon'=>'💵'],
			['name'=>'سایر درآمدها','type'=>'income','color'=>'#06b6d4','icon'=>'💰'],
			['name'=>'دستمزد کارشناسان','type'=>'expense','color'=>'#f59e0b','icon'=>'👤'],
			['name'=>'هزینه‌های اداری','type'=>'expense','color'=>'#a855f7','icon'=>'🏢'],
			['name'=>'هزینه‌های بازاریابی','type'=>'expense','color'=>'#ec4899','icon'=>'📣'],
			['name'=>'هزینه نرم‌افزار/سرور','type'=>'expense','color'=>'#0ea5e9','icon'=>'☁️'],
			['name'=>'سایر هزینه‌ها','type'=>'expense','color'=>'#ef4444','icon'=>'📦'],
		];
		foreach ($rows as $r) $wpdb->insert($t, $r);

		// Seed a default cash account
		$ta = self::tbl_accounts();
		$cnt = (int)$wpdb->get_var("SELECT COUNT(*) FROM $ta");
		if ($cnt === 0) {
			$wpdb->insert($ta, [
				'name'  => 'صندوق نقدی',
				'type'  => 'cash',
				'icon'  => '💵',
				'color' => '#16a34a',
				'created_at' => (int) current_time('timestamp', true),
				'created_by' => (int) get_current_user_id(),
			]);
		}
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Admin Menus — every module is a standalone page
	 * ─────────────────────────────────────────────────────────────────── */
	public function register_menus(){
		// Parent menu
		add_menu_page(
			'مالی هماهنگ',
			'💰 مالی',
			'edit_cptt_projects',
			'cptt-finance',
			[$this, 'render_dashboard_page'],
			'dashicons-money-alt',
			25
		);
		// Sub-pages
		add_submenu_page('cptt-finance', 'داشبورد مالی',     'داشبورد مالی',     'edit_cptt_projects', 'cptt-finance',                [$this, 'render_dashboard_page']);
		add_submenu_page('cptt-finance', 'مطالبات مشتریان',  'مطالبات مشتریان',  'edit_cptt_projects', 'cptt-finance-receivables',    [$this, 'render_receivables_page']);
		add_submenu_page('cptt-finance', 'اشخاص (طرف‌های حساب)', '🪪 اشخاص', 'edit_cptt_projects', 'cptt-finance-persons', [$this, 'render_persons_page']);
		add_submenu_page('cptt-finance', 'فاکتورها', '🧾 فاکتورها', 'edit_cptt_projects', 'cptt-finance-invoices', [$this, 'render_invoices_page']); // v9.2.56
		add_submenu_page('cptt-finance', 'اسناد و چک‌ها', '🏦 اسناد و چک‌ها', 'edit_cptt_projects', 'cptt-finance-cheques', [$this, 'render_cheques_page']); // v9.3.0
		add_submenu_page('cptt-finance', 'مرکز گزارشات', '📈 مرکز گزارشات', 'edit_cptt_projects', 'cptt-finance-reports', [$this, 'render_reports_page']); // v9.3.0
		add_submenu_page('cptt-finance', 'تسویه کارشناسان',  'تسویه کارشناسان',  'edit_cptt_projects', 'cptt-finance-payouts',        [$this, 'render_payouts_page']);
		add_submenu_page('cptt-finance', 'درآمد و هزینه',     'درآمد و هزینه',    'edit_cptt_projects', 'cptt-finance-transactions',   [$this, 'render_transactions_page']);
		add_submenu_page('cptt-finance', 'خزانه‌داری',         'خزانه‌داری',        'edit_cptt_projects', 'cptt-finance-treasury',       [$this, 'render_treasury_page']);
		add_submenu_page('cptt-finance', 'دسته‌بندی‌های مالی',  'دسته‌بندی‌ها',      'edit_cptt_projects', 'cptt-finance-categories',     [$this, 'render_categories_page']);
		// v6.4.1 — Classic project accounting view migrated under Finance menu.
		add_submenu_page('cptt-finance', 'حساب پروژه‌ها', '📒 حساب پروژه‌ها', 'edit_cptt_projects', 'cptt-finance-classic',        [$this, 'render_classic_accounting_page']);
		add_submenu_page('cptt-finance', 'همگام‌سازی داده‌های قدیمی', '🧩 همگام‌سازی', 'manage_options', 'cptt-finance-sync', [$this, 'render_sync_page']);
		add_submenu_page('cptt-finance', 'گردش حساب',            '📑 گردش حساب',     'edit_cptt_projects', 'cptt-finance-ledger',         [$this, 'render_ledger_page']);
		// v8.5.0 — C-2: Cash Flow (Cash-View) report — non-destructive, read-only view.
	}

	public function add_body_class($classes){
		$page = isset($_GET['page']) ? (string)$_GET['page'] : '';
		if (strpos($page, 'cptt-finance') === 0) {
			$classes .= ' cptt-v2-scope';
		}
		return $classes;
	}

	public function enqueue_admin_assets($hook){
		if (strpos($hook, 'cptt-finance') === false) return;
		wp_enqueue_style('cptt-finance', CPTT_URL . 'assets/css/finance.css', [], CPTT_VERSION);
		// v9.2.24 — classic accounting page reuses CPTT_Admin markup/JS/CSS
		$page = isset($_GET['page']) ? (string)$_GET['page'] : '';
		if ($page === 'cptt-finance-classic') {
			wp_enqueue_style('cptt-admin', CPTT_URL . 'assets/css/admin.css', ['cptt-finance'], CPTT_VERSION);
			wp_enqueue_script('jquery-ui-sortable');
			wp_enqueue_script('cptt-admin', CPTT_URL . 'assets/js/admin.js', ['jquery','jquery-ui-sortable'], CPTT_VERSION, true);
			wp_localize_script('cptt-admin', 'CPTT_CURRENCY', ['unit'=>'rial','label'=>'ریال','factor'=>1,'decimals'=>0]);
			wp_localize_script('cptt-admin', 'CPTT_ADMIN', [
				'ajax' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('cptt_admin_nonce'),
				'branding' => class_exists('CPTT_Settings') ? CPTT_Settings::get() : [],
				'logo_url' => class_exists('CPTT_Settings') ? wp_get_attachment_image_url(CPTT_Settings::get()['logo_id'] ?? 0, 'large') : '',
			]);
			wp_add_inline_style('cptt-admin', self::classic_host_css());
		}

		// v9.2.6 — CPTT_Settings::inject_dynamic_css() paints every element
		// under body.cptt-v2-scope with the plugin font (including dashicons,
		// which then render as boxes). Restore icon fonts here — higher
		// specificity + !important beats the settings override.
		$scoped_css = "
			body.cptt-v2-scope .dashicons,
			body.cptt-v2-scope .dashicons-before::before,
			body.cptt-v2-scope [class^='dashicons-']::before,
			body.cptt-v2-scope [class*=' dashicons-']::before,
			body.cptt-v2-scope #adminmenu .wp-menu-image::before,
			body.cptt-v2-scope #wpadminbar .ab-icon::before,
			body.cptt-v2-scope #wpadminbar .ab-item::before {
				font-family: dashicons !important;
			}
			body.cptt-v2-scope .material-icons,
			body.cptt-v2-scope .material-symbols-outlined {
				font-family: 'Material Icons', 'Material Symbols Outlined' !important;
			}
		";
		wp_add_inline_style('cptt-finance', $scoped_css);

		// v9.2.0 — Chart.js (bundled locally so it works on restricted Iranian hosts)
		wp_enqueue_script('cptt-chartjs', CPTT_URL . 'assets/vendor/chart.umd.min.js', [], '4.4.1', true);
		wp_enqueue_script('cptt-finance', CPTT_URL . 'assets/js/finance.js', ['jquery','cptt-chartjs'], CPTT_VERSION, true);
		wp_localize_script('cptt-finance', 'CPTT_FIN', [
			'ajax'  => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce(self::NONCE),
			// v9.2.13 — admin_nonce is needed for step settlement AJAX (CPTT_Admin handlers)
			'admin_nonce' => wp_create_nonce('cptt_admin_nonce'),
			'currency' => 'ریال',
		]);
	}

	/* v9.2.4 — read plugin font from CPTT_Settings safely */
	private function _get_plugin_font_stack(){
		$f = 'dana';
		if (class_exists('CPTT_Settings')) {
			$s = CPTT_Settings::get_styles();
			$f = isset($s['font_family']) ? $s['font_family'] : 'dana';
		}
		switch ($f) {
			case 'iransans':  return "'IranSans', Tahoma, sans-serif";
			case 'iranyekan': return "'IranYekan', Tahoma, sans-serif";
			case 'kalameh':   return "'Kalameh', Tahoma, sans-serif";
			case 'peyda':     return "'Peyda', Tahoma, sans-serif";
			case 'vazir':     return "'Vazirmatn', Tahoma, sans-serif";
			case 'dana':
			default:          return "'Dana', Tahoma, sans-serif";
		}
	}
	private function _get_plugin_font_face_css(){
		// The @font-face declarations are already emitted in the page head by
		// CPTT_Settings::inject_dynamic_css() (which runs on every admin page).
		// Returning empty avoids duplicating them.
		return '';
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * HELPERS
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function fmt($n){
		// v9.2.1/9.2.13 — format the stored amount as-is (no unit conversion).
		// Unit conversion is display-only via CPTT_Currency when callers need it;
		// finance pages store/read the same scale the rest of the plugin uses.
		// Always Persian digits, even if site locale is non-Persian.
		$s = number_format((float)$n, 0, '.', ',');
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'to_persian_digits')) {
			return CPTT_Core::to_persian_digits($s);
		}
		$fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
		return preg_replace_callback('/[0-9]/', function($m) use ($fa){ return $fa[(int)$m[0]]; }, $s);
	}
	public static function fa_date($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		return class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($ts) : date('Y-m-d H:i', $ts);
	}
	public static function currency_label(){
		return 'ریال'; // v9.2.18 — always rial
	}

	public static function get_accounts($only_active = true){
		global $wpdb;
		$where = $only_active ? 'WHERE status=1' : '';
		return $wpdb->get_results("SELECT * FROM " . self::tbl_accounts() . " $where ORDER BY id ASC");
	}
	public static function get_account($id){
		global $wpdb;
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_accounts() . " WHERE id=%d", $id));
	}
	public static function get_categories($type = ''){
		global $wpdb;
		if ($type === '') {
			return $wpdb->get_results("SELECT * FROM " . self::tbl_categories() . " ORDER BY type ASC, sort_order ASC, id ASC");
		}
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::tbl_categories() . " WHERE type=%s ORDER BY sort_order ASC, id ASC", $type));
	}

	/**
	 * Compute current balance of an account = initial + ∑(direction * amount)
	 */
	public static function account_balance($account_id){
		global $wpdb;
		$acc = self::get_account($account_id);
		if (!$acc) return 0.0;
		$sum = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT COALESCE(SUM(direction * amount), 0) FROM " . self::tbl_ledger() . " WHERE account_id=%d",
			$account_id
		));
		return (float)$acc->initial_balance + $sum;
	}

	/**
	 * v6.4.1 — Balance of an account at a given timestamp (inclusive of
	 * older transactions). Used by the ledger view for running-balance.
	 * Pass $ts=0 to get just the initial balance (no transactions yet).
	 */
	public static function account_balance_at($account_id, $ts){
		global $wpdb;
		$acc = self::get_account($account_id);
		if (!$acc) return 0.0;
		if ($ts <= 0) return (float) $acc->initial_balance;
		$sum = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT COALESCE(SUM(direction * amount), 0) FROM " . self::tbl_ledger() . " WHERE account_id=%d AND date_at <= %d",
			$account_id, $ts
		));
		return (float)$acc->initial_balance + $sum;
	}

	/**
	 * Recompute the project settlement flag from the canonical step amounts.
	 * This keeps receivables/cards honest after deleting or reversing a payment.
	 */
	private static function refresh_project_settlement_flag($project_id){
		$project_id = (int)$project_id;
		if ($project_id <= 0) return false;
		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) {
			update_post_meta($project_id, '_cptt_is_settled', 0);
			return false;
		}
		$cost = 0.0; $paid = 0.0;
		foreach ($steps as $st) {
			if (!is_array($st)) continue;
			$cost += (float)($st['cost'] ?? 0);
			$paid += (float)($st['paid'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ef) {
					if (!is_array($ef)) continue;
					$cost += (float)($ef['cost'] ?? 0);
					$paid += (float)($ef['paid'] ?? 0);
				}
			}
		}
		$is_settled = ($cost > 0 && ($cost - $paid) <= 0.5) ? 1 : 0;
		update_post_meta($project_id, '_cptt_is_settled', $is_settled);
		return (bool)$is_settled;
	}

	/**
	 * Insert a ledger entry. $args:
	 *   account_id (req), type (req), direction (+1/-1), amount (req),
	 *   category_id, project_id, step_id, customer_id, expert_id,
	 *   ref_type, ref_id, linked_id, date_at, description
	 */
	public static function ledger_insert($args){
		global $wpdb;
		$defaults = [
			'account_id'  => 0,
			'type'        => 'manual',
			'direction'   => 1,
			'amount'      => 0,
			'category_id' => 0,
			'project_id'  => 0,
			'step_id'     => '',
			'customer_id' => 0,
			'expert_id'   => 0,
			'ref_type'    => '',
			'ref_id'      => 0,
			'linked_id'   => 0,
			'voucher_no'  => '',
			'voucher_kind'=> '',
			'status'      => 'posted',
			'reversed_by' => 0,
			'reverses_id' => 0,
			'date_at'     => (int) current_time('timestamp', true),
			'description' => '',
			'created_by'  => (int) get_current_user_id(),
		];
		$a = array_merge($defaults, $args);
		$a['amount']    = (float) $a['amount'];
		$a['direction'] = (int) $a['direction'] >= 0 ? 1 : -1;
		$a['date_fa']   = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime((int)$a['date_at']) : date('Y-m-d H:i', (int)$a['date_at']);
		$a['created_at']= (int) current_time('timestamp', true);
		if (empty($a['voucher_kind'])) {
			$a['voucher_kind'] = self::voucher_kind_for_type((string)$a['type'], (int)$a['direction']);
		}
		if (empty($a['voucher_no'])) {
			$a['voucher_no'] = self::next_voucher_no((string)$a['voucher_kind']);
		}
		if (empty($a['status'])) $a['status'] = 'posted';
		$wpdb->insert(self::tbl_ledger(), $a);
		return (int) $wpdb->insert_id;
	}

	/** v9.2.20 — map ledger type to voucher kind */
	public static function voucher_kind_for_type($type, $direction = 1){
		$type = sanitize_key((string)$type);
		if (in_array($type, ['income'], true)) return 'receipt';
		if (in_array($type, ['expense','expert_payout'], true)) return 'payment';
		if ($type === 'transfer_in' || $type === 'transfer_out') return 'transfer';
		return ((int)$direction >= 0) ? 'receipt' : 'payment';
	}

	/** v9.2.20 — sequential voucher number like RCV-1405-000123 / PAY-1405-000123 */
	public static function next_voucher_no($kind = 'receipt'){
		$kind = $kind === 'payment' ? 'payment' : ($kind === 'transfer' ? 'transfer' : 'receipt');
		$prefix = $kind === 'payment' ? 'PAY' : ($kind === 'transfer' ? 'TRF' : 'RCV');
		$year = 1400;
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'jalali_datetime')) {
			$fa = CPTT_Core::jalali_datetime(current_time('timestamp', true));
			if (preg_match('/(\d{4})/', (string)$fa, $m)) $year = (int)$m[1];
		} else {
			$year = (int) date('Y');
		}
		$opt = 'cptt_fin_voucher_seq_' . $kind . '_' . $year;
		$n = (int) get_option($opt, 0) + 1;
		update_option($opt, $n, false);
		return sprintf('%s-%d-%06d', $prefix, $year, $n);
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * v9.2.56 — فاکتورها (فاز ۲): پیش‌فاکتور/فروش/خرید/برگشتی + تسویه‌ی تخصیصی
	 * لایه‌ی اسناد بالای همان دفتر فعلی؛ مانده‌ها از منابع قبلی خوانده می‌شوند.
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function invoice_kind_vocab(){
		return [
			'pre'             => 'پیش‌فاکتور',
			'sale'            => 'فاکتور فروش',
			'purchase'        => 'فاکتور خرید',
			'return_sale'     => 'برگشت از فروش',
			'return_purchase' => 'برگشت از خرید',
		];
	}

	/** جهت تسویه: receipt = باید از شخص دریافت کنیم · payment = باید به شخص پرداخت کنیم */
	public static function invoice_settle_dir($kind){
		return in_array($kind, ['purchase','return_sale'], true) ? 'payment' : 'receipt';
	}

	public static function invoice_status_vocab(){
		return [
			'draft'     => 'پیش‌نویس',
			'issued'    => 'صادر شده',
			'partial'   => 'تسویه جزئی',
			'settled'   => 'تسویه شده',
			'cancelled' => 'باطل',
		];
	}

	public static function next_invoice_no(){
		$year = 1400;
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core','jalali_datetime')) {
			$fa = CPTT_Core::jalali_datetime(current_time('timestamp', true));
			if (preg_match('/(\d{4})/', (string)$fa, $m)) $year = (int)$m[1];
		} else { $year = (int)date('Y'); }
		$opt = 'cptt_fin_invoice_seq_' . $year;
		$n = (int) get_option($opt, 0) + 1;
		update_option($opt, $n, false);
		return sprintf('INV-%d-%05d', $year, $n);
	}

	/** بازمحاسبه‌ی مبلغ تسویه‌شده و وضعیت فاکتور از روی تخصیص‌ها */
	public static function invoice_recalc($invoice_id){
		global $wpdb;
		$invoice_id = (int)$invoice_id;
		if ($invoice_id <= 0) return false;
		$inv = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_invoices() . " WHERE id=%d", $invoice_id));
		if (!$inv) return false;
		$sum = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM " . self::tbl_invoice_allocs() . " WHERE invoice_id=%d", $invoice_id));
		$status = (string)$inv->status;
		if ($status !== 'cancelled') {
			if ($status === 'draft') {
				$status = $sum > 0.005 ? 'partial' : 'draft';
			} else {
				$status = ($sum >= (float)$inv->amount - 0.005) ? 'settled' : ($sum > 0.005 ? 'partial' : 'issued');
			}
		}
		$wpdb->update(self::tbl_invoices(), [
			'settled'    => $sum,
			'status'     => $status,
			'updated_at' => (int)current_time('timestamp', true),
		], ['id' => $invoice_id]);
		return $status;
	}

	/** v9.2.20 — human label for voucher/type */
	public static function voucher_label($row){
		$kind = is_object($row) ? (string)($row->voucher_kind ?? '') : (string)($row['voucher_kind'] ?? '');
		$type = is_object($row) ? (string)($row->type ?? '') : (string)($row['type'] ?? '');
		$status = is_object($row) ? (string)($row->status ?? 'posted') : (string)($row['status'] ?? 'posted');
		if ($kind === '') $kind = self::voucher_kind_for_type($type);
		$map = [
			'receipt'  => '📥 سند دریافتی',
			'payment'  => '📤 سند پرداختی',
			'transfer' => '🔁 سند انتقال',
		];
		$label = $map[$kind] ?? '📄 سند';
		if ($type === 'expert_payout') $label = '👤 سند پرداختی (تسویه کارشناس)';
		if ($status === 'reversed') $label .= ' · برگشت‌خورده';
		if ($status === 'reversal') $label = '↩️ سند برگشت';
		return $label;
	}


	/* ═══════════════════════════════════════════════════════════════════
	 * v9.3.0 — خنثی‌سازی «جفت برگشت» بر پایه‌ی وجود سند برگشت (نه فقط پرچم وضعیت)
	 *
	 * علت ریشه‌ای: ممکن است سند اصلی «فعال» بماند در حالی که سند برگشتِ آن ثبت
	 * شده (مثلاً به‌روزرسانی پرچم وضعیت در داده‌های قدیمی انجام نشده باشد)؛ در آن
	 * صورت اصل سند بی‌صدا دوبار محاسبه می‌شد. از این نسخه، «خنثی بودن» از روی
	 * وجود سند برگشتِ مرتبط تشخیص داده می‌شود، نه صرفاً از ستون وضعیت —
	 * بنابراین اسناد برگشتی/برگشت‌خورده در «هیچ محاسبه‌ای» لحاظ نمی‌شوند
	 * (فقط در لیست‌ها با برچسب «خنثی» دیده می‌شوند).
	 * ═══════════════════════════════════════════════════════════════════ */

	/** شرط SQL «سند مؤثر»: فعال + نه اصلِ برگشت‌خورده + نه هدفِ هیچ سند برگشتی */
	public static function sql_active_cond($alias = 'l'){
		$t = self::tbl_ledger();
		$a = $alias !== '' ? ($alias . '.') : '';
		return "({$a}status='posted' AND {$a}reversed_by=0 AND NOT EXISTS (SELECT 1 FROM $t cptt_nx WHERE cptt_nx.reverses_id = {$a}id))";
	}

	/** مجموعه‌ی شناسه‌هایی که هدفِ یک سند برگشت‌اند (کش درخواستی) */
	public static function neutral_targets(){
		static $cache = null;
		if (is_array($cache)) return $cache;
		global $wpdb;
		$ids = $wpdb->get_col("SELECT DISTINCT reverses_id FROM " . self::tbl_ledger() . " WHERE reverses_id > 0");
		$cache = [];
		if (is_array($ids)) foreach ($ids as $i) $cache[(int)$i] = true;
		return $cache;
	}

	/** آیا این ردیف دفتری «خنثی» است؟ (اصلیِ برگشت‌خورده، سند برگشت، یا هدفِ برگشت) */
	public static function is_row_neutral($r){
		$st = is_object($r) ? (string)($r->status ?? 'posted') : (string)($r['status'] ?? 'posted');
		if ($st !== 'posted') return true;
		$rb = (int)(is_object($r) ? ($r->reversed_by ?? 0) : ($r['reversed_by'] ?? 0));
		if ($rb > 0) return true;
		$id = (int)(is_object($r) ? ($r->id ?? 0) : ($r['id'] ?? 0));
		if ($id <= 0) return false;
		$t = self::neutral_targets();
		return isset($t[$id]);
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * v9.3.0 (فاز ۳) — اسناد و چک‌ها + گزارش سنی مطالبات
	 * ═══════════════════════════════════════════════════════════════════ */

	public static function cheque_status_vocab(){
		return ['pending'=>'در انتظار وصول/پاس','cleared'=>'وصول/پاس شد','bounced'=>'برگشت خورده','cancelled'=>'باطل'];
	}

	/** لیست چک‌ها با فیلترهای صفحه */
	public static function get_cheques($args = []){
		global $wpdb;
		$t = self::tbl_cheques();
		$w = ['1=1'];
		if (!empty($args['direction'])) $w[] = 'c.direction=' . ((int)$args['direction'] >= 0 ? 1 : -1);
		if (!empty($args['status']) && $args['status'] !== 'all') $w[] = $wpdb->prepare('c.status=%s', (string)$args['status']);
		if (!empty($args['person_id'])) $w[] = $wpdb->prepare('c.person_id=%d', (int)$args['person_id']);
		if (!empty($args['from'])) $w[] = $wpdb->prepare('c.due_ts>=%d', (int)$args['from']);
		if (!empty($args['to'])) $w[] = $wpdb->prepare('c.due_ts<=%d', (int)$args['to']);
		if (!empty($args['q'])) {
			$like = '%' . $wpdb->esc_like((string)$args['q']) . '%';
			$w[] = $wpdb->prepare('(c.cheque_no LIKE %s OR c.bank LIKE %s OR c.note LIKE %s)', $like, $like, $like);
		}
		$sql = "SELECT c.* FROM $t c WHERE " . implode(' AND ', $w) . " ORDER BY c.status='pending' DESC, c.due_ts ASC, c.id DESC LIMIT 400";
		$rows = $wpdb->get_results($sql);
		if (!is_array($rows)) return [];
		$names = [];
		foreach ($rows as $r) {
			$pid = (int)$r->person_id;
			if ($pid > 0 && !isset($names[$pid])) { $u = get_user_by('id', $pid); $names[$pid] = $u ? (string)$u->display_name : ('#' . $pid); }
			$r->person_name = $pid > 0 ? (string)($names[$pid] ?? ('#' . $pid)) : '—';
			$r->project_title = '';
			if ((int)$r->project_id > 0) { $t2 = get_the_title((int)$r->project_id); $r->project_title = $t2 !== '' ? $t2 : ('#' . (int)$r->project_id); }
		}
		return $rows;
	}

	/** KPIهای صفحه‌ی چک‌ها */
	public static function cheque_kpis(){
		global $wpdb;
		$t = self::tbl_cheques(); $now = (int)current_time('timestamp', true); $week = $now + 7 * 86400;
		$row = $wpdb->get_row(
			"SELECT
				COALESCE(SUM(CASE WHEN status='pending' AND direction>0 THEN amount ELSE 0 END),0) AS pend_in,
				COALESCE(SUM(CASE WHEN status='pending' AND direction<0 THEN amount ELSE 0 END),0) AS pend_out,
				COALESCE(SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END),0) AS pend_n,
				COALESCE(SUM(CASE WHEN status='pending' AND due_ts>0 AND due_ts<=" . (int)$week . " THEN 1 ELSE 0 END),0) AS due7_n,
				COALESCE(SUM(CASE WHEN status='pending' AND due_ts>0 AND due_ts<=" . (int)$week . " THEN amount ELSE 0 END),0) AS due7_amt,
				COALESCE(SUM(CASE WHEN status='bounced' THEN 1 ELSE 0 END),0) AS bounced_n
			FROM $t", ARRAY_A
		);
		return is_array($row) ? $row : ['pend_in'=>0,'pend_out'=>0,'pend_n'=>0,'due7_n'=>0,'due7_amt'=>0,'bounced_n'=>0];
	}

	/**
	 * گزارش سنی مطالبات (بر پایه‌ی فاکتورهای فروش باز) —
	 * سطل‌ها: سررسید نرسیده / ۱‑۳۰ / ۳۱‑۶۰ / ۶۱‑۹۰ / +۹۰ روز گذشته از سررسید
	 */
	public static function invoice_aging(){
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT id, person_id, invoice_no, amount, settled, due_ts FROM " . self::tbl_invoices() . "
			 WHERE kind='sale' AND status IN ('issued','partial') ORDER BY due_ts ASC, id ASC"
		);
		$now = (int)current_time('timestamp', true);
		$per = []; $tot = ['cur'=>0.0,'b30'=>0.0,'b60'=>0.0,'b90'=>0.0,'b90p'=>0.0,'total'=>0.0];
		if (is_array($rows)) foreach ($rows as $r) {
			$remain = (float)$r->amount - (float)$r->settled;
			if ($remain <= 0.005) continue;
			$pid = (int)$r->person_id;
			if (!isset($per[$pid])) {
				$u = $pid > 0 ? get_user_by('id', $pid) : null;
				$per[$pid] = ['person_id'=>$pid,'name'=>$u ? (string)$u->display_name : ($pid > 0 ? ('#'.$pid) : '— بدون شخص —'),
					'cur'=>0.0,'b30'=>0.0,'b60'=>0.0,'b90'=>0.0,'b90p'=>0.0,'total'=>0.0];
			}
			$due = (int)$r->due_ts;
			$days = $due > 0 ? (int)floor(($now - $due) / 86400) : 0;
			$b = 'cur';
			if ($due > 0 && $days > 0) $b = $days <= 30 ? 'b30' : ($days <= 60 ? 'b60' : ($days <= 90 ? 'b90' : 'b90p'));
			$per[$pid][$b] += $remain; $per[$pid]['total'] += $remain;
			$tot[$b] += $remain; $tot['total'] += $remain;
		}
		uasort($per, function($a,$b){ return $b['total'] <=> $a['total']; });
		return ['rows'=>array_values($per), 'totals'=>$tot];
	}

	/**
	 * تراز همه‌ی اشخاص (همان فرمول صفحه‌ی اشخاص، با خنثی‌سازی جفت برگشت) —
	 * برای مرکز گزارشات؛ فقط خواندنی.
	 */
	public static function person_balances(){
		global $wpdb;
		$t = self::tbl_ledger();
		$A = self::sql_active_cond('l');
		$live_map = [];
		$lr = $wpdb->get_results(
			"SELECT l.project_id, SUM(l.amount * l.direction) AS live FROM $t l
			 WHERE l.project_id > 0 AND l.type='income' AND l.voucher_kind='receipt' AND $A GROUP BY l.project_id"
		);
		if (is_array($lr)) foreach ($lr as $r) $live_map[(int)$r->project_id] = (float)$r->live;
		$people = [];
		$mk = function($uid) use (&$people){
			$uid = (int)$uid;
			if (!isset($people[$uid])) $people[$uid] = ['id'=>$uid,'name'=>'','cost'=>0.0,'live'=>0.0,'np_in'=>0.0,'np_out'=>0.0,'bal'=>0.0];
			return $uid;
		};
		foreach (get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]) as $p) {
			$cid = (int)get_post_meta($p->ID, '_cptt_client_user_id', true);
			if (!$cid) continue;
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			$cost = 0.0;
			if (is_array($steps)) foreach ($steps as $st) {
				if (!is_array($st)) continue;
				$cost += (float)($st['cost'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance']))
					foreach ($st['extra_finance'] as $ef) if (is_array($ef)) $cost += (float)($ef['cost'] ?? 0);
			}
			$k = $mk($cid);
			$people[$k]['cost'] += $cost;
			$people[$k]['live'] += isset($live_map[$p->ID]) ? (float)$live_map[$p->ID] : 0.0;
		}
		$np = $wpdb->get_results(
			"SELECT l.customer_id, l.expert_id,
				SUM(CASE WHEN l.direction > 0 THEN l.amount ELSE 0 END) AS tin,
				SUM(CASE WHEN l.direction < 0 THEN l.amount ELSE 0 END) AS tout
			 FROM $t l WHERE $A AND (l.project_id = 0 OR l.project_id IS NULL) AND (l.customer_id > 0 OR l.expert_id > 0)
			 GROUP BY l.customer_id, l.expert_id"
		);
		if (is_array($np)) foreach ($np as $a) {
			foreach ([(int)$a->customer_id, (int)$a->expert_id] as $uid) {
				if ($uid <= 0) continue;
				$k = $mk($uid);
				$people[$k]['np_in'] += (float)$a->tin; $people[$k]['np_out'] += (float)$a->tout;
			}
		}
		foreach ($people as &$pr) {
			$u = get_user_by('id', (int)$pr['id']);
			$pr['name'] = $u ? (string)$u->display_name : ('#' . (int)$pr['id']);
			$pr['bal'] = round(($pr['cost'] - $pr['live']) - $pr['np_in'] + $pr['np_out'], 2);
		}
		unset($pr);
		return array_values($people);
	}

	/* ── AJAX: چک‌ها (فاز ۳) ── */
	public function ajax_cheque_save(){
		$this->check_ajax();
		global $wpdb;
		$id        = (int)($_POST['id'] ?? 0);
		$direction = ((int)($_POST['direction'] ?? 1) >= 0) ? 1 : -1;
		$person_id = (int)($_POST['person_id'] ?? 0);
		$project_id= (int)($_POST['project_id'] ?? 0);
		$cheque_no = sanitize_text_field($_POST['cheque_no'] ?? '');
		$bank      = sanitize_text_field($_POST['bank'] ?? '');
		$branch    = sanitize_text_field($_POST['branch'] ?? '');
		$amount    = self::parse_amount($_POST['amount'] ?? 0);
		$due_in    = sanitize_text_field($_POST['due'] ?? '');
		$due_ts    = $due_in !== '' ? self::parse_jalali_local($due_in . ' 23:59') : 0;
		$note      = sanitize_textarea_field($_POST['note'] ?? '');
		if ($person_id <= 0) wp_send_json_error('شخص طرف چک را انتخاب کنید', 400);
		if ($amount <= 0) wp_send_json_error('مبلغ چک نامعتبر است', 400);
		if ($due_ts <= 0) wp_send_json_error('تاریخ سررسید را وارد کنید', 400);
		if ($cheque_no === '') wp_send_json_error('شماره چک/سفته را وارد کنید', 400);

		if ($id > 0) {
			$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_cheques() . " WHERE id=%d", $id));
			if (!$row) wp_send_json_error('چک یافت نشد', 404);
			if ((string)$row->status !== 'pending') wp_send_json_error('فقط چک «در انتظار» قابل ویرایش است', 400);
			$wpdb->update(self::tbl_cheques(), [
				'direction'=>$direction,'person_id'=>$person_id,'project_id'=>$project_id,
				'cheque_no'=>$cheque_no,'bank'=>$bank,'branch'=>$branch,
				'due_ts'=>$due_ts,'amount'=>$amount,'note'=>$note,
				'updated_at'=>(int)current_time('timestamp', true),
			], ['id'=>$id]);
			wp_send_json_success(['id'=>$id]);
		}
		$ok = $wpdb->insert(self::tbl_cheques(), [
			'direction'=>$direction,'person_id'=>$person_id,'project_id'=>$project_id,
			'cheque_no'=>$cheque_no,'bank'=>$bank,'branch'=>$branch,
			'due_ts'=>$due_ts,'amount'=>$amount,'status'=>'pending','note'=>$note,
			'created_by'=>(int)get_current_user_id(),
			'created_at'=>(int)current_time('timestamp', true),
			'updated_at'=>(int)current_time('timestamp', true),
		]);
		if (!$ok) wp_send_json_error('خطا در ثبت چک', 500);
		wp_send_json_success(['id'=>(int)$wpdb->insert_id]);
	}

	public function ajax_cheque_status(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$to = sanitize_key($_POST['to'] ?? '');
		$vocab = self::cheque_status_vocab();
		if ($id <= 0 || !isset($vocab[$to])) wp_send_json_error('درخواست نامعتبر است', 400);
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_cheques() . " WHERE id=%d", $id));
		if (!$row) wp_send_json_error('چک یافت نشد', 404);
		$status = (string)$row->status;

		if ($to === 'cleared') {
			if (!in_array($status, ['pending','bounced'], true)) wp_send_json_error('فقط چک در انتظار/برگشتی قابل وصول است', 400);
			// ثبت سند واقعی دفتر — اثر مالی چک فقط همین‌جا وارد حساب‌ها می‌شود
			$is_in = ((int)$row->direction >= 0);
			$desc  = ($is_in ? 'وصول چک شماره ' : 'پاس/تسویه چک پرداختی شماره ') . (string)$row->cheque_no;
			if ((string)$row->bank !== '') $desc .= ' — بانک ' . (string)$row->bank;
			$ledger_id = self::ledger_insert([
				'account_id'  => self::default_cash_account_id(),
				'type'        => $is_in ? 'income'  : 'expense',
				'direction'   => $is_in ? 1 : -1,
				'amount'      => (float)$row->amount,
				'project_id'  => (int)$row->project_id,
				'customer_id' => (int)$row->person_id,
				'ref_type'    => 'cheque_clear',
				'ref_id'      => $id,
				'voucher_kind'=> $is_in ? 'receipt' : 'payment',
				'status'      => 'posted',
				'description' => $desc,
			]);
			if (!$ledger_id) wp_send_json_error('خطا در ثبت سند دفتر', 500);
			$wpdb->update(self::tbl_cheques(), ['status'=>'cleared','ledger_id'=>(int)$ledger_id,'updated_at'=>(int)current_time('timestamp', true)], ['id'=>$id]);
			if ($is_in && (int)$row->project_id > 0 && class_exists('CPTT_Expert') && method_exists('CPTT_Expert','rebalance_project_public')) {
				CPTT_Expert::rebalance_project_public((int)$row->project_id);
			}
			wp_send_json_success(['cleared'=>true,'ledger_id'=>(int)$ledger_id]);
		}
		if ($to === 'bounced') {
			if ($status !== 'pending') wp_send_json_error('فقط چک در انتظار می‌تواند برگشت بخورد', 400);
			$wpdb->update(self::tbl_cheques(), ['status'=>'bounced','updated_at'=>(int)current_time('timestamp', true)], ['id'=>$id]);
			wp_send_json_success(['bounced'=>true]);
		}
		if ($to === 'pending') {
			if ($status !== 'bounced') wp_send_json_error('فقط چک برگشتی به انتظار برمی‌گردد', 400);
			$wpdb->update(self::tbl_cheques(), ['status'=>'pending','updated_at'=>(int)current_time('timestamp', true)], ['id'=>$id]);
			wp_send_json_success(['pending'=>true]);
		}
		// cancelled — فقط از حالت انتظار
		if ($status !== 'pending') wp_send_json_error('فقط چک در انتظار قابل ابطال است', 400);
		$wpdb->update(self::tbl_cheques(), ['status'=>'cancelled','updated_at'=>(int)current_time('timestamp', true)], ['id'=>$id]);
		wp_send_json_success(['cancelled'=>true]);
	}

	public function ajax_cheque_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if ($id <= 0) wp_send_json_error('شناسه نامعتبر است', 400);
		$row = $wpdb->get_row($wpdb->prepare("SELECT status FROM " . self::tbl_cheques() . " WHERE id=%d", $id));
		if (!$row) wp_send_json_error('چک یافت نشد', 404);
		if (!in_array((string)$row->status, ['pending','cancelled'], true)) wp_send_json_error('فقط چک در انتظار یا باطل قابل حذف است', 400);
		$wpdb->delete(self::tbl_cheques(), ['id'=>$id]);
		wp_send_json_success(['deleted'=>true]);
	}


	/* ═══════════════════════════════════════════════════════════════════
	 * AUTO-HOOKS (link existing system to the ledger)
	 * ═══════════════════════════════════════════════════════════════════ */
	public function log_expert_payout($project_id, $step_id, $expert_id, $amount, $mode){
		// v9.2.15 — allow caller to pick treasury account via filter / global request
		$account_id = 0;
		if (!empty($_POST['account_id'])) $account_id = absint($_POST['account_id']);
		if (!$account_id) $account_id = (int) apply_filters('cptt_expert_payout_account_id', 0, $project_id, $step_id, $expert_id, $amount, $mode);
		if (!$account_id) $account_id = self::default_cash_account_id();
		if (!$account_id || (float)$amount <= 0) return;
		$mode_label = ($mode === 'final') ? 'تسویه نهایی' : 'پرداخت جزئی';
		self::ledger_insert([
			'account_id'   => $account_id,
			'type'         => 'expert_payout',
			'direction'    => -1,
			'amount'       => (float)$amount,
			'project_id'   => (int)$project_id,
			'step_id'      => (string)$step_id,
			'expert_id'    => (int)$expert_id,
			'ref_type'     => 'expert_payout',
			'voucher_kind' => 'payment',
			'status'       => 'posted',
			'description'  => $mode_label . ' با کارشناس - مرحله',
		]);
	}
	public function log_manual_payment($expert_id, $amount, $note){
		$account_id = !empty($_POST['account_id']) ? absint($_POST['account_id']) : 0;
		if (!$account_id) $account_id = self::default_cash_account_id();
		if (!$account_id || (float)$amount <= 0) return;
		self::ledger_insert([
			'account_id'   => $account_id,
			'type'         => 'expert_payout',
			'direction'    => -1,
			'amount'       => (float)$amount,
			'expert_id'    => (int)$expert_id,
			'ref_type'     => 'manual_payment',
			'voucher_kind' => 'payment',
			'status'       => 'posted',
			'description'  => (string)$note ?: 'پرداخت دستی به کارشناس',
		]);
	}
	public static function default_cash_account_id(){
		global $wpdb;
		$id = (int) $wpdb->get_var("SELECT id FROM " . self::tbl_accounts() . " WHERE status=1 ORDER BY id ASC LIMIT 1");
		return $id;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * KPI computations (used by dashboard + receivables)
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function compute_kpis(){
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		$total_cost=0; $total_paid=0; $total_remain=0;
		$debt_projects = 0; $settled = 0; $unsettled = 0;
		$expert_payouts_total = 0;
		foreach ($projects as $p) {
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			if (!is_array($steps)) continue;
			$pc=0; $pp=0; $ep=0;
			foreach ($steps as $st) {
				$pc += (float)($st['cost'] ?? 0);
				$pp += (float)($st['paid'] ?? 0);
				$ep += (float)($st['expert_paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) {
						$pc += (float)($ef['cost'] ?? 0);
						$pp += (float)($ef['paid'] ?? 0);
					}
				}
			}
			$total_cost += $pc;
			$total_paid += $pp;
			$remain = max(0, $pc - $pp);
			$total_remain += $remain;
			if ($remain > 0) $debt_projects++;
			if ((int)get_post_meta($p->ID,'_cptt_is_settled',true)) $settled++; else $unsettled++;
			$expert_payouts_total += $ep;
		}
		$gross_profit = $total_paid - $expert_payouts_total;
		return [
			'total_revenue'    => $total_paid,           // received money
			'total_invoiced'   => $total_cost,
			'receivables'      => $total_remain,
			'expert_payouts'   => $expert_payouts_total,
			'gross_profit'     => $gross_profit,
			'debt_projects'    => $debt_projects,
			'settled_projects' => $settled,
			'unsettled_projects'=> $unsettled,
			'projects_total'   => count($projects),
		];
	}

	/* v6.4.1 — Monthly aggregation combining BOTH the unified ledger AND
	 * existing project finance data. This way the dashboard correctly
	 * reflects revenue & expert payouts even before the user has imported
	 * everything into the ledger.
	 *
	 * Projects are matched by their post_date_gmt (creation month) because
	 * step-level dates aren't stored consistently. This is a pragmatic
	 * approximation that becomes more accurate as users start using the
	 * ledger for new income/expense events.
	 */
	public static function monthly_series(){
		global $wpdb;
		$series = []; // 'YYYY-MM' => ['income'=>0,'expense'=>0, 'jlabel'=>'YYYY/MM']
		$now = current_time('timestamp', true);

		// Use Jalali month labels so users see Persian dates
		$fa_months = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

		for ($i = 5; $i >= 0; $i--) {
			$ts = strtotime("-{$i} months", $now);
			$mk = date('Y-m', $ts);
			$jlabel = $mk;
			if (class_exists('CPTT_Core')) {
				// v9.2.0 — use *_en variant so regex can match ASCII digits
				$jfull = method_exists('CPTT_Core', 'jalali_datetime_en')
					? CPTT_Core::jalali_datetime_en($ts)
					: CPTT_Core::jalali_datetime($ts);
				if (preg_match('#^(\d{4})/(\d{1,2})/#', $jfull, $mm)) {
					$jy = (int)$mm[1]; $jmn = (int)$mm[2];
					$jlabel = (isset($fa_months[$jmn-1]) ? $fa_months[$jmn-1] : $jmn) . ' ' . $jy;
				}
			}
			$series[$mk] = ['label' => $jlabel, 'income' => 0, 'expense' => 0];
		}
		$cutoff = strtotime('-6 months', $now);

		// 1) From ledger (income/expense direction)
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT DATE_FORMAT(FROM_UNIXTIME(l.date_at), '%%Y-%%m') AS mk, l.direction, l.type, SUM(l.amount) AS s
			 FROM " . self::tbl_ledger() . " l
			 WHERE l.date_at >= %d AND l.type NOT IN ('transfer_in','transfer_out')
			   AND " . self::sql_active_cond('l') . "
			 GROUP BY mk, l.direction, l.type",
			$cutoff
		));
		foreach ($rows as $r) {
			if (!isset($series[$r->mk])) continue;
			if ((int)$r->direction > 0) $series[$r->mk]['income']  += (float)$r->s;
			else                         $series[$r->mk]['expense'] += (float)$r->s;
		}

		// 2) From projects (paid → income, expert_paid → expense) bucketed by
		// the project's creation month. This bridges old data into the chart.
		$projects = get_posts([
			'post_type'   => 'cptt_project',
			'post_status' => 'any',
			'numberposts' => -1,
			'date_query'  => [['after' => date('Y-m-d', $cutoff), 'inclusive' => true]],
		]);
		foreach ($projects as $p) {
			$mk = date('Y-m', strtotime($p->post_date_gmt));
			if (!isset($series[$mk])) continue;
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			if (!is_array($steps)) continue;
			$paid = 0; $epaid = 0;
			foreach ($steps as $st) {
				$paid  += (float)($st['paid']        ?? 0);
				$epaid += (float)($st['expert_paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) $paid += (float)($ef['paid'] ?? 0);
				}
			}
			$series[$mk]['income']  += $paid;
			$series[$mk]['expense'] += $epaid;
		}

		return array_values($series);
	}

	/**
	 * v6.4.1 — Top customers by REVENUE (paid amount), top 6.
	 */
	public static function top_customers_series($limit = 6){
		$map = []; // cid => ['name'=>, 'paid'=>, 'remain'=>]
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		foreach ($projects as $p) {
			$cid = (int) get_post_meta($p->ID, '_cptt_client_user_id', true);
			if (!$cid) continue;
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			if (!is_array($steps)) continue;
			$paid = 0; $cost = 0;
			foreach ($steps as $st) {
				$cost += (float)($st['cost'] ?? 0);
				$paid += (float)($st['paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) { $cost += (float)($ef['cost']??0); $paid += (float)($ef['paid']??0); }
				}
			}
			if (!isset($map[$cid])) {
				$u = get_user_by('id', $cid);
				$map[$cid] = ['name' => $u ? $u->display_name : ('#'.$cid), 'paid' => 0, 'remain' => 0];
			}
			$map[$cid]['paid']   += $paid;
			$map[$cid]['remain'] += max(0, $cost - $paid);
		}
		uasort($map, function($a,$b){ return ($b['paid'] <=> $a['paid']); });
		return array_slice(array_values($map), 0, $limit);
	}

	/**
	 * v6.4.1 — Income breakdown by category for current ledger entries.
	 */
	public static function category_breakdown($type = 'expense'){
		global $wpdb;
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT l.category_id, c.name, c.color, c.icon, SUM(l.amount) AS s
			 FROM " . self::tbl_ledger() . " l
			 LEFT JOIN " . self::tbl_categories() . " c ON c.id = l.category_id
			 WHERE l.type=%s AND " . self::sql_active_cond('l') . "
			 GROUP BY l.category_id
			 ORDER BY s DESC
			 LIMIT 8",
			$type
		));
		$out = [];
		foreach ($rows as $r) {
			$out[] = [
				'name'  => $r->name ?: 'بدون دسته',
				'color' => $r->color ?: '#94a3b8',
				'icon'  => $r->icon  ?: '🏷',
				'value' => (float)$r->s,
			];
		}
		return $out;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * AJAX HANDLERS
	 * ═══════════════════════════════════════════════════════════════════ */
	private function check_ajax(){
		if (!is_user_logged_in() || !current_user_can('edit_cptt_projects')) {
			wp_send_json_error('no_access', 403);
		}
		check_ajax_referer(self::NONCE, 'nonce');
	}

	public function ajax_account_save(){
		$this->check_ajax();
		global $wpdb;
		$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
		$data = [
			'name'            => sanitize_text_field($_POST['name'] ?? ''),
			'type'            => in_array(($_POST['type'] ?? 'cash'), ['cash','bank'], true) ? $_POST['type'] : 'cash',
			'bank_name'       => sanitize_text_field($_POST['bank_name'] ?? ''),
			'account_number'  => sanitize_text_field($_POST['account_number'] ?? ''),
			'iban'            => sanitize_text_field($_POST['iban'] ?? ''),
			'card_number'     => sanitize_text_field($_POST['card_number'] ?? ''),
			'initial_balance' => self::parse_amount($_POST['initial_balance'] ?? 0),
			'color'           => sanitize_text_field($_POST['color'] ?? '#6366f1'),
			'icon'            => sanitize_text_field($_POST['icon'] ?? '🏦'),
			'status'          => isset($_POST['status']) ? (int)$_POST['status'] : 1,
		];
		if ($data['name'] === '') wp_send_json_error('نام حساب الزامی است', 400);
		if ($id > 0) {
			$wpdb->update(self::tbl_accounts(), $data, ['id'=>$id]);
		} else {
			$data['created_at'] = (int) current_time('timestamp', true);
			$data['created_by'] = (int) get_current_user_id();
			$wpdb->insert(self::tbl_accounts(), $data);
			$id = (int) $wpdb->insert_id;
		}
		wp_send_json_success(['id'=>$id]);
	}

	public function ajax_account_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if (!$id) wp_send_json_error('invalid', 400);
		$has_ledger = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . self::tbl_ledger() . " WHERE account_id=%d", $id));
		if ($has_ledger > 0) {
			// Soft-disable instead of delete
			$wpdb->update(self::tbl_accounts(), ['status'=>0], ['id'=>$id]);
			wp_send_json_success(['archived'=>true]);
		}
		$wpdb->delete(self::tbl_accounts(), ['id'=>$id]);
		wp_send_json_success(['deleted'=>true]);
	}

	public function ajax_cat_save(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$data = [
			'name'      => sanitize_text_field($_POST['name'] ?? ''),
			'type'      => in_array(($_POST['type'] ?? ''), ['income','expense'], true) ? $_POST['type'] : 'expense',
			'parent_id' => (int)($_POST['parent_id'] ?? 0),
			'color'     => sanitize_text_field($_POST['color'] ?? '#64748b'),
			'icon'      => sanitize_text_field($_POST['icon'] ?? '🏷'),
			'sort_order'=> (int)($_POST['sort_order'] ?? 0),
		];
		if ($data['name'] === '') wp_send_json_error('نام دسته الزامی است', 400);
		if ($id > 0) $wpdb->update(self::tbl_categories(), $data, ['id'=>$id]);
		else { $wpdb->insert(self::tbl_categories(), $data); $id = (int)$wpdb->insert_id; }
		wp_send_json_success(['id'=>$id]);
	}

	public function ajax_cat_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if (!$id) wp_send_json_error('invalid', 400);
		$wpdb->delete(self::tbl_categories(), ['id'=>$id]);
		wp_send_json_success(['deleted'=>true]);
	}

	public function ajax_tx_save(){
		$this->check_ajax();
		global $wpdb;
		$id          = (int)($_POST['id'] ?? 0);
		$type        = ($_POST['tx_type'] ?? 'expense') === 'income' ? 'income' : 'expense';
		$account_id  = (int)($_POST['account_id'] ?? 0);
		$amount      = self::parse_amount($_POST['amount'] ?? 0);
		$category_id = (int)($_POST['category_id'] ?? 0);
		$project_id  = (int)($_POST['project_id'] ?? 0);
		$customer_id = (int)($_POST['customer_id'] ?? 0);
		$person_id   = (int)($_POST['person_id'] ?? 0);
		$expert_id   = (int)($_POST['expert_id'] ?? 0);
		// person_id can be customer or expert; map by role
		if ($person_id > 0) {
			$pu = get_user_by('id', $person_id);
			if ($pu) {
				$roles = (array)$pu->roles;
				if (in_array('cptt_expert', $roles, true) || in_array('administrator', $roles, true)) {
					$expert_id = $person_id;
					if (!$customer_id) $customer_id = 0;
				} else {
					$customer_id = $person_id;
				}
			}
		}
		$description = sanitize_textarea_field($_POST['description'] ?? '');
		$date_local  = sanitize_text_field($_POST['date_local'] ?? '');

		if (!$account_id) wp_send_json_error('انتخاب حساب الزامی است', 400);
		if ($amount <= 0) wp_send_json_error('مبلغ نامعتبر', 400);

		$date_at = self::parse_jalali_local($date_local, true) ?: current_time('timestamp', true);
		$old_row = $id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $id)) : null;

		$voucher_kind = $type === 'income' ? 'receipt' : 'payment';
		$row = [
			'account_id'   => $account_id,
			'type'         => $type,
			'direction'    => $type === 'income' ? 1 : -1,
			'amount'       => $amount,
			'category_id'  => $category_id,
			'project_id'   => $project_id,
			'customer_id'  => $customer_id,
			'expert_id'    => $expert_id,
			'description'  => $description,
			'date_at'      => $date_at,
			'date_fa'      => class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($date_at) : date('Y-m-d H:i', $date_at),
			'created_by'   => (int) get_current_user_id(),
			'created_at'   => (int) current_time('timestamp', true),
			'ref_type'     => 'manual_tx',
			'voucher_kind' => $voucher_kind,
			'status'       => 'posted',
		];
		if ($id > 0) {
			// If an existing income receipt is edited, undo its old side-effect first;
			// then the new amount/project below is applied exactly once.
			if ($old_row && $old_row->type === 'income' && (int)$old_row->project_id > 0 && (float)$old_row->amount > 0) {
				self::_reverse_income_from_project((int)$old_row->project_id, (float)$old_row->amount);
			}
			// keep original voucher_no on edit
			unset($row['created_at']);
			$wpdb->update(self::tbl_ledger(), $row, ['id'=>$id]);
		} else {
			$row['voucher_no'] = self::next_voucher_no($voucher_kind);
			$wpdb->insert(self::tbl_ledger(), $row);
			$id = (int) $wpdb->insert_id;
		}

		// v9.2.7 — Apply INCOME with a project_id back onto the project's
		// step ledger (_cptt_steps.paid) so the receivables page reflects
		// the settlement immediately. Otherwise the ledger and the project
		// meta diverge and the debtor never disappears from the list.
		if ($type === 'income' && $project_id > 0 && $amount > 0) {
			self::_apply_income_to_project($project_id, (float)$amount);
		}
		if ($old_row && (int)$old_row->project_id > 0) self::refresh_project_settlement_flag((int)$old_row->project_id);
		if ($project_id > 0) self::refresh_project_settlement_flag($project_id);

		wp_send_json_success(['id'=>$id]);
	}

	/**
	 * Distribute a paid amount across the project's still-open steps
	 * (fills each step's remaining balance in order until the amount runs out).
	 * Also handles `extra_finance` sub-rows.
	 */
	public static function _apply_income_to_project($project_id, $amount){
		$project_id = (int)$project_id;
		$remaining  = (float)$amount;
		if ($project_id <= 0 || $remaining <= 0) return 0;

		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) return 0;

		$applied = 0.0;
		foreach ($steps as $si => $st) {
			if ($remaining <= 0) break;
			$cost = (float)($st['cost'] ?? 0);
			$paid = (float)($st['paid'] ?? 0);
			$open = max(0, $cost - $paid);
			if ($open > 0) {
				$take = min($open, $remaining);
				$steps[$si]['paid'] = $paid + $take;
				$remaining -= $take;
				$applied   += $take;
			}
			// Extra finance rows on the same step
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ei => $ef) {
					if ($remaining <= 0) break;
					$ec = (float)($ef['cost'] ?? 0);
					$ep = (float)($ef['paid'] ?? 0);
					$eo = max(0, $ec - $ep);
					if ($eo > 0) {
						$take = min($eo, $remaining);
						$steps[$si]['extra_finance'][$ei]['paid'] = $ep + $take;
						$remaining -= $take;
						$applied   += $take;
					}
				}
			}
		}
		update_post_meta($project_id, '_cptt_steps', $steps);
		self::refresh_project_settlement_flag($project_id);
		return $applied;
	}

	public function ajax_tx_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if (!$id) wp_send_json_error('invalid', 400);

		// v9.2.8 — If this row was an INCOME tied to a project, reverse the
		// paid amount from the project's steps so the debtor re-appears in
		// the receivables list. Symmetric to _apply_income_to_project().
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $id));
		$affected_project_id = $row ? (int)$row->project_id : 0;
		if ($row && $row->type === 'income' && $affected_project_id > 0 && (float)$row->amount > 0) {
			self::_reverse_income_from_project($affected_project_id, (float)$row->amount);
		}

		$wpdb->delete(self::tbl_ledger(), ['id'=>$id]);
		if ($affected_project_id > 0) self::refresh_project_settlement_flag($affected_project_id);
		wp_send_json_success(['deleted'=>true]);
	}


	/**
	 * v9.2.20 — reverse a posted voucher (creates opposite document and undoes side-effects)
	 */
	public function ajax_tx_reverse(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$note = sanitize_textarea_field($_POST['note'] ?? '');
		if (!$id) wp_send_json_error('شناسه سند نامعتبر است', 400);
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $id));
		if (!$row) wp_send_json_error('سند یافت نشد', 404);
		$status = (string)($row->status ?? 'posted');
		if ($status === 'reversed') wp_send_json_error('این سند قبلاً برگشت خورده است', 400);
		if ($status === 'reversal') wp_send_json_error('سند برگشت را نمی‌توان دوباره برگشت زد', 400);
		if ((int)($row->reversed_by ?? 0) > 0) wp_send_json_error('این سند قبلاً برگشت خورده است', 400);

		$amount = (float)$row->amount;
		if ($amount <= 0) wp_send_json_error('مبلغ سند نامعتبر است', 400);

		// reverse side-effects first
		if ($row->type === 'income' && (int)$row->project_id > 0) {
			self::_reverse_income_from_project((int)$row->project_id, $amount);
		}
		if ($row->type === 'expert_payout') {
			self::_reverse_expert_payout_row($row);
		}

		$orig_kind = (string)($row->voucher_kind ?? '');
		if ($orig_kind === '') $orig_kind = self::voucher_kind_for_type((string)$row->type, (int)$row->direction);
		// reversal keeps same type but opposite direction, status=reversal
		$rev_dir = ((int)$row->direction >= 0) ? -1 : 1;
		$desc = 'برگشت سند ' . ((string)($row->voucher_no ?: ('#'.$row->id)));
		if ($note !== '') $desc .= ' — ' . $note;
		if (!empty($row->description)) $desc .= ' | اصل: ' . $row->description;

		$rev_id = self::ledger_insert([
			'account_id'   => (int)$row->account_id,
			'type'         => (string)$row->type,
			'direction'    => $rev_dir,
			'amount'       => $amount,
			'category_id'  => (int)$row->category_id,
			'project_id'   => (int)$row->project_id,
			'step_id'      => (string)$row->step_id,
			'customer_id'  => (int)$row->customer_id,
			'expert_id'    => (int)$row->expert_id,
			'ref_type'     => 'reversal',
			'ref_id'       => (int)$row->id,
			'linked_id'    => (int)$row->id,
			'voucher_kind' => $orig_kind,
			'status'       => 'reversal',
			'reverses_id'  => (int)$row->id,
			'description'  => $desc,
		]);

		$upd = $wpdb->update(self::tbl_ledger(), [
			'status' => 'reversed',
			'reversed_by' => $rev_id,
		], ['id' => (int)$row->id]);
		// v9.3.0 — اگر به‌روزرسانی پرچم سند اصلی شکست خورد، سند برگشت هم حذف می‌شود
		// تا «اصلِ فعال + برگشت» کنار هم نمانند و اصل سند بی‌صدا دوبار حساب نشود.
		if ($upd === false) {
			$wpdb->delete(self::tbl_ledger(), ['id' => (int)$rev_id]);
			wp_send_json_error('خطا در به‌روزرسانی سند اصلی؛ برگشت اعمال نشد', 500);
		}
		// v9.3.0 — اگر سند از «وصول چک» بود، چک به حالت انتظار برمی‌گردد تا از نو پیگیری شود
		if ((string)$row->ref_type === 'cheque_clear' && (int)$row->ref_id > 0) {
			$wpdb->update(self::tbl_cheques(), ['status'=>'pending','ledger_id'=>0,'updated_at'=>(int)current_time('timestamp', true)], ['id'=>(int)$row->ref_id]);
		}
		if ((int)$row->project_id > 0) self::refresh_project_settlement_flag((int)$row->project_id);

		wp_send_json_success(['reversed'=>true, 'reversal_id'=>$rev_id, 'voucher_no'=> (string)$wpdb->get_var($wpdb->prepare("SELECT voucher_no FROM ".self::tbl_ledger()." WHERE id=%d", $rev_id))]);
	}

	/**
	 * Undo expert step settlement effects for a ledger payout row.
	 * Best-effort: reduces expert_paid for that expert/step and reopens settlement.
	 */
	public static function _reverse_expert_payout_row($row){
		$project_id = (int)($row->project_id ?? 0);
		$step_id = (string)($row->step_id ?? '');
		$expert_id = (int)($row->expert_id ?? 0);
		$amount = (float)($row->amount ?? 0);
		if ($project_id <= 0 || $step_id === '' || $amount <= 0) return false;
		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) return false;
		$found = false;
		foreach ($steps as $i => $st) {
			$sid = isset($st['id']) ? (string)$st['id'] : (string)$i;
			if ($sid !== $step_id) continue;
			$found = true;
			$key = (string)$expert_id;
			if ($expert_id && isset($steps[$i]['expert_settlements'][$key]) && is_array($steps[$i]['expert_settlements'][$key])) {
				$cur = (float)($steps[$i]['expert_settlements'][$key]['expert_paid'] ?? 0);
				$new = max(0, $cur - $amount);
				if ($new <= 0.001) {
					unset($steps[$i]['expert_settlements'][$key]);
					if (empty($steps[$i]['expert_settlements'])) unset($steps[$i]['expert_settlements']);
				} else {
					$steps[$i]['expert_settlements'][$key]['expert_paid'] = $new;
					$steps[$i]['expert_settlements'][$key]['step_settled'] = 0;
					unset($steps[$i]['expert_settlements'][$key]['settle_at'], $steps[$i]['expert_settlements'][$key]['settle_at_fa'], $steps[$i]['expert_settlements'][$key]['admin_received']);
				}
				// recompute mirrors
				$pool = 0.0; $pool_admin = 0.0; $any_open = false;
				if (!empty($steps[$i]['expert_settlements']) && is_array($steps[$i]['expert_settlements'])) {
					foreach ($steps[$i]['expert_settlements'] as $er) {
						if (!is_array($er)) continue;
						$pool += (float)($er['expert_paid'] ?? 0);
						$pool_admin += (float)($er['admin_received'] ?? 0);
						if (empty($er['step_settled'])) $any_open = true;
					}
				} else { $any_open = true; }
				$steps[$i]['expert_paid'] = $pool;
				$steps[$i]['admin_received'] = $pool_admin;
				$steps[$i]['step_settled'] = $any_open ? 0 : 1;
				if ($any_open) unset($steps[$i]['settle_at'], $steps[$i]['settle_at_fa'], $steps[$i]['settled_by']);
			} else {
				// legacy single fields
				$cur = (float)($steps[$i]['expert_paid'] ?? 0);
				$steps[$i]['expert_paid'] = max(0, $cur - $amount);
				$steps[$i]['step_settled'] = 0;
				$steps[$i]['admin_received'] = 0;
				unset($steps[$i]['settle_at'], $steps[$i]['settle_at_fa'], $steps[$i]['settled_by']);
			}
			break;
		}
		if (!$found) return false;
		update_post_meta($project_id, '_cptt_steps', $steps);
		update_post_meta($project_id, '_cptt_is_settled', 0);
		return true;
	}

	/**
	 * v9.2.8 — inverse of _apply_income_to_project(): removes a paid amount
	 * from the project's step ledger, starting with the LAST paid step so
	 * we roll back in reverse order (LIFO).
	 */
	public static function _reverse_income_from_project($project_id, $amount){
		$project_id = (int)$project_id;
		$remaining  = (float)$amount;
		if ($project_id <= 0 || $remaining <= 0) return 0;

		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) return 0;

		$reversed = 0.0;
		// walk backwards (LIFO)
		$keys = array_reverse(array_keys($steps));
		foreach ($keys as $si) {
			if ($remaining <= 0) break;
			$st = $steps[$si];
			// First reverse extra_finance rows on this step (also LIFO)
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				$ekeys = array_reverse(array_keys($st['extra_finance']));
				foreach ($ekeys as $ei) {
					if ($remaining <= 0) break;
					$ep = (float)($st['extra_finance'][$ei]['paid'] ?? 0);
					if ($ep > 0) {
						$take = min($ep, $remaining);
						$steps[$si]['extra_finance'][$ei]['paid'] = $ep - $take;
						$remaining -= $take;
						$reversed  += $take;
					}
				}
			}
			// Then the step's own paid
			$paid = (float)($steps[$si]['paid'] ?? 0);
			if ($remaining > 0 && $paid > 0) {
				$take = min($paid, $remaining);
				$steps[$si]['paid'] = $paid - $take;
				$remaining -= $take;
				$reversed  += $take;
			}
		}
		update_post_meta($project_id, '_cptt_steps', $steps);
		self::refresh_project_settlement_flag($project_id);
		return $reversed;
	}

	/**
	 * v9.2.10 — Receivables ↔ Ledger resync (hard mode).
	 *
	 * Treats the ledger as the single source of truth: for every project,
	 * sets total paid = SUM(income rows with matching project_id), capped
	 * by the project's total cost. Distributes the target amount across
	 * steps in order (step 1 first, then extra_finance rows, then step 2…).
	 *
	 * Any manual `paid` values that were entered before ledger tracking
	 * existed will be overwritten. The user must re-enter them as ledger
	 * transactions if they want them preserved.
	 */
	public function ajax_recv_resync(){
		$this->check_ajax();
		global $wpdb;
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1,'fields'=>'ids']);
		$changed = 0;
		foreach ($projects as $pid) {
			$steps = get_post_meta($pid, '_cptt_steps', true);
			if (!is_array($steps) || empty($steps)) continue;

			// current paid across all steps + extra_finance
			$current_paid = 0.0;
			$capacity     = 0.0;
			foreach ($steps as $st) {
				$current_paid += (float)($st['paid'] ?? 0);
				$capacity     += (float)($st['cost'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) {
						$current_paid += (float)($ef['paid'] ?? 0);
						$capacity     += (float)($ef['cost'] ?? 0);
					}
				}
			}
			// sum of income ledger rows tied to this project
			$ledger_paid = (float) $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(l.amount * l.direction),0) FROM " . self::tbl_ledger() . " l WHERE l.project_id=%d AND l.type='income' AND l.voucher_kind='receipt' AND " . self::sql_active_cond('l') . ",",
				$pid
			));

			$target_total = min($capacity, $ledger_paid);
			if (abs($target_total - $current_paid) < 0.5) continue; // already in sync

			// Reset all paid values, then re-fill in step order up to target_total
			$remaining = $target_total;
			foreach ($steps as $si => $st) {
				$cap_step = (float)($st['cost'] ?? 0);
				if ($cap_step > 0 && $remaining > 0) {
					$take = min($cap_step, $remaining);
					$steps[$si]['paid'] = $take;
					$remaining -= $take;
				} else {
					$steps[$si]['paid'] = 0;
				}
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ei => $ef) {
						$cap_ef = (float)($ef['cost'] ?? 0);
						if ($cap_ef > 0 && $remaining > 0) {
							$take = min($cap_ef, $remaining);
							$steps[$si]['extra_finance'][$ei]['paid'] = $take;
							$remaining -= $take;
						} else {
							$steps[$si]['extra_finance'][$ei]['paid'] = 0;
						}
					}
				}
			}
			update_post_meta($pid, '_cptt_steps', $steps);
			self::refresh_project_settlement_flag($pid);
			$changed++;
		}
		wp_send_json_success(['changed'=>$changed]);
	}

	/**
	 * v9.2.11 — Audit view for receivables page.
	 * Returns every project with cost + meta paid + ledger paid + delta,
	 * so the user can see exactly where mismatches live.
	 */
	public function ajax_recv_audit(){
		$this->check_ajax();
		global $wpdb;
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		$out = [];
		foreach ($projects as $p) {
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			$cost = 0.0; $paid_meta = 0.0;
			if (is_array($steps)) {
				foreach ($steps as $st) {
					$cost      += (float)($st['cost'] ?? 0);
					$paid_meta += (float)($st['paid'] ?? 0);
					if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
						foreach ($st['extra_finance'] as $ef) {
							$cost      += (float)($ef['cost'] ?? 0);
							$paid_meta += (float)($ef['paid'] ?? 0);
						}
					}
				}
			}
			$paid_ledger = (float) $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(l.amount * l.direction),0) FROM " . self::tbl_ledger() . " l WHERE l.project_id=%d AND l.type='income' AND l.voucher_kind='receipt' AND " . self::sql_active_cond('l') . ",",
				$p->ID
			));
			$cid = (int) get_post_meta($p->ID, '_cptt_client_user_id', true);
			$cu  = $cid ? get_user_by('id', $cid) : null;
			$out[] = [
				'id'          => (int)$p->ID,
				'title'       => get_the_title($p),
				'client'      => $cu ? $cu->display_name : '—',
				'cost'        => $cost,
				'paid_meta'   => $paid_meta,
				'paid_ledger' => $paid_ledger,
				'delta'       => $paid_meta - $paid_ledger,
				'remain'      => max(0, $cost - $paid_meta),
				'edit_url'    => get_edit_post_link($p->ID, 'raw'),
			];
		}
		wp_send_json_success(['projects'=>$out]);
	}

	/**
	 * v9.2.11 — Reset ONE project's paid values to match ledger exactly.
	 * Same algorithm as ajax_recv_resync but scoped to a single project.
	 */
	public function ajax_recv_project_reset(){
		$this->check_ajax();
		global $wpdb;
		$pid = (int)($_POST['project_id'] ?? 0);
		if ($pid <= 0) wp_send_json_error('invalid', 400);
		$steps = get_post_meta($pid, '_cptt_steps', true);
		if (!is_array($steps) || empty($steps)) wp_send_json_error('no_steps', 400);

		$capacity = 0.0;
		foreach ($steps as $st) {
			$capacity += (float)($st['cost'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ef) $capacity += (float)($ef['cost'] ?? 0);
			}
		}
		$ledger_paid = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT COALESCE(SUM(l.amount * l.direction),0) FROM " . self::tbl_ledger() . " l WHERE l.project_id=%d AND l.type='income' AND l.voucher_kind='receipt' AND " . self::sql_active_cond('l') . ",",
			$pid
		));
		$target = min($capacity, $ledger_paid);
		$remaining = $target;
		foreach ($steps as $si => $st) {
			$cap_step = (float)($st['cost'] ?? 0);
			if ($cap_step > 0 && $remaining > 0) {
				$take = min($cap_step, $remaining);
				$steps[$si]['paid'] = $take;
				$remaining -= $take;
			} else {
				$steps[$si]['paid'] = 0;
			}
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ei => $ef) {
					$cap_ef = (float)($ef['cost'] ?? 0);
					if ($cap_ef > 0 && $remaining > 0) {
						$take = min($cap_ef, $remaining);
						$steps[$si]['extra_finance'][$ei]['paid'] = $take;
						$remaining -= $take;
					} else {
						$steps[$si]['extra_finance'][$ei]['paid'] = 0;
					}
				}
			}
		}
		update_post_meta($pid, '_cptt_steps', $steps);
		self::refresh_project_settlement_flag($pid);
		wp_send_json_success(['project_id'=>$pid,'new_paid'=>$target]);
	}

	/**
	 * v9.2.12 — Return all ledger income rows for a single project so the
	 * user can inspect / delete duplicates from inside the audit modal.
	 */
	public function ajax_recv_project_ledger(){
		$this->check_ajax();
		global $wpdb;
		$pid = (int)($_POST['project_id'] ?? 0);
		if ($pid <= 0) wp_send_json_error('invalid', 400);
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT id, amount, date_at, date_fa, description, account_id
			 FROM " . self::tbl_ledger() . "
			 WHERE project_id=%d AND type='income'
			 ORDER BY date_at DESC, id DESC",
			$pid
		));
		$out = [];
		foreach ($rows as $r) {
			$acc = self::get_account((int)$r->account_id);
			$out[] = [
				'id'          => (int)$r->id,
				'amount'      => (float)$r->amount,
				'date_fa'     => (string)$r->date_fa,
				'description' => (string)$r->description,
				'account'     => $acc ? ($acc->icon . ' ' . $acc->name) : '—',
			];
		}
		wp_send_json_success(['rows'=>$out]);
	}

	public function ajax_transfer(){
		$this->check_ajax();
		$from = (int)($_POST['from_id'] ?? 0);
		$to   = (int)($_POST['to_id']   ?? 0);
		$amt  = self::parse_amount($_POST['amount'] ?? 0);
		$desc = sanitize_text_field($_POST['description'] ?? '');
		$date_local = sanitize_text_field($_POST['date_local'] ?? '');
		if (!$from || !$to || $from === $to) wp_send_json_error('حساب مبدا و مقصد نامعتبر', 400);
		if ($amt <= 0) wp_send_json_error('مبلغ نامعتبر', 400);
		$ts = self::parse_jalali_local($date_local, true) ?: current_time('timestamp', true);

		$out_id = self::ledger_insert([
			'account_id'=>$from,'type'=>'transfer_out','direction'=>-1,'amount'=>$amt,
			'date_at'=>$ts,'description'=>'انتقال به حساب #'.$to.($desc?(' — '.$desc):'')
		]);
		$in_id = self::ledger_insert([
			'account_id'=>$to,'type'=>'transfer_in','direction'=>1,'amount'=>$amt,
			'date_at'=>$ts,'description'=>'انتقال از حساب #'.$from.($desc?(' — '.$desc):''),
			'linked_id'=>$out_id
		]);
		// Update the OUT row's linked_id to point at the IN row
		global $wpdb;
		$wpdb->update(self::tbl_ledger(), ['linked_id'=>$in_id], ['id'=>$out_id]);
		wp_send_json_success(['ok'=>true]);
	}


	public static function legacy_project_audit(){
		global $wpdb;
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		$out=[]; $tot=['income_delta'=>0,'payout_delta'=>0,'projects'=>0];
		foreach($projects as $p){
			$steps=get_post_meta($p->ID,'_cptt_steps',true); if(!is_array($steps)) continue;
			$cost=0; $paid=0; $expert=0;
			foreach($steps as $st){ if(!is_array($st)) continue; $cost+=(float)($st['cost']??0); $paid+=(float)($st['paid']??0); $expert+=(float)($st['expert_paid']??0); if(!empty($st['extra_finance'])&&is_array($st['extra_finance'])) foreach($st['extra_finance'] as $ef){ if(is_array($ef)){ $cost+=(float)($ef['cost']??0); $paid+=(float)($ef['paid']??0); } } }
			$ledger_income=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(l.direction*l.amount),0) FROM ".self::tbl_ledger()." l WHERE l.project_id=%d AND l.type='income' AND l.voucher_kind='receipt' AND ".self::sql_active_cond('l'),$p->ID));
			$ledger_payout=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN direction<0 THEN amount ELSE -amount END),0) FROM ".self::tbl_ledger()." WHERE project_id=%d AND type='expert_payout'",$p->ID));
			$income_delta=max(0,$paid-$ledger_income); $payout_delta=max(0,$expert-$ledger_payout);
			if($cost||$paid||$expert||$income_delta||$payout_delta){ $tot['projects']++; $tot['income_delta']+=$income_delta; $tot['payout_delta']+=$payout_delta; $out[]=['id'=>$p->ID,'title'=>get_the_title($p),'cost'=>$cost,'paid_meta'=>$paid,'paid_ledger'=>$ledger_income,'income_delta'=>$income_delta,'expert_meta'=>$expert,'expert_ledger'=>$ledger_payout,'payout_delta'=>$payout_delta]; }
		}
		return ['rows'=>$out,'totals'=>$tot];
	}
	public function ajax_legacy_import(){
		$this->check_ajax();
		if(!current_user_can('manage_options')) wp_send_json_error('no_access',403);
		$account_id=(int)($_POST['account_id']??0); $kind=sanitize_key($_POST['kind']??'income');
		if(!$account_id) wp_send_json_error('حساب خزانه را انتخاب کنید.',400);
		$audit=self::legacy_project_audit(); $created=0; $sum=0;
		foreach($audit['rows'] as $r){
			if($kind==='income'){ $amount=(float)$r['income_delta']; if($amount<=0.5) continue; self::ledger_insert(['account_id'=>$account_id,'type'=>'income','direction'=>1,'amount'=>$amount,'project_id'=>(int)$r['id'],'ref_type'=>'legacy_import_income','voucher_kind'=>'receipt','status'=>'posted','description'=>'ورود داده قدیمی: دریافتی‌های ثبت‌شده قبل از دفتر مالی']); }
			elseif($kind==='payout'){ $amount=(float)$r['payout_delta']; if($amount<=0.5) continue; self::ledger_insert(['account_id'=>$account_id,'type'=>'expert_payout','direction'=>-1,'amount'=>$amount,'project_id'=>(int)$r['id'],'ref_type'=>'legacy_import_payout','voucher_kind'=>'payment','status'=>'posted','description'=>'ورود داده قدیمی: تسویه‌های کارشناسان قبل از دفتر مالی']); }
			$created++; $sum+=$amount;
		}
		wp_send_json_success(['created'=>$created,'sum'=>$sum,'audit'=>self::legacy_project_audit()]);
	}

	public function ajax_dashboard_data(){
		$this->check_ajax();
		wp_send_json_success([
			'kpis'    => self::compute_kpis(),
			'monthly' => self::monthly_series(),
		]);
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * Page renderers (loaded from separate template files)
	 * ═══════════════════════════════════════════════════════════════════ */
	private function shell_open($title, $current){
		$tabs = [
			'cptt-finance'                => ['label' => '📊 داشبورد',         'icon' => '📊'],
			'cptt-finance-receivables'    => ['label' => '👥 مطالبات',         'icon' => '👥'],
			'cptt-finance-persons'       => ['label' => '🪪 اشخاص',          'icon' => '🪪'],
			'cptt-finance-invoices'      => ['label' => '🧾 فاکتورها',        'icon' => '🧾'], // v9.2.56
			'cptt-finance-cheques'       => ['label' => '🏦 چک‌ها',           'icon' => '🏦'], // v9.3.0
			'cptt-finance-reports'       => ['label' => '📈 گزارشات',         'icon' => '📈'], // v9.3.0
			'cptt-finance-payouts'        => ['label' => '💼 تسویه‌ها',         'icon' => '💼'],
			'cptt-finance-transactions'   => ['label' => '💸 درآمد/هزینه',      'icon' => '💸'],
			'cptt-finance-treasury'       => ['label' => '🏦 خزانه',           'icon' => '🏦'],
			'cptt-finance-ledger'         => ['label' => '📑 گردش حساب',       'icon' => '📑'],
			'cptt-finance-classic'        => ['label' => '📒 حساب پروژه‌ها',    'icon' => '📒'],
			'cptt-finance-sync'           => ['label' => '🧩 همگام‌سازی',      'icon' => '🧩'],
			'cptt-finance-categories'     => ['label' => '🏷 دسته‌ها',          'icon' => '🏷'],
		];
		?>
		<div class="cpttf-app" dir="rtl">
			<header class="cpttf-app__topbar">
				<div class="cpttf-app__brand">
					<span class="cpttf-app__brand-mark">💰</span>
					<div>
						<strong>مالی هماهنگ</strong>
						<small><?php echo esc_html($title); ?></small>
					</div>
				</div>
				<nav class="cpttf-app__nav">
					<?php foreach ($tabs as $slug => $info): ?>
						<a class="cpttf-app__tab <?php echo $slug === $current ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=' . $slug)); ?>"><?php echo esc_html($info['label']); ?></a>
					<?php endforeach; ?>
				</nav>
			</header>
			<main class="cpttf-app__main">
		<?php
	}
	private function shell_close(){
		?>
			</main>
		</div>
		<?php
	}

	public function render_dashboard_page(){
		require_once CPTT_PATH . 'includes/finance/page-dashboard.php';
		$this->shell_open('داشبورد مالی', 'cptt-finance');
		cpttf_render_dashboard();
		$this->shell_close();
	}
	public function render_receivables_page(){
		require_once CPTT_PATH . 'includes/finance/page-receivables.php';
		$this->shell_open('مطالبات مشتریان', 'cptt-finance-receivables');
		cpttf_render_receivables();
		$this->shell_close();
	}
	/** v9.2.53 — صفحه‌ی «اشخاص»: تراز حساب با هر مشتری/کارشناس/شخص */
	public function render_persons_page(){
		require_once CPTT_PATH . 'includes/finance/page-persons.php';
		$this->shell_open('اشخاص (طرف‌های حساب)', 'cptt-finance-persons');
		cpttf_render_persons();
		$this->shell_close();
	}
	public function render_invoices_page(){
		require_once CPTT_PATH . 'includes/finance/page-invoices.php';
		$this->shell_open('فاکتورها', 'cptt-finance-invoices');
		if (function_exists('cpttf_render_invoices')) cpttf_render_invoices();
		$this->shell_close();
	}
	/** v9.3.0 — اسناد و چک‌ها (فاز ۳) */
	public function render_cheques_page(){
		require_once CPTT_PATH . 'includes/finance/page-cheques.php';
		$this->shell_open('اسناد و چک‌ها', 'cptt-finance-cheques');
		if (function_exists('cpttf_render_cheques')) cpttf_render_cheques();
		$this->shell_close();
	}
	/** v9.3.0 — مرکز گزارشات + گزارش سنی مطالبات (فاز ۳) */
	public function render_reports_page(){
		require_once CPTT_PATH . 'includes/finance/page-reports.php';
		$this->shell_open('مرکز گزارشات', 'cptt-finance-reports');
		if (function_exists('cpttf_render_reports')) cpttf_render_reports();
		$this->shell_close();
	}

	public function render_payouts_page(){
		require_once CPTT_PATH . 'includes/finance/page-payouts.php';
		$this->shell_open('تسویه کارشناسان', 'cptt-finance-payouts');
		cpttf_render_payouts();
		$this->shell_close();
	}
	public function render_transactions_page(){
		require_once CPTT_PATH . 'includes/finance/page-transactions.php';
		$this->shell_open('درآمد و هزینه', 'cptt-finance-transactions');
		cpttf_render_transactions();
		$this->shell_close();
	}
	public function render_treasury_page(){
		require_once CPTT_PATH . 'includes/finance/page-treasury.php';
		$this->shell_open('خزانه‌داری', 'cptt-finance-treasury');
		cpttf_render_treasury();
		$this->shell_close();
	}
	public function render_categories_page(){
		require_once CPTT_PATH . 'includes/finance/page-categories.php';
		$this->shell_open('دسته‌بندی‌های مالی', 'cptt-finance-categories');
		cpttf_render_categories();
		$this->shell_close();
	}
	public function render_ledger_page(){
		require_once CPTT_PATH . 'includes/finance/page-ledger.php';
		$this->shell_open('گردش حساب', 'cptt-finance-ledger');
		cpttf_render_ledger();
		$this->shell_close();
	}

	/** v9.2.24 — layout fixes when classic accounting is embedded in finance shell */
	public static function classic_host_css(){
		return '
/* host resets */
.cpttf-classic-host{padding:0!important;overflow:visible!important;}
.cpttf-classic-host .wrap.cptt-dashboard.cptt-accounting{margin:0!important;padding:8px 4px 20px!important;background:transparent!important;max-width:100%!important;}
.cpttf-classic-host .cptt-dashboard__hero{display:none!important;}

/* KPI cards: force proper grid + readable values */
.cpttf-classic-host .cptt-acct-kpi-grid{
  display:grid!important;
  grid-template-columns:repeat(auto-fit,minmax(180px,1fr))!important;
  gap:12px!important;
  margin:0 0 16px!important;
  width:100%!important;
}
.cpttf-classic-host .cptt-acct-kpi{
  display:flex!important;
  flex-direction:row!important;
  align-items:center!important;
  gap:12px!important;
  background:#fff!important;
  border:1px solid #e5e7eb!important;
  border-radius:16px!important;
  padding:14px!important;
  box-shadow:0 8px 20px rgba(15,23,42,.05)!important;
  min-height:84px!important;
  width:auto!important;
  max-width:none!important;
  float:none!important;
}
.cpttf-classic-host .cptt-acct-kpi__icon{
  width:44px!important;height:44px!important;border-radius:12px!important;
  display:flex!important;align-items:center!important;justify-content:center!important;
  font-size:20px!important;flex:0 0 44px!important;
}
.cpttf-classic-host .cptt-acct-kpi__body{flex:1 1 auto!important;min-width:0!important;}
.cpttf-classic-host .cptt-acct-kpi__label{font-size:12px!important;font-weight:800!important;color:#64748b!important;margin:0 0 4px!important;line-height:1.3!important;}
.cpttf-classic-host .cptt-acct-kpi__value{font-size:20px!important;font-weight:950!important;color:#0f172a!important;line-height:1.15!important;word-break:break-word!important;}
.cpttf-classic-host .cptt-acct-kpi__body small{display:block!important;margin-top:2px!important;color:#94a3b8!important;font-size:11px!important;}

/* charts + filters */
.cpttf-classic-host .cptt-finance-pro-panel{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))!important;gap:12px!important;margin:0 0 16px!important;}
.cpttf-classic-host .cptt-acct-filters,
.cpttf-classic-host .cptt-acct-filters--sticky{
  display:flex!important;flex-wrap:wrap!important;gap:10px!important;align-items:flex-end!important;
  position:static!important;top:auto!important;background:#fff!important;border:1px solid #e5e7eb!important;
  border-radius:14px!important;padding:12px!important;margin:0 0 14px!important;
}
.cpttf-classic-host .cptt-acct-filters label{display:flex!important;flex-direction:column!important;gap:4px!important;min-width:130px!important;flex:1 1 140px!important;font-size:12px!important;font-weight:800!important;color:#334155!important;}
.cpttf-classic-host .cptt-acct-filters input,
.cpttf-classic-host .cptt-acct-filters select{width:100%!important;min-height:36px!important;box-sizing:border-box!important;}
.cpttf-classic-host .cptt-acct-filters .button{height:36px!important;align-self:flex-end!important;}

/* table */
.cpttf-classic-host .cptt-acct-table-wrap{overflow-x:auto!important;border:1px solid #e5e7eb!important;border-radius:14px!important;background:#fff!important;}
.cpttf-classic-host .cptt-acct-table{width:100%!important;border-collapse:collapse!important;}
.cpttf-classic-host .cptt-acct-table th{position:static!important;top:auto!important;}

@media (max-width:782px){
  .cpttf-classic-host .cptt-acct-kpi-grid{grid-template-columns:1fr 1fr!important;}
  .cpttf-classic-host .cptt-acct-filters label{min-width:100%!important;}
}
@media (max-width:520px){
  .cpttf-classic-host .cptt-acct-kpi-grid{grid-template-columns:1fr!important;}
}
';
	}

	public function render_classic_accounting_page(){
		require_once CPTT_PATH . 'includes/finance/page-project-accounts.php';
		$this->shell_open('حساب پروژه‌ها', 'cptt-finance-classic');
		cpttf_render_project_accounts();
		$this->shell_close();
	}
	public function render_sync_page(){
		require_once CPTT_PATH . 'includes/finance/page-sync.php';
		$this->shell_open('همگام‌سازی داده‌های قدیمی', 'cptt-finance-sync');
		cpttf_render_sync_page();
		$this->shell_close();
	}


	/* ═══════════════════════════════════════════════════════════════════
	 * Small parsing helpers
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function parse_amount($v){
		if (class_exists('CPTT_Currency')) return (float) CPTT_Currency::parse_input($v);
		$v = (string)$v;
		$v = preg_replace('/[^\d.\-]/', '', str_replace(',', '', $v));
		return (float)$v;
	}
	/**
	 * v9.2.53 — تبدیل «تاریخ/ساعت محلی شمسی» به timestamp واقعی.
	 *
	 * علت ریشه‌ای باگ «ساعت سند اشتباه (مثلاً ۳:۳۰)»: نسخه‌ی قبلی با
	 * mktime() در منطقه‌ی زمانی UTC پارس می‌کرد، ولی هنگام نمایش،
	 * CPTT_Core::jalali_datetime همان timestamp را به آسیا/تهران تبدیل
	 * می‌کرد؛ در نتیجه هر سند +۳:۳۰ ساعت جابه‌جا می‌شد و اگر کاربر فقط
	 * تاریخ را انتخاب می‌کرد (بدون ساعت)، ساعت ۰۰:۰۰ UTC ثبت و روی صفحه
	 * «۰۳:۳۰» نمایش داده می‌شد.
	 *
	 * رفتار جدید:
	 *  - تاریخ/ساعت ورودی «به وقت تهران» تفسیر می‌شود (همان چیزی که کاربر
	 *    روی صفحه می‌بیند).
	 *  - اگر $no_time_means_now=true باشد و کاربر فقط تاریخ داده باشد،
	 *    ساعتِ لحظه‌ی ثبت به‌جای ۰۰:۰۰ استفاده می‌شود (ثبت سند در همان لحظه).
	 */
	public static function parse_jalali_local($s, $no_time_means_now = false){
		$s = trim((string)$s);
		if ($s === '') return 0;
		// تبدیل ارقام فارسی/عربی به لاتین
		$s = strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
		$has_time = (bool) preg_match('#\\d{1,2}\\s*:\\s*\\d{1,2}#', $s);
		// فقط تاریخ → ساعت فعلی (وقتی فراخواننده خواسته باشد)
		if ($no_time_means_now && !$has_time && preg_match('#^\\d{4}[/\\-]\\d{1,2}[/\\-]\\d{1,2}$#', $s)) {
			try { $nowTz = new DateTime('now', new DateTimeZone('Asia/Tehran')); $s .= ' ' . $nowTz->format('H:i'); }
			catch (Exception $e) { /* fallback below */ }
		}
		// قانونی پارس — تفسیر به وقت تهران (canonical از CPTT_Core)
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'parse_jalali_datetime')) {
			$ts = CPTT_Core::parse_jalali_datetime($s);
			if ($ts) return (int) $ts;
		}
		if (preg_match('#^(\\d{4})[/\\-\\.](\\d{1,2})[/\\-\\.](\\d{1,2})(?:[ T](\\d{1,2}):(\\d{1,2}))?$#', $s, $m)) {
			$jy = (int)$m[1]; $jm = (int)$m[2]; $jd = (int)$m[3];
			$h = isset($m[4]) ? (int)$m[4] : 0; $mi = isset($m[5]) ? (int)$m[5] : 0;
			if ($no_time_means_now && !$has_time && $h === 0 && $mi === 0) {
				try { $nowTz = new DateTime('now', new DateTimeZone('Asia/Tehran')); $h = (int)$nowTz->format('G'); $mi = (int)$nowTz->format('i'); }
				catch (Exception $e) { /* keep 0:0 */ }
			}
			if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'jalali_to_gregorian')) {
				$g = CPTT_Core::jalali_to_gregorian($jy, $jm, $jd);
				if (is_array($g) && count($g) === 3) {
					try {
						$dt = new DateTime('now', new DateTimeZone('Asia/Tehran'));
						$dt->setDate((int)$g[0], (int)$g[1], (int)$g[2]);
						$dt->setTime($h, $mi, 0);
						return (int) $dt->getTimestamp();
					} catch (Exception $e) {
						return mktime($h, $mi, 0, $g[1], $g[2], $g[0]);
					}
				}
			}
			// rough fallback
			return strtotime("$jy-$jm-$jd $h:$mi");
		}
		return (int) strtotime($s);
	}

	/**
	 * v9.2.53 — فهرست اشخاص (مشتری/کارشناس/مدیر) برای کمبوباکس و مدال‌ها.
	 * هر آیتم: id, name, tag, phone, label
	 */
	public static function get_person_options_list(){
		$users = get_users([
			'role__in' => ['customer','subscriber','cptt_expert','administrator'],
			'orderby' => 'display_name',
			'order' => 'ASC',
			'number' => 800,
		]);
		$out = [];
		foreach ($users as $u) {
			$roles = (array)$u->roles;
			$tag = in_array('cptt_expert', $roles, true) ? 'کارشناس' : (in_array('administrator', $roles, true) ? 'مدیر' : 'مشتری');
			$phone = (string)get_user_meta($u->ID, 'billing_phone', true);
			if ($phone === '') $phone = (string)get_user_meta($u->ID, 'cptt_phone', true);
			if ($phone === '') $phone = (string)get_user_meta($u->ID, 'mobile', true);
			$out[] = [
				'id'    => (int)$u->ID,
				'name'  => (string)$u->display_name,
				'tag'   => $tag,
				'phone' => $phone,
				'label' => $u->display_name . ' · ' . $tag . ($phone ? (' · ' . $phone) : ''),
			];
		}
		return $out;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * v9.2.55 — پروفایل «طرف حساب» (Party profile)
	 * هر شخص یک کاربر وردپرس است؛ اطلاعات تکمیلی در user_meta نگه‌داری می‌شود
	 * تا لینک‌بندی موجود (پروژه‌ها و دفتر مالی) هیچ تغییری نکند.
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function get_party_profile($uid){
		$uid = (int)$uid;
		$u = get_user_by('id', $uid);
		$roles_json = (string)get_user_meta($uid, 'cptt_party_roles', true);
		$roles = $roles_json !== '' ? json_decode($roles_json, true) : [];
		if (!is_array($roles)) $roles = [];
		// نقش‌های مشتق‌شده از سیستم (اگر دستی خالی بود)
		if (empty($roles) && $u) {
			$roles = [];
			global $wpdb;
			$has_proj = false;
			foreach ((array)$u->roles as $r) { if ($r === 'cptt_expert') $roles[] = 'کارشناس'; }
			if (!in_array('کارشناس', $roles, true)) {
				// مشتری پروژه دارد؟
				$posts = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>1,'meta_key'=>'_cptt_client_user_id','meta_value'=>$uid]);
				if ($posts) $roles[] = 'مشتری';
			}
			if (empty($roles)) $roles[] = 'سایر';
		}
		$tags_json = (string)get_user_meta($uid, 'cptt_party_tags', true);
		$tags = $tags_json !== '' ? json_decode($tags_json, true) : [];
		if (!is_array($tags)) $tags = [];
		$phone = (string)get_user_meta($uid, 'billing_phone', true);
		if ($phone === '') $phone = (string)get_user_meta($uid, 'cptt_phone', true);
		if ($phone === '') $phone = (string)get_user_meta($uid, 'mobile', true);
		$created_by = (int)get_user_meta($uid, 'cptt_party_created_by', true);
		$created_by_name = '';
		if ($created_by) { $cu = get_user_by('id', $created_by); if ($cu) $created_by_name = $cu->display_name; }
		return [
			'type'      => get_user_meta($uid, 'cptt_party_type', true) === 'legal' ? 'legal' : 'real',
			'code'      => (string)(get_user_meta($uid, 'cptt_party_code', true) ?: ('PRS-' . $uid)),
			'phone'     => $phone,
			'address'   => (string)get_user_meta($uid, 'cptt_party_address', true),
			'bank'      => (string)get_user_meta($uid, 'cptt_party_bank', true),
			'bank_account' => (string)get_user_meta($uid, 'cptt_party_bank_account', true),
			'iban'      => (string)get_user_meta($uid, 'cptt_party_iban', true),
			'card'      => (string)get_user_meta($uid, 'cptt_party_card', true),
			'roles'     => array_values(array_filter(array_map('sanitize_text_field', $roles))),
			'tags'      => array_values(array_filter(array_map('sanitize_text_field', $tags))),
			'note'      => (string)get_user_meta($uid, 'cptt_party_note', true),
			'active'    => (int)(get_user_meta($uid, 'cptt_party_active', true) !== '' ? get_user_meta($uid, 'cptt_party_active', true) : 1),
			'created_by_name' => $created_by_name,
			'np_in'     => 0.0, // پرکننده: محاسبه در page-persons
			'np_out'    => 0.0,
		];
	}

	/** ذخیره‌ی پروفایل طرف‌حساب (ویرایش یا ساخت شخص جدید) */
	public function ajax_person_save(){
		$this->check_ajax();
		$uid = (int)($_POST['user_id'] ?? 0);
		$is_new = !empty($_POST['new_person']);
		if ($is_new) {
			$name = sanitize_text_field((string)($_POST['name'] ?? ''));
			if ($name === '') wp_send_json_error('نام الزامی است', 400);
			$login = 'party_' . time() . wp_rand(100, 999);
			$email = $login . '@party.local';
			$uid = wp_insert_user([
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => wp_generate_password(24, true, true),
				'display_name' => $name,
				'role'         => 'customer',
			]);
			if (is_wp_error($uid)) wp_send_json_error($uid->get_error_message(), 400);
			update_user_meta($uid, 'cptt_party_created_by', (int)get_current_user_id());
		}
		if (!$uid || !get_user_by('id', $uid)) wp_send_json_error('person_not_found', 404);

		$phone = sanitize_text_field((string)($_POST['phone'] ?? ''));
		if ($phone !== '') {
			$phone = strtr($phone, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
			update_user_meta($uid, 'billing_phone', $phone);
			update_user_meta($uid, 'cptt_phone', $phone);
		}
		if (!$is_new && isset($_POST['display_name'])) {
			$dn = sanitize_text_field((string)$_POST['display_name']);
			if ($dn !== '') wp_update_user(['ID' => $uid, 'display_name' => $dn]);
		}
		$type = ($_POST['type'] ?? '') === 'legal' ? 'legal' : 'real';
		update_user_meta($uid, 'cptt_party_type', $type);
		$code = sanitize_text_field((string)($_POST['code'] ?? ''));
		if ($code === '') $code = 'PRS-' . $uid;
		update_user_meta($uid, 'cptt_party_code', $code);
		if (isset($_POST['address']))      update_user_meta($uid, 'cptt_party_address', sanitize_text_field((string)$_POST['address']));
		if (isset($_POST['bank']))         update_user_meta($uid, 'cptt_party_bank', sanitize_text_field((string)$_POST['bank']));
		if (isset($_POST['bank_account'])) update_user_meta($uid, 'cptt_party_bank_account', sanitize_text_field((string)$_POST['bank_account']));
		if (isset($_POST['iban']))         update_user_meta($uid, 'cptt_party_iban', sanitize_text_field((string)$_POST['iban']));
		if (isset($_POST['card']))         update_user_meta($uid, 'cptt_party_card', sanitize_text_field((string)$_POST['card']));
		if (isset($_POST['note']))         update_user_meta($uid, 'cptt_party_note', sanitize_textarea_field((string)$_POST['note']));
		if (isset($_POST['active']))       update_user_meta($uid, 'cptt_party_active', (int)$_POST['active'] ? 1 : 0);
		// نقش‌ها (چندگانه)
		$roles = isset($_POST['roles']) && is_array($_POST['roles']) ? array_map('sanitize_text_field', wp_unslash($_POST['roles'])) : [];
		$roles = array_values(array_unique(array_filter($roles)));
		update_user_meta($uid, 'cptt_party_roles', wp_json_encode($roles, JSON_UNESCAPED_UNICODE));
		// برچسب‌ها (با ویرگول فارسی/لاتین)
		if (isset($_POST['tags'])) {
			$raw = str_replace(['،', ';'], ',', (string)wp_unslash($_POST['tags']));
			$tags = array_values(array_filter(array_map(function($t){ return sanitize_text_field(trim($t)); }, explode(',', $raw))));
			update_user_meta($uid, 'cptt_party_tags', wp_json_encode($tags, JSON_UNESCAPED_UNICODE));
		}
		if (!get_user_meta($uid, 'cptt_party_created_by', true)) update_user_meta($uid, 'cptt_party_created_by', (int)get_current_user_id());
		wp_send_json_success(['user_id' => $uid]);
	}

	/** خروجی «چاپ/CSV صورتحساب» — باید قبل از هر خروجی HTML اجرا شود */
	/* ═══════════════════════════════════════════════════════════════════
	 * v9.2.56 — AJAX فاکتورها
	 * ═══════════════════════════════════════════════════════════════════ */
	public function ajax_invoice_save(){
		$this->check_ajax();
		global $wpdb;
		$id        = (int)($_POST['id'] ?? 0);
		$kind      = sanitize_key((string)($_POST['kind'] ?? ''));
		$vocab     = self::invoice_kind_vocab();
		if (!isset($vocab[$kind])) wp_send_json_error('نوع فاکتور نامعتبر است', 400);
		$person_id = (int)($_POST['person_id'] ?? 0);
		if ($person_id <= 0 || !get_user_by('id', $person_id)) wp_send_json_error('انتخاب شخص الزامی است', 400);
		$project_id = (int)($_POST['project_id'] ?? 0);
		if ($project_id > 0 && get_post_type($project_id) !== 'cptt_project') wp_send_json_error('پروژه نامعتبر است', 400);
		$amount    = self::parse_amount($_POST['amount'] ?? 0);
		if ($amount <= 0) wp_send_json_error('مبلغ فاکتور نامعتبر است', 400);
		$status    = sanitize_key((string)($_POST['status'] ?? 'issued'));
		if (!in_array($status, ['draft','issued'], true)) $status = 'issued';
		$issue_in  = sanitize_text_field((string)($_POST['issue_date'] ?? ''));
		$due_in    = sanitize_text_field((string)($_POST['due_date'] ?? ''));
		$issue_ts  = $issue_in !== '' ? self::parse_jalali_local($issue_in) : 0;
		$due_ts    = $due_in !== '' ? self::parse_jalali_local($due_in . ' 23:59') : 0;
		$note      = sanitize_textarea_field((string)($_POST['note'] ?? ''));
		$now       = (int)current_time('timestamp', true);

		if ($id > 0) {
			$inv = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_invoices() . " WHERE id=%d", $id));
			if (!$inv) wp_send_json_error('فاکتور یافت نشد', 404);
			if ((string)$inv->status === 'cancelled') wp_send_json_error('فاکتور باطل قابل ویرایش نیست', 400);
			$wpdb->update(self::tbl_invoices(), [
				'kind'=>$kind,'person_id'=>$person_id,'project_id'=>$project_id,'amount'=>$amount,
				'issue_ts'=>($issue_ts ?: (int)$inv->issue_ts),'due_ts'=>$due_ts,'note'=>$note,'updated_at'=>$now,
			], ['id'=>$id]);
			self::invoice_recalc($id);
			wp_send_json_success(['saved'=>true,'id'=>$id,'invoice_no'=>(string)$inv->invoice_no,'msg'=>'فاکتور ' . $inv->invoice_no . ' به‌روزرسانی شد']);
		}

		$no = self::next_invoice_no();
		$wpdb->insert(self::tbl_invoices(), [
			'invoice_no'=>$no,'kind'=>$kind,'person_id'=>$person_id,'project_id'=>$project_id,
			'issue_ts'=>($issue_ts ?: $now),'due_ts'=>$due_ts,'amount'=>$amount,'settled'=>0.0,
			'status'=>$status,'note'=>$note,'created_by'=>(int)get_current_user_id(),'created_at'=>$now,'updated_at'=>$now,
		]);
		$iid = (int)$wpdb->insert_id;
		if ($iid <= 0) wp_send_json_error('خطا در ذخیره فاکتور', 500);
		wp_send_json_success(['saved'=>true,'id'=>$iid,'invoice_no'=>$no,'msg'=>'فاکتور ' . $no . ' صادر شد']);
	}

	/** تسویه‌ی تخصیصی: یک سند دریافت/پرداخت + تخصیص مبلغ به یک یا چند فاکتور باز */
	public function ajax_invoice_settle(){
		$this->check_ajax();
		global $wpdb;
		$t_inv = self::tbl_invoices(); $t_al = self::tbl_invoice_allocs();
		$allocs_in = isset($_POST['alloc']) && is_array($_POST['alloc']) ? wp_unslash($_POST['alloc']) : [];
		$clean = [];
		foreach ($allocs_in as $iid => $amt) {
			$iid = (int)$iid; $amt = self::parse_amount($amt);
			if ($iid > 0 && $amt > 0.004) $clean[$iid] = (isset($clean[$iid]) ? $clean[$iid] : 0.0) + $amt;
		}
		if (empty($clean)) wp_send_json_error('مبلغی برای تخصیص وارد نشده است', 400);
		$ids = array_map('intval', array_keys($clean));
		$in  = implode(',', $ids);
		$rows = $wpdb->get_results("SELECT * FROM $t_inv WHERE id IN ($in)");
		if (!$rows || count($rows) !== count($ids)) wp_send_json_error('برخی فاکتورها یافت نشد', 404);
		$person = 0; $dir = ''; $total = 0.0; $projects = []; $nos = [];
		foreach ($rows as $inv) {
			if ((string)$inv->status === 'cancelled') wp_send_json_error('فاکتور ' . $inv->invoice_no . ' باطل است', 400);
			if ((string)$inv->status === 'draft') wp_send_json_error('فاکتور ' . $inv->invoice_no . ' پیش‌نویس است؛ ابتدا صادرش کنید', 400);
			if ((string)$inv->status === 'settled') wp_send_json_error('فاکتور ' . $inv->invoice_no . ' قبلاً تسویه شده است', 400);
			$d = self::invoice_settle_dir((string)$inv->kind);
			if ($dir === '') $dir = $d;
			if ($d !== $dir) wp_send_json_error('جهت تسویه فاکتورهای انتخابی یکسان نیست (دریافت و پرداخت قابل ترکیب نیستند)', 400);
			if ($person === 0) $person = (int)$inv->person_id;
			if ((int)$inv->person_id !== $person) wp_send_json_error('همه‌ی فاکتورها باید متعلق به یک شخص باشند', 400);
			$remain = (float)$inv->amount - (float)$inv->settled;
			$amt = (float)$clean[(int)$inv->id];
			if ($amt > $remain + 0.5) wp_send_json_error('مبلغ تخصیص فاکتور ' . $inv->invoice_no . ' بیشتر از مانده‌ی آن است', 400);
			$total += $amt; $nos[] = (string)$inv->invoice_no;
			if ((int)$inv->project_id > 0) $projects[(int)$inv->project_id] = true;
		}
		if ($total <= 0.004) wp_send_json_error('مبلغ تسویه نامعتبر است', 400);
		$account_id = (int)($_POST['account_id'] ?? 0);
		if (!$account_id) $account_id = self::default_cash_account_id();
		if (!$account_id) wp_send_json_error('حساب خزانه‌ی فعالی یافت نشد؛ ابتدا در خزانه‌داری حساب بسازید', 400);
		$date_local = sanitize_text_field((string)($_POST['date_local'] ?? ''));
		$date_at = self::parse_jalali_local($date_local, true) ?: current_time('timestamp', true);
		$note = sanitize_textarea_field((string)($_POST['description'] ?? ''));
		$desc = 'تسویه فاکتور: ' . implode('، ', $nos) . ($note !== '' ? ' — ' . $note : '');
		$customer_id = 0; $expert_id = 0;
		$pu = get_user_by('id', $person);
		if ($pu && (in_array('cptt_expert', (array)$pu->roles, true) || in_array('administrator', (array)$pu->roles, true))) $expert_id = $person; else $customer_id = $person;
		$pkeys = array_keys($projects);
		$project_id = count($pkeys) === 1 ? (int)$pkeys[0] : 0;
		$is_receipt = $dir === 'receipt';
		$ledger_id = self::ledger_insert([
			'account_id'=>$account_id,
			'type'=> $is_receipt ? 'income' : 'expense',
			'direction'=> $is_receipt ? 1 : -1,
			'amount'=>$total,
			'project_id'=>$project_id,
			'customer_id'=>$customer_id, 'expert_id'=>$expert_id,
			'ref_type'=>'invoice_settle',
			'voucher_kind'=> $is_receipt ? 'receipt' : 'payment',
			'status'=>'posted',
			'date_at'=>$date_at,
			'description'=>$desc,
		]);
		if ($ledger_id <= 0) wp_send_json_error('ثبت سند تسویه ناموفق بود', 500);
		$now = (int)current_time('timestamp', true);
		foreach ($rows as $inv) {
			$amt = (float)$clean[(int)$inv->id];
			$wpdb->insert($t_al, [
				'invoice_id'=>(int)$inv->id,'ledger_id'=>$ledger_id,'amount'=>$amt,
				'created_by'=>(int)get_current_user_id(),'created_at'=>$now,
			]);
			self::invoice_recalc((int)$inv->id);
		}
		// اگر کل تسویه متعلق به یک پروژه بود، مراحل/مانده‌ی پروژه هم همگام شود
		if ($project_id > 0 && class_exists('CPTT_Expert') && method_exists('CPTT_Expert','rebalance_project_public')) {
			CPTT_Expert::rebalance_project_public($project_id);
		}
		wp_send_json_success(['settled'=>true,'ledger_id'=>$ledger_id,'total'=>$total,'msg'=>'سند تسویه ' . number_format($total) . ' ثبت و به ' . count($rows) . ' فاکتور تخصیص یافت']);
	}

	public function ajax_invoice_cancel(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$inv = $id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_invoices() . " WHERE id=%d", $id)) : null;
		if (!$inv) wp_send_json_error('فاکتور یافت نشد', 404);
		if ((string)$inv->status === 'cancelled') wp_send_json_error('این فاکتور قبلاً باطل شده است', 400);
		$n = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . self::tbl_invoice_allocs() . " WHERE invoice_id=%d", $id));
		if ($n > 0) wp_send_json_error('برای این فاکتور تخصیص ثبت شده؛ ابتدا تخصیص‌ها را حذف کنید', 400);
		$wpdb->update(self::tbl_invoices(), ['status'=>'cancelled','updated_at'=>(int)current_time('timestamp', true)], ['id'=>$id]);
		wp_send_json_success(['cancelled'=>true,'msg'=>'فاکتور ' . $inv->invoice_no . ' باطل شد']);
	}

	public function ajax_invoice_alloc_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$al = $id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_invoice_allocs() . " WHERE id=%d", $id)) : null;
		if (!$al) wp_send_json_error('تخصیص یافت نشد', 404);
		$inv = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_invoices() . " WHERE id=%d", (int)$al->invoice_id));
		if ($inv && (string)$inv->status === 'cancelled') wp_send_json_error('فاکتور باطل است', 400);
		$wpdb->delete(self::tbl_invoice_allocs(), ['id'=>$id]);
		if ($inv) self::invoice_recalc((int)$inv->id);
		wp_send_json_success(['deleted'=>true,'msg'=>'تخصیص حذف شد؛ سند مالی همچنان در دفتر باقی است']);
	}

	/** v9.2.56 — انتساب سند «بدون پروژه» به یک پروژه (اصلاح داده بدون خرابی حساب‌ها) */
	public function ajax_voucher_assign(){
		$this->check_ajax();
		global $wpdb;
		$ledger_id  = (int)($_POST['id'] ?? 0);
		$project_id = (int)($_POST['project_id'] ?? 0);
		$row = $ledger_id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $ledger_id)) : null;
		if (!$row) wp_send_json_error('سند یافت نشد', 404);
		if ((string)($row->status ?: 'posted') !== 'posted') wp_send_json_error('فقط سند فعال قابل انتساب است', 400);
		if ((int)$row->project_id > 0) wp_send_json_error('این سند از قبل به پروژه پیوند دارد', 400);
		if ($project_id <= 0 || get_post_type($project_id) !== 'cptt_project') wp_send_json_error('پروژه نامعتبر است', 400);
		if (!in_array((string)$row->type, ['income','expense'], true)) wp_send_json_error('این نوع سند قابل انتساب نیست', 400);
		$wpdb->update(self::tbl_ledger(), ['project_id'=>$project_id], ['id'=>$ledger_id]);
		if ((string)$row->type === 'income' && class_exists('CPTT_Expert') && method_exists('CPTT_Expert','rebalance_project_public')) {
			CPTT_Expert::rebalance_project_public($project_id);
		}
		$pt = get_the_title($project_id) ?: ('#' . $project_id);
		$desc = (string)$row->description;
		$tag = ' [انتساب دستی به پروژه «' . $pt . '»]';
		if (mb_strpos($desc, '[انتساب دستی به پروژه') === false) {
			$wpdb->update(self::tbl_ledger(), ['description'=>$desc . $tag], ['id'=>$ledger_id]);
		}
		wp_send_json_success(['assigned'=>true,'msg'=>'سند به پروژه «' . $pt . '» پیوند خورد']);
	}

	public function maybe_person_statement_output(){
		if (!is_admin()) return;
		$page = isset($_GET['page']) ? (string)$_GET['page'] : '';
		if ($page !== 'cptt-finance-persons') return;
		$mode = isset($_GET['stmt']) ? sanitize_key($_GET['stmt']) : '';
		if ($mode === '') return;
		if (!is_user_logged_in() || !current_user_can('edit_cptt_projects')) return;
		$pid = (int)($_GET['pid'] ?? 0);
		if (!$pid) return;
		require_once CPTT_PATH . 'includes/finance/page-person.php';
		if ($mode === 'csv') cpttf_person_statement_csv($pid);
		elseif ($mode === 'print') cpttf_person_statement_print($pid);
	}
}
