plugins {
    // AGP 8.6.1 حداقل نسخه‌ای است که رسماً با compileSdk 35 تست شده.
    // (با AGP 8.5.2 هشدار "tested up to compileSdk 34" می‌گرفتیم.)
    // AGP 8.6.x نیازمند Gradle 8.7+ است که در wrapper تنظیم شده.
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.kapt") version "1.9.24" apply false
}
