import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

// اگر فایل keystore.properties وجود داشته باشد، APK ریلیز امضا می‌شود.
// اگر نباشد، فقط debug قابل ساخت است (که برای استفاده‌ی شخصی کافی است).
val keystorePropertiesFile = rootProject.file("keystore.properties")
val hasKeystore = keystorePropertiesFile.exists()
val keystoreProperties = Properties().apply {
    if (hasKeystore) load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "ir.arena.companion"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.arena.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        if (hasKeystore) {
            create("release") {
                storeFile = rootProject.file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasKeystore) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            isMinifyEnabled = false
            // تا بتوانی هم‌زمان با نسخه‌ی ریلیز نصبش کنی
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

// محافظ: اگر کتابخانه‌ای به‌طور غیرمستقیم kotlin-stdlib جدیدتر بیاورد،
// آن را به نسخه‌ی سازگار با کامپایلر همین پروژه پایین می‌آوریم.
// بدون این، خطای «compiled with an incompatible version of Kotlin» می‌گیریم.
configurations.all {
    resolutionStrategy {
        force("org.jetbrains.kotlin:kotlin-stdlib:1.9.24")
        force("org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.9.24")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // Multi-Profile API: هر پروفایل کوکی/استوریج مستقل دارد.
    //
    // ⚠️ چرا 1.15.0 و نه 1.16.0؟
    // نسخه‌ی 1.16.0 به kotlin-stdlib 2.1.20 وابسته است و با کامپایلر
    // Kotlin 1.9.24 این پروژه سازگار نیست:
    //   «Class 'kotlin.Unit' was compiled with an incompatible version of Kotlin»
    // نسخه‌ی 1.15.0 هیچ وابستگی به kotlin-stdlib ندارد و تمام APIهای
    // مورد نیاز ما را دارد (بررسی‌شده در بایت‌کد):
    //   ProfileStore.getInstance / getOrCreateProfile / getProfile / deleteProfile
    //   Profile.getName / getCookieManager / getWebStorage / getServiceWorkerController
    //   WebViewCompat.setProfile / getProfile
    //   WebViewFeature.MULTI_PROFILE
    implementation("androidx.webkit:webkit:1.15.0")

    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Room — آرشیو مکالمات، کتابخانه‌ی پرامپت، ردیاب مصرف.
    // 2.6.1 عمداً انتخاب شده: 2.7.0 به kotlin-stdlib 2.1.10 وابسته است
    // و با کامپایلر Kotlin 1.9.24 این پروژه ناسازگار می‌شود.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
}
