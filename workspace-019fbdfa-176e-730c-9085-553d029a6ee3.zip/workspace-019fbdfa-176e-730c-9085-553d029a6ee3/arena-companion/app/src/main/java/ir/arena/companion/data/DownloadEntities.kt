package ir.arena.companion.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query

/** یک فایل دانلودشده. */
@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val mimeType: String,
    val sourceUrl: String,
    /** مسیر فایل (content:// روی اندروید ۱۰+ یا file:// روی قدیمی‌تر) */
    val localUri: String,
    val sizeBytes: Long,
    val profileId: String,
    val createdAt: Long = System.currentTimeMillis(),
    /** pending / done / failed */
    val status: String = STATUS_DONE,
    val error: String? = null
) {
    companion object {
        const val STATUS_PENDING = "pending"
        const val STATUS_DONE = "done"
        const val STATUS_FAILED = "failed"
    }
}

@Dao
interface DownloadDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(d: DownloadItem): Long

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    suspend fun all(): List<DownloadItem>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun byId(id: Long): DownloadItem?

    @Query("UPDATE downloads SET status = :status, sizeBytes = :size, localUri = :uri, error = :err WHERE id = :id")
    suspend fun finish(id: Long, status: String, size: Long, uri: String, err: String?)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM downloads")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM downloads")
    suspend fun count(): Int

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM downloads")
    suspend fun totalBytes(): Long
}
