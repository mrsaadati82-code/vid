package ir.arena.companion

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.webkit.Profile

/**
 * پیکربندی WebViewهایی که arena.ai را درست بالا می‌آورند.
 *
 * درباره‌ی iframe: arena.ai هدر `frame-ancestors 'self' huggingface.co` می‌فرستد،
 * پس داخل <iframe> بالا نمی‌آید. اما WebView نیتیو یک top-level browsing context
 * است نه فریم تودرتو، بنابراین این محدودیت به آن اعمال نمی‌شود.
 */
object ArenaWebViewFactory {

    const val ARENA_HOME = "https://arena.ai/"

    /**
     * @param profile آبجکت پروفایل اختصاصی این WebView. اگر null باشد از
     *        CookieManager سراسری استفاده می‌شود (حالت fallback).
     *
     * 🔴 باگی که اینجا رفع شد:
     * قبلاً `CookieManager.getInstance()` صدا زده می‌شد که همیشه کوکی‌جار
     * *پیش‌فرض* را برمی‌گرداند، نه کوکی‌جار پروفایل فعال. نتیجه این بود که
     * تنظیم `setAcceptThirdPartyCookies` روی پروفایل اشتباه اعمال می‌شد و
     * کوکی‌های شخص‌ثالث گوگل (که برای نگه‌داشتن سشن OAuth لازم‌اند) درست
     * ذخیره نمی‌شدند — برای همین کاربر مجبور می‌شد دوباره لاگین کند.
     */
    @SuppressLint("SetJavaScriptEnabled")
    fun configure(
        webView: WebView,
        profile: Profile? = null,
        spoofUserAgent: Boolean = true
    ) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true

            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = false

            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false

            useWideViewPort = true
            loadWithOverviewMode = true

            // برای جریان OAuth گوگل لازم است
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)

            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

            if (spoofUserAgent) {
                userAgentString = UserAgentHelper.toBrowserLike(userAgentString)
            }
        }

        // ✅ کوکی‌جار درست: اول پروفایل اختصاصی، بعد سراسری
        val cookieManager = profile?.cookieManager ?: CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.isScrollbarFadingEnabled = true
        webView.overScrollMode = WebView.OVER_SCROLL_NEVER
    }
}
