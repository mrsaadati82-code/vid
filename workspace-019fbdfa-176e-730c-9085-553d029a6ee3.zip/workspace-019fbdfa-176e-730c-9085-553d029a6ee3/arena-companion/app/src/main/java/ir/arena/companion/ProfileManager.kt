package ir.arena.companion

import android.content.Context
import android.content.SharedPreferences
import android.webkit.WebView
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

/**
 * مدیریت چند پروفایل مستقل برای WebView — بدون محدودیت تعداد.
 *
 * هر Profile کوکی‌جار، WebStorage و ServiceWorkerController کاملاً مستقل دارد،
 * بنابراین می‌توان هم‌زمان با چند اکانت گوگل وارد شد.
 */
class ProfileManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    val isSupported: Boolean
        get() = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)

    data class ArenaProfile(
        val id: String,
        var label: String,
        var colorIndex: Int = 0,
        var lastUsed: Long = 0L
    ) {
        /** حرف اول برچسب برای نمایش در آواتار */
        val initial: String
            get() = label.trim().firstOrNull()?.uppercase() ?: "?"

        val color: Int get() = PALETTE[colorIndex % PALETTE.size]

        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("colorIndex", colorIndex)
            put("lastUsed", lastUsed)
        }

        companion object {
            /** پالت رنگ برای تشخیص سریع اکانت فعال */
            val PALETTE = intArrayOf(
                0xFF4285F4.toInt(), // آبی
                0xFFEA4335.toInt(), // قرمز
                0xFF34A853.toInt(), // سبز
                0xFFFBBC04.toInt(), // زرد
                0xFF9C27B0.toInt(), // بنفش
                0xFF00ACC1.toInt(), // فیروزه‌ای
                0xFFFF7043.toInt(), // نارنجی
                0xFF5E35B1.toInt()  // بنفش تیره
            )

            fun fromJson(o: JSONObject) = ArenaProfile(
                id = o.getString("id"),
                label = o.getString("label"),
                colorIndex = o.optInt("colorIndex", 0),
                lastUsed = o.optLong("lastUsed", 0L)
            )
        }
    }

    // ---------- لیست پروفایل‌ها ----------

    fun listProfiles(): MutableList<ArenaProfile> {
        val raw = prefs.getString(KEY_PROFILES, null)
        if (raw.isNullOrBlank()) return defaultProfiles()
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { ArenaProfile.fromJson(arr.getJSONObject(it)) }
        }.getOrElse { defaultProfiles() }
    }

    private fun defaultProfiles(): MutableList<ArenaProfile> {
        val seed = mutableListOf(
            ArenaProfile("acct_1", "اکانت اول", 0),
            ArenaProfile("acct_2", "اکانت دوم", 1)
        )
        saveProfiles(seed)
        return seed
    }

    fun saveProfiles(profiles: List<ArenaProfile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_PROFILES, arr.toString()).apply()
    }

    /** افزودن پروفایل جدید — بدون سقف تعداد. */
    fun addProfile(label: String): ArenaProfile {
        val list = listProfiles()
        val newProfile = ArenaProfile(
            id = "acct_${System.currentTimeMillis()}",
            label = label,
            colorIndex = list.size % ArenaProfile.PALETTE.size
        )
        list.add(newProfile)
        saveProfiles(list)
        return newProfile
    }

    fun renameProfile(id: String, newLabel: String) {
        val list = listProfiles()
        list.find { it.id == id }?.label = newLabel
        saveProfiles(list)
    }

    fun changeColor(id: String, colorIndex: Int) {
        val list = listProfiles()
        list.find { it.id == id }?.colorIndex = colorIndex
        saveProfiles(list)
    }

    /** حذف کامل پروفایل. آخرین پروفایل قابل حذف نیست. */
    fun deleteProfile(id: String): Boolean {
        val list = listProfiles()
        if (list.size <= 1) return false
        list.removeAll { it.id == id }
        saveProfiles(list)
        if (activeProfileId == id) activeProfileId = list.first().id
        runCatching {
            if (isSupported) ProfileStore.getInstance().deleteProfile(id)
        }
        return true
    }

    // ---------- پروفایل فعال ----------

    var activeProfileId: String
        get() {
            val saved = prefs.getString(KEY_ACTIVE, null)
            val list = listProfiles()
            return if (saved != null && list.any { it.id == saved }) saved else list.first().id
        }
        set(value) {
            prefs.edit().putString(KEY_ACTIVE, value).apply()
            val list = listProfiles()
            list.find { it.id == value }?.lastUsed = System.currentTimeMillis()
            saveProfiles(list)
        }

    fun activeProfile(): ArenaProfile =
        listProfiles().find { it.id == activeProfileId } ?: listProfiles().first()

    fun nextProfile(): ArenaProfile {
        val list = listProfiles()
        val idx = list.indexOfFirst { it.id == activeProfileId }
        return list[(idx + 1) % list.size]
    }

    // ---------- اتصال به WebView ----------

    /** آبجکت Profile را برمی‌گرداند تا بتوان به CookieManager اختصاصی‌اش دسترسی داشت. */
    fun getProfileObject(profileId: String): Profile? {
        if (!isSupported) return null
        return runCatching { ProfileStore.getInstance().getOrCreateProfile(profileId) }.getOrNull()
    }

    /** باید *قبل از* اولین loadUrl صدا زده شود. */
    fun attach(webView: WebView, profileId: String): Boolean {
        if (!isSupported) return false
        return runCatching {
            val profile = ProfileStore.getInstance().getOrCreateProfile(profileId)
            WebViewCompat.setProfile(webView, profile.name)
            true
        }.getOrDefault(false)
    }

    /**
     * 🔴 حیاتی: کوکی‌ها را از حافظه روی دیسک می‌نویسد.
     *
     * بدون این، وقتی سیستم پروسه را بکشد کوکی‌های سشن از بین می‌روند و
     * کاربر مجبور می‌شود دوباره لاگین کند. باید در onPause صدا زده شود.
     */
    fun flushCookies(profileId: String) {
        runCatching {
            if (isSupported) {
                ProfileStore.getInstance().getProfile(profileId)?.cookieManager?.flush()
            } else {
                android.webkit.CookieManager.getInstance().flush()
            }
        }
    }

    fun flushAll() {
        runCatching {
            if (isSupported) {
                ProfileStore.getInstance().allProfileNames.forEach { name ->
                    ProfileStore.getInstance().getProfile(name)?.cookieManager?.flush()
                }
            } else {
                android.webkit.CookieManager.getInstance().flush()
            }
        }
    }

    /** خروج از حساب: داده‌های همان پروفایل پاک می‌شود. */
    fun signOut(profileId: String): Boolean {
        if (!isSupported) {
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            android.webkit.CookieManager.getInstance().flush()
            return true
        }
        return runCatching {
            ProfileStore.getInstance().getProfile(profileId)?.let { p ->
                p.cookieManager.removeAllCookies(null)
                p.cookieManager.flush()
                p.webStorage.deleteAllData()
            }
            true
        }.getOrDefault(false)
    }

    companion object {
        private const val PREFS_NAME = "arena_profiles"
        private const val KEY_PROFILES = "profiles_json"
        private const val KEY_ACTIVE = "active_profile"
    }
}
