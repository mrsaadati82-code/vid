package ir.arena.companion.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import ir.arena.companion.R
import ir.arena.companion.data.LeaderboardRepo
import ir.arena.companion.databinding.ActivityLeaderboardBinding
import kotlinx.coroutines.launch

/**
 * لیدربورد نیتیو — فقط مدل‌هایی که واقعاً در Arena ارزیابی شده‌اند.
 * منبع: دیتاست رسمی Arena روی Hugging Face.
 */
class LeaderboardActivity : ThemedActivity() {

    private lateinit var b: ActivityLeaderboardBinding
    private var board = LeaderboardRepo.BOARDS.first()
    private var onlyOpenWeights = false
    private var entries: List<LeaderboardRepo.Entry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLeaderboardBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.list.layoutManager = LinearLayoutManager(this)

        buildChips()

        b.filterOpen.setOnCheckedChangeListener { _, checked ->
            onlyOpenWeights = checked
            render()
        }
        b.swipe.setOnRefreshListener { load(force = true) }

        load()
    }

    private fun buildChips() {
        LeaderboardRepo.BOARDS.forEach { brd ->
            val chip = Chip(this).apply {
                text = brd.title
                isCheckable = true
                isChecked = brd.id == board.id
                setOnClickListener {
                    if (board.id != brd.id) {
                        board = brd
                        for (i in 0 until b.chipGroup.childCount) {
                            (b.chipGroup.getChildAt(i) as? Chip)?.isChecked = false
                        }
                        isChecked = true
                        load()
                    } else isChecked = true
                }
            }
            b.chipGroup.addView(chip)
        }
    }

    private fun load(force: Boolean = false) {
        b.progress.isVisible = true
        b.emptyView.isVisible = false
        lifecycleScope.launch {
            entries = LeaderboardRepo.fetch(board, force)
            b.progress.isVisible = false
            b.swipe.isRefreshing = false
            render()
        }
    }

    private fun render() {
        val filtered =
            if (onlyOpenWeights) entries.filter { it.isOpenWeight } else entries

        b.subtitle.text = getString(R.string.lb_subtitle, board.title, filtered.size)
        b.emptyView.isVisible = filtered.isEmpty()
        b.list.adapter = Adapter(filtered)
    }

    private inner class Adapter(private val items: List<LeaderboardRepo.Entry>) :
        RecyclerView.Adapter<Adapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val rank: TextView = v.findViewById(R.id.rank)
            val model: TextView = v.findViewById(R.id.model)
            val org: TextView = v.findViewById(R.id.org)
            val score: TextView = v.findViewById(R.id.score)
            val votes: TextView = v.findViewById(R.id.votes)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_leaderboard, parent, false)
        )

        override fun onBindViewHolder(holder: VH, position: Int) {
            val e = items[position]
            holder.rank.text = when (e.rank) {
                1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"
                else -> e.rank.toString()
            }
            holder.model.text = e.modelName
            holder.org.text = e.organization +
                    if (e.isOpenWeight) "  •  ${getString(R.string.open_weights)}" else ""
            holder.score.text = e.rating.toInt().toString()
            val ci = ((e.ratingUpper - e.ratingLower) / 2).toInt()
            holder.votes.text = getString(R.string.lb_votes, ci, e.voteCount)
        }

        override fun getItemCount() = items.size
    }
}
