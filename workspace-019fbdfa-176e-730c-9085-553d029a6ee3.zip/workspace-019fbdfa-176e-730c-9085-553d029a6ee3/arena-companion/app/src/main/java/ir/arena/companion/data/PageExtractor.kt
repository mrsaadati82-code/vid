package ir.arena.companion.data

/**
 * جاوااسکریپتی که داخل صفحه‌ی Arena تزریق می‌شود تا محتوای مکالمه را
 * استخراج کند (برای آرشیو) و ارسال پیام را تشخیص دهد (برای ردیاب مصرف).
 *
 * همه‌چیز فقط *خواندن* DOM است — هیچ اتوماسیون یا ارسال خودکاری در کار
 * نیست، پس با بند (vi) شرایط استفاده تداخل ندارد.
 */
object PageExtractor {

    const val BRIDGE = "AndroidBridge"

    /** با addDocumentStartJavascript یا evaluateJavascript اجرا می‌شود. */
    val SCRIPT: String = """
    (function () {
      if (window.__arenaCompanionInstalled) return;
      window.__arenaCompanionInstalled = true;

      function textOf(el) {
        if (!el) return '';
        return (el.innerText || el.textContent || '').trim();
      }

      function collect() {
        var main = document.querySelector('main') || document.body;
        var body = textOf(main);
        if (body.length < 40) return null;

        var title = document.title || '';
        var h = main.querySelector('h1, h2');
        if (h && textOf(h).length > 3) title = textOf(h);
        if (!title || title.length < 3) {
          title = body.slice(0, 60).replace(/\s+/g, ' ');
        }

        return {
          title: title.slice(0, 200),
          body: body.slice(0, 200000),
          url: location.href
        };
      }

      function push() {
        try {
          var d = collect();
          if (!d) return;
          if (window.$BRIDGE && window.$BRIDGE.saveConversation) {
            window.$BRIDGE.saveConversation(d.title, d.body, d.url);
          }
        } catch (e) {}
      }

      // ذخیره‌ی خودکار وقتی محتوا تغییر کرد و آرام شد
      var timer = null;
      var observer = new MutationObserver(function () {
        clearTimeout(timer);
        timer = setTimeout(push, 2500);
      });
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });

      // تشخیص ارسال پیام برای شمارش مصرف
      function isSendKey(e) {
        return e.key === 'Enter' && !e.shiftKey;
      }
      document.addEventListener('keydown', function (e) {
        var t = e.target;
        if (!t) return;
        var isInput = t.tagName === 'TEXTAREA' ||
                      (t.getAttribute && t.getAttribute('contenteditable') === 'true');
        if (isInput && isSendKey(e)) {
          try { window.$BRIDGE && window.$BRIDGE.recordSend && window.$BRIDGE.recordSend(); } catch (x) {}
        }
      }, true);

      document.addEventListener('click', function (e) {
        var el = e.target;
        for (var i = 0; i < 4 && el; i++) {
          var t = (el.getAttribute && (el.getAttribute('aria-label') || '')) + ' ' +
                  (el.textContent || '');
          if (/send|ارسال|submit/i.test(t) && el.tagName === 'BUTTON') {
            try { window.$BRIDGE && window.$BRIDGE.recordSend && window.$BRIDGE.recordSend(); } catch (x) {}
            break;
          }
          el = el.parentElement;
        }
      }, true);

      setTimeout(push, 3000);
    })();
    """.trimIndent()

    /** تزریق پرامپت در textarea — با native setter تا React هم بفهمد. */
    fun injectPromptScript(text: String): String {
        val escaped = org.json.JSONObject.quote(text)
        return """
        (function () {
          var el = document.querySelector('textarea') ||
                   document.querySelector('[contenteditable="true"]');
          if (!el) return 'not-found';
          if (el.tagName === 'TEXTAREA') {
            var setter = Object.getOwnPropertyDescriptor(
                window.HTMLTextAreaElement.prototype, 'value').set;
            setter.call(el, $escaped);
            el.dispatchEvent(new Event('input', { bubbles: true }));
          } else {
            el.textContent = $escaped;
            el.dispatchEvent(new Event('input', { bubbles: true }));
          }
          el.focus();
          return 'ok';
        })();
        """.trimIndent()
    }
}
