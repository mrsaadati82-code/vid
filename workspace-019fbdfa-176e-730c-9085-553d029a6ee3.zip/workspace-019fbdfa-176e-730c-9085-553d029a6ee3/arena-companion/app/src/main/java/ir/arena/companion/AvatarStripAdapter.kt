package ir.arena.companion

import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView

/**
 * نوار افقی آواتارها.
 * ضربه = سوییچ فوری. نگه‌داشتن = منوی کامل اکانت‌ها.
 * بج قرمز = آن اکانت محتوای جدید دارد.
 */
class AvatarStripAdapter(
    private var profiles: List<ProfileManager.ArenaProfile>,
    private var activeId: String,
    private var badges: Set<String> = emptySet(),
    private val onClick: (ProfileManager.ArenaProfile) -> Unit,
    private val onLongClick: () -> Unit
) : RecyclerView.Adapter<AvatarStripAdapter.VH>() {

    class VH(val container: FrameLayout, val avatar: AvatarView) :
        RecyclerView.ViewHolder(container)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val d = parent.context.resources.displayMetrics.density
        val size = (34 * d).toInt()
        val margin = (4 * d).toInt()

        val avatar = AvatarView(parent.context).apply {
            layoutParams = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
        }
        val container = FrameLayout(parent.context).apply {
            layoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply { marginStart = margin; marginEnd = margin }
            addView(avatar)
            isClickable = true
            isFocusable = true
        }
        return VH(container, avatar)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = profiles[position]
        val isActive = p.id == activeId

        holder.avatar.apply {
            initial = p.initial
            circleColor = p.color
            showRing = isActive
            showBadge = !isActive && p.id in badges
            alpha = if (isActive) 1f else 0.5f
        }

        holder.container.setOnClickListener { onClick(p) }
        holder.container.setOnLongClickListener { onLongClick(); true }
    }

    override fun getItemCount() = profiles.size

    fun update(
        newProfiles: List<ProfileManager.ArenaProfile>,
        newActiveId: String,
        newBadges: Set<String> = badges
    ) {
        profiles = newProfiles
        activeId = newActiveId
        badges = newBadges
        notifyDataSetChanged()
    }
}
