package ir.arena.companion.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Conversation::class, ConversationFts::class, SavedPrompt::class,
        UsageEvent::class, DownloadItem::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun conversations(): ConversationDao
    abstract fun prompts(): PromptDao
    abstract fun usage(): UsageDao
    abstract fun downloads(): DownloadDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "arena_companion.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
