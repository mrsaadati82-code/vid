package ir.arena.companion.ui

import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import ir.arena.companion.ProfileManager
import ir.arena.companion.R
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.databinding.ActivityUsageBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** ردیاب مصرف: امروز، ۷ روز اخیر، و تفکیک هر اکانت. */
class UsageActivity : ThemedActivity() {

    private lateinit var b: ActivityUsageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityUsageBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        load()
    }

    private fun load() {
        val db = AppDatabase.get(this)
        val pm = ProfileManager(this)
        val today = dayKey(0)
        val weekAgo = dayKey(-6)

        lifecycleScope.launch {
            val todayTotal = db.usage().todayTotal(today)
            val daily = db.usage().dailyBreakdown(weekAgo)
            val perProfile = db.usage().byProfile(weekAgo)
            val convCount = db.conversations().count()

            b.todayCount.text = todayTotal.toString()
            b.weekCount.text = daily.sumOf { it.count }.toString()
            b.archiveCount.text = convCount.toString()

            // نمودار میله‌ای متنی ۷ روز اخیر
            val map = daily.associate { it.day to it.count }
            val max = (map.values.maxOrNull() ?: 1).coerceAtLeast(1)
            b.chart.text = buildString {
                for (i in -6..0) {
                    val d = dayKey(i)
                    val n = map[d] ?: 0
                    val bars = (n * 18 / max).coerceAtLeast(if (n > 0) 1 else 0)
                    append(d.substring(5))
                    append("  ")
                    append("▌".repeat(bars).ifEmpty { "·" })
                    append("  $n\n")
                }
            }

            val labels = pm.listProfiles().associate { it.id to it.label }
            b.perProfile.text = if (perProfile.isEmpty())
                getString(R.string.no_usage_yet)
            else perProfile.joinToString("\n") { pu ->
                "• ${labels[pu.profileId] ?: pu.profileId}: ${pu.count}"
            }
        }
    }

    private fun dayKey(offsetDays: Int): String {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offsetDays) }
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }
}
