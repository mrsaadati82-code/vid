package ir.arena.companion.ui

import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import ir.arena.companion.ProfileManager
import ir.arena.companion.R
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.databinding.ActivityStorageBinding
import kotlinx.coroutines.launch

/**
 * مدیریت و پاکسازی حافظه.
 *
 * سه سطح پاکسازی:
 *  • هدفمند — قدیمی‌تر از N روز، یا بدون ستاره
 *  • انتخابی — چند مورد از داخل آرشیو (حالت انتخاب)
 *  • کامل — همه‌چیز
 *
 * مکالمات ستاره‌دار در پاکسازی‌های هدفمند محفوظ می‌مانند.
 */
class StorageActivity : ThemedActivity() {

    private lateinit var b: ActivityStorageBinding
    private val db by lazy { AppDatabase.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityStorageBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }

        b.rowOld30.setOnClickListener { confirmOlderThan(30) }
        b.rowOld7.setOnClickListener { confirmOlderThan(7) }
        b.rowUnstarred.setOnClickListener { confirmUnstarred() }
        b.rowByProfile.setOnClickListener { chooseProfile() }
        b.rowUsage.setOnClickListener { confirmUsage() }
        b.rowPrompts.setOnClickListener { confirmPrompts() }
        b.rowWebData.setOnClickListener { confirmWebData() }
        b.rowEverything.setOnClickListener { confirmEverything() }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val convs = db.conversations().count()
            val chars = db.conversations().totalChars()
            val prompts = db.prompts().count()
            val usage = db.usage().totalCount()
            val unstarred = db.conversations().countUnstarred()

            b.statConversations.text = convs.toString()
            b.statSize.text = humanSize(chars * 2)   // UTF-16 ≈ ۲ بایت
            b.statPrompts.text = prompts.toString()

            b.subOld30.text = getString(R.string.items_n, countOld(30))
            b.subOld7.text = getString(R.string.items_n, countOld(7))
            b.subUnstarred.text = getString(R.string.items_n, unstarred)
            b.subUsage.text = getString(R.string.records_n, usage)
            b.subPrompts.text = getString(R.string.items_n, prompts)
        }
    }

    private suspend fun countOld(days: Int): Int =
        db.conversations().countOlderThan(cutoff(days))

    private fun cutoff(days: Int): Long =
        System.currentTimeMillis() - days * 24L * 60 * 60 * 1000

    // ─────────── عملیات ───────────

    private fun confirmOlderThan(days: Int) {
        lifecycleScope.launch {
            val n = countOld(days)
            if (n == 0) { toast(getString(R.string.nothing_to_clear)); return@launch }
            ask(
                getString(R.string.clear_older_title, days),
                getString(R.string.clear_older_desc, n)
            ) {
                lifecycleScope.launch {
                    db.conversations().deleteOlderThan(cutoff(days))
                    refresh(); toast(getString(R.string.cleared_n, n))
                }
            }
        }
    }

    private fun confirmUnstarred() {
        lifecycleScope.launch {
            val n = db.conversations().countUnstarred()
            if (n == 0) { toast(getString(R.string.nothing_to_clear)); return@launch }
            ask(
                getString(R.string.clear_unstarred),
                getString(R.string.clear_unstarred_desc, n)
            ) {
                lifecycleScope.launch {
                    db.conversations().deleteUnstarred()
                    refresh(); toast(getString(R.string.cleared_n, n))
                }
            }
        }
    }

    private fun chooseProfile() {
        val pm = ProfileManager(this)
        val profiles = pm.listProfiles()
        lifecycleScope.launch {
            val labels = profiles.map { p ->
                "${p.label}  (${db.conversations().countByProfile(p.id)})"
            }.toTypedArray()

            MaterialAlertDialogBuilder(this@StorageActivity)
                .setTitle(R.string.clear_by_profile)
                .setItems(labels) { _, which ->
                    val p = profiles[which]
                    ask(
                        getString(R.string.clear_profile_title, p.label),
                        getString(R.string.clear_profile_desc)
                    ) {
                        lifecycleScope.launch {
                            db.conversations().deleteByProfile(p.id)
                            refresh(); toast(getString(R.string.cleared))
                        }
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun confirmUsage() = ask(
        getString(R.string.clear_usage), getString(R.string.clear_usage_desc)
    ) {
        lifecycleScope.launch {
            db.usage().deleteAll(); refresh(); toast(getString(R.string.cleared))
        }
    }

    private fun confirmPrompts() = ask(
        getString(R.string.clear_prompts), getString(R.string.clear_prompts_desc)
    ) {
        lifecycleScope.launch {
            db.prompts().deleteAll(); refresh(); toast(getString(R.string.cleared))
        }
    }

    /** کش و داده‌ی وب همه‌ی پروفایل‌ها — کوکی‌های لاگین دست‌نخورده. */
    private fun confirmWebData() = ask(
        getString(R.string.clear_web_cache), getString(R.string.clear_web_cache_desc)
    ) {
        runCatching {
            android.webkit.WebStorage.getInstance().deleteAllData()
            cacheDir.deleteRecursively()
        }
        toast(getString(R.string.cleared))
    }

    private fun confirmEverything() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.clear_everything)
            .setMessage(R.string.clear_everything_desc)
            .setPositiveButton(R.string.delete_all) { _, _ ->
                // تأیید دوم — چون برگشت‌ناپذیر است
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.are_you_sure)
                    .setMessage(R.string.clear_everything_confirm)
                    .setPositiveButton(R.string.yes_delete) { _, _ ->
                        lifecycleScope.launch {
                            db.conversations().deleteAll()
                            db.usage().deleteAll()
                            db.prompts().deleteAll()
                            runCatching {
                                android.webkit.WebStorage.getInstance().deleteAllData()
                                cacheDir.deleteRecursively()
                            }
                            refresh()
                            toast(getString(R.string.all_cleared))
                        }
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ─────────── کمکی ───────────

    private fun ask(title: String, msg: String, onYes: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton(R.string.clear) { _, _ -> onYes() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(m: String) = Snackbar.make(b.root, m, Snackbar.LENGTH_SHORT).show()

    private fun humanSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
    }
}
