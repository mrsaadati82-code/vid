package ir.arena.companion

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** لیست عمودی اکانت‌ها در BottomSheet. */
class ProfileListAdapter(
    private var profiles: List<ProfileManager.ArenaProfile>,
    private var activeId: String,
    private val loggedInIds: Set<String>,
    private val onSelect: (ProfileManager.ArenaProfile) -> Unit,
    private val onMore: (ProfileManager.ArenaProfile, View) -> Unit
) : RecyclerView.Adapter<ProfileListAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: AvatarView = v.findViewById(R.id.avatar)
        val label: TextView = v.findViewById(R.id.label)
        val status: TextView = v.findViewById(R.id.status)
        val btnMore: ImageButton = v.findViewById(R.id.btnMore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = profiles[position]
        val isActive = p.id == activeId
        val ctx = holder.itemView.context

        holder.avatar.apply {
            initial = p.initial
            circleColor = p.color
            showRing = false
        }
        holder.label.text = p.label

        holder.status.text = when {
            isActive -> ctx.getString(R.string.status_active)
            p.id in loggedInIds -> ctx.getString(R.string.status_ready)
            else -> ctx.getString(R.string.status_tap_to_open)
        }

        holder.itemView.setOnClickListener { onSelect(p) }
        holder.btnMore.setOnClickListener { onMore(p, holder.btnMore) }
    }

    override fun getItemCount() = profiles.size
}
