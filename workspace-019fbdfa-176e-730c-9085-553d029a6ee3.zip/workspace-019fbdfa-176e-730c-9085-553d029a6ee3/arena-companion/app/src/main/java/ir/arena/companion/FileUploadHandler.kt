package ir.arena.companion

import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import androidx.activity.result.ActivityResultLauncher

/**
 * پشتیبانی از آپلود فایل در WebView.
 *
 * 🔴 چرا دکمه‌ی آپلود کار نمی‌کرد؟
 * WebView به‌طور پیش‌فرض `<input type="file">` را **نادیده می‌گیرد**.
 * باید `WebChromeClient.onShowFileChooser` را override کنی وگرنه کلیک
 * روی دکمه‌ی آپلود هیچ اتفاقی نمی‌افتد. این متد اصلاً پیاده نشده بود.
 */
class FileUploadHandler(
    private val launcher: ActivityResultLauncher<Intent>
) {

    /** callback در انتظار — تا وقتی کاربر فایل انتخاب کند نگه داشته می‌شود. */
    private var pendingCallback: ValueCallbackHolder? = null

    class ValueCallbackHolder(val cb: android.webkit.ValueCallback<Array<Uri>>)

    /**
     * از onShowFileChooser صدا زده می‌شود.
     * @return true اگر انتخابگر باز شد
     */
    fun onShowFileChooser(
        filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
        params: WebChromeClient.FileChooserParams?
    ): Boolean {
        if (filePathCallback == null) return false

        // اگر درخواست قبلی معلق مانده، لغوش کن تا WebView قفل نشود
        pendingCallback?.cb?.onReceiveValue(null)
        pendingCallback = ValueCallbackHolder(filePathCallback)

        val mimeTypes = params?.acceptTypes
            ?.filter { it.isNotBlank() }
            ?.toTypedArray()
            ?: emptyArray()

        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (mimeTypes.size == 1) mimeTypes[0] else "*/*"
            if (mimeTypes.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            if (params?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
        }

        return runCatching {
            launcher.launch(Intent.createChooser(intent, "انتخاب فایل"))
            true
        }.getOrElse {
            // اگر انتخابگر باز نشد، باید callback را آزاد کنیم
            pendingCallback?.cb?.onReceiveValue(null)
            pendingCallback = null
            false
        }
    }

    /** نتیجه‌ی انتخاب فایل را به WebView برمی‌گرداند. */
    fun onResult(resultCode: Int, data: Intent?) {
        val cb = pendingCallback?.cb
        pendingCallback = null
        if (cb == null) return

        if (resultCode != android.app.Activity.RESULT_OK || data == null) {
            // 🔴 حیاتی: اگر null ندهیم، WebView برای همیشه قفل می‌ماند
            // و دفعه‌ی بعد دکمه‌ی آپلود کار نمی‌کند.
            cb.onReceiveValue(null)
            return
        }

        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }

        cb.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
    }

    /** موقع بسته شدن صفحه — از نشت جلوگیری می‌کند. */
    fun cancel() {
        pendingCallback?.cb?.onReceiveValue(null)
        pendingCallback = null
    }
}
