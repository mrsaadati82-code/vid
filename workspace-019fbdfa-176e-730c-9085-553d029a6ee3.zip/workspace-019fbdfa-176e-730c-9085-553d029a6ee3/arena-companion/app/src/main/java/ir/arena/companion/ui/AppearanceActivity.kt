package ir.arena.companion.ui

import android.os.Bundle
import android.widget.SeekBar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.arena.companion.R
import ir.arena.companion.data.AppearancePrefs
import ir.arena.companion.databinding.ActivityAppearanceBinding

/** تنظیمات ظاهر: فونت، اندازه، چیدمان راست‌چین، تم رنگی. */
class AppearanceActivity : ThemedActivity() {

    private lateinit var b: ActivityAppearanceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAppearanceBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }

        // اصلاح چیدمان راست‌چین
        b.switchRtl.isChecked = appearance.rtlFix
        b.switchRtl.setOnCheckedChangeListener { _, v -> appearance.rtlFix = v; markChanged() }

        // فونت وزیرمتن
        b.switchFont.isChecked = appearance.persianFont
        b.switchFont.setOnCheckedChangeListener { _, v -> appearance.persianFont = v; markChanged() }

        // فاصله‌ی فشرده
        b.switchCompact.isChecked = appearance.compact
        b.switchCompact.setOnCheckedChangeListener { _, v -> appearance.compact = v; markChanged() }

        // اندازه‌ی فونت ۸۰..۱۵۰
        b.seekFont.max = 70
        b.seekFont.progress = appearance.fontScale - 80
        updateFontLabel()
        b.seekFont.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) {
                appearance.fontScale = 80 + p
                updateFontLabel()
                if (user) markChanged()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.btnPreviewInfo.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.rtl_fix)
                .setMessage(R.string.rtl_explain)
                .setPositiveButton(R.string.ok, null)
                .show()
        }
    }

    private fun updateFontLabel() {
        b.fontLabel.text = getString(R.string.font_size_n, appearance.fontScale)
        b.sampleText.textSize = 15f * appearance.fontScale / 100f
    }

    private fun markChanged() {
        setResult(RESULT_OK)
        b.hint.text = getString(R.string.appearance_applied)
    }
}
