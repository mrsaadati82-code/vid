package ir.arena.companion

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/**
 * آواتار دایره‌ای با حرف اول نام، رنگ اختصاصی، حلقه‌ی «فعال» و بج اعلان.
 */
class AvatarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE53935.toInt()
    }
    private val badgeBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }

    var initial: String = "?"
        set(v) { field = v; invalidate() }

    var circleColor: Int = 0xFF4285F4.toInt()
        set(v) { field = v; invalidate() }

    /** حلقه‌ی دور آواتار = پروفایل فعال */
    var showRing: Boolean = false
        set(v) { field = v; invalidate() }

    /** بج قرمز = این اکانت محتوای جدید دارد */
    var showBadge: Boolean = false
        set(v) { field = v; invalidate() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val ringW = min(w, h) * 0.07f
        val radius = min(w, h) / 2f - if (showRing) ringW * 1.6f else ringW * 0.5f

        circlePaint.color = circleColor
        canvas.drawCircle(cx, cy, radius, circlePaint)

        if (showRing) {
            ringPaint.strokeWidth = ringW
            canvas.drawCircle(cx, cy, radius + ringW * 1.1f, ringPaint)
        }

        textPaint.textSize = radius * 1.05f
        canvas.drawText(
            initial, cx,
            cy - (textPaint.descent() + textPaint.ascent()) / 2f,
            textPaint
        )

        if (showBadge) {
            val br = min(w, h) * 0.17f
            val bx = cx + radius * 0.72f
            val by = cy - radius * 0.72f
            badgeBorderPaint.strokeWidth = br * 0.42f
            canvas.drawCircle(bx, by, br, badgeBorderPaint)
            canvas.drawCircle(bx, by, br, badgePaint)
        }
    }
}
