package ir.arena.companion.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import ir.arena.companion.R
import ir.arena.companion.data.AppearancePrefs

/**
 * پایه‌ی همه‌ی صفحه‌ها — تم یکسان و دسترسی به تنظیمات ظاهر.
 *
 * توجه: انتخاب تم رنگی از UI برداشته شد، چون فقط رابط خود اپ را عوض
 * می‌کرد و روی صفحه‌ی arena.ai اثری نداشت (استایل آن سایت را نمی‌توان
 * کامل بازنویسی کرد). تم بنفش پیش‌فرض باقی ماند.
 */
abstract class ThemedActivity : AppCompatActivity() {

    protected val appearance: AppearancePrefs by lazy { AppearancePrefs(this) }
    private var appliedTheme = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedTheme = appearance.themeIndex
        setTheme(THEME_STYLES[appliedTheme.coerceIn(THEME_STYLES.indices)])
        // محتوا تا پشت نوار وضعیت کشیده شود — ظاهر مدرن
        WindowCompat.setDecorFitsSystemWindows(window, true)
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        // اگر کاربر تم را در صفحه‌ی دیگری عوض کرد، این صفحه بازسازی شود
        if (appliedTheme != appearance.themeIndex) recreate()
    }

    companion object {
        val THEME_STYLES = intArrayOf(
            R.style.Theme_ArenaPlus_Violet,
            R.style.Theme_ArenaPlus_Blue,
            R.style.Theme_ArenaPlus_Green,
            R.style.Theme_ArenaPlus_Orange,
            R.style.Theme_ArenaPlus_Pink,
            R.style.Theme_ArenaPlus_Teal
        )
    }
}
