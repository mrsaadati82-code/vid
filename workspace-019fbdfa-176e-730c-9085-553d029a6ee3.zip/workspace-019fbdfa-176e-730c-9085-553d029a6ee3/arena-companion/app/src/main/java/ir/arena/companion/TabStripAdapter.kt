package ir.arena.companion

import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.color.MaterialColors

/**
 * نوار تب با ظاهر «سگمنت» شبیه iOS.
 *
 * تب فعال: پس‌زمینه‌ی پررنگ + متن ضخیم
 * تب غیرفعال: شفاف، متن کم‌رنگ
 * آخرین آیتم: دکمه‌ی +
 */
class TabStripAdapter(
    private var items: List<TabManager.Tab>,
    private var activeTabId: Long,
    private val onSelect: (TabManager.Tab) -> Unit,
    private val onClose: (TabManager.Tab) -> Unit,
    private val onNew: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private companion object {
        const val TYPE_TAB = 0
        const val TYPE_ADD = 1
    }

    class TabVH(val root: LinearLayout, val label: TextView, val close: ImageView) :
        RecyclerView.ViewHolder(root)

    class AddVH(val root: TextView) : RecyclerView.ViewHolder(root)

    override fun getItemViewType(position: Int) =
        if (position == items.size) TYPE_ADD else TYPE_TAB

    override fun getItemCount() = items.size + 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()

        if (viewType == TYPE_ADD) {
            val tv = TextView(ctx).apply {
                text = "＋"
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(
                    MaterialColors.getColor(
                        this, com.google.android.material.R.attr.colorPrimary
                    )
                )
                layoutParams = ViewGroup.MarginLayoutParams(dp(34f), dp(30f))
                    .apply { marginStart = dp(3f); marginEnd = dp(3f) }
                setBackgroundResource(R.drawable.bg_tab_add)
                isClickable = true
                isFocusable = true
            }
            return AddVH(tv)
        }

        val label = TextView(ctx).apply {
            textSize = 12.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            maxWidth = dp(120f)
        }
        val close = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_close_small)
            layoutParams = LinearLayout.LayoutParams(dp(15f), dp(15f))
                .apply { marginStart = dp(7f) }
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13f), 0, dp(9f), 0)
            layoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(30f)
            ).apply { marginStart = dp(3f); marginEnd = dp(3f) }
            setBackgroundResource(R.drawable.bg_tab_chip)
            isClickable = true
            isFocusable = true
            addView(label)
            addView(close)
        }
        return TabVH(row, label, close)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is AddVH) {
            holder.root.setOnClickListener { onNew() }
            return
        }
        val h = holder as TabVH
        val tab = items[position]
        val active = tab.id == activeTabId

        h.label.text = tab.title
        h.root.isSelected = active

        val onSurface = MaterialColors.getColor(
            h.root, com.google.android.material.R.attr.colorOnSurface
        )
        val onVariant = MaterialColors.getColor(
            h.root, com.google.android.material.R.attr.colorOnSurfaceVariant
        )

        h.label.setTextColor(if (active) onSurface else onVariant)
        h.label.setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
        h.close.setColorFilter(onVariant)
        h.close.alpha = if (active) 0.7f else 0.4f

        h.close.visibility =
            if (items.size > 1) android.view.View.VISIBLE else android.view.View.GONE

        h.root.setOnClickListener { onSelect(tab) }
        h.close.setOnClickListener { onClose(tab) }
    }

    fun update(newItems: List<TabManager.Tab>, newActiveId: Long) {
        items = newItems
        activeTabId = newActiveId
        notifyDataSetChanged()
    }
}
