package ir.arena.companion.data

/**
 * استایل فارسی + رفع به‌هم‌ریختگی چیدمان (bidi) در arena.ai
 *
 * ═══ چرا متن فارسی به‌هم می‌ریزد؟ ═══
 *
 * وقتی جمله‌ی فارسی حاوی کلمه‌ی انگلیسی یا پرانتز باشد، مرورگر از الگوریتم
 * Unicode Bidi استفاده می‌کند. مشکل اینجاست که جهت پاراگراف را از **اولین
 * کاراکتر جهت‌دار** تعیین می‌کند. اگر آن کاراکتر لاتین باشد (مثلاً جمله با
 * "React" شروع شود)، کل پاراگراف LTR می‌شود و فارسی به هم می‌ریزد.
 *
 * همچنین علائم «خنثی» مثل پرانتز، نقطه و ویرگول جهت مستقل ندارند و از
 * همسایه‌شان تبعیت می‌کنند — برای همین آخر جمله می‌پرند.
 *
 * ═══ راه‌حل ═══
 *
 * فقط `direction: rtl` کافی نیست. کاری که می‌کنیم:
 *
 * ۱. نسبت حروف فارسی هر بلوک را می‌سنجیم (نه فقط کاراکتر اول)
 * ۲. اگر بیش از آستانه بود → `dir="rtl"` صریح روی همان عنصر
 * ۳. بلوک‌های کد (pre/code) **همیشه LTR اجباری** — وگرنه کد خراب می‌شود
 * ۴. اعداد و URL داخل متن فارسی با `unicode-bidi: isolate` جدا می‌شوند
 * ۵. textarea با تشخیص زنده هنگام تایپ
 */
object PersianStyle {

    /** فونت وزیرمتن از CDN — با fallback به فونت سیستم. */
    private const val FONT_CSS = """
@font-face {
  font-family: 'VazirmatnApp';
  font-style: normal; font-weight: 400; font-display: swap;
  src: url('https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts/webfonts/Vazirmatn-Regular.woff2') format('woff2');
}
@font-face {
  font-family: 'VazirmatnApp';
  font-style: normal; font-weight: 700; font-display: swap;
  src: url('https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts/webfonts/Vazirmatn-Bold.woff2') format('woff2');
}
"""

    /**
     * CSS اصلی. مقادیر رنگ و اندازه از تنظیمات کاربر جایگذاری می‌شوند.
     */
    fun buildCss(
        fontScale: Int,        // درصد، مثلاً 100
        accent: String,        // رنگ تأکید
        rtlEnabled: Boolean,
        persianFont: Boolean,
        compact: Boolean
    ): String {
        val fontStack = if (persianFont)
            "'VazirmatnApp', -apple-system, system-ui, 'Segoe UI', Roboto, sans-serif"
        else
            "-apple-system, system-ui, 'Segoe UI', Roboto, sans-serif"

        val spacing = if (compact) "0.35rem" else "0.75rem"

        val rtlBlock = if (!rtlEnabled) "" else """
/* ═══ رفع چیدمان دوجهته ═══ */

/* عناصری که JS تشخیص داده فارسی‌اند */
[data-fa="1"] {
  direction: rtl !important;
  text-align: right !important;
}

/* هر پاراگراف مستقل جهت‌یابی شود؛ از سرایت جهت جلوگیری می‌کند */
[data-fa="1"] p,
[data-fa="1"] li,
[data-fa="1"] blockquote,
[data-fa="1"] td,
[data-fa="1"] th {
  unicode-bidi: plaintext;
  text-align: right;
}

/* 🔴 حیاتی: کد هرگز راست‌چین نشود */
pre, code, kbd, samp,
pre *, code *,
[data-fa="1"] pre, [data-fa="1"] code,
[data-fa="1"] pre *, [data-fa="1"] code * {
  direction: ltr !important;
  text-align: left !important;
  unicode-bidi: isolate !important;
  font-family: 'SF Mono', Menlo, Consolas, monospace !important;
}

/* عدد، لینک و کلمه‌ی لاتین داخل متن فارسی جدا بماند */
[data-fa="1"] a[href],
[data-fa="1"] .ac-ltr {
  unicode-bidi: isolate;
}

/* لیست‌ها: نقطه و شماره سمت راست */
[data-fa="1"] ul, [data-fa="1"] ol {
  padding-right: 1.5em;
  padding-left: 0;
  list-style-position: outside;
}

/* کادر ورودی */
textarea[data-fa="1"],
[contenteditable="true"][data-fa="1"] {
  direction: rtl !important;
  text-align: right !important;
  unicode-bidi: plaintext;
}
"""

        return """
$FONT_CSS

/* ═══ پایه ═══ */
html, body, button, input, textarea, select,
[contenteditable="true"] {
  font-family: $fontStack !important;
}

body {
  font-size: $fontScale% !important;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

/* خوانایی بهتر برای فارسی */
p, li, td, th, [contenteditable="true"], textarea {
  line-height: 1.9 !important;
  letter-spacing: 0 !important;
  word-spacing: 0.02em;
}

h1, h2, h3, h4 { line-height: 1.6 !important; }

p + p, li + li { margin-top: $spacing; }

/* حذف هایلایت آبی هنگام لمس */
* { -webkit-tap-highlight-color: transparent; }

/* اسکرول‌بار نازک */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-thumb {
  background: ${accent}55; border-radius: 3px;
}
::-webkit-scrollbar-track { background: transparent; }

/* رنگ انتخاب متن */
::selection { background: ${accent}44; }

/* دکمه‌ها کمی گردتر و بزرگ‌تر برای لمس راحت‌تر */
button { border-radius: 10px !important; }

$rtlBlock
""".trimIndent()
    }

    /**
     * جاوااسکریپت تشخیص فارسی و علامت‌گذاری.
     * روی محتوای جدید (استریم پاسخ) هم اعمال می‌شود.
     */
    fun buildScript(rtlEnabled: Boolean, css: String): String {
        val cssJson = org.json.JSONObject.quote(css)
        return """
(function () {
  var STYLE_ID = 'arena-plus-style';

  function applyCss() {
    var old = document.getElementById(STYLE_ID);
    if (old) old.remove();
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = $cssJson;
    (document.head || document.documentElement).appendChild(s);
  }
  applyCss();

  if (!$rtlEnabled) return;

  // بازه‌ی یونیکد عربی/فارسی
  var FA = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
  var FA_G = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/g;
  var LAT_G = /[A-Za-z]/g;

  /** آیا این بلوک عمدتاً فارسی است؟ */
  function isPersian(text) {
    if (!text || text.length < 2) return false;
    if (!FA.test(text)) return false;
    var fa = (text.match(FA_G) || []).length;
    var lat = (text.match(LAT_G) || []).length;
    // آستانه: فارسی حداقل ۳۰٪ از حروف معنادار
    return fa > 0 && fa >= (fa + lat) * 0.30;
  }

  var BLOCKS = 'p,li,td,th,blockquote,h1,h2,h3,h4,h5,h6,figcaption,dd,dt';

  function markTree(root) {
    if (!root || !root.querySelectorAll) return;

    // بلوک‌های متنی
    var nodes = root.querySelectorAll(BLOCKS);
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (el.closest('pre,code')) continue;      // کد را دست نزن
      if (el.dataset.faChecked === '1' && !el.dataset.faDirty) continue;
      var t = el.textContent || '';
      if (isPersian(t)) {
        el.setAttribute('data-fa', '1');
        el.setAttribute('dir', 'rtl');
      } else if (el.getAttribute('data-fa')) {
        el.removeAttribute('data-fa');
        el.removeAttribute('dir');
      }
      el.dataset.faChecked = '1';
    }

    // ظرف‌های پیام (وقتی پاراگراف مشخصی ندارند)
    var containers = root.querySelectorAll('[class*="message"],[class*="markdown"],[class*="prose"],[data-message-author-role]');
    for (var j = 0; j < containers.length; j++) {
      var c = containers[j];
      if (c.querySelector(BLOCKS)) continue;     // فرزند بلوکی دارد، قبلاً رسیدگی شد
      if (isPersian(c.textContent || '')) {
        c.setAttribute('data-fa', '1');
        c.setAttribute('dir', 'rtl');
      }
    }
  }

  /** کادر ورودی: جهت زنده حین تایپ */
  function hookInputs() {
    var inputs = document.querySelectorAll('textarea,[contenteditable="true"]');
    for (var i = 0; i < inputs.length; i++) {
      var el = inputs[i];
      if (el.dataset.faHooked === '1') continue;
      el.dataset.faHooked = '1';
      var update = (function (node) {
        return function () {
          var v = node.value !== undefined ? node.value : node.textContent;
          if (isPersian(v)) {
            node.setAttribute('data-fa', '1');
            node.setAttribute('dir', 'rtl');
          } else {
            node.removeAttribute('data-fa');
            node.setAttribute('dir', 'ltr');
          }
        };
      })(el);
      el.addEventListener('input', update);
      el.addEventListener('focus', update);
      update();
    }
  }

  function runAll() {
    try { markTree(document.body); hookInputs(); } catch (e) {}
  }

  // اجرای اولیه + رصد تغییرات (پاسخ‌ها استریم می‌شوند)
  runAll();
  var pending = null;
  var mo = new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i];
      if (m.type === 'characterData' && m.target.parentElement) {
        var pe = m.target.parentElement.closest(BLOCKS);
        if (pe) pe.dataset.faDirty = '1';
      }
    }
    clearTimeout(pending);
    pending = setTimeout(runAll, 180);
  });
  mo.observe(document.documentElement, {
    childList: true, subtree: true, characterData: true
  });
})();
""".trimIndent()
    }
}
