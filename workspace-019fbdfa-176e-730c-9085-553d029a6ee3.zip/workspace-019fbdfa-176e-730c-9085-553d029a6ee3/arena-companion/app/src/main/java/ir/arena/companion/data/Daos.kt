package ir.arena.companion.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ConversationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: Conversation)

    @Query("SELECT * FROM conversations ORDER BY savedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 200): List<Conversation>

    @Query("SELECT * FROM conversations WHERE profileId = :pid ORDER BY savedAt DESC")
    suspend fun byProfile(pid: String): List<Conversation>

    @Query("SELECT * FROM conversations WHERE starred = 1 ORDER BY savedAt DESC")
    suspend fun starred(): List<Conversation>

    /**
     * جست‌وجوی full-text. FTS4 برای متن فارسی هم کار می‌کند چون
     * توکنایزر پیش‌فرض بر اساس فاصله جدا می‌کند.
     */
    @Query(
        """
        SELECT c.* FROM conversations c
        JOIN conversations_fts f ON c.rowid = f.rowid
        WHERE conversations_fts MATCH :query
        ORDER BY c.savedAt DESC LIMIT 100
        """
    )
    suspend fun search(query: String): List<Conversation>

    @Query("UPDATE conversations SET starred = :value WHERE id = :id")
    suspend fun setStarred(id: String, value: Boolean)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM conversations WHERE profileId = :pid")
    suspend fun deleteByProfile(pid: String)

    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun count(): Int

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun byId(id: String): Conversation?

    // ── پاکسازی ──

    @Query("DELETE FROM conversations WHERE id IN (:ids)")
    suspend fun deleteMany(ids: List<String>)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()

    @Query("DELETE FROM conversations WHERE starred = 0")
    suspend fun deleteUnstarred()

    @Query("DELETE FROM conversations WHERE savedAt < :beforeTs AND starred = 0")
    suspend fun deleteOlderThan(beforeTs: Long)

    @Query("SELECT COUNT(*) FROM conversations WHERE savedAt < :beforeTs AND starred = 0")
    suspend fun countOlderThan(beforeTs: Long): Int

    @Query("SELECT COUNT(*) FROM conversations WHERE starred = 0")
    suspend fun countUnstarred(): Int

    @Query("SELECT COUNT(*) FROM conversations WHERE profileId = :pid")
    suspend fun countByProfile(pid: String): Int

    /** مجموع کاراکترهای ذخیره‌شده — تخمین حجم مصرفی. */
    @Query("SELECT COALESCE(SUM(LENGTH(bodyText)), 0) FROM conversations")
    suspend fun totalChars(): Long
}

@Dao
interface PromptDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: SavedPrompt): Long

    @Query("SELECT * FROM prompts ORDER BY useCount DESC, createdAt DESC")
    suspend fun all(): List<SavedPrompt>

    @Query("SELECT * FROM prompts WHERE category = :cat ORDER BY useCount DESC")
    suspend fun byCategory(cat: String): List<SavedPrompt>

    @Query("SELECT DISTINCT category FROM prompts ORDER BY category")
    suspend fun categories(): List<String>

    @Query("UPDATE prompts SET useCount = useCount + 1 WHERE id = :id")
    suspend fun incrementUse(id: Long)

    @Query("DELETE FROM prompts WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM prompts")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM prompts")
    suspend fun count(): Int
}

@Dao
interface UsageDao {

    @Insert
    suspend fun record(e: UsageEvent)

    @Query("SELECT COUNT(*) FROM usage_events WHERE profileId = :pid AND day = :day")
    suspend fun todayCount(pid: String, day: String): Int

    @Query("SELECT COUNT(*) FROM usage_events WHERE day = :day")
    suspend fun todayTotal(day: String): Int

    @Query(
        """
        SELECT day, COUNT(*) as count FROM usage_events
        WHERE day >= :sinceDay GROUP BY day ORDER BY day
        """
    )
    suspend fun dailyBreakdown(sinceDay: String): List<DailyUsage>

    @Query(
        """
        SELECT profileId, COUNT(*) as count FROM usage_events
        WHERE day >= :sinceDay GROUP BY profileId ORDER BY count DESC
        """
    )
    suspend fun byProfile(sinceDay: String): List<ProfileUsage>

    @Query("SELECT COUNT(*) FROM usage_events WHERE profileId = :pid")
    suspend fun totalForProfile(pid: String): Int

    @Query("DELETE FROM usage_events WHERE day < :beforeDay")
    suspend fun pruneOlderThan(beforeDay: String)

    @Query("DELETE FROM usage_events")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM usage_events")
    suspend fun totalCount(): Int
}
