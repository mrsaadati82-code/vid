package ir.arena.companion.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import ir.arena.companion.R
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.data.Conversation
import ir.arena.companion.databinding.ActivityArchiveBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * آرشیو مکالمات: جست‌وجوی full-text، ستاره‌دار کردن، خواندن آفلاین،
 * و حالت انتخاب چندگانه برای حذف گروهی.
 */
class ArchiveActivity : ThemedActivity() {

    private lateinit var b: ActivityArchiveBinding
    private val db by lazy { AppDatabase.get(this) }

    private var showStarredOnly = false
    private var items: List<Conversation> = emptyList()

    /** حالت انتخاب چندگانه */
    private var selectMode = false
    private val selected = linkedSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityArchiveBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { if (selectMode) exitSelectMode() else finish() }
        b.list.layoutManager = LinearLayoutManager(this)

        b.searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = doSearch(s?.toString().orEmpty())
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
        })

        b.btnStarred.setOnClickListener {
            showStarredOnly = !showStarredOnly
            b.btnStarred.alpha = if (showStarredOnly) 1f else 0.5f
            doSearch(b.searchInput.text.toString())
        }
        b.btnStarred.alpha = 0.5f

        b.btnSelect.setOnClickListener {
            if (selectMode) exitSelectMode() else enterSelectMode()
        }

        // نوار عملیات انتخاب
        b.btnSelectAll.setOnClickListener {
            if (selected.size == items.size) selected.clear()
            else { selected.clear(); items.forEach { selected.add(it.id) } }
            updateSelectionBar(); b.list.adapter?.notifyDataSetChanged()
        }
        b.btnDeleteSelected.setOnClickListener { confirmDeleteSelected() }
        b.btnStarSelected.setOnClickListener { starSelected() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selectMode) exitSelectMode()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        doSearch("")
    }

    // ─────────── حالت انتخاب ───────────

    private fun enterSelectMode() {
        selectMode = true
        selected.clear()
        b.selectionBar.isVisible = true
        b.btnSelect.alpha = 1f
        updateSelectionBar()
        b.list.adapter?.notifyDataSetChanged()
    }

    private fun exitSelectMode() {
        selectMode = false
        selected.clear()
        b.selectionBar.isVisible = false
        b.btnSelect.alpha = 0.6f
        b.list.adapter?.notifyDataSetChanged()
    }

    private fun updateSelectionBar() {
        b.selectionCount.text = getString(R.string.n_selected, selected.size)
        val any = selected.isNotEmpty()
        b.btnDeleteSelected.isEnabled = any
        b.btnStarSelected.isEnabled = any
        b.btnDeleteSelected.alpha = if (any) 1f else 0.4f
        b.btnStarSelected.alpha = if (any) 1f else 0.4f
        b.btnSelectAll.text =
            if (selected.size == items.size && items.isNotEmpty())
                getString(R.string.deselect_all) else getString(R.string.select_all)
    }

    private fun confirmDeleteSelected() {
        val n = selected.size
        if (n == 0) return
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.delete_n_title, n))
            .setMessage(R.string.delete_n_desc)
            .setPositiveButton(R.string.delete) { _, _ ->
                lifecycleScope.launch {
                    db.conversations().deleteMany(selected.toList())
                    exitSelectMode()
                    doSearch(b.searchInput.text.toString())
                    toast(getString(R.string.cleared_n, n))
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun starSelected() {
        lifecycleScope.launch {
            selected.forEach { db.conversations().setStarred(it, true) }
            val n = selected.size
            exitSelectMode()
            doSearch(b.searchInput.text.toString())
            toast(getString(R.string.starred_n, n))
        }
    }

    // ─────────── داده ───────────

    private fun doSearch(query: String) {
        lifecycleScope.launch {
            items = when {
                showStarredOnly -> db.conversations().starred()
                query.isBlank() -> db.conversations().recent()
                else -> runCatching {
                    db.conversations().search("${query.trim()}*")
                }.getOrElse { emptyList() }
            }
            selected.retainAll(items.map { it.id }.toSet())
            b.emptyView.isVisible = items.isEmpty()
            b.emptyView.text = if (query.isBlank())
                getString(R.string.archive_empty) else getString(R.string.no_results)
            b.counter.text = getString(R.string.archive_count, items.size)
            b.list.adapter = Adapter()
            if (selectMode) updateSelectionBar()
        }
    }

    private fun toast(m: String) = Snackbar.make(b.root, m, Snackbar.LENGTH_SHORT).show()

    // ─────────── آداپتر ───────────

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        private val fmt = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault())

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val check: CheckBox = v.findViewById(R.id.check)
            val title: TextView = v.findViewById(R.id.title)
            val snippet: TextView = v.findViewById(R.id.snippet)
            val date: TextView = v.findViewById(R.id.date)
            val star: ImageButton = v.findViewById(R.id.btnStar)
        }

        override fun onCreateViewHolder(p: ViewGroup, vt: Int) = VH(
            LayoutInflater.from(p.context).inflate(R.layout.item_conversation, p, false)
        )

        override fun onBindViewHolder(h: VH, pos: Int) {
            val c = items[pos]
            h.title.text = c.title
            h.snippet.text = c.bodyText.take(140).replace("\n", " ")
            h.date.text = fmt.format(Date(c.savedAt))

            h.check.isVisible = selectMode
            h.star.isVisible = !selectMode
            h.star.alpha = if (c.starred) 1f else 0.3f

            if (selectMode) {
                h.check.setOnCheckedChangeListener(null)
                h.check.isChecked = c.id in selected
                h.check.setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(c.id) else selected.remove(c.id)
                    updateSelectionBar()
                }
            }

            h.star.setOnClickListener {
                lifecycleScope.launch {
                    db.conversations().setStarred(c.id, !c.starred)
                    doSearch(b.searchInput.text.toString())
                }
            }

            h.itemView.setOnClickListener {
                if (selectMode) {
                    h.check.isChecked = !h.check.isChecked
                } else {
                    startActivity(
                        Intent(this@ArchiveActivity, ReaderActivity::class.java)
                            .putExtra("id", c.id)
                    )
                }
            }

            h.itemView.setOnLongClickListener {
                if (!selectMode) {
                    MaterialAlertDialogBuilder(this@ArchiveActivity)
                        .setTitle(c.title)
                        .setItems(arrayOf(
                            getString(R.string.replay_session),
                            getString(R.string.select_mode)
                        )) { _, which ->
                            when (which) {
                                0 -> startActivity(Intent(
                                    this@ArchiveActivity, ReplayActivity::class.java)
                                    .putExtra("id", c.id))
                                1 -> { enterSelectMode(); selected.add(c.id)
                                       updateSelectionBar(); notifyDataSetChanged() }
                            }
                        }
                        .show()
                }
                true
            }
        }


        override fun getItemCount() = items.size
    }
}
