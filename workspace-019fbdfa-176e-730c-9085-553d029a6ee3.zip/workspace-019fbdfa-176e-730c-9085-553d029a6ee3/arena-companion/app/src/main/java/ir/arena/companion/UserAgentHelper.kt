package ir.arena.companion

/**
 * اصلاح User-Agent برای عبور از بلاک «disallowed_useragent» گوگل.
 *
 * پس‌زمینه
 * ---------
 * گوگل از سپتامبر ۲۰۲۱ (و سختگیرانه‌تر از جولای ۲۰۲۳) اجازه نمی‌دهد جریان
 * OAuth داخل WebView تعبیه‌شده اجرا شود و خطای «403: disallowed_useragent»
 * برمی‌گرداند. تشخیص عمدتاً بر پایه‌ی توکن "; wv" در User-Agent است که
 * WebView اندروید به‌صورت خودکار اضافه می‌کند.
 *
 * ⚠️ هشدار مهم
 * -------------
 * حذف این توکن یعنی خودت را به‌جای مرورگر واقعی جا زدن. این کار:
 *   • خلاف سیاست رسمی گوگل است
 *   • ممکن است هر زمان از کار بیفتد (گوگل سیگنال‌های دیگری هم دارد)
 *   • در اپ منتشرشده در Play Store می‌تواند باعث ریجکت یا بن اکانت شود
 *
 * چون این اپ فقط برای استفاده‌ی شخصی و منتشرنشده است، به‌عنوان راهکار عملی
 * پذیرفتنی است. اگر روزی خواستی منتشرش کنی، حتماً به مسیر Custom Tabs
 * (کلاس AuthLauncher) سوییچ کن که مسیر رسمی و پایدار است.
 */
object UserAgentHelper {

    /**
     * توکن‌های نشان‌دهنده‌ی WebView را از UA حذف می‌کند.
     * ورودی نمونه:
     *   Mozilla/5.0 (Linux; Android 14; Pixel 8 Build/UQ1A; wv) AppleWebKit/537.36 ...
     * خروجی:
     *   Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 ... Chrome/120.0.0.0 Mobile Safari/537.36
     */
    fun toBrowserLike(original: String): String {
        var ua = original

        // 1) حذف "; wv" که علامت قطعی WebView است
        ua = ua.replace("; wv)", ")").replace("; wv", "")

        // 2) حذف بخش Build/XXXX که مرورگر واقعی کروم آن را ندارد
        ua = ua.replace(Regex("\\s*Build/[^;)\\s]+"), "")

        // 3) حذف "Version/x.y" که مخصوص WebView است و کروم واقعی ندارد
        ua = ua.replace(Regex("\\s*Version/\\d+(\\.\\d+)*"), "")

        // 4) تمیزکاری فاصله‌ها و نقطه‌ویرگول‌های اضافه
        ua = ua.replace(Regex(";\\s*\\)"), ")")
            .replace(Regex("\\s{2,}"), " ")
            .trim()

        return ua
    }

    /** آیا این UA هنوز نشانه‌ی WebView دارد؟ برای نمایش هشدار در UI. */
    fun looksLikeWebView(ua: String): Boolean =
        ua.contains("; wv", ignoreCase = true) || ua.contains("Version/", ignoreCase = false)
}
