package ir.arena.companion.data

import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.PrimaryKey

/** یک مکالمه‌ی ذخیره‌شده (آرشیو + حالت آفلاین). */
@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey val id: String,
    val profileId: String,
    val title: String,
    val bodyText: String,
    val url: String,
    val savedAt: Long,
    val starred: Boolean = false,
    /** HTML کامل صفحه برای خواندن آفلاین */
    val offlineHtml: String? = null
)

/** جدول جست‌وجوی full-text — روی همان محتوا. */
@Fts4(contentEntity = Conversation::class)
@Entity(tableName = "conversations_fts")
data class ConversationFts(
    val title: String,
    val bodyText: String
)

/** پرامپت ذخیره‌شده در کتابخانه. */
@Entity(tableName = "prompts")
data class SavedPrompt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val category: String = "عمومی",
    val useCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

/** یک رویداد مصرف (هر پیام ارسالی) — برای ردیاب مصرف. */
@Entity(tableName = "usage_events")
data class UsageEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    /** روز به فرم yyyy-MM-dd برای گروه‌بندی سریع */
    val day: String,
    val timestamp: Long = System.currentTimeMillis()
)

/** خروجی تجمیعی مصرف روزانه. */
data class DailyUsage(val day: String, val count: Int)

/** خروجی تجمیعی مصرف هر اکانت. */
data class ProfileUsage(val profileId: String, val count: Int)
