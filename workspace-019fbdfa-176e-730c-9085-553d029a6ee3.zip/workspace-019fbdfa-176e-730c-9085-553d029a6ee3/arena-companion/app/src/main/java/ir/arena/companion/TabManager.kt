package ir.arena.companion

import android.content.Context
import android.webkit.WebView

/**
 * چند «تب» در هر پروفایل.
 *
 * همه‌ی تب‌های یک پروفایل **همان کوکی‌جار** را دارند، پس با یک بار لاگین
 * چند گفت‌وگوی هم‌زمان داری — دقیقاً مثل چند تب مرورگر.
 *
 * برای صرفه‌جویی در حافظه، حداکثر MAX_LIVE تب زنده می‌ماند؛ بقیه آزاد
 * می‌شوند و هنگام بازگشت دوباره لود می‌شوند (URL نگه داشته می‌شود).
 */
class TabManager {

    data class Tab(
        val id: Long,
        val profileId: String,
        var title: String,
        var url: String,
        var webView: WebView? = null
    )

    private val tabs = mutableListOf<Tab>()
    private var nextId = 1L

    /** تب فعال هر پروفایل */
    private val activeByProfile = mutableMapOf<String, Long>()

    fun tabsOf(profileId: String): List<Tab> = tabs.filter { it.profileId == profileId }

    fun countOf(profileId: String) = tabsOf(profileId).size

    fun activeTab(profileId: String): Tab? {
        val id = activeByProfile[profileId]
        return tabs.find { it.id == id && it.profileId == profileId }
            ?: tabsOf(profileId).firstOrNull()?.also { activeByProfile[profileId] = it.id }
    }

    fun setActive(profileId: String, tabId: Long) {
        activeByProfile[profileId] = tabId
    }

    fun newTab(
        context: Context,
        profileId: String,
        url: String = ArenaWebViewFactory.ARENA_HOME,
        title: String = ""
    ): Tab {
        val tab = Tab(
            id = nextId++,
            profileId = profileId,
            title = title.ifBlank { "تب ${countOf(profileId) + 1}" },
            url = url
        )
        tabs.add(tab)
        activeByProfile[profileId] = tab.id
        return tab
    }

    fun find(tabId: Long): Tab? = tabs.find { it.id == tabId }

    /** بستن تب. اگر آخرین تبِ پروفایل باشد بسته نمی‌شود. */
    fun close(tabId: Long): Boolean {
        val tab = tabs.find { it.id == tabId } ?: return false
        if (countOf(tab.profileId) <= 1) return false

        tab.webView?.let { runCatching { it.stopLoading(); it.destroy() } }
        tabs.remove(tab)

        if (activeByProfile[tab.profileId] == tabId) {
            tabsOf(tab.profileId).firstOrNull()?.let {
                activeByProfile[tab.profileId] = it.id
            }
        }
        return true
    }

    fun closeAllOf(profileId: String) {
        tabsOf(profileId).forEach { t ->
            t.webView?.let { runCatching { it.stopLoading(); it.destroy() } }
        }
        tabs.removeAll { it.profileId == profileId }
        activeByProfile.remove(profileId)
    }

    /**
     * آزادسازی WebViewهای قدیمی برای صرفه‌جویی حافظه.
     * URL حفظ می‌شود، پس هنگام بازگشت همان صفحه لود می‌شود.
     */
    fun trimMemory(keepTabId: Long) {
        val live = tabs.filter { it.webView != null }
        if (live.size <= MAX_LIVE) return
        live.filter { it.id != keepTabId }
            .take(live.size - MAX_LIVE)
            .forEach { t ->
                t.webView?.let { wv ->
                    t.url = wv.url ?: t.url
                    runCatching { wv.stopLoading(); wv.destroy() }
                }
                t.webView = null
            }
    }

    fun destroyAll() {
        tabs.forEach { it.webView?.let { wv -> runCatching { wv.destroy() } } }
        tabs.clear()
        activeByProfile.clear()
    }

    companion object {
        const val MAX_LIVE = 4
    }
}
