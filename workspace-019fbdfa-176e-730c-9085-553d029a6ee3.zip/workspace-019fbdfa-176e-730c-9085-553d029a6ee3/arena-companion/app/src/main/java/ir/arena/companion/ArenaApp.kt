package ir.arena.companion

import android.app.Application
import android.os.Build
import android.webkit.WebView

class ArenaApp : Application() {

    lateinit var profiles: ProfileManager
        private set

    override fun onCreate() {
        super.onCreate()
        profiles = ProfileManager(this)

        // دیباگ WebView از طریق chrome://inspect — برای اپ شخصی خیلی به کار می‌آید
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true)
        }
    }
}
