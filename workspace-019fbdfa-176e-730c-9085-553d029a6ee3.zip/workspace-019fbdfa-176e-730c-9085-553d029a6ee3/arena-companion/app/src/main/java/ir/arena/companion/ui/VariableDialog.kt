package ir.arena.companion.ui

import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.arena.companion.R
import ir.arena.companion.data.PromptVariables

/**
 * وقتی پرامپت متغیر دارد، قبل از تزریق مقادیر را می‌پرسد.
 * برای هر {متغیر} یک فیلد می‌سازد.
 */
object VariableDialog {

    fun show(
        context: Context,
        promptBody: String,
        onReady: (String) -> Unit
    ) {
        val vars = PromptVariables.extract(promptBody)
        if (vars.isEmpty()) {
            onReady(promptBody)
            return
        }

        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }

        val fields = LinkedHashMap<String, EditText>()

        vars.forEachIndexed { index, name ->
            container.addView(TextView(context).apply {
                text = name
                textSize = 13f
                alpha = 0.7f
                setPadding(dp(4), if (index == 0) 0 else dp(14), 0, dp(2))
            })

            val input = EditText(context).apply {
                hint = context.getString(R.string.var_value_hint, name)
                inputType = InputType.TYPE_CLASS_TEXT or
                        InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                maxLines = 3
                if (index == 0) requestFocus()
            }
            fields[name] = input
            container.addView(input)
        }

        val scroll = ScrollView(context).apply {
            addView(container)
            isFillViewport = true
        }

        MaterialAlertDialogBuilder(context)
            .setTitle(R.string.fill_variables)
            .setMessage(context.getString(R.string.fill_variables_desc, vars.size))
            .setView(scroll)
            .setPositiveButton(R.string.insert) { _, _ ->
                val values = fields.mapValues { it.value.text.toString().trim() }
                onReady(PromptVariables.fill(promptBody, values))
            }
            .setNeutralButton(R.string.insert_raw) { _, _ -> onReady(promptBody) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
