package ir.arena.companion.data

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import androidx.webkit.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * دانلود فایل در پوشه‌ی اختصاصی «Arena Plus».
 *
 * ═══ چرا دکمه‌ی دانلود کار نمی‌کرد؟ ═══
 * WebView به‌طور پیش‌فرض دانلود را **نادیده می‌گیرد**. باید
 * `setDownloadListener` تنظیم شود وگرنه کلیک روی لینک دانلود هیچ اتفاقی
 * نمی‌افتد. این listener اصلاً وجود نداشت.
 *
 * ═══ سه نوع منبع دانلود ═══
 * ۱. لینک عادی http/https  → دانلود با کوکی پروفایل
 * ۲. data:  (base64)        → مستقیم دیکد و ذخیره
 * ۳. blob:                  → با تزریق JS به data تبدیل می‌شود
 *
 * ═══ محل ذخیره ═══
 * اندروید ۱۰+ : MediaStore با RELATIVE_PATH = "Download/Arena Plus"
 *               بدون نیاز به هیچ مجوزی
 * قدیمی‌تر    : /storage/emulated/0/Download/Arena Plus
 */
object DownloadHelper {

    private const val TAG = "ArenaPlusDL"
    const val FOLDER = "Arena Plus"

    data class Prepared(
        val fileName: String,
        val mimeType: String,
        val url: String
    )

    /** نام فایل تمیز و بدون کاراکتر غیرمجاز. */
    fun resolveFileName(
        url: String,
        contentDisposition: String?,
        mimeType: String?
    ): String {
        var name = runCatching {
            URLUtil.guessFileName(url, contentDisposition, mimeType)
        }.getOrNull() ?: "file"

        // اگر پسوند ندارد از mime حدس بزن
        if (!name.contains('.')) {
            val ext = mimeType?.let {
                MimeTypeMap.getSingleton().getExtensionFromMimeType(it)
            }
            if (!ext.isNullOrBlank()) name = "$name.$ext"
        }

        // کاراکترهای غیرمجاز در نام فایل
        name = name.replace(Regex("""[\\/:*?"<>|]"""), "_").trim()
        if (name.isBlank()) name = "download_${System.currentTimeMillis()}"
        return name.take(120)
    }

    /**
     * آیا می‌توانیم از DownloadManager سیستم استفاده کنیم؟
     *
     * 🔴 باگی که اینجا رفع شد:
     * setDestinationInExternalPublicDir روی اندروید ۱۰+ برای مسیرهای
     * سفارشی داخل Download اغلب SecurityException یا
     * IllegalStateException می‌دهد، چون دسترسی مستقیم به فایل‌سیستم
     * عمومی (Scoped Storage) محدود شده. نتیجه: «دانلود ناموفق بود».
     *
     * حالا روی اندروید ۱۰+ همیشه دستی دانلود می‌کنیم و با MediaStore
     * ذخیره می‌کنیم — که هیچ مجوزی نمی‌خواهد و همیشه کار می‌کند.
     */
    fun canUseSystemManager(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    /** فقط برای اندروید ۹ و پایین‌تر. */
    fun enqueueSystem(
        context: Context,
        url: String,
        fileName: String,
        mimeType: String?,
        userAgent: String?,
        profile: Profile?
    ): Long {
        val req = DownloadManager.Request(Uri.parse(url)).apply {
            setTitle(fileName)
            setDescription(FOLDER)
            setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            setAllowedOverMetered(true)
            setAllowedOverRoaming(true)
            mimeType?.let { setMimeType(it) }
            userAgent?.let { addRequestHeader("User-Agent", it) }

            val cm = profile?.cookieManager ?: CookieManager.getInstance()
            cm.getCookie(url)?.let { addRequestHeader("Cookie", it) }
            addRequestHeader("Referer", "https://arena.ai/")

            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS, "$FOLDER/$fileName"
            )
        }
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(req)
    }

    /**
     * ذخیره‌ی محتوای خام (برای data: و blob:) در پوشه‌ی اختصاصی.
     * @return Uri فایل ذخیره‌شده
     */
    suspend fun saveBytes(
        context: Context,
        bytes: ByteArray,
        fileName: String,
        mimeType: String
    ): Uri = withContext(Dispatchers.IO) {
        android.util.Log.d(TAG, "saveBytes: $fileName (${bytes.size} B, $mimeType)")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER"
                )
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("ساخت فایل ناموفق بود")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: error("نوشتن فایل ناموفق بود")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            android.util.Log.d(TAG, "ذخیره شد: $uri")
            uri
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS
                ), FOLDER
            )
            if (!dir.exists()) dir.mkdirs()
            val f = uniqueFile(dir, fileName)
            f.writeBytes(bytes)
            Uri.fromFile(f)
        }
    }

    /** دانلود دستی با کوکی — وقتی DownloadManager جواب ندهد. */
    suspend fun downloadManually(
        context: Context,
        url: String,
        fileName: String,
        mimeType: String,
        userAgent: String?,
        cookie: String?
    ): Pair<Uri, Long> = withContext(Dispatchers.IO) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30000
            readTimeout = 60000
            instanceFollowRedirects = true
            userAgent?.let { setRequestProperty("User-Agent", it) }
            cookie?.let { setRequestProperty("Cookie", it) }
            setRequestProperty("Referer", "https://arena.ai/")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) {
                error(when (code) {
                    401, 403 -> "دسترسی رد شد (کد $code) — شاید لاگین لازم است"
                    404 -> "فایل پیدا نشد (۴۰۴)"
                    else -> "پاسخ سرور: $code"
                })
            }
            // نوع واقعی را از سرور بگیر؛ دقیق‌تر از حدس WebView است
            val realMime = conn.contentType?.substringBefore(';')?.trim()
                ?.takeIf { it.isNotBlank() } ?: mimeType
            val bytes = conn.inputStream.use { it.readBytes() }
            if (bytes.isEmpty()) error("فایل خالی بود")
            val uri = saveBytes(context, bytes, fileName, realMime)
            uri to bytes.size.toLong()
        } finally {
            conn.disconnect()
        }
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    /**
     * جاوااسکریپتی که blob: را به data: تبدیل می‌کند.
     * blob فقط داخل خود صفحه معنا دارد و از بیرون قابل دانلود نیست،
     * پس باید در همان صفحه خوانده و به کاتلین پاس داده شود.
     */
    fun blobToBase64Script(blobUrl: String, bridgeName: String): String {
        val u = org.json.JSONObject.quote(blobUrl)
        return """
        (function () {
          fetch($u)
            .then(function (r) { return r.blob(); })
            .then(function (b) {
              var fr = new FileReader();
              fr.onloadend = function () {
                window.$bridgeName.onBlobData(fr.result, b.type || '', b.size || 0);
              };
              fr.onerror = function () {
                window.$bridgeName.onBlobError('خواندن فایل ناموفق بود');
              };
              fr.readAsDataURL(b);
            })
            .catch(function (e) {
              window.$bridgeName.onBlobError(String(e));
            });
        })();
        """.trimIndent()
    }

    fun humanSize(bytes: Long): String = when {
        bytes <= 0 -> "—"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        bytes < 1024L * 1024 * 1024 -> String.format("%.1f MB", bytes / 1048576.0)
        else -> String.format("%.2f GB", bytes / 1073741824.0)
    }
}
