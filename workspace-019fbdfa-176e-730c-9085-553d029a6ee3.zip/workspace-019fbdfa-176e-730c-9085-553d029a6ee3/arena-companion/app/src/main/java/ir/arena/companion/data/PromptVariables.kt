package ir.arena.companion.data

/**
 * پشتیبانی از متغیر در پرامپت‌ها.
 *
 * الگو: {نام متغیر}
 * مثال: «متن زیر را به {زبان} ترجمه کن با لحن {لحن}»
 *
 * موقع استفاده، اپ همه‌ی متغیرها را پیدا می‌کند و از کاربر می‌پرسد.
 */
object PromptVariables {

    /** فقط حروف/عدد/فاصله/زیرخط داخل آکولاد — از تطبیق با JSON یا کد جلوگیری می‌کند. */
    private val PATTERN = Regex("""\{([\p{L}\p{N}_][\p{L}\p{N}_ \-]{0,40})\}""")

    /** لیست یکتای متغیرها به ترتیب ظهور. */
    fun extract(body: String): List<String> =
        PATTERN.findAll(body)
            .map { it.groupValues[1].trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .toList()

    fun hasVariables(body: String): Boolean = PATTERN.containsMatchIn(body)

    /** جایگذاری مقادیر. متغیرِ بدون مقدار دست‌نخورده می‌ماند. */
    fun fill(body: String, values: Map<String, String>): String =
        PATTERN.replace(body) { m ->
            val key = m.groupValues[1].trim()
            values[key]?.takeIf { it.isNotBlank() } ?: m.value
        }

    /** پیش‌نمایش کوتاه برای نمایش در لیست. */
    fun preview(body: String, maxLen: Int = 110): String =
        body.replace("\n", " ").trim().let {
            if (it.length <= maxLen) it else it.take(maxLen) + "…"
        }
}
