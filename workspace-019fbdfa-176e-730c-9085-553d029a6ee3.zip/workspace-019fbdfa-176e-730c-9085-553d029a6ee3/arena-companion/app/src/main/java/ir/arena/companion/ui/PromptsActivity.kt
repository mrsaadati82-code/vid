package ir.arena.companion.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.arena.companion.R
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.data.PromptVariables
import ir.arena.companion.data.SavedPrompt
import ir.arena.companion.databinding.ActivityPromptsBinding
import kotlinx.coroutines.launch

/**
 * کتابخانه‌ی پرامپت. انتخاب یک پرامپت آن را به MainActivity برمی‌گرداند
 * تا در textarea تزریق شود.
 */
class PromptsActivity : ThemedActivity() {

    private lateinit var b: ActivityPromptsBinding
    private val db by lazy { AppDatabase.get(this) }
    private var items: List<SavedPrompt> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPromptsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.list.layoutManager = LinearLayoutManager(this)
        b.btnAdd.setOnClickListener { showEditor(null) }

        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            items = db.prompts().all()
            if (items.isEmpty()) seedDefaults()
            b.emptyView.isVisible = items.isEmpty()
            b.list.adapter = Adapter()
        }
    }

    /** چند پرامپت نمونه برای شروع. */
    private suspend fun seedDefaults() {
        val seeds = listOf(
            SavedPrompt(
                title = "خلاصه‌ی فارسی",
                body = "متن زیر را به فارسی روان و دقیق خلاصه کن. نکات کلیدی را بولت کن:\n\n",
                category = "نویسندگی"
            ),
            SavedPrompt(
                title = "بازبینی کد",
                body = "این کد را بررسی کن. باگ‌ها، مشکلات امنیتی و نکات کارایی را " +
                        "با اولویت‌بندی بگو. راه‌حل هر مورد را هم بنویس:\n\n```\n\n```",
                category = "کدنویسی"
            ),
            SavedPrompt(
                title = "توضیح ساده",
                body = "مفهوم {موضوع} را طوری توضیح بده که یک {مخاطب} بفهمد. " +
                        "از مثال روزمره استفاده کن و از اصطلاح تخصصی پرهیز کن.",
                category = "آموزش"
            ),
            SavedPrompt(
                title = "ایمیل حرفه‌ای",
                body = "یک ایمیل {لحن} به {گیرنده} بنویس درباره‌ی {موضوع}. " +
                        "کوتاه و شفاف باشد، حداکثر سه پاراگراف.",
                category = "نویسندگی"
            ),
            SavedPrompt(
                title = "مقایسه‌ی فنی",
                body = "{گزینه اول} را با {گزینه دوم} مقایسه کن. " +
                        "جدول مزایا و معایب بده و در پایان بگو برای {کاربرد} کدام بهتر است.",
                category = "تحقیق"
            ),
            SavedPrompt(
                title = "ترجمه‌ی طبیعی",
                body = "متن زیر را به فارسی ترجمه کن. ترجمه باید طبیعی و روان باشد، " +
                        "نه تحت‌اللفظی:\n\n",
                category = "نویسندگی"
            )
        )
        seeds.forEach { db.prompts().upsert(it) }
        items = db.prompts().all()
    }

    private fun showEditor(existing: SavedPrompt?) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 24, 56, 8)
        }
        val titleInput = EditText(this).apply {
            hint = getString(R.string.prompt_title_hint)
            setText(existing?.title ?: "")
        }
        val catInput = EditText(this).apply {
            hint = getString(R.string.prompt_category_hint)
            setText(existing?.category ?: "عمومی")
        }
        val bodyInput = EditText(this).apply {
            hint = getString(R.string.prompt_body_hint)
            setText(existing?.body ?: "")
            minLines = 4
            maxLines = 10
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
        }
        val hint = android.widget.TextView(this).apply {
            text = getString(R.string.variable_hint)
            textSize = 12f
            alpha = 0.65f
            setPadding(4, 16, 4, 0)
        }
        container.addView(titleInput); container.addView(catInput)
        container.addView(bodyInput); container.addView(hint)

        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) R.string.new_prompt else R.string.edit_prompt)
            .setView(container)
            .setPositiveButton(R.string.save) { _, _ ->
                val t = titleInput.text.toString().trim()
                val bd = bodyInput.text.toString()
                if (t.isBlank() || bd.isBlank()) return@setPositiveButton
                lifecycleScope.launch {
                    db.prompts().upsert(
                        SavedPrompt(
                            id = existing?.id ?: 0,
                            title = t,
                            body = bd,
                            category = catInput.text.toString().trim().ifBlank { "عمومی" },
                            useCount = existing?.useCount ?: 0
                        )
                    )
                    refresh()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val title: TextView = v.findViewById(R.id.title)
            val body: TextView = v.findViewById(R.id.body)
            val cat: TextView = v.findViewById(R.id.category)
            val edit: ImageButton = v.findViewById(R.id.btnEdit)
        }

        override fun onCreateViewHolder(p: ViewGroup, vt: Int) = VH(
            LayoutInflater.from(p.context).inflate(R.layout.item_prompt, p, false)
        )

        override fun onBindViewHolder(h: VH, pos: Int) {
            val p = items[pos]
            h.title.text = p.title
            h.body.text = p.body.take(110).replace("\n", " ")
            val vars = PromptVariables.extract(p.body)
            h.cat.text = buildString {
                append(p.category)
                if (vars.isNotEmpty()) {
                    append("  •  ")
                    append(getString(R.string.n_variables, vars.size))
                }
                if (p.useCount > 0) {
                    append("  •  ")
                    append(getString(R.string.used_n, p.useCount))
                }
            }

            h.itemView.setOnClickListener {
                lifecycleScope.launch { db.prompts().incrementUse(p.id) }
                setResult(Activity.RESULT_OK, Intent().putExtra("prompt", p.body))
                finish()
            }
            h.edit.setOnClickListener { showEditor(p) }
            h.itemView.setOnLongClickListener {
                MaterialAlertDialogBuilder(this@PromptsActivity)
                    .setTitle(R.string.delete)
                    .setMessage(p.title)
                    .setPositiveButton(R.string.delete) { _, _ ->
                        lifecycleScope.launch { db.prompts().delete(p.id); refresh() }
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
                true
            }
        }

        override fun getItemCount() = items.size
    }
}
