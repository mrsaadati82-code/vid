package ir.arena.companion.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * لیدربورد از دیتاست *رسمی* Arena روی Hugging Face.
 *
 * چرا این منبع؟
 *  • خود تیم Arena منتشرش می‌کند → فقط مدل‌هایی که واقعاً در Arena
 *    ارزیابی شده‌اند در آن هستند. مدل بیرونی وارد نمی‌شود.
 *  • استفاده از آن مجاز است (برخلاف اسکرپ کردن سایت).
 */
object LeaderboardRepo {

    private const val BASE = "https://datasets-server.huggingface.co"
    private const val DATASET = "lmarena-ai%2Fleaderboard-dataset"

    data class Entry(
        val rank: Int,
        val modelName: String,
        val organization: String,
        val license: String,
        val rating: Double,
        val ratingLower: Double,
        val ratingUpper: Double,
        val voteCount: Int
    ) {
        val isOpenWeight: Boolean
            get() = !license.equals("Proprietary", ignoreCase = true)
    }

    /** یک دسته‌ی قابل انتخاب در UI. */
    data class Board(
        val id: String,        // شناسه‌ی داخلی
        val title: String,     // عنوان فارسی
        val config: String,    // config در دیتاست
        val category: String   // category داخل آن config
    )

    /**
     * دسته‌بندی‌ها — همگی از داده‌ی واقعی Arena تأیید شده‌اند.
     *
     * ⚠️ درباره‌ی فارسی: Arena رتبه‌بندی زبانی دارد (انگلیسی، چینی، فرانسه،
     * آلمانی، ژاپنی، کره‌ای، روسی، اسپانیایی، لهستانی) اما **فارسی جزو
     * آن‌ها نیست** — چون حجم رأی فارسی به حد نصاب آماری نمی‌رسد.
     * نزدیک‌ترین گزینه «غیرانگلیسی» است که در فهرست آمده.
     */
    val BOARDS: List<Board> = listOf(
        // ── کلی ──
        Board("overall", "کلی", "text", "overall"),
        Board("hard", "پرامپت سخت", "text", "hard_prompts"),
        Board("expert", "سطح متخصص", "text", "expert"),
        Board("multi_turn", "گفت‌وگوی چندمرحله‌ای", "text", "multi_turn"),
        Board("instruction", "پیروی از دستور", "text", "instruction_following"),

        // ── تخصصی ──
        Board("coding", "کدنویسی", "text", "coding"),
        Board("math", "ریاضی", "text", "math"),
        Board("creative", "نویسندگی خلاق", "text", "creative_writing"),
        Board("longer", "پاسخ بلند", "text", "longer_query"),

        // ── زبان ──
        Board("english", "انگلیسی", "text", "english"),
        Board("non_english", "غیرانگلیسی", "text", "non_english"),
        Board("chinese", "چینی", "text", "chinese"),
        Board("russian", "روسی", "text", "russian"),
        Board("spanish", "اسپانیایی", "text", "spanish"),
        Board("french", "فرانسوی", "text", "french"),
        Board("german", "آلمانی", "text", "german"),
        Board("japanese", "ژاپنی", "text", "japanese"),
        Board("korean", "کره‌ای", "text", "korean"),

        // ── صنعت ──
        Board("ind_software", "نرم‌افزار و IT", "text",
            "industry_software_and_it_services"),
        Board("ind_science", "علوم", "text",
            "industry_life_and_physical_and_social_science"),
        Board("ind_math", "ریاضیات کاربردی", "text", "industry_mathematical"),
        Board("ind_medicine", "پزشکی", "text", "industry_medicine_and_healthcare"),
        Board("ind_legal", "حقوقی و دولتی", "text", "industry_legal_and_government"),
        Board("ind_business", "کسب‌وکار و مالی", "text",
            "industry_business_and_management_and_financial_operations"),
        Board("ind_writing", "ادبیات و زبان", "text",
            "industry_writing_and_literature_and_language"),
        Board("ind_media", "سرگرمی و رسانه", "text",
            "industry_entertainment_and_sports_and_media"),

        // ── سایر حالت‌ها ──
        Board("webdev", "توسعه‌ی وب", "webdev", "overall"),
        Board("vision", "بینایی و تصویر", "vision", "overall"),
        Board("document", "درک اسناد", "document", "overall"),
        Board("search", "جست‌وجو و تحقیق", "search", "overall"),
        Board("agent", "ایجنت", "agent", "overall"),
        Board("t2i", "تولید تصویر", "text_to_image", "overall"),
        Board("image_edit", "ویرایش تصویر", "image_edit", "overall"),
        Board("t2v", "تولید ویدیو", "text_to_video", "overall"),
        Board("i2v", "تصویر به ویدیو", "image_to_video", "overall"),
        Board("video_edit", "ویرایش ویدیو", "video_edit", "overall")
    )

    private val cache = mutableMapOf<String, Pair<Long, List<Entry>>>()
    private const val TTL = 6 * 60 * 60 * 1000L   // ۶ ساعت

    suspend fun fetch(board: Board, force: Boolean = false): List<Entry> =
        withContext(Dispatchers.IO) {
            val key = "${board.config}/${board.category}"
            if (!force) {
                cache[key]?.let { (ts, data) ->
                    if (System.currentTimeMillis() - ts < TTL) return@withContext data
                }
            }

            val where = java.net.URLEncoder.encode("\"category\"='${board.category}'", "UTF-8")
            val url = "$BASE/filter?dataset=$DATASET&config=${board.config}" +
                    "&split=latest&where=$where&limit=150"

            val json = httpGet(url) ?: return@withContext cache[key]?.second ?: emptyList()

            val rows = JSONObject(json).optJSONArray("rows") ?: return@withContext emptyList()
            val list = ArrayList<Entry>(rows.length())
            for (i in 0 until rows.length()) {
                val r = rows.getJSONObject(i).optJSONObject("row") ?: continue
                list.add(
                    Entry(
                        rank = r.optDouble("rank", 0.0).toInt(),
                        modelName = r.optString("model_name"),
                        organization = r.optString("organization"),
                        license = r.optString("license"),
                        rating = r.optDouble("rating", 0.0),
                        ratingLower = r.optDouble("rating_lower", 0.0),
                        ratingUpper = r.optDouble("rating_upper", 0.0),
                        voteCount = r.optDouble("vote_count", 0.0).toInt()
                    )
                )
            }
            val sorted = list.sortedBy { if (it.rank > 0) it.rank else Int.MAX_VALUE }
            cache[key] = System.currentTimeMillis() to sorted
            sorted
        }

    private fun httpGet(url: String): String? = runCatching {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
        }
        conn.use { if (it.responseCode in 200..299) it.inputStream.bufferedReader().readText() else null }
    }.getOrNull()

    private inline fun <T> HttpURLConnection.use(block: (HttpURLConnection) -> T): T =
        try { block(this) } finally { disconnect() }
}
