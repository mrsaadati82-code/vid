package ir.arena.companion

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Message
import android.view.ViewGroup
import android.view.Window
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.Profile

/**
 * مدیریت پنجره‌ی پاپ‌آپ لاگین گوگل — داخل همین اپ.
 *
 * 🔴 باگی که اینجا رفع شد
 * ------------------------
 * قبلاً `setSupportMultipleWindows(true)` تنظیم شده بود ولی `onCreateWindow`
 * پیاده‌سازی نشده بود. جریان OAuth گوگل با `window.open()` یک پنجره‌ی جدید
 * باز می‌کند. وقتی WebView نمی‌داند با آن چه کند، لینک به مرورگر بیرونی
 * می‌رفت — جایی که:
 *
 *   • کوکی‌های پروفایل اپ وجود ندارند
 *   • state/nonce ساخته‌شده در اپ با درخواست مرورگر نمی‌خواند
 *   → نتیجه: خطای 400 و شکست لاگین
 *
 * حالا پاپ‌آپ در یک Dialog داخل اپ باز می‌شود که **همان پروفایل و همان
 * کوکی‌جار** والد را دارد، پس چرخه‌ی OAuth کامل و بدون خطا بسته می‌شود.
 */
object AuthPopupHandler {

    /**
     * در onCreateWindow صدا زده می‌شود.
     * @return true اگر پنجره ساخته شد (باید resultMsg ارسال شود)
     */
    @SuppressLint("SetJavaScriptEnabled")
    fun handleCreateWindow(
        context: Context,
        profile: Profile?,
        parentUserAgent: String?,
        resultMsg: Message?,
        onClosed: () -> Unit
    ): Boolean {
        if (resultMsg == null) return false

        val popupWebView = WebView(context)

        // همان پروفایل والد → همان کوکی‌جار → سشن مشترک
        if (profile != null) {
            runCatching {
                androidx.webkit.WebViewCompat.setProfile(popupWebView, profile.name)
            }
        }

        popupWebView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            // 🔴 حیاتی: همان UA والد، وگرنه گوگل «disallowed_useragent» می‌دهد
            parentUserAgent?.let { userAgentString = it }
        }

        val cookieManager = profile?.cookieManager ?: CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(popupWebView, true)

        val dialog = Dialog(context, android.R.style.Theme_Material_Light_NoActionBar).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(popupWebView)
            window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnDismissListener {
                runCatching {
                    popupWebView.stopLoading()
                    popupWebView.destroy()
                }
                onClosed()
            }
        }

        popupWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = false   // همه‌چیز داخل همین پاپ‌آپ

            override fun onPageFinished(view: WebView?, url: String?) {
                cookieManager.flush()
                // وقتی به arena.ai برگشتیم یعنی لاگین تمام شده
                if (url != null && url.contains("arena.ai") &&
                    !url.contains("accounts.google.com")
                ) {
                    runCatching { if (dialog.isShowing) dialog.dismiss() }
                }
            }
        }

        popupWebView.webChromeClient = object : WebChromeClient() {
            override fun onCloseWindow(window: WebView?) {
                runCatching { if (dialog.isShowing) dialog.dismiss() }
            }

            // پاپ‌آپ تودرتو (گوگل گاهی می‌سازد)
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                nestedMsg: Message?
            ): Boolean = handleCreateWindow(
                context, profile, parentUserAgent, nestedMsg, onClosed
            )
        }

        dialog.show()

        // اتصال پاپ‌آپ به WebView والد
        (resultMsg.obj as? WebView.WebViewTransport)?.webView = popupWebView
        resultMsg.sendToTarget()
        return true
    }
}
