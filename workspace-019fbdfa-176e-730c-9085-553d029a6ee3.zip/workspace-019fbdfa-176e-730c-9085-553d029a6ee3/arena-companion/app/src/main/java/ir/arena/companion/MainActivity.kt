package ir.arena.companion

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.data.Conversation
import ir.arena.companion.data.AppearancePrefs
import ir.arena.companion.data.DownloadHelper
import ir.arena.companion.data.DownloadInterceptor
import ir.arena.companion.data.DownloadItem
import ir.arena.companion.data.PageExtractor
import ir.arena.companion.data.UsageEvent
import ir.arena.companion.databinding.ActivityMainBinding
import ir.arena.companion.ui.ArchiveActivity
import ir.arena.companion.ui.LeaderboardActivity
import ir.arena.companion.ui.PromptsActivity
import ir.arena.companion.ui.AppearanceActivity
import ir.arena.companion.ui.DownloadsActivity
import ir.arena.companion.ui.ReplayActivity
import ir.arena.companion.ui.StorageActivity
import ir.arena.companion.ui.VariableDialog
import ir.arena.companion.ui.UsageActivity
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ir.arena.companion.ui.ThemedActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var pm: ProfileManager
    private val db by lazy { AppDatabase.get(this) }

    private var currentWebView: WebView? = null
    private lateinit var stripAdapter: AvatarStripAdapter
    private lateinit var tabAdapter: TabStripAdapter

    private val tabs = TabManager()

    /** اکانت‌هایی که محتوای جدید دارند (بج قرمز) */
    private val badgedProfiles = mutableSetOf<String>()

    // برای دانلود blob: — بین درخواست و پاسخ JS نگه داشته می‌شود
    private var pendingBlobName: String? = null
    private var pendingBlobProfile: String? = null
    private var pendingBlobSource: String? = null

    private val promptLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.getStringExtra("prompt")?.let { body ->
                // اگر پرامپت {متغیر} دارد، اول مقادیر را بپرس
                VariableDialog.show(this, body) { filled -> injectPrompt(filled) }
            }
        }
    }

    private lateinit var uploadHandler: FileUploadHandler

    private val uploadLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        uploadHandler.onResult(result.resultCode, result.data)
    }

    private val appearanceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        // اگر تم عوض شده باشد، ThemedActivity.onResume خودش recreate می‌کند.
        // در غیر این صورت فقط استایل صفحه‌های وب را تازه می‌کنیم.
        reapplyStyleToAll()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uploadHandler = FileUploadHandler(uploadLauncher)

        pm = (application as ArenaApp).profiles
        if (!pm.isSupported) showUnsupportedWarning()

        // رنگ نوار وضعیت با سطح اپ یکی شود
        window.statusBarColor = com.google.android.material.color.MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorSurface
        )

        setupAvatarStrip()
        setupTabStrip()
        setupButtons()
        setupBackHandling()

        switchToProfile(pm.activeProfileId)
    }

    // ═══════════ نوار آواتار ═══════════

    private fun setupAvatarStrip() {
        stripAdapter = AvatarStripAdapter(
            profiles = pm.listProfiles(),
            activeId = pm.activeProfileId,
            badges = badgedProfiles,
            onClick = { p ->
                if (p.id != pm.activeProfileId) switchToProfile(p.id) else showProfileSheet()
            },
            onLongClick = { showProfileSheet() }
        )
        binding.avatarStrip.layoutManager =
            LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        binding.avatarStrip.adapter = stripAdapter
    }

    private fun refreshStrip() {
        stripAdapter.update(pm.listProfiles(), pm.activeProfileId, badgedProfiles)
    }

    private fun setupButtons() {
        binding.btnHome.setOnClickListener {
            currentWebView?.loadUrl(ArenaWebViewFactory.ARENA_HOME)
        }
        binding.btnLeaderboard.setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }
        binding.btnRefresh.setOnClickListener {
            binding.errorView.isVisible = false
            currentWebView?.reload()
        }
        binding.btnMenu.setOnClickListener { showOverflowMenu(binding.btnMenu) }
        binding.btnRetry.setOnClickListener {
            binding.errorView.isVisible = false
            currentWebView?.reload()
        }
    }

    // ═══════════ سوییچ پروفایل ═══════════

    private fun setupTabStrip() {
        tabAdapter = TabStripAdapter(
            items = emptyList(), activeTabId = -1L,
            onSelect = { t -> showTab(t) },
            onClose = { t -> closeTab(t) },
            onNew = { newTab() }
        )
        binding.tabStrip.layoutManager =
            LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        binding.tabStrip.adapter = tabAdapter
    }

    private fun refreshTabs() {
        val pid = pm.activeProfileId
        val list = tabs.tabsOf(pid)
        val active = tabs.activeTab(pid)?.id ?: -1L
        tabAdapter.update(list, active)
        // نوار تب همیشه هست تا دکمه‌ی + در دسترس باشد
        binding.tabStrip.isVisible = true
    }

    private fun switchToProfile(profileId: String) {
        detachCurrent()
        pm.activeProfileId = profileId
        badgedProfiles.remove(profileId)

        // اگر این پروفایل تبی ندارد، یکی بساز
        if (tabs.countOf(profileId) == 0) tabs.newTab(this, profileId)
        val tab = tabs.activeTab(profileId)!!

        attachTab(tab)
        refreshStrip()
        refreshTabs()
    }

    private fun newTab() {
        val pid = pm.activeProfileId
        detachCurrent()
        val tab = tabs.newTab(this, pid)
        attachTab(tab)
        refreshTabs()
        toast(getString(R.string.new_tab_created))
    }

    private fun showTab(tab: TabManager.Tab) {
        if (tabs.activeTab(tab.profileId)?.id == tab.id && currentWebView != null) return
        detachCurrent()
        tabs.setActive(tab.profileId, tab.id)
        attachTab(tab)
        refreshTabs()
    }

    private fun closeTab(tab: TabManager.Tab) {
        val wasActive = tabs.activeTab(tab.profileId)?.id == tab.id
        if (wasActive) detachCurrent()
        if (!tabs.close(tab.id)) {
            toast(getString(R.string.last_tab_cannot_close)); return
        }
        tabs.activeTab(pm.activeProfileId)?.let { attachTab(it) }
        refreshTabs()
    }

    /** WebView فعلی را از صفحه جدا می‌کند (نابود نمی‌کند). */
    private fun detachCurrent() {
        currentWebView?.let { wv ->
            pm.flushCookies(pm.activeProfileId)
            binding.webContainer.removeView(wv)
            wv.onPause()
        }
        currentWebView = null
    }

    private fun attachTab(tab: TabManager.Tab) {
        val wv = tab.webView ?: createWebViewFor(tab).also { tab.webView = it }
        binding.webContainer.addView(
            wv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        wv.onResume()
        currentWebView = wv
        binding.errorView.isVisible = false
        if (wv.url == null) wv.loadUrl(tab.url)
        tabs.trimMemory(tab.id)
    }

    private fun createWebViewFor(tab: TabManager.Tab): WebView {
        val profileId = tab.profileId
        val wv = WebView(this)

        val attached = pm.attach(wv, profileId)
        if (!attached && pm.isSupported) toast(getString(R.string.profile_attach_failed))

        val profile = pm.getProfileObject(profileId)
        ArenaWebViewFactory.configure(wv, profile, spoofUserAgent = true)
        wv.addJavascriptInterface(Bridge(profileId), PageExtractor.BRIDGE)

        // استایل فارسی قبل از رندر — از پرش جلوگیری می‌کند
        runCatching {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(
                    androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT)) {
                androidx.webkit.WebViewCompat.addDocumentStartJavaScript(
                    wv, appearance.script(), setOf("https://arena.ai")
                )
                androidx.webkit.WebViewCompat.addDocumentStartJavaScript(
                    wv, DownloadInterceptor.script(PageExtractor.BRIDGE),
                    setOf("https://arena.ai")
                )
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                binding.progressBar.isVisible = true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                binding.progressBar.isVisible = false
                pm.flushCookies(profileId)
                view?.evaluateJavascript(PageExtractor.SCRIPT, null)
                view?.evaluateJavascript(appearance.script(), null)
                // رهگیر دانلود: کلیک روی <a download> و blob را می‌قاپد
                view?.evaluateJavascript(
                    DownloadInterceptor.script(PageExtractor.BRIDGE), null
                )

                url?.let { tab.url = it }
                view?.title?.takeIf { it.isNotBlank() }?.let {
                    tab.title = it.take(22)
                    runOnUiThread { refreshTabs() }
                }

                if (profileId != pm.activeProfileId) {
                    badgedProfiles.add(profileId)
                    runOnUiThread { refreshStrip() }
                }
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    binding.errorView.isVisible = true
                    binding.progressBar.isVisible = false
                    }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val host = request.url.host ?: return false
                val internal = host.endsWith("arena.ai") ||
                        host.endsWith("google.com") ||
                        host.endsWith("googleapis.com") ||
                        host.endsWith("gstatic.com") ||
                        host.endsWith("googleusercontent.com") ||
                        host.endsWith("cloudflare.com") ||
                        host.endsWith("hcaptcha.com") ||
                        host.endsWith("recaptcha.net")
                if (internal) return false
                return runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url)); true
                }.getOrDefault(false)
            }
        }

        // 🔴 رفع باگ دانلود:
        // WebView بدون DownloadListener هر درخواست دانلود را بی‌صدا دور می‌ریزد.
        // این listener سه حالت را پوشش می‌دهد: لینک عادی، data: و blob:
        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            handleDownload(url, userAgent, contentDisposition, mimeType, profileId, profile, wv)
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.isVisible = newProgress < 100
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                title?.takeIf { it.isNotBlank() }?.let {
                    tab.title = it.take(22); refreshTabs()
                }
            }

            // 🔴 بدون این، دکمه‌ی آپلود در سایت هیچ کاری نمی‌کند
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: android.webkit.ValueCallback<Array<android.net.Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean = uploadHandler.onShowFileChooser(filePathCallback, fileChooserParams)

            override fun onCreateWindow(
                view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
            ): Boolean = AuthPopupHandler.handleCreateWindow(
                context = this@MainActivity,
                profile = profile,
                parentUserAgent = wv.settings.userAgentString,
                resultMsg = resultMsg,
                onClosed = { currentWebView?.reload() }
            )
        }

        return wv
    }

    /** بعد از تغییر تنظیمات ظاهر، همه‌ی تب‌های زنده به‌روز شوند. */
    private fun reapplyStyleToAll() {
        val js = appearance.script()
        tabs.tabsOf(pm.activeProfileId).forEach { it.webView?.evaluateJavascript(js, null) }
        currentWebView?.evaluateJavascript(js, null)
    }

    // ═══════════ دانلود ═══════════

    private var lastLongPressImage: String? = null

    private fun offerSaveImage(src: String) {
        if (src == lastLongPressImage) return
        lastLongPressImage = src
        binding.root.postDelayed({ lastLongPressImage = null }, 1500)

        Snackbar.make(binding.root, getString(R.string.save_image_q), Snackbar.LENGTH_LONG)
            .setAction(R.string.save) {
                currentWebView?.evaluateJavascript(
                    DownloadInterceptor.fetchImageScript(src, PageExtractor.BRIDGE), null
                )
            }.show()
    }


    private fun handleDownload(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?,
        profileId: String,
        profile: androidx.webkit.Profile?,
        webView: WebView
    ) {
        val fileName = DownloadHelper.resolveFileName(url, contentDisposition, mimeType)
        val mime = mimeType ?: "application/octet-stream"

        when {
            url.startsWith("blob:") -> {
                // blob فقط داخل خود صفحه معنا دارد → با JS به base64 تبدیل شود
                toast(getString(R.string.dl_preparing))
                pendingBlobName = fileName
                pendingBlobProfile = profileId
                pendingBlobSource = url
                webView.evaluateJavascript(
                    DownloadHelper.blobToBase64Script(url, PageExtractor.BRIDGE), null
                )
            }

            url.startsWith("data:") -> saveDataUri(url, fileName, mime, profileId, url)

            else -> {
                // 🔴 روی اندروید ۱۰+ همیشه دستی: DownloadManager با مسیر
                // سفارشی داخل Download اغلب SecurityException می‌دهد.
                if (!DownloadHelper.canUseSystemManager()) {
                    manualDownload(url, fileName, mime, userAgent, profile, profileId)
                    return
                }
                val ok = runCatching {
                    DownloadHelper.enqueueSystem(
                        this, url, fileName, mimeType, userAgent, profile
                    )
                }.isSuccess
                if (ok) {
                    lifecycleScope.launch {
                        db.downloads().insert(
                            DownloadItem(
                                fileName = fileName, mimeType = mime, sourceUrl = url,
                                localUri = "", sizeBytes = 0, profileId = profileId,
                                status = DownloadItem.STATUS_PENDING
                            )
                        )
                    }
                    showDownloadStarted(fileName)
                } else {
                    manualDownload(url, fileName, mime, userAgent, profile, profileId)
                }
            }
        }
    }

    private fun manualDownload(
        url: String, fileName: String, mime: String,
        userAgent: String?, profile: androidx.webkit.Profile?, profileId: String
    ) {
        toast(getString(R.string.dl_starting))
        lifecycleScope.launch {
            val cookie = (profile?.cookieManager
                ?: android.webkit.CookieManager.getInstance()).getCookie(url)
            runCatching {
                DownloadHelper.downloadManually(
                    this@MainActivity, url, fileName, mime, userAgent, cookie
                )
            }.onSuccess { (uri, size) ->
                db.downloads().insert(
                    DownloadItem(
                        fileName = fileName, mimeType = mime, sourceUrl = url,
                        localUri = uri.toString(), sizeBytes = size,
                        profileId = profileId, status = DownloadItem.STATUS_DONE
                    )
                )
                showDownloadDone(fileName)
            }.onFailure { e ->
                db.downloads().insert(
                    DownloadItem(
                        fileName = fileName, mimeType = mime, sourceUrl = url,
                        localUri = "", sizeBytes = 0, profileId = profileId,
                        status = DownloadItem.STATUS_FAILED,
                        error = e.message?.take(160)
                    )
                )
                Snackbar.make(
                    binding.root,
                    getString(R.string.dl_failed_reason, e.message ?: "?"),
                    Snackbar.LENGTH_LONG
                ).setAction(R.string.dl_open_manager) {
                    startActivity(Intent(this@MainActivity, DownloadsActivity::class.java))
                }.show()
            }
        }
    }

    private fun saveDataUri(
        dataUrl: String, fileName: String, mime: String,
        profileId: String, source: String
    ) {
        lifecycleScope.launch {
            runCatching {
                val comma = dataUrl.indexOf(',')
                require(comma > 0) { "data URI نامعتبر" }
                val header = dataUrl.substring(0, comma)
                val payload = dataUrl.substring(comma + 1)
                val bytes = if (header.contains("base64", true)) {
                    android.util.Base64.decode(payload, android.util.Base64.DEFAULT)
                } else {
                    java.net.URLDecoder.decode(payload, "UTF-8").toByteArray()
                }
                val realMime = header.removePrefix("data:")
                    .substringBefore(';').ifBlank { mime }
                val uri = DownloadHelper.saveBytes(
                    this@MainActivity, bytes, fileName, realMime
                )
                Triple(uri, bytes.size.toLong(), realMime)
            }.onSuccess { (uri, size, realMime) ->
                db.downloads().insert(
                    DownloadItem(
                        fileName = fileName, mimeType = realMime,
                        sourceUrl = source.take(200), localUri = uri.toString(),
                        sizeBytes = size, profileId = profileId,
                        status = DownloadItem.STATUS_DONE
                    )
                )
                showDownloadDone(fileName)
            }.onFailure { toast(getString(R.string.dl_failed)) }
        }
    }

    private fun showDownloadStarted(name: String) {
        Snackbar.make(
            binding.root,
            getString(R.string.dl_started, name),
            Snackbar.LENGTH_LONG
        ).setAction(R.string.dl_open_manager) {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }.show()
    }

    private fun showDownloadDone(name: String) {
        Snackbar.make(
            binding.root,
            getString(R.string.dl_saved, name, DownloadHelper.FOLDER),
            Snackbar.LENGTH_LONG
        ).setAction(R.string.dl_open_manager) {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }.show()
    }

    // ═══════════ پل JS ═══════════

    private inner class Bridge(private val profileId: String) {

        @JavascriptInterface
        fun saveConversation(title: String, body: String, url: String) {
            if (body.length < 60) return
            lifecycleScope.launch {
                val id = sha1(url + "|" + title)
                db.conversations().upsert(
                    Conversation(
                        id = id,
                        profileId = profileId,
                        title = title.ifBlank { getString(R.string.untitled) },
                        bodyText = body,
                        url = url,
                        savedAt = System.currentTimeMillis()
                    )
                )
            }
        }

        /** رهگیر JS شروع دانلود را اعلام کرد. */
        @JavascriptInterface
        fun onDownloadStart(fileName: String) {
            runOnUiThread { toast(getString(R.string.dl_preparing)) }
        }

        /** محتوای فایل به‌صورت data URI رسید — از هر منبعی. */
        @JavascriptInterface
        fun onFileData(dataUrl: String, mime: String, fileName: String) {
            if (!dataUrl.startsWith("data:")) {
                runOnUiThread { toast(getString(R.string.dl_failed)) }
                return
            }
            val safeName = DownloadHelper.resolveFileName(
                fileName, null, mime.ifBlank { null }
            )
            runOnUiThread {
                saveDataUri(
                    dataUrl, safeName,
                    mime.ifBlank { "application/octet-stream" },
                    profileId, fileName
                )
            }
        }

        @JavascriptInterface
        fun onFileError(msg: String) {
            runOnUiThread {
                Snackbar.make(
                    binding.root,
                    getString(R.string.dl_failed_reason, msg.take(90)),
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }

        /** لانگ‌پرس روی تصویر → پیشنهاد ذخیره. */
        @JavascriptInterface
        fun onImageLongPress(src: String) {
            runOnUiThread { offerSaveImage(src) }
        }

        @JavascriptInterface
        fun onBlobData(dataUrl: String, mime: String, size: Double) {
            val name = pendingBlobName ?: return
            val src = pendingBlobSource ?: ""
            pendingBlobName = null; pendingBlobSource = null
            runOnUiThread {
                saveDataUri(dataUrl, name, mime.ifBlank { "application/octet-stream" },
                    profileId, src)
            }
        }

        @JavascriptInterface
        fun onBlobError(msg: String) {
            pendingBlobName = null; pendingBlobSource = null
            runOnUiThread { toast(getString(R.string.dl_failed)) }
        }

        @JavascriptInterface
        fun recordSend() {
            lifecycleScope.launch {
                db.usage().record(UsageEvent(profileId = profileId, day = todayKey()))
            }
        }
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun todayKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)

    private fun injectPrompt(text: String) {
        currentWebView?.evaluateJavascript(PageExtractor.injectPromptScript(text)) { r ->
            if (r?.contains("not-found") == true) toast(getString(R.string.no_input_found))
        }
    }

    // ═══════════ BottomSheet اکانت‌ها ═══════════

    private fun showProfileSheet() {
        val sheet = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.sheet_profiles, null)
        sheet.setContentView(view)

        // ✅ باز شدن کامل تا دکمه‌ی «افزودن» همیشه دیده شود
        sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        sheet.behavior.skipCollapsed = true

        val profiles = pm.listProfiles()
        view.findViewById<TextView>(R.id.accountCount).text =
            getString(R.string.n_accounts, profiles.size)

        val list = view.findViewById<RecyclerView>(R.id.profileList)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = ProfileListAdapter(
            profiles = profiles,
            activeId = pm.activeProfileId,
            loggedInIds = tabs.tabsOf(pm.activeProfileId).mapNotNull {
                if (it.webView?.url != null) it.profileId else null }.toSet(),
            onSelect = { p ->
                sheet.dismiss()
                if (p.id != pm.activeProfileId) switchToProfile(p.id)
            },
            onMore = { p, anchor -> showProfileMenu(p, anchor, sheet) }
        )

        view.findViewById<LinearLayout>(R.id.btnAddAccount).setOnClickListener {
            sheet.dismiss(); showAddProfileDialog()
        }
        sheet.show()
    }

    private fun showProfileMenu(
        p: ProfileManager.ArenaProfile, anchor: View, parent: BottomSheetDialog
    ) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, getString(R.string.rename))
            menu.add(0, 2, 1, getString(R.string.change_color))
            menu.add(0, 3, 2, getString(R.string.sign_out))
            if (pm.listProfiles().size > 1) menu.add(0, 4, 3, getString(R.string.delete_account))
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> showRenameDialog(p, parent)
                    2 -> showColorPicker(p, parent)
                    3 -> confirmSignOut(p, parent)
                    4 -> confirmDelete(p, parent)
                }
                true
            }
            show()
        }
    }

    private fun showAddProfileDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.account_name_hint)
            setPadding(56, 40, 56, 40)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_account)
            .setMessage(R.string.add_account_desc)
            .setView(input)
            .setPositiveButton(R.string.create) { _, _ ->
                val name = input.text.toString().trim()
                    .ifBlank { getString(R.string.account_n, pm.listProfiles().size + 1) }
                val p = pm.addProfile(name)
                switchToProfile(p.id)
                toast(getString(R.string.account_created, p.label))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showRenameDialog(p: ProfileManager.ArenaProfile, sheet: BottomSheetDialog) {
        val input = EditText(this).apply {
            setText(p.label); setSelection(p.label.length); setPadding(56, 40, 56, 40)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.rename)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotBlank()) { pm.renameProfile(p.id, n); refreshStrip(); sheet.dismiss() }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showColorPicker(p: ProfileManager.ArenaProfile, sheet: BottomSheetDialog) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.change_color)
            .setItems(resources.getStringArray(R.array.color_names)) { _, which ->
                pm.changeColor(p.id, which); refreshStrip(); sheet.dismiss()
            }
            .show()
    }

    private fun confirmSignOut(p: ProfileManager.ArenaProfile, sheet: BottomSheetDialog) {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.sign_out_title, p.label))
            .setMessage(R.string.sign_out_desc)
            .setPositiveButton(R.string.sign_out) { _, _ ->
                pm.signOut(p.id)
                if (p.id == pm.activeProfileId) {
                    currentWebView?.loadUrl(ArenaWebViewFactory.ARENA_HOME)
                } else {
                    tabs.closeAllOf(p.id)
                }
                sheet.dismiss(); toast(getString(R.string.signed_out, p.label))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDelete(p: ProfileManager.ArenaProfile, sheet: BottomSheetDialog) {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.delete_title, p.label))
            .setMessage(R.string.delete_desc)
            .setPositiveButton(R.string.delete) { _, _ ->
                tabs.closeAllOf(p.id)
                lifecycleScope.launch { db.conversations().deleteByProfile(p.id) }
                pm.deleteProfile(p.id)
                sheet.dismiss()
                switchToProfile(pm.activeProfileId)
                refreshStrip()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ═══════════ منوی اصلی ═══════════

    private fun showOverflowMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, getString(R.string.archive))
            menu.add(0, 2, 1, getString(R.string.prompt_library))
            menu.add(0, 3, 2, getString(R.string.usage_tracker))
            menu.add(0, 9, 3, getString(R.string.storage_manager))
            menu.add(0, 12, 4, getString(R.string.downloads))
            menu.add(0, 10, 5, getString(R.string.appearance))
            menu.add(0, 11, 5, getString(R.string.new_tab))
            menu.add(0, 4, 3, getString(R.string.leaderboard))
            menu.add(0, 5, 4, getString(R.string.reload))
            menu.add(0, 6, 5, getString(R.string.open_in_browser))
            menu.add(0, 7, 6, getString(R.string.share))
            menu.add(0, 8, 7, getString(R.string.diagnostics))
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> startActivity(Intent(this@MainActivity, ArchiveActivity::class.java))
                    2 -> promptLauncher.launch(
                        Intent(this@MainActivity, PromptsActivity::class.java)
                    )
                    3 -> startActivity(Intent(this@MainActivity, UsageActivity::class.java))
                    9 -> startActivity(Intent(this@MainActivity, StorageActivity::class.java))
                    10 -> appearanceLauncher.launch(
                        Intent(this@MainActivity, AppearanceActivity::class.java))
                    11 -> newTab()
                    12 -> startActivity(
                        Intent(this@MainActivity, DownloadsActivity::class.java))
                    4 -> startActivity(Intent(this@MainActivity, LeaderboardActivity::class.java))
                    5 -> currentWebView?.reload()
                    6 -> currentWebView?.url?.let {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)))
                    }
                    7 -> currentWebView?.url?.let { url ->
                        startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url)
                            }, getString(R.string.share)
                        ))
                    }
                    8 -> showDiagnostics()
                }
                true
            }
            show()
        }
    }

    private fun showDiagnostics() {
        val ua = currentWebView?.settings?.userAgentString ?: "—"
        lifecycleScope.launch {
            val convs = db.conversations().count()
            val msg = buildString {
                appendLine("پشتیبانی چندپروفایلی: ${if (pm.isSupported) "✅ بله" else "❌ خیر"}")
                appendLine("تعداد اکانت‌ها: ${pm.listProfiles().size}")
                appendLine("اکانت فعال: ${pm.activeProfile().label}")
                appendLine("تب‌های باز: ${tabs.countOf(pm.activeProfileId)}")
                appendLine("مکالمات آرشیوشده: $convs")
                appendLine()
                appendLine("مثل WebView دیده می‌شود؟ " +
                        if (UserAgentHelper.looksLikeWebView(ua)) "⚠️ بله" else "✅ خیر")
                appendLine()
                appendLine("User-Agent:")
                appendLine(ua)
            }
            MaterialAlertDialogBuilder(this@MainActivity)
                .setTitle(R.string.diagnostics)
                .setMessage(msg)
                .setPositiveButton(R.string.ok, null)
                .show()
        }
    }

    private fun showUnsupportedWarning() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.device_limit)
            .setMessage(R.string.device_limit_desc)
            .setPositiveButton(R.string.ok, null)
            .show()
    }

    // ═══════════ سایر ═══════════

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = currentWebView
                if (wv != null && wv.canGoBack()) wv.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
    }

    private fun toast(msg: String) =
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()

    override fun onPause() {
        super.onPause()
        pm.flushAll()
    }

    override fun onDestroy() {
        pm.flushAll()
        currentWebView = null
        tabs.destroyAll()
        super.onDestroy()
    }

    companion object {
        /** نوار تب همیشه دیده شود یا فقط وقتی بیش از یک تب هست */
        const val SHOW_TAB_BAR_ALWAYS = true
    }
}
