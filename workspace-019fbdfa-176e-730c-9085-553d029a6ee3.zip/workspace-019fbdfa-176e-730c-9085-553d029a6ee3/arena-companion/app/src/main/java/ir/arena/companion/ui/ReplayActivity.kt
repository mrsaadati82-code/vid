package ir.arena.companion.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import ir.arena.companion.R
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.data.AppearancePrefs
import ir.arena.companion.databinding.ActivityReplayBinding
import kotlinx.coroutines.launch
import kotlin.math.max

/**
 * بازپخش مکالمه با انیمیشن تایپ.
 *
 * چرا مفید است: یک گفت‌وگوی خوب را می‌خواهی نشان بدهی، ولی اسکرین‌شات
 * ناقص است. اینجا مکالمه دوباره «زنده» پخش می‌شود — قابل ضبط با
 * اسکرین‌رکوردر گوشی برای اشتراک‌گذاری.
 */
class ReplayActivity : ThemedActivity() {

    private lateinit var b: ActivityReplayBinding
    private val handler = Handler(Looper.getMainLooper())

    private var fullText = ""
    private var pos = 0
    private var playing = false
    private var speed = 2          // ۱=آرام ۲=معمولی ۳=سریع ۴=خیلی سریع
    private var isPersian = false

    private val tick = object : Runnable {
        override fun run() {
            if (!playing) return
            val step = when (speed) {
                1 -> 2; 2 -> 6; 3 -> 16; else -> 40
            }
            pos = (pos + step).coerceAtMost(fullText.length)
            render()
            if (pos >= fullText.length) {
                playing = false
                updateControls()
            } else {
                // ۳۳ms ≈ ۳۰fps — روان است و بار کمتری روی layout می‌گذارد
                handler.postDelayed(this, 33L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityReplayBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.btnPlay.setOnClickListener { toggle() }
        b.btnRestart.setOnClickListener { restart() }
        b.btnSpeed.setOnClickListener { cycleSpeed() }

        b.seek.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    sb: android.widget.SeekBar?, p: Int, fromUser: Boolean
                ) {
                    if (fromUser && fullText.isNotEmpty()) {
                        pos = (fullText.length * p / 100).coerceIn(0, fullText.length)
                        autoFollow = true
                        b.btnFollow.isVisible = false
                        render()
                    }
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {
                    playing = false; updateControls()
                }
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })

        // تشخیص اسکرول دستی کاربر
        b.scroll.setOnTouchListener { v, _ ->
            autoFollow = false
            b.btnFollow.isVisible = true
            v.performClick(); false
        }
        b.btnFollow.setOnClickListener {
            autoFollow = true
            b.btnFollow.isVisible = false
            render()
        }
        b.btnFollow.isVisible = false

        val id = intent.getStringExtra("id") ?: run { finish(); return }
        load(id)
    }

    private fun load(id: String) {
        lifecycleScope.launch {
            val c = AppDatabase.get(this@ReplayActivity).conversations().byId(id)
            if (c == null) { finish(); return@launch }

            b.title.text = c.title
            fullText = c.bodyText
            isPersian = detectPersian(fullText)

            // چیدمان متن بر اساس زبان
            b.content.textDirection =
                if (isPersian) android.view.View.TEXT_DIRECTION_RTL
                else android.view.View.TEXT_DIRECTION_LTR
            b.content.textAlignment =
                if (isPersian) android.view.View.TEXT_ALIGNMENT_VIEW_START
                else android.view.View.TEXT_ALIGNMENT_VIEW_START

            val prefs = AppearancePrefs(this@ReplayActivity)
            b.content.textSize = 15f * prefs.fontScale / 100f

            pos = 0
            render()
            // شروع خودکار
            playing = true
            updateControls()
            handler.post(tick)
        }
    }

    private fun detectPersian(t: String): Boolean {
        val fa = t.count { it in '\u0600'..'\u06FF' }
        val lat = t.count { it in 'A'..'Z' || it in 'a'..'z' }
        return fa > 0 && fa >= (fa + lat) * 0.30
    }

    /** آیا کاربر خودش اسکرول کرده؟ اگر بله، دنبال‌کردن خودکار متوقف شود. */
    private var autoFollow = true

    private fun render(scrollToEnd: Boolean = true) {
        b.content.text = fullText.substring(0, pos)
        val pct = if (fullText.isEmpty()) 0
        else (pos * 100 / max(1, fullText.length))
        b.seek.progress = pct
        b.progressLabel.text = getString(R.string.replay_progress, pct)

        // 🔴 رفع لرزش:
        // قبلاً fullScroll در هر فریم (۱۶ms) صدا زده می‌شد. این با
        // layout مجدد TextView تداخل می‌کرد و باعث پرش شدید می‌شد.
        // حالا مستقیم scrollY را ست می‌کنیم — بدون انیمیشن، بدون post،
        // و فقط وقتی واقعاً لازم است.
        if (scrollToEnd && autoFollow) {
            b.scroll.post {
                val target = (b.content.height - b.scroll.height + b.scroll.paddingTop
                        + b.scroll.paddingBottom).coerceAtLeast(0)
                if (target != b.scroll.scrollY) b.scroll.scrollY = target
            }
        }
    }

    private fun toggle() {
        if (pos >= fullText.length) { restart(); return }
        playing = !playing
        updateControls()
        if (playing) handler.post(tick)
    }

    private fun restart() {
        pos = 0
        playing = true
        render()
        updateControls()
        handler.post(tick)
    }

    private fun cycleSpeed() {
        speed = if (speed >= 4) 1 else speed + 1
        updateControls()
    }

    private fun updateControls() {
        b.btnPlay.setImageResource(
            if (playing) R.drawable.ic_pause else R.drawable.ic_play
        )
        b.btnSpeed.text = "${speed}×"
    }

    override fun onPause() {
        super.onPause()
        playing = false
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
