package ir.arena.companion.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import ir.arena.companion.R
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.data.DownloadHelper
import ir.arena.companion.data.DownloadItem
import ir.arena.companion.databinding.ActivityDownloadsBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** مدیریت دانلودها — باز کردن، اشتراک‌گذاری، حذف. */
class DownloadsActivity : ThemedActivity() {

    private lateinit var b: ActivityDownloadsBinding
    private val db by lazy { AppDatabase.get(this) }
    private var items: List<DownloadItem> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDownloadsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.list.layoutManager = LinearLayoutManager(this)

        b.btnOpenFolder.setOnClickListener { openFolder() }
        b.btnClearAll.setOnClickListener { confirmClearAll() }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            items = db.downloads().all()
            val total = db.downloads().totalBytes()
            b.subtitle.text = getString(
                R.string.dl_summary, items.size, DownloadHelper.humanSize(total)
            )
            b.emptyView.isVisible = items.isEmpty()
            b.list.adapter = Adapter()
        }
    }

    /** باز کردن پوشه‌ی Arena Plus در فایل‌منیجر. */
    private fun openFolder() {
        val tried = listOf(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(
                    Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FArena%20Plus"),
                    "vnd.android.document/directory"
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            },
            Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS)
        )
        for (i in tried) {
            try { startActivity(i); return } catch (_: ActivityNotFoundException) {}
        }
        toast(getString(R.string.dl_folder_hint))
    }

    private fun openFile(d: DownloadItem) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(d.localUri), d.mimeType.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            toast(getString(R.string.dl_no_app))
        } catch (_: Exception) {
            toast(getString(R.string.dl_open_failed))
        }
    }

    private fun shareFile(d: DownloadItem) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = d.mimeType.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, Uri.parse(d.localUri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            startActivity(Intent.createChooser(intent, getString(R.string.share)))
        }.onFailure { toast(getString(R.string.dl_open_failed)) }
    }

    private fun confirmDelete(d: DownloadItem) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.dl_remove_title)
            .setMessage(getString(R.string.dl_remove_desc, d.fileName))
            .setPositiveButton(R.string.delete) { _, _ ->
                lifecycleScope.launch {
                    // فایل واقعی هم پاک شود
                    runCatching {
                        contentResolver.delete(Uri.parse(d.localUri), null, null)
                    }
                    db.downloads().delete(d.id)
                    refresh()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmClearAll() {
        if (items.isEmpty()) { toast(getString(R.string.nothing_to_clear)); return }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.dl_clear_list)
            .setMessage(R.string.dl_clear_list_desc)
            .setPositiveButton(R.string.clear) { _, _ ->
                lifecycleScope.launch { db.downloads().deleteAll(); refresh() }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(m: String) = Snackbar.make(b.root, m, Snackbar.LENGTH_SHORT).show()

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        private val fmt = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault())

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: TextView = v.findViewById(R.id.icon)
            val name: TextView = v.findViewById(R.id.name)
            val meta: TextView = v.findViewById(R.id.meta)
            val more: ImageButton = v.findViewById(R.id.btnMore)
        }

        override fun onCreateViewHolder(p: ViewGroup, vt: Int) = VH(
            LayoutInflater.from(p.context).inflate(R.layout.item_download, p, false)
        )

        override fun onBindViewHolder(h: VH, pos: Int) {
            val d = items[pos]
            h.icon.text = iconFor(d.mimeType, d.fileName)
            h.name.text = d.fileName

            h.meta.text = when (d.status) {
                DownloadItem.STATUS_PENDING -> getString(R.string.dl_in_progress)
                DownloadItem.STATUS_FAILED ->
                    getString(R.string.dl_failed_reason, d.error ?: "")
                else -> "${DownloadHelper.humanSize(d.sizeBytes)}  •  ${fmt.format(Date(d.createdAt))}"
            }

            h.itemView.setOnClickListener {
                if (d.status == DownloadItem.STATUS_DONE) openFile(d)
                else toast(getString(R.string.dl_not_ready))
            }

            h.more.setOnClickListener { anchor ->
                android.widget.PopupMenu(this@DownloadsActivity, anchor).apply {
                    menu.add(0, 1, 0, getString(R.string.open))
                    menu.add(0, 2, 1, getString(R.string.share))
                    menu.add(0, 3, 2, getString(R.string.dl_copy_link))
                    menu.add(0, 4, 3, getString(R.string.delete))
                    setOnMenuItemClickListener { mi ->
                        when (mi.itemId) {
                            1 -> openFile(d)
                            2 -> shareFile(d)
                            3 -> {
                                val cm = getSystemService(CLIPBOARD_SERVICE)
                                        as android.content.ClipboardManager
                                cm.setPrimaryClip(
                                    android.content.ClipData.newPlainText("url", d.sourceUrl)
                                )
                                toast(getString(R.string.copied))
                            }
                            4 -> confirmDelete(d)
                        }
                        true
                    }
                    show()
                }
            }
        }

        override fun getItemCount() = items.size

        private fun iconFor(mime: String, name: String): String {
            val n = name.lowercase()
            return when {
                mime.startsWith("image/") -> "🖼️"
                mime.startsWith("video/") -> "🎬"
                mime.startsWith("audio/") -> "🎵"
                mime.contains("pdf") || n.endsWith(".pdf") -> "📕"
                mime.contains("zip") || n.endsWith(".zip") || n.endsWith(".rar") -> "🗜️"
                n.endsWith(".json") || n.endsWith(".xml") || n.endsWith(".csv") -> "📊"
                mime.startsWith("text/") || n.endsWith(".md") || n.endsWith(".txt") -> "📄"
                n.endsWith(".apk") -> "📦"
                else -> "📁"
            }
        }
    }
}
