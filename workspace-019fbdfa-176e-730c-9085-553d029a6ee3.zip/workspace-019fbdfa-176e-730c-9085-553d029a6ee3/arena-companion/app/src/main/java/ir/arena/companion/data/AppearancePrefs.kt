package ir.arena.companion.data

import android.content.Context

/** تنظیمات ظاهر و چیدمان. */
class AppearancePrefs(context: Context) {

    private val p = context.getSharedPreferences("appearance", Context.MODE_PRIVATE)

    /** اصلاح چیدمان راست‌به‌چپ */
    var rtlFix: Boolean
        get() = p.getBoolean("rtl", true)
        set(v) = p.edit().putBoolean("rtl", v).apply()

    /** فونت وزیرمتن */
    var persianFont: Boolean
        get() = p.getBoolean("font", true)
        set(v) = p.edit().putBoolean("font", v).apply()

    /** اندازه‌ی فونت به درصد (۸۰ تا ۱۵۰) */
    var fontScale: Int
        get() = p.getInt("scale", 100).coerceIn(80, 150)
        set(v) = p.edit().putInt("scale", v.coerceIn(80, 150)).apply()

    /** فشرده‌سازی فاصله‌ها */
    var compact: Boolean
        get() = p.getBoolean("compact", false)
        set(v) = p.edit().putBoolean("compact", v).apply()

    /** ایندکس تم رنگی */
    var themeIndex: Int
        get() = p.getInt("theme", 0).coerceIn(0, THEMES.size - 1)
        set(v) = p.edit().putInt("theme", v.coerceIn(0, THEMES.size - 1)).apply()

    val accent: String get() = THEMES[themeIndex].accent

    /** CSS نهایی بر اساس تنظیمات فعلی */
    fun css(): String = PersianStyle.buildCss(
        fontScale = fontScale,
        accent = accent,
        rtlEnabled = rtlFix,
        persianFont = persianFont,
        compact = compact
    )

    /** اسکریپت نهایی */
    fun script(): String = PersianStyle.buildScript(rtlFix, css())

    data class Theme(val name: String, val accent: String, val preview: Int)

    companion object {
        val THEMES = listOf(
            Theme("بنفش", "#7C3AED", 0xFF7C3AED.toInt()),
            Theme("آبی", "#2563EB", 0xFF2563EB.toInt()),
            Theme("سبز", "#059669", 0xFF059669.toInt()),
            Theme("نارنجی", "#EA580C", 0xFFEA580C.toInt()),
            Theme("صورتی", "#DB2777", 0xFFDB2777.toInt()),
            Theme("فیروزه‌ای", "#0891B2", 0xFF0891B2.toInt())
        )
    }
}
