package ir.arena.companion.data

/**
 * رهگیری دانلود در سطح جاوااسکریپت.
 *
 * ═══ چرا لازم است؟ ═══
 * `WebView.setDownloadListener` فقط وقتی صدا زده می‌شود که مرورگر به یک
 * ناوبری واقعی برسد که نمی‌تواند رندرش کند. اما Arena مثل اکثر SPAها
 * این‌طور دانلود می‌کند:
 *
 *     const url = URL.createObjectURL(blob)
 *     const a = document.createElement('a')
 *     a.href = url; a.download = 'image.png'
 *     a.click()                    ← ناوبری نیست، فقط کلیک DOM
 *     URL.revokeObjectURL(url)     ← بلافاصله blob را نابود می‌کند
 *
 * در این حالت DownloadListener هرگز صدا زده نمی‌شود.
 *
 * ═══ راه‌حل ═══
 * ۱. کلیک روی هر <a download> را در فاز capture می‌قاپیم
 * ۲. URL.revokeObjectURL را موقتاً به تعویق می‌اندازیم (۱۵ ثانیه)،
 *    وگرنه blob قبل از خواندن نابود می‌شود
 * ۳. محتوا را با fetch+FileReader به base64 تبدیل و به کاتلین می‌دهیم
 * ۴. تصاویر <img> هم با نگه‌داشتن انگشت قابل ذخیره می‌شوند
 */
object DownloadInterceptor {

    fun script(bridge: String): String = """
(function () {
  if (window.__apDownloadHook) return;
  window.__apDownloadHook = true;

  // ── ۱) revokeObjectURL را به تعویق بینداز ──
  // بعضی سایت‌ها بلافاصله بعد از click آن را صدا می‌زنند و blob می‌میرد.
  var origRevoke = URL.revokeObjectURL.bind(URL);
  URL.revokeObjectURL = function (u) {
    setTimeout(function () { try { origRevoke(u); } catch (e) {} }, 15000);
  };

  function nameFrom(a, fallbackExt) {
    var n = (a && a.getAttribute && a.getAttribute('download')) || '';
    n = String(n).trim();
    if (!n) {
      try {
        var p = new URL(a.href, location.href).pathname.split('/').pop();
        if (p && p.indexOf('.') > 0) n = decodeURIComponent(p);
      } catch (e) {}
    }
    if (!n) n = 'arena_' + Date.now() + (fallbackExt || '');
    return n;
  }

  function sendBlob(blobUrl, fileName) {
    try { window.$bridge.onDownloadStart(fileName); } catch (e) {}
    fetch(blobUrl)
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.blob();
      })
      .then(function (b) {
        if (b.size > 60 * 1024 * 1024) {
          throw new Error('فایل بزرگ‌تر از ۶۰ مگابایت است');
        }
        var fr = new FileReader();
        fr.onloadend = function () {
          try {
            window.$bridge.onFileData(String(fr.result), b.type || '', fileName);
          } catch (e) {}
        };
        fr.onerror = function () {
          try { window.$bridge.onFileError('خواندن فایل ناموفق بود'); } catch (e) {}
        };
        fr.readAsDataURL(b);
      })
      .catch(function (e) {
        try { window.$bridge.onFileError(String(e && e.message || e)); } catch (x) {}
      });
  }

  // ── ۲) کلیک روی لینک دانلود ──
  document.addEventListener('click', function (ev) {
    var el = ev.target;
    for (var i = 0; i < 6 && el; i++) {
      if (el.tagName === 'A' && el.href) {
        var isDl = el.hasAttribute('download');
        var href = el.href;
        if (isDl || href.indexOf('blob:') === 0 || href.indexOf('data:') === 0) {
          ev.preventDefault();
          ev.stopPropagation();
          var fname = nameFrom(el, '');
          if (href.indexOf('data:') === 0) {
            try { window.$bridge.onFileData(href, '', fname); } catch (e) {}
          } else {
            sendBlob(href, fname);
          }
          return;
        }
      }
      el = el.parentElement;
    }
  }, true);

  // ── ۳) رهگیری a.click() برنامه‌نویسی‌شده ──
  // بعضی سایت‌ها لینک را به DOM اضافه نمی‌کنند، مستقیم click() می‌زنند.
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      var href = this.href || '';
      if (this.hasAttribute('download') ||
          href.indexOf('blob:') === 0 || href.indexOf('data:') === 0) {
        var fname = nameFrom(this, '');
        if (href.indexOf('data:') === 0) {
          window.$bridge.onFileData(href, '', fname);
        } else {
          sendBlob(href, fname);
        }
        return;
      }
    } catch (e) {}
    return origClick.apply(this, arguments);
  };

  // ── ۴) ذخیره‌ی تصویر با نگه‌داشتن انگشت ──
  var pressTimer = null;
  document.addEventListener('touchstart', function (ev) {
    var img = ev.target;
    if (!img || img.tagName !== 'IMG' || !img.src) return;
    pressTimer = setTimeout(function () {
      try { window.$bridge.onImageLongPress(img.src); } catch (e) {}
    }, 650);
  }, true);
  ['touchend', 'touchmove', 'touchcancel'].forEach(function (t) {
    document.addEventListener(t, function () { clearTimeout(pressTimer); }, true);
  });
})();
""".trimIndent()

    /** تبدیل یک URL تصویر به base64 — برای ذخیره با لانگ‌پرس. */
    fun fetchImageScript(url: String, bridge: String): String {
        val u = org.json.JSONObject.quote(url)
        return """
        (function () {
          fetch($u).then(function (r) { return r.blob(); })
            .then(function (b) {
              var fr = new FileReader();
              fr.onloadend = function () {
                var n = 'image_' + Date.now() +
                        ((b.type && b.type.indexOf('png') >= 0) ? '.png' : '.jpg');
                window.$bridge.onFileData(String(fr.result), b.type || '', n);
              };
              fr.readAsDataURL(b);
            })
            .catch(function (e) {
              window.$bridge.onFileError(String(e && e.message || e));
            });
        })();
        """.trimIndent()
    }
}
