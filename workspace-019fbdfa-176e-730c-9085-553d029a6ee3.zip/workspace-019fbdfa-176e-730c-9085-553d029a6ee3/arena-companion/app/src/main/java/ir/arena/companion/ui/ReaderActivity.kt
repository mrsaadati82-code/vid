package ir.arena.companion.ui

import android.os.Bundle
import android.webkit.WebView
import androidx.lifecycle.lifecycleScope
import ir.arena.companion.data.AppDatabase
import ir.arena.companion.databinding.ActivityReaderBinding
import kotlinx.coroutines.launch

/**
 * خواندن آفلاین یک مکالمه‌ی ذخیره‌شده.
 * هیچ درخواست شبکه‌ای نمی‌زند — همه‌چیز از دیتابیس محلی است.
 */
class ReaderActivity : ThemedActivity() {

    private lateinit var b: ActivityReaderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityReaderBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }

        val id = intent.getStringExtra("id") ?: run { finish(); return }

        // آفلاین کامل: بارگذاری از شبکه ممنوع
        b.reader.settings.apply {
            javaScriptEnabled = false
            blockNetworkLoads = true
            blockNetworkImage = true
            textZoom = 105
        }

        lifecycleScope.launch {
            val c = AppDatabase.get(this@ReaderActivity).conversations().byId(id)
            if (c == null) { finish(); return@launch }
            b.title.text = c.title
            b.reader.loadDataWithBaseURL(null, buildHtml(c.title, c.bodyText),
                "text/html", "UTF-8", null)
        }
    }

    private fun buildHtml(title: String, body: String): String {
        val safe = body
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("\n", "<br/>")
        return """
        <!DOCTYPE html><html><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          :root { color-scheme: light dark; }
          body { font-family: -apple-system, system-ui, sans-serif;
                 line-height: 1.75; padding: 18px 16px 40px;
                 font-size: 15px; word-wrap: break-word; }
          h1 { font-size: 18px; margin: 0 0 14px; }
          @media (prefers-color-scheme: dark) {
            body { background: #111318; color: #e3e3e6; }
          }
        </style></head>
        <body><h1>${title.replace("<", "&lt;")}</h1><div>$safe</div></body></html>
        """.trimIndent()
    }

    override fun onDestroy() {
        b.reader.destroy()
        super.onDestroy()
    }
}
