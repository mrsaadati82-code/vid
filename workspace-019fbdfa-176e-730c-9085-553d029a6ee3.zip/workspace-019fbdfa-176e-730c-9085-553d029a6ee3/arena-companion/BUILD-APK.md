# راهنمای گرفتن خروجی APK — از صفر

اگر تا حالا از اپ اندروید خروجی نگرفتی، این راهنما قدم‌به‌قدم می‌بردت تا فایل APK
روی گوشیت نصب بشه.

**خلاصه‌ی مسیر:** نصب Android Studio ← باز کردن پروژه ← دکمه‌ی Build ← انتقال APK به گوشی.

⏱ بار اول حدود **۴۰ تا ۹۰ دقیقه** طول می‌کشه (بیشترش دانلوده). دفعات بعد ۲ دقیقه.

---

## 🔑 اول این را بفهم: Debug در برابر Release

این مهم‌ترین نکته‌ایه که تازه‌کارها گیجشون می‌کنه:

| | **Debug APK** | **Release APK** |
|---|---|---|
| ساختش | یک کلیک | نیاز به ساخت کلید امضا |
| امضا | خودکار با کلید موقت | با کلید خودت |
| نصب روی گوشی | ✅ بله | ✅ بله |
| حجم | بزرگ‌تر | کوچک‌تر |
| سرعت | کمی کندتر | بهینه |
| **برای تو** | ✅ **همین کافیه** | فقط اگر خواستی به کسی بدی |

> 💡 **برای استفاده‌ی شخصی، Debug APK کاملاً کافیه.** فرقی در عملکرد اپ حس نمی‌کنی.
> از بخش ۱ تا ۴ برو و تمام. بخش ۶ (Release) رو فقط وقتی بخون که خواستی اپ رو
> به یکی دیگه بدی.

---

## ۱. نصب Android Studio

از [developer.android.com/studio](https://developer.android.com/studio) دانلود کن.
حجمش حدود ۱ گیگه.

**ویندوز:** فایل `.exe` رو اجرا کن، همه‌جا Next.
**مک:** فایل `.dmg` رو باز کن، آیکون رو بکش توی Applications.
**لینوکس:** فایل `.tar.gz` رو باز کن، `bin/studio.sh` رو اجرا کن.

بار اول که باز می‌شه یه ویزارد میاد:

1. **Import Settings** → «Do not import settings» → OK
2. **Install Type** → **Standard** ← این مهمه، Custom رو انتخاب نکن
3. **Verify Settings** → Next
4. **License Agreement** → همه‌ی موارد سمت چپ رو کلیک کن و برای هرکدوم **Accept** بزن
5. Finish

حالا شروع می‌کنه به دانلود Android SDK (حدود ۲ تا ۵ گیگ). صبر کن تموم شه.

> ⚠️ اگر تو ایران هستی و دانلود گیر کرد، احتمالاً به تحریم خورده. توی
> **Settings → Appearance & Behavior → System Settings → HTTP Proxy** پروکسی
> رو تنظیم کن، یا کل مرحله رو با VPN انجام بده.

**نکته:** JDK جدا نصب نکن. Android Studio خودش JDK 17 داخلش داره و
خودکار استفاده می‌کنه.

### پیام‌های آخر ویزارد — کدام خطاست و کدام نیست

آخر ویزارد معمولاً چنین چیزی می‌بینی:

```
Nothing to do!
Android SDK is up to date.
SDK emulator directory is missing
```

| پیام | معنی | اقدام |
|---|---|---|
| `Nothing to do!` | چیزی برای دانلود نمانده | ✅ هیچی |
| `Android SDK is up to date` | SDK کامل نصب است | ✅ هیچی |
| `SDK emulator directory is missing` | شبیه‌ساز نصب نشده | ⚠️ برای تو مهم نیست |

**هر سه بی‌خطرند و ویزارد موفق بوده.** فقط **Finish** رو بزن.

سومی می‌گوید پوشه‌ی Android Emulator ساخته نشده. شبیه‌ساز یعنی گوشی مجازی روی
کامپیوتر — چون تو اپ را روی **گوشی واقعی** نصب می‌کنی، اصلاً بهش نیاز نداری.
اپ بدون شبیه‌ساز کاملاً build و نصب می‌شود.

> 💡 شبیه‌ساز چند گیگ حجم دارد و RAM زیادی می‌خورد. نبودنش برای این پروژه
> در واقع یک مزیت است.

**اگر بعداً خواستی شبیه‌ساز داشته باشی:**
**Tools → SDK Manager → تب SDK Tools** → تیک **Android Emulator** → Apply

⚠️ هشدار: WebView شبیه‌ساز معمولاً قدیمی است و لاگین گوگل داخلش کار نمی‌کند.
برای تست این اپ حتماً از گوشی واقعی استفاده کن.

---

## ۲. باز کردن پروژه

1. صفحه‌ی خوش‌آمد Android Studio → **Open**
2. پوشه‌ی `arena-companion` رو انتخاب کن ← **خودِ پوشه، نه فایل داخلش**
3. OK

حالا Gradle Sync شروع می‌شه. پایین پنجره یه نوار پیشرفت می‌بینی:

```
Gradle: Downloading gradle-8.7-bin.zip...
Gradle: Resolving dependencies...
```

**بار اول ۱۰ تا ۳۰ دقیقه طول می‌کشه.** داره Gradle و همه‌ی کتابخونه‌ها رو دانلود
می‌کنه. تا وقتی «BUILD SUCCESSFUL» یا «Sync finished» نیومده، دکمه‌ی Build کار نمی‌کنه.

اگر بالای صفحه بنر زرد دیدی که می‌گه چیزی نصب نیست (مثلاً «Install missing SDK
platform»)، روی لینک آبیش کلیک کن تا خودش نصب کنه.

---

## ۳. ساخت Debug APK

وقتی Sync تموم شد:

**منوی بالا → Build → Build App Bundle(s) / APK(s) → Build APK(s)**

یکی دو دقیقه صبر کن. پایین سمت راست یه نوتیفیکیشن میاد:

```
✅ APK(s) generated successfully for 1 module
   locate  |  analyze
```

روی **locate** کلیک کن تا فایل‌منیجر باز شه و APK رو نشونت بده.

مسیر فایل:

```
arena-companion/app/build/outputs/apk/debug/app-debug.apk
```

**همین فایله که باید روی گوشی نصب کنی.** 🎉

### یا از خط فرمان

اگه ترمینال رو ترجیح می‌دی، توی پوشه‌ی پروژه:

```bash
# لینوکس / مک
./gradlew assembleDebug

# ویندوز (PowerShell یا CMD)
gradlew.bat assembleDebug
```

> ⚠️ برای این روش باید Android SDK نصب باشه و متغیر `ANDROID_HOME` تنظیم شده باشه.
> اگه Android Studio رو نصب کردی، معمولاً اینجاست:
> - ویندوز: `C:\Users\نام‌کاربری\AppData\Local\Android\Sdk`
> - مک: `~/Library/Android/sdk`
> - لینوکس: `~/Android/Sdk`
>
> اگه ارور `SDK location not found` گرفتی، یه فایل `local.properties` کنار
> `settings.gradle.kts` بساز با این محتوا:
> ```
> sdk.dir=/مسیر/کامل/به/Android/Sdk
> ```
> (توی ویندوز بک‌اسلش‌ها رو دوتایی بنویس: `C:\\Users\\...\\Sdk`)

---

## ۴. نصب روی گوشی

### روش الف: کپی مستقیم (ساده‌ترین)

1. فایل `app-debug.apk` رو با کابل USB یا تلگرام یا هر روشی به گوشی منتقل کن
2. توی گوشی، فایل‌منیجر رو باز کن و روی APK بزن
3. اندروید می‌گه «برای امنیت، نصب اپ از این منبع مجازه نیست» →
   **Settings** → **Allow from this source** رو روشن کن → برگرد و دوباره بزن
4. **Install** → تمام

### روش ب: با ADB (اگه کابل داری)

اول روی گوشی **USB Debugging** رو روشن کن:

1. **Settings → About phone**
2. هفت بار پشت‌سرهم روی **Build number** بزن
   (پیام میاد: «You are now a developer»)
3. برگرد به **Settings → System → Developer options**
4. **USB debugging** رو روشن کن

حالا گوشی رو با کابل وصل کن و:

```bash
adb devices          # باید گوشیت رو لیست کنه
adb install app/build/outputs/apk/debug/app-debug.apk
```

اولین بار روی گوشی یه دیالوگ میاد: «Allow USB debugging?» → **Allow**.

### روش ج: مستقیم از Android Studio (بهترین برای توسعه)

گوشی رو با USB وصل کن (با USB debugging روشن)، بالای Android Studio اسم گوشیت
رو انتخاب کن و دکمه‌ی سبز **▶ Run** رو بزن. خودش می‌سازه، نصب می‌کنه و اجرا می‌کنه.

---

## ۵. بعد از نصب — این را حتماً چک کن

اپ که باز شد، **منوی ⋮ → اطلاعات فنی** رو بزن. باید ببینی:

```
پشتیبانی چندپروفایلی: ✅ بله
هنوز مثل WebView دیده می‌شود؟ ✅ خیر
```

اگر اولی **❌ خیر** بود، سوییچ اکانت کار نمی‌کنه. راه‌حل: **Android System WebView**
رو از Play Store آپدیت کن (نیاز به نسخه‌ی ۱۱۸ یا بالاتر).

اگر دومی **⚠️ بله** بود، لاگین گوگل احتمالاً خطای `disallowed_useragent` می‌ده.

---

## ۶. ساخت Release APK (اختیاری)

**فقط اگه می‌خوای اپ رو به کس دیگه‌ای بدی.** برای خودت لازم نیست.

### قدم ۱: ساخت کلید امضا

توی پوشه‌ی پروژه این دستور رو بزن:

```bash
keytool -genkey -v -keystore arena-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias arena
```

> `keytool` همراه JDK میاد. اگه پیدا نشد، از JDK داخل Android Studio استفاده کن:
> - مک: `/Applications/Android\ Studio.app/Contents/jbr/Contents/Home/bin/keytool`
> - ویندوز: `"C:\Program Files\Android\Android Studio\jbr\bin\keytool.exe"`
> - لینوکس: `~/android-studio/jbr/bin/keytool`

ازت رمز و چند تا سؤال می‌پرسه (اسم، شهر و...). می‌تونی الکی پر کنی ولی
**رمز رو یادداشت کن**.

### قدم ۲: ساخت فایل تنظیمات

فایل `keystore.properties.example` رو کپی کن به `keystore.properties` و پرش کن:

```properties
storeFile=arena-release.jks
storePassword=همون-رمزی-که-گذاشتی
keyAlias=arena
keyPassword=همون-رمز
```

### قدم ۳: ساخت

```bash
./gradlew assembleRelease
```

خروجی:
```
app/build/outputs/apk/release/app-release.apk
```

> 🔐 **مهم:** فایل‌های `arena-release.jks` و `keystore.properties` رو هرگز
> جایی آپلود نکن. توی `.gitignore` گذاشتمشون. اگه کلید رو گم کنی، دیگه
> نمی‌تونی آپدیت همین اپ رو منتشر کنی.

---

## ۷. خطاهای رایج

| خطا | علت | راه‌حل |
|---|---|---|
| `Class 'kotlin.Unit' was compiled with an incompatible version of Kotlin` | کتابخانه‌ای kotlin-stdlib جدیدتر از کامپایلر پروژه آورده | ✅ حل شده — پایین را بخوان |
| `SDK location not found` | SDK پیدا نشد | فایل `local.properties` بساز (بخش ۳) |
| `Unsupported Java version` | JDK قدیمی | از Android Studio بساز، نه ترمینال |
| `Could not resolve androidx...` | تحریم / شبکه | ✅ آینه اضافه شده — پایین را بخوان |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | نسخه‌ی قبلی با امضای دیگه نصبه | اول اپ قبلی رو پاک کن |
| `App not installed` | معمولاً امضا یا فضای کم | نسخه‌ی قبلی رو حذف کن |
| Gradle Sync گیر کرده | دانلود ناقص | `File → Invalidate Caches → Restart` |
| `adb: no devices found` | USB debugging خاموشه | بخش ۴ روش ب رو ببین |

### درباره‌ی خطای «incompatible version of Kotlin»

اگر با نسخه‌ی قدیمی پروژه صدها ارور شبیه این گرفتی:

```
Class 'kotlin.Unit' was compiled with an incompatible version of Kotlin.
The actual metadata version is 2.1.0, but the compiler version 1.9.0 ...
kotlin-stdlib-2.1.20.jar!/kotlin/Unit.class
```

**علت:** کتابخانه‌ی `androidx.webkit:1.16.0` به `kotlin-stdlib 2.1.20` وابسته است،
ولی کامپایلر پروژه Kotlin 1.9.24 بود. کامپایلر قدیمی نمی‌تواند کلاس‌هایی را که با
کامپایلر جدیدتر ساخته شده‌اند بخواند — و چون `kotlin.Unit` در هر تابع Kotlin
استفاده می‌شود، خطا در تمام فایل‌ها پخش می‌شود (۱۷۵ ارور از یک ریشه).

**حل شده در نسخه‌ی فعلی:**

1. `androidx.webkit` به **1.15.0** برگشت — بررسی بایت‌کد نشان داد تمام APIهای
   لازم (`ProfileStore`, `Profile`, `WebViewCompat.setProfile`,
   `WebViewFeature.MULTI_PROFILE`) را دارد و هیچ وابستگی به kotlin-stdlib ندارد.
2. یک `resolutionStrategy` اضافه شد که اگر کتابخانه‌ی دیگری در آینده
   kotlin-stdlib جدیدتر بیاورد، به نسخه‌ی سازگار پایین بیاورد.

> 💡 **قاعده‌ی کلی:** نسخه‌ی `kotlin-stdlib` هیچ وابستگی‌ای نباید از نسخه‌ی
> کامپایلر Kotlin پروژه جلوتر باشد. عکسش (قدیمی‌تر بودن) مشکلی ندارد.

### درباره‌ی خطای «Could not resolve androidx.annotation:annotation:1.8.0»

```
Could not resolve androidx.annotation:annotation:1.8.0
Required by:
    project :app > androidx.lifecycle:lifecycle-runtime...
Possible solution:
 - Declare repository providing the artifact
```

**این خطای کد نیست — خطای دانلود است.** بررسی کردم: فایل روی سرور گوگل کاملاً
سالم و در دسترس است. یعنی *شبکه‌ی تو* نتوانسته به `dl.google.com` وصل شود
(تحریم، فیلترینگ، یا قطعی موقت).

نکته‌ی گمراه‌کننده: خطا اسم `androidx.annotation` را می‌آورد ولی تو مستقیم
از آن استفاده نکرده‌ای — این وابستگی *غیرمستقیم* `lifecycle` است. هر
کتابخانه‌ای می‌توانست جایش باشد؛ همان اولی که دانلودش شکست خورده گزارش می‌شود.

**حل شده در نسخه‌ی فعلی:** در `settings.gradle.kts` آینه‌های Aliyun اضافه شده‌اند
که تست کردم و همه‌ی artifactهای این پروژه را دارند:

```
annotation-1.8.0.jar      -> 200 ✅
webkit-1.15.0.aar         -> 200 ✅
core-ktx-1.13.1.aar       -> 200 ✅
appcompat-1.7.0.aar       -> 200 ✅
gradle-8.6.1.pom          -> 200 ✅
```

Gradle اول مخازن رسمی گوگل را امتحان می‌کند؛ اگر جواب نداد سراغ آینه می‌رود.
پس چه VPN داشته باشی چه نه، کار می‌کند.

همچنین در `gradle.properties` مهلت شبکه از ۱۰ ثانیه به ۱۲۰ ثانیه افزایش یافت،
چون روی اتصال کند دانلود نیمه‌کاره رها می‌شد و همین خطا را می‌داد.

#### اگر باز هم نشد

**گزینه ۱ — VPN:** روشنش کن و در Android Studio بزن **File → Sync Project with
Gradle Files**.

**گزینه ۲ — پروکسی محلی:** اگر VPN تو پروکسی محلی می‌سازد (مثل v2ray روی
پورت 8889)، در فایل `gradle.properties` این خطوط را از کامنت دربیاور و پورت
خودت را بگذار:

```properties
systemProp.http.proxyHost=127.0.0.1
systemProp.http.proxyPort=8889
systemProp.https.proxyHost=127.0.0.1
systemProp.https.proxyPort=8889
```

**گزینه ۳ — پاک کردن کش خراب:** اگر دانلود نیمه‌کاره در کش مانده باشد، حتی با
شبکه‌ی سالم هم خطا ادامه می‌یابد:

```bash
rm -rf ~/.gradle/caches/modules-2/files-2.1/androidx.annotation
# یا برای پاک‌سازی کامل (دانلود مجدد همه‌چیز):
rm -rf ~/.gradle/caches
```

### اگه Gradle Sync اصلاً تموم نشد

```bash
# پاک کردن کش و شروع دوباره
./gradlew clean --refresh-dependencies
```

یا توی Android Studio: **File → Invalidate Caches...** → همه‌ی تیک‌ها →
**Invalidate and Restart**.

---

## ۸. مرجع سریع دستورات

```bash
./gradlew assembleDebug      # ساخت APK دیباگ
./gradlew assembleRelease    # ساخت APK ریلیز (نیاز به keystore)
./gradlew clean              # پاک کردن خروجی‌های قبلی
./gradlew tasks              # لیست همه‌ی کارهای ممکن

adb devices                  # لیست گوشی‌های وصل
adb install -r app.apk       # نصب با جایگزینی نسخه‌ی قبلی
adb uninstall ir.arena.companion   # حذف اپ
adb logcat | grep -i arena   # دیدن لاگ‌های اپ
```

---

## ۹. دیباگ کردن WebView

چون قلب این اپ WebView هست، این خیلی به کارت میاد:

1. گوشی رو با USB وصل کن (USB debugging روشن)
2. توی کروم دسکتاپ برو به: `chrome://inspect`
3. زیر بخش Remote Target اپت رو می‌بینی → **inspect**

حالا DevTools کامل کروم برای صفحه‌ی داخل اپت باز می‌شه — می‌تونی کنسول، شبکه و
کوکی‌ها رو ببینی. (این قابلیت رو توی `ArenaApp.kt` فعال کردم.)

مخصوصاً برای وقتی که لاگین گوگل مشکل داشت، تب Network اینجا دقیقاً نشون می‌ده
کجا خطا خورده.
