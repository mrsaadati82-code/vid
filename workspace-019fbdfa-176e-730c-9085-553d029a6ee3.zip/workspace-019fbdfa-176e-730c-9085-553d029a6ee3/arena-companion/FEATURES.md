# فیچرهای پیشنهادی — فازهای بعدی

مرتب‌شده بر اساس **نسبت ارزش به زحمت**. هر کدام مستقل است.

---

## 🥇 دسته‌ی اول: بیشترین ارزش

### ۱. آرشیو جست‌وجوپذیر مکالمات

**مشکلی که حل می‌کند:** Arena تاریخچه‌ی ضعیفی دارد. یک هفته بعد پیدا کردن آن
جواب خوبی که گرفتی تقریباً غیرممکن است.

**راه‌حل:** با `addDocumentStartJavascript` (موجود در androidx.webkit) یک اسکریپت
تزریق کن که DOM را رصد کند و مکالمات را به Room بفرستد. جست‌وجوی full-text با FTS4.

```kotlin
@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey val id: String,
    val profileId: String,      // کدام اکانت
    val title: String,
    val bodyText: String,
    val url: String,
    val savedAt: Long,
    val tags: String = ""
)

@Dao interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE bodyText MATCH :q ORDER BY savedAt DESC")
    fun search(q: String): List<Conversation>
}
```

**زحمت:** متوسط · **ارزش:** خیلی زیاد

---

### ۲. تب لیدربورد نیتیو (۱۰۰٪ قانونی)

**چرا مهم است:** برخلاف اسکرپ کردن سایت، دیتاست رسمی Arena روی Hugging Face
منتشر می‌شود و استفاده از آن کاملاً مجاز است.

**تست‌شده و کار می‌کند:**

```bash
curl "https://datasets-server.huggingface.co/rows?dataset=lmarena-ai%2Fleaderboard-dataset&config=text&split=latest&offset=0&length=10"
```

خروجی واقعی:
```json
{"model_name": "claude-opus-5-max", "organization": "anthropic",
 "rating": 1511.6, "vote_count": 2386, "rank": 1,
 "leaderboard_publish_date": "2026-07-27"}
```

```kotlin
// config های موجود: text, code, vision, agent, document,
//                   text-to-image, text-to-video, image-edit, search, ...
// split: "latest" برای فعلی، "full" برای تاریخچه‌ی کامل

data class LeaderboardEntry(
    val modelName: String,
    val organization: String,
    val rating: Double,
    val voteCount: Int,
    val rank: Int
)

suspend fun fetchLeaderboard(config: String = "text"): List<LeaderboardEntry> {
    val url = "https://datasets-server.huggingface.co/rows" +
              "?dataset=lmarena-ai%2Fleaderboard-dataset" +
              "&config=$config&split=latest&offset=0&length=100"
    // parse json → rows[].row
}
```

با `split=full` می‌توانی نمودار روند رتبه‌ی یک مدل در طول زمان بکشی — چیزی که
خود سایت Arena ندارد.

**زحمت:** کم · **ارزش:** زیاد

---

### ۳. حالت خواندن و دارک‌مود واقعی

```kotlin
val css = """
    :root { color-scheme: dark; }
    body { font-size: ${fontSize}px !important; }
    * { -webkit-tap-highlight-color: transparent; }
"""
webView.evaluateJavascript("""
    (function(){
      var s = document.createElement('style');
      s.textContent = `$css`;
      document.head.appendChild(s);
    })();
""", null)
```

بهتر است با `addDocumentStartJavascript` تزریق شود تا قبل از رندر اعمال شود و
پرش نداشته باشد.

**زحمت:** کم · **ارزش:** متوسط

---

## 🥈 دسته‌ی دوم: کیفیت زندگی

### ۴. کتابخانه‌ی پرامپت‌ها

پرامپت‌های پرتکرار را ذخیره کن و با یک ضربه داخل textarea تزریق کن:

```kotlin
fun insertPrompt(text: String) {
    val escaped = org.json.JSONObject.quote(text)
    webView.evaluateJavascript("""
        (function(){
          var el = document.querySelector('textarea') ||
                   document.querySelector('[contenteditable="true"]');
          if (!el) return 'not-found';
          var setter = Object.getOwnPropertyDescriptor(
              window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(el, $escaped);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.focus();
          return 'ok';
        })();
    """, null)
}
```

نکته‌ی مهم: React روی `value` را رهگیری می‌کند، پس باید از native setter استفاده
کرد وگرنه state آپدیت نمی‌شود.

### ۵. بج شمارنده روی پروفایل غیرفعال

وقتی روی اکانت اول هستی، بدانی اکانت دوم پاسخ جدید دارد. با یک ping سبک روی
WebView غیرفعال قابل پیاده‌سازی است.

### ۶. اسکرین‌شات و اشتراک‌گذاری پاسخ

```kotlin
val bitmap = Bitmap.createBitmap(webView.width, webView.contentHeight,
                                 Bitmap.Config.ARGB_8888)
webView.draw(Canvas(bitmap))
```

### ۷. قفل بیومتریک

`BiometricPrompt` هنگام باز شدن اپ — چون سشن‌های لاگین‌شده داخلش هست.

---

## 🥉 دسته‌ی سوم: پیشرفته

### ۸. Backup و Restore پروفایل‌ها

خروجی رمزنگاری‌شده از کوکی‌ها با `EncryptedSharedPreferences` برای انتقال بین
دستگاه‌ها.

### ۹. مقایسه‌ی پاسخ دو اکانت کنار هم

نمای split-screen: همان پرامپت را در هر دو پروفایل بفرست و خروجی‌ها را کنار هم
ببین. مفید وقتی یکی اشتراک پولی دارد و دیگری رایگان.

### ۱۰. مسیر رسمی OAuth با Custom Tabs

اگر روزی خواستی اپ را منتشر کنی، UA spoofing جواب نمی‌دهد. مسیر درست:

```kotlin
// 1) لاگین در Custom Tab (مرورگر واقعی — گوگل بلاک نمی‌کند)
CustomTabsIntent.Builder().build()
    .launchUrl(context, Uri.parse(loginUrl))

// 2) بازگشت با deep link
// 3) انتقال کوکی‌ها به پروفایل WebView
```

پیچیده‌تر است ولی پایدار و منطبق با سیاست گوگل.

---

## ❌ فیچرهایی که نباید بسازی

| فیچر | چرا |
|---|---|
| نمایش نام مدل در Agent Mode | داده در کلاینت وجود ندارد + بند (vii) ToS |
| اسکرپ خودکار لیدربورد از HTML | بند (vi) و (vii) ToS — به‌جایش از دیتاست HF استفاده کن |
| ارسال خودکار پرامپت / بات | «programmatic or automated means» — بند (vi) |
| رأی دادن خودکار | داده‌ی تحقیقاتی را خراب می‌کند، بن قطعی |

---

## ترتیب پیشنهادی پیاده‌سازی

```
فاز ۱ (الان)   ✅ سوییچ چنداکانتی + WebView پایه
فاز ۲          → تب لیدربورد (کم‌زحمت، قانونی، مفید)
فاز ۳          → آرشیو مکالمات + جست‌وجو
فاز ۴          → کتابخانه‌ی پرامپت + دارک‌مود
فاز ۵          → قفل بیومتریک + backup
```
