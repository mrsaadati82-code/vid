// ─────────────────────────────────────────────────────────────────────────────
//  تنظیم مخازن با آینه‌های جایگزین
//
//  چرا؟ خطای «Could not resolve androidx.annotation:annotation:1.8.0» یعنی
//  Gradle نتوانست فایل را از dl.google.com دانلود کند. artifact سالم است —
//  مشکل دسترسی شبکه است (تحریم / فیلترینگ / قطعی).
//
//  راه‌حل: علاوه بر مخازن رسمی، آینه‌های عمومی هم اضافه شده‌اند. Gradle به
//  ترتیب امتحان می‌کند و از اولین مخزنی که جواب داد استفاده می‌کند.
//
//  💡 اگر VPN داری، همین تنظیمات با VPN هم کار می‌کند (رسمی‌ها اول امتحان
//     می‌شوند). اگر نداری، آینه‌ها کار را راه می‌اندازند.
// ─────────────────────────────────────────────────────────────────────────────

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()

        // ── آینه‌ها (فقط وقتی مخازن بالا جواب ندهند استفاده می‌شوند) ──
        maven("https://maven.aliyun.com/repository/google")
        maven("https://maven.aliyun.com/repository/gradle-plugin")
        maven("https://maven.aliyun.com/repository/public")
    }
}

dependencyResolutionManagement {
    // PREFER_SETTINGS به‌جای FAIL_ON_PROJECT_REPOS:
    // اگر لازم شد بتوانی در build.gradle.kts هم مخزن اضافه کنی، خطا نگیری.
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)

    repositories {
        google()
        mavenCentral()

        // ── آینه‌ها ──
        maven("https://maven.aliyun.com/repository/google")
        maven("https://maven.aliyun.com/repository/public")
        maven("https://maven.aliyun.com/repository/central")
    }
}

rootProject.name = "ArenaPlus"
include(":app")
