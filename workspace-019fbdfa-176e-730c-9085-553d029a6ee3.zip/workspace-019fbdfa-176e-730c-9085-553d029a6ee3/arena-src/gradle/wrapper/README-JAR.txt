gradle-wrapper.jar عمداً حذف شده تا حجم آرشیو کم بماند.
Android Studio هنگام باز کردن پروژه خودش می‌سازدش.
