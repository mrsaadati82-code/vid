#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  ساخت فایل نصبی مک (.dmg) — بهینه برای M1
#
#      bash build-mac.sh
#
#  اول مطمئن می‌شود همه‌چیز نصب است، بعد build می‌گیرد.
# ═══════════════════════════════════════════════════════════════

set -e
cd "$(dirname "$0")" 2>/dev/null || {
  echo "❌ اول بزن:  cd ~/Downloads/arena-plus-desktop"; exit 1; }

CACHE="$HOME/.arena-plus-cache"
mkdir -p "$CACHE"

echo ""
echo "📦 ساخت Arena Plus برای مک"
echo "═══════════════════════════════════"

if [ "$(uname -m)" = "arm64" ]; then
  EARCH="arm64"; echo "   تراشه: Apple Silicon (M1/M2/M3/M4)"
else
  EARCH="x64";   echo "   تراشه: Intel"
fi

BIN="node_modules/electron/dist/Electron.app/Contents/MacOS/Electron"

# ── وابستگی‌ها ──
if [ ! -x "$BIN" ]; then
  echo "→ آماده‌سازی…"
  bash run.sh --setup-only 2>/dev/null || {
    export ELECTRON_SKIP_BINARY_DOWNLOAD=1
    npm install --no-audit --no-fund --loglevel=error
    unset ELECTRON_SKIP_BINARY_DOWNLOAD
  }
fi

# ── آینه برای electron-builder ──
# خود builder هم موقع بسته‌بندی باینری لازم دارد
export ELECTRON_MIRROR="https://npmmirror.com/mirrors/electron/"
export ELECTRON_BUILDER_BINARIES_MIRROR="https://npmmirror.com/mirrors/electron-builder-binaries/"
# امضا نمی‌کنیم — اپ شخصی است
export CSC_IDENTITY_AUTO_DISCOVERY=false

echo ""
echo "→ ساخت DMG (۳ تا ۸ دقیقه)…"
echo ""
npx electron-builder --mac --"$EARCH" --publish never

echo ""
echo "═══════════════════════════════════"
echo "✅ آماده شد!"
echo ""
ls -lh dist/*.dmg 2>/dev/null | awk '{print "   " $9 "  (" $5 ")"}'
echo ""
echo "برای باز کردن پوشه:"
echo "    open dist"
echo ""
echo "⚠️ بار اول که اپ را باز می‌کنی، مک هشدار می‌دهد."
echo "   راست‌کلیک روی اپ → Open → دوباره Open"
echo ""
