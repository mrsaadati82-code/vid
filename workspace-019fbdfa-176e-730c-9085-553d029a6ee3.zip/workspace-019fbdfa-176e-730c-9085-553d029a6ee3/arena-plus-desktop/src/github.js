'use strict';

/**
 * کلاینت GitHub — مدیریت کامل مخزن‌ها.
 *
 * چرا PAT و نه OAuth؟
 * OAuth به سرور callback نیاز دارد که برای اپ دسکتاپ شخصی پیچیدگی
 * بی‌مورد است. PAT ساده، امن و کاملاً تحت کنترل کاربر است.
 */

const API = 'https://api.github.com';

class GitHub {
  constructor(token) { this.token = token || ''; }

  setToken(t) { this.token = t || ''; }
  get connected() { return !!this.token; }

  async _req(pathname, opts = {}) {
    if (!this.token) throw new Error('توکن GitHub تنظیم نشده');
    const res = await fetch(API + pathname, {
      ...opts,
      headers: {
        Accept: 'application/vnd.github+json',
        Authorization: `Bearer ${this.token}`,
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'ArenaPlus',
        ...(opts.headers || {})
      }
    });

    if (res.status === 401) throw new Error('توکن نامعتبر یا منقضی است');
    if (res.status === 403) {
      const left = res.headers.get('x-ratelimit-remaining');
      throw new Error(left === '0'
        ? 'سقف درخواست GitHub پر شد — کمی صبر کن'
        : 'دسترسی رد شد — دسترسی repo را در توکن فعال کن');
    }
    if (res.status === 404) throw new Error('پیدا نشد');
    if (res.status === 409) throw new Error('مخزن خالی است یا تعارض دارد');
    if (res.status === 422) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j.message || 'داده‌ی نامعتبر');
    }
    if (!res.ok) throw new Error(`GitHub: ${res.status}`);
    if (res.status === 204) return null;
    return res.json();
  }

  // ───────── حساب ─────────

  me() { return this._req('/user'); }

  async rateLimit() {
    const j = await this._req('/rate_limit');
    return j.rate;
  }

  // ───────── مخزن ─────────

  repos({ page = 1, sort = 'updated', affiliation = 'owner,collaborator' } = {}) {
    return this._req(
      `/user/repos?per_page=100&sort=${sort}&page=${page}` +
      `&affiliation=${encodeURIComponent(affiliation)}`
    );
  }

  repo(owner, name) { return this._req(`/repos/${owner}/${name}`); }

  createRepo({ name, description = '', isPrivate = true, autoInit = true }) {
    return this._req('/user/repos', {
      method: 'POST',
      body: JSON.stringify({
        name, description, private: isPrivate, auto_init: autoInit
      })
    });
  }

  deleteRepo(owner, name) {
    return this._req(`/repos/${owner}/${name}`, { method: 'DELETE' });
  }

  updateRepo(owner, name, patch) {
    return this._req(`/repos/${owner}/${name}`, {
      method: 'PATCH', body: JSON.stringify(patch)
    });
  }

  branches(owner, repo) {
    return this._req(`/repos/${owner}/${repo}/branches?per_page=100`);
  }

  commits(owner, repo, branch = '', limit = 20) {
    const q = branch ? `&sha=${encodeURIComponent(branch)}` : '';
    return this._req(`/repos/${owner}/${repo}/commits?per_page=${limit}${q}`);
  }

  // ───────── فایل ─────────

  contents(owner, repo, p = '', ref = '') {
    const q = ref ? `?ref=${encodeURIComponent(ref)}` : '';
    const safe = p.split('/').map(encodeURIComponent).join('/');
    return this._req(`/repos/${owner}/${repo}/contents/${safe}${q}`);
  }

  async fileText(owner, repo, p, ref = '') {
    const j = await this.contents(owner, repo, p, ref);
    if (Array.isArray(j)) throw new Error('این یک پوشه است');
    if (j.encoding === 'base64') {
      return Buffer.from(j.content, 'base64').toString('utf8');
    }
    return j.content || '';
  }

  async tree(owner, repo, branch = '') {
    if (!branch) {
      const info = await this.repo(owner, repo);
      branch = info.default_branch || 'main';
    }
    const j = await this._req(
      `/repos/${owner}/${repo}/git/trees/${encodeURIComponent(branch)}?recursive=1`
    );
    return { branch, truncated: !!j.truncated, items: j.tree || [] };
  }

  /** ساخت یا به‌روزرسانی فایل. */
  async putFile(owner, repo, p, content, message, branch = '', isBase64 = false) {
    let sha;
    try {
      const cur = await this.contents(owner, repo, p, branch);
      if (!Array.isArray(cur)) sha = cur.sha;
    } catch { /* فایل جدید */ }

    const body = {
      message: message || `به‌روزرسانی ${p}`,
      content: isBase64 ? content
        : Buffer.from(content, 'utf8').toString('base64')
    };
    if (sha) body.sha = sha;
    if (branch) body.branch = branch;

    const safe = p.split('/').map(encodeURIComponent).join('/');
    return this._req(`/repos/${owner}/${repo}/contents/${safe}`, {
      method: 'PUT', body: JSON.stringify(body)
    });
  }

  /** حذف یک فایل. */
  async deleteFile(owner, repo, p, message, branch = '') {
    const cur = await this.contents(owner, repo, p, branch);
    if (Array.isArray(cur)) throw new Error('این یک پوشه است');
    const body = { message: message || `حذف ${p}`, sha: cur.sha };
    if (branch) body.branch = branch;
    const safe = p.split('/').map(encodeURIComponent).join('/');
    return this._req(`/repos/${owner}/${repo}/contents/${safe}`, {
      method: 'DELETE', body: JSON.stringify(body)
    });
  }

  /**
   * 🔴 حذف/آپلود دسته‌جمعی با Git Data API.
   *
   * چرا نه حذف تک‌تک با contents API؟
   * هر حذف یک commit جداگانه می‌سازد و برای ۵۰ فایل یعنی ۱۰۰ درخواست و
   * ۵۰ commit آشفته. اینجا یک درخت جدید می‌سازیم و **یک commit** می‌زنیم.
   *
   * @param {Array<{path:string, content?:string, delete?:boolean}>} changes
   */
  async batchCommit(owner, repo, changes, message, branch = '') {
    if (!branch) {
      const info = await this.repo(owner, repo);
      branch = info.default_branch || 'main';
    }

    // ۱) کامیت فعلی شاخه
    const ref = await this._req(
      `/repos/${owner}/${repo}/git/ref/heads/${encodeURIComponent(branch)}`);
    const headSha = ref.object.sha;
    const headCommit = await this._req(
      `/repos/${owner}/${repo}/git/commits/${headSha}`);
    const baseTree = headCommit.tree.sha;

    // ۲) ساخت blob برای فایل‌های جدید
    const treeItems = [];
    for (const ch of changes) {
      if (ch.delete) {
        // sha=null یعنی «این مسیر را حذف کن»
        treeItems.push({ path: ch.path, mode: '100644', type: 'blob', sha: null });
      } else {
        const blob = await this._req(`/repos/${owner}/${repo}/git/blobs`, {
          method: 'POST',
          body: JSON.stringify({
            content: Buffer.from(ch.content || '', 'utf8').toString('base64'),
            encoding: 'base64'
          })
        });
        treeItems.push({
          path: ch.path, mode: '100644', type: 'blob', sha: blob.sha
        });
      }
    }

    // ۳) درخت جدید
    const tree = await this._req(`/repos/${owner}/${repo}/git/trees`, {
      method: 'POST',
      body: JSON.stringify({ base_tree: baseTree, tree: treeItems })
    });

    // ۴) کامیت
    const commit = await this._req(`/repos/${owner}/${repo}/git/commits`, {
      method: 'POST',
      body: JSON.stringify({
        message: message || `${changes.length} تغییر از Arena Plus`,
        tree: tree.sha,
        parents: [headSha]
      })
    });

    // ۵) جابه‌جایی شاخه
    await this._req(
      `/repos/${owner}/${repo}/git/refs/heads/${encodeURIComponent(branch)}`, {
        method: 'PATCH',
        body: JSON.stringify({ sha: commit.sha, force: false })
      });

    return { sha: commit.sha, count: changes.length, branch };
  }

  // ───────── Gist ─────────

  createGist(filename, content, description = '', isPublic = false) {
    return this._req('/gists', {
      method: 'POST',
      body: JSON.stringify({
        description, public: isPublic,
        files: { [filename]: { content } }
      })
    });
  }

  gists() { return this._req('/gists?per_page=50'); }

  // ───────── Issue ─────────

  issues(owner, repo, state = 'open') {
    return this._req(`/repos/${owner}/${repo}/issues?state=${state}&per_page=50`);
  }

  createIssue(owner, repo, title, body = '') {
    return this._req(`/repos/${owner}/${repo}/issues`, {
      method: 'POST', body: JSON.stringify({ title, body })
    });
  }
}

module.exports = GitHub;
