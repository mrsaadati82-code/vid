'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

/**
 * تبدیل ZIP (یا پوشه) به یک فایل Markdown که Arena می‌پذیرد.
 *
 * ═══ چرا این کار لازم است؟ ═══
 * سرور Arena فقط این فرمت‌ها را می‌پذیرد:
 *   image/*, text/plain, text/markdown, text/csv, text/html,
 *   text/xml, text/css, text/javascript, application/json,
 *   application/xml, application/javascript, application/pdf
 *
 * بررسی روی *سرور* انجام می‌شود، پس جعل MIME در کلاینت بی‌فایده است.
 * اما `text/markdown` مجاز است — و یک Markdown ساختاریافته برای مدل
 * حتی خواناتر از ZIP است، چون درخت پوشه‌ها و محتوای فایل‌ها را یکجا
 * می‌بیند.
 *
 * پیاده‌سازی ZIP با zlib داخلی Node — بدون هیچ وابستگی خارجی.
 */

// ─────────────────────────────────────────────────────────────
//  خواننده‌ی ZIP
// ─────────────────────────────────────────────────────────────

/** یافتن End of Central Directory (از انتها به عقب). */
function findEOCD(buf) {
  const MIN = 22;
  const max = Math.min(buf.length, 0xffff + MIN);
  for (let i = buf.length - MIN; i >= buf.length - max; i--) {
    if (i < 0) break;
    if (buf.readUInt32LE(i) === 0x06054b50) return i;
  }
  return -1;
}

/** استخراج فهرست فایل‌ها از ZIP. */
function readZipEntries(buf) {
  const eocd = findEOCD(buf);
  if (eocd < 0) throw new Error('فایل ZIP معتبر نیست');

  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const entries = [];

  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;

    const method   = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const rawSize  = buf.readUInt32LE(off + 24);
    const nameLen  = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const cmtLen   = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name     = buf.toString('utf8', off + 46, off + 46 + nameLen);

    entries.push({ name, method, compSize, rawSize, localOff });
    off += 46 + nameLen + extraLen + cmtLen;
  }
  return entries;
}

/** خواندن محتوای یک ورودی. */
function extractEntry(buf, entry) {
  const lo = entry.localOff;
  if (buf.readUInt32LE(lo) !== 0x04034b50) return null;

  const nameLen  = buf.readUInt16LE(lo + 26);
  const extraLen = buf.readUInt16LE(lo + 28);
  const start = lo + 30 + nameLen + extraLen;
  const data = buf.subarray(start, start + entry.compSize);

  if (entry.method === 0) return data;                 // ذخیره‌شده
  if (entry.method === 8) {                            // deflate
    try { return zlib.inflateRawSync(data); } catch { return null; }
  }
  return null;                                          // روش پشتیبانی‌نشده
}

// ─────────────────────────────────────────────────────────────
//  تنظیمات تبدیل
// ─────────────────────────────────────────────────────────────

const LANG = {
  '.js': 'javascript', '.mjs': 'javascript', '.cjs': 'javascript',
  '.ts': 'typescript', '.tsx': 'tsx', '.jsx': 'jsx',
  '.json': 'json', '.html': 'html', '.css': 'css', '.scss': 'scss',
  '.py': 'python', '.kt': 'kotlin', '.java': 'java', '.swift': 'swift',
  '.go': 'go', '.rs': 'rust', '.rb': 'ruby', '.php': 'php',
  '.sh': 'bash', '.bash': 'bash', '.zsh': 'bash',
  '.xml': 'xml', '.yml': 'yaml', '.yaml': 'yaml', '.toml': 'toml',
  '.sql': 'sql', '.md': 'markdown', '.gradle': 'gradle',
  '.kts': 'kotlin', '.c': 'c', '.h': 'c', '.cpp': 'cpp', '.cs': 'csharp'
};

/** پوشه‌هایی که هیچ‌وقت مفید نیستند. */
const SKIP_DIRS = new Set([
  'node_modules', '.git', 'dist', 'build', 'out', 'target',
  '.gradle', '.idea', '.vscode', '__pycache__', '.next', 'vendor',
  'Pods', '.venv', 'venv', 'coverage', '.dart_tool'
]);

/** پسوندهای باینری — فقط نامشان ذکر می‌شود. */
const BINARY = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.icns', '.bmp',
  '.zip', '.gz', '.tar', '.rar', '.7z', '.jar', '.aar', '.apk',
  '.pdf', '.mp3', '.mp4', '.mov', '.avi', '.woff', '.woff2',
  '.ttf', '.otf', '.eot', '.so', '.dylib', '.dll', '.exe', '.bin',
  '.keystore', '.jks', '.p12', '.class', '.pyc', '.lock'
]);

function shouldSkip(p) {
  const parts = p.split('/');
  if (parts.some(x => SKIP_DIRS.has(x))) return true;
  if (parts.some(x => x.startsWith('._'))) return true;
  if (p.includes('__MACOSX')) return true;
  if (path.basename(p) === '.DS_Store') return true;
  return false;
}

function isBinary(name) {
  return BINARY.has(path.extname(name).toLowerCase());
}

function human(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return Math.round(n / 1024) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

/** ساخت درخت پوشه‌ها به شکل ASCII. */
function buildTree(paths) {
  const root = {};
  paths.forEach(p => {
    let node = root;
    p.split('/').forEach(seg => {
      node[seg] = node[seg] || {};
      node = node[seg];
    });
  });

  const lines = [];
  (function walk(node, prefix) {
    const keys = Object.keys(node).sort((a, b) => {
      const aDir = Object.keys(node[a]).length > 0;
      const bDir = Object.keys(node[b]).length > 0;
      if (aDir !== bDir) return aDir ? -1 : 1;
      return a.localeCompare(b);
    });
    keys.forEach((k, i) => {
      const last = i === keys.length - 1;
      lines.push(prefix + (last ? '└── ' : '├── ') + k);
      if (Object.keys(node[k]).length) {
        walk(node[k], prefix + (last ? '    ' : '│   '));
      }
    });
  })(root, '');
  return lines.join('\n');
}

// ─────────────────────────────────────────────────────────────
//  تبدیل اصلی
// ─────────────────────────────────────────────────────────────

/**
 * @param {Array<{path:string, content:Buffer|null, size:number}>} files
 * @param {string} title
 * @param {{maxFileKB:number, maxTotalMB:number}} opts
 */
function filesToMarkdown(files, title, opts = {}) {
  const maxFile = (opts.maxFileKB || 220) * 1024;
  const maxTotal = (opts.maxTotalMB || 4) * 1024 * 1024;

  const kept = [], skipped = [], binaries = [];
  let total = 0;

  for (const f of files) {
    if (isBinary(f.path) || f.content === null) {
      binaries.push({ path: f.path, size: f.size });
      continue;
    }
    if (f.size > maxFile) {
      skipped.push({ path: f.path, size: f.size, reason: 'بزرگ' });
      continue;
    }
    if (total + f.size > maxTotal) {
      skipped.push({ path: f.path, size: f.size, reason: 'سقف حجم' });
      continue;
    }
    // فایل‌های باینریِ بدون پسوند شناخته‌شده
    const text = f.content.toString('utf8');
    if (text.includes('\u0000')) {
      binaries.push({ path: f.path, size: f.size });
      continue;
    }
    kept.push({ path: f.path, text, size: f.size });
    total += f.size;
  }

  const out = [];
  out.push(`# ${title}`);
  out.push('');
  out.push(`> پروژه‌ی صادرشده برای بررسی — ${kept.length} فایل متنی، ` +
           `${binaries.length} فایل باینری، مجموع ${human(total)}`);
  out.push('');

  out.push('## ساختار پروژه');
  out.push('');
  out.push('```');
  out.push(buildTree([...kept, ...binaries].map(f => f.path)));
  out.push('```');
  out.push('');

  if (binaries.length) {
    out.push('## فایل‌های باینری (محتوا گنجانده نشده)');
    out.push('');
    binaries.slice(0, 60).forEach(b =>
      out.push(`- \`${b.path}\` — ${human(b.size)}`));
    if (binaries.length > 60) out.push(`- … و ${binaries.length - 60} فایل دیگر`);
    out.push('');
  }

  if (skipped.length) {
    out.push('## فایل‌های رد شده');
    out.push('');
    skipped.slice(0, 40).forEach(s =>
      out.push(`- \`${s.path}\` — ${human(s.size)} (${s.reason})`));
    out.push('');
  }

  out.push('---');
  out.push('');
  out.push('## محتوای فایل‌ها');
  out.push('');

  kept.sort((a, b) => a.path.localeCompare(b.path));
  for (const f of kept) {
    const lang = LANG[path.extname(f.path).toLowerCase()] || '';
    out.push(`### \`${f.path}\``);
    out.push('');
    // اگر خود فایل ``` دارد، از حصار بلندتر استفاده کن
    const fence = f.text.includes('```') ? '````' : '```';
    out.push(fence + lang);
    out.push(f.text.replace(/\s+$/, ''));
    out.push(fence);
    out.push('');
  }

  return out.join('\n');
}

/** ZIP → Markdown */
function zipToMarkdown(zipPath, opts = {}) {
  const buf = fs.readFileSync(zipPath);
  const entries = readZipEntries(buf);

  const files = [];
  for (const e of entries) {
    if (e.name.endsWith('/')) continue;
    if (shouldSkip(e.name)) continue;
    const content = isBinary(e.name) ? null : extractEntry(buf, e);
    files.push({ path: e.name, content, size: e.rawSize });
  }

  const title = path.basename(zipPath, path.extname(zipPath));
  return filesToMarkdown(files, title, opts);
}

/** پوشه → Markdown */
function folderToMarkdown(dir, opts = {}) {
  const files = [];
  const base = path.resolve(dir);

  (function walk(d) {
    let items;
    try { items = fs.readdirSync(d, { withFileTypes: true }); }
    catch { return; }
    for (const it of items) {
      const full = path.join(d, it.name);
      const rel = path.relative(base, full).split(path.sep).join('/');
      if (shouldSkip(rel)) continue;
      if (it.isDirectory()) { walk(full); continue; }
      if (!it.isFile()) continue;
      let st;
      try { st = fs.statSync(full); } catch { continue; }
      const content = isBinary(it.name) ? null
        : (() => { try { return fs.readFileSync(full); } catch { return null; } })();
      files.push({ path: rel, content, size: st.size });
    }
  })(base);

  return filesToMarkdown(files, path.basename(base), opts);
}

module.exports = { zipToMarkdown, folderToMarkdown, filesToMarkdown };
