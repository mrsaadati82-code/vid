'use strict';

/**
 * اصلاح چیدمان فارسی + فونت وزیرمتن.
 *
 * همان منطقی که در نسخه‌ی اندروید تست شد:
 * نسبت حروف فارسی هر بلوک سنجیده می‌شود (نه فقط کاراکتر اول)، چون
 * مرورگر جهت پاراگراف را از اولین کاراکتر جهت‌دار می‌گیرد و اگر جمله
 * با کلمه‌ی انگلیسی شروع شود کل پاراگراف LTR می‌شود.
 */

const fs = require('fs');
const path = require('path');

/**
 * 🔴 چرا فونت را جاسازی می‌کنیم؟
 *
 * CSP سایت Arena فقط این منابع را برای فونت مجاز می‌داند:
 *     font-src 'self' data: vercel.live assets.vercel.com *.gstatic.com
 *
 * jsdelivr در فهرست نیست، پس بارگذاری از CDN رد می‌شود:
 *     "Refused to load the font ... violates Content Security Policy"
 *
 * اما `data:` مجاز است. پس فونت را به‌صورت base64 داخل CSS می‌گذاریم.
 * مزیت جانبی: بدون اینترنت هم کار می‌کند و سریع‌تر است.
 */
let FONT_FACE = '';
try {
  const dir = path.join(__dirname, 'fonts');
  const b64 = (f) =>
    fs.readFileSync(path.join(dir, f)).toString('base64');
  FONT_FACE = `
@font-face {
  font-family: 'VazirmatnAP';
  font-style: normal; font-weight: 400; font-display: swap;
  src: url(data:font/woff2;base64,${b64('Vazirmatn-Regular.woff2')}) format('woff2');
}
@font-face {
  font-family: 'VazirmatnAP';
  font-style: normal; font-weight: 700; font-display: swap;
  src: url(data:font/woff2;base64,${b64('Vazirmatn-Bold.woff2')}) format('woff2');
}`;
} catch (e) {
  console.warn('فونت وزیرمتن بارگذاری نشد:', e.message);
  FONT_FACE = '';
}

function PERSIAN_CSS(s) {
  const scale = s.fontScale || 100;
  const stack = s.persianFont
    ? `'VazirmatnAP', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`
    : `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`;
  const gap = s.compact ? '0.35rem' : '0.75rem';

  const rtl = !s.rtlFix ? '' : `
[data-fa="1"] {
  direction: rtl !important;
  text-align: right !important;
}
[data-fa="1"] p, [data-fa="1"] li, [data-fa="1"] blockquote,
[data-fa="1"] td, [data-fa="1"] th {
  unicode-bidi: plaintext;
  text-align: right;
}
/* کد هرگز راست‌چین نشود — وگرنه خراب می‌شود */
pre, code, kbd, samp, pre *, code *,
[data-fa="1"] pre, [data-fa="1"] code,
[data-fa="1"] pre *, [data-fa="1"] code * {
  direction: ltr !important;
  text-align: left !important;
  unicode-bidi: isolate !important;
  font-family: 'SF Mono', Menlo, Consolas, monospace !important;
}
[data-fa="1"] a[href] { unicode-bidi: isolate; }
[data-fa="1"] ul, [data-fa="1"] ol {
  padding-right: 1.5em; padding-left: 0; list-style-position: outside;
}
textarea[data-fa="1"], [contenteditable="true"][data-fa="1"] {
  direction: rtl !important; text-align: right !important;
  unicode-bidi: plaintext;
}`;

  return `${FONT_FACE}

html, body, button, input, textarea, select, [contenteditable="true"] {
  font-family: ${stack} !important;
}
body { font-size: ${scale}% !important; -webkit-font-smoothing: antialiased; }
p, li, td, th, [contenteditable="true"], textarea {
  line-height: 1.9 !important; letter-spacing: 0 !important;
}
h1, h2, h3, h4 { line-height: 1.6 !important; }
p + p, li + li { margin-top: ${gap}; }
::-webkit-scrollbar { width: 9px; height: 9px; }
::-webkit-scrollbar-thumb { background: #8884; border-radius: 5px; }
::-webkit-scrollbar-thumb:hover { background: #8887; }
::-webkit-scrollbar-track { background: transparent; }
${rtl}`;
}

function PERSIAN_JS(s) {
  return `(function () {
  var RTL = ${s.rtlFix ? 'true' : 'false'};
  if (window.__apPersian) { window.__apPersian(RTL); return; }

  var FA   = /[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF]/;
  var FA_G = /[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF]/g;
  var LAT_G = /[A-Za-z]/g;
  var BLOCKS = 'p,li,td,th,blockquote,h1,h2,h3,h4,h5,h6,figcaption,dd,dt';

  function isPersian(t) {
    if (!t || t.length < 2) return false;
    if (!FA.test(t)) return false;
    var fa = (t.match(FA_G) || []).length;
    var la = (t.match(LAT_G) || []).length;
    return fa > 0 && fa >= (fa + la) * 0.30;
  }

  function mark(root, enabled) {
    if (!root || !root.querySelectorAll) return;
    var nodes = root.querySelectorAll(BLOCKS);
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (el.closest('pre,code')) continue;
      if (enabled && isPersian(el.textContent || '')) {
        el.setAttribute('data-fa', '1'); el.setAttribute('dir', 'rtl');
      } else {
        el.removeAttribute('data-fa'); el.removeAttribute('dir');
      }
    }
    var cs = root.querySelectorAll('[class*="message"],[class*="markdown"],[class*="prose"]');
    for (var j = 0; j < cs.length; j++) {
      var c = cs[j];
      if (c.querySelector(BLOCKS)) continue;
      if (enabled && isPersian(c.textContent || '')) {
        c.setAttribute('data-fa', '1'); c.setAttribute('dir', 'rtl');
      } else {
        c.removeAttribute('data-fa'); c.removeAttribute('dir');
      }
    }
  }

  function hookInputs(enabled) {
    var ins = document.querySelectorAll('textarea,[contenteditable="true"]');
    for (var i = 0; i < ins.length; i++) {
      var el = ins[i];
      if (el.dataset.apHooked === '1') continue;
      el.dataset.apHooked = '1';
      (function (node) {
        function upd() {
          var v = node.value !== undefined ? node.value : node.textContent;
          if (RTL && isPersian(v)) {
            node.setAttribute('data-fa', '1'); node.setAttribute('dir', 'rtl');
          } else {
            node.removeAttribute('data-fa'); node.setAttribute('dir', 'ltr');
          }
        }
        node.addEventListener('input', upd);
        node.addEventListener('focus', upd);
        upd();
      })(el);
    }
  }

  function runAll() {
    try { mark(document.body, RTL); hookInputs(RTL); } catch (e) {}
  }

  window.__apPersian = function (enabled) { RTL = enabled; runAll(); };

  runAll();
  var timer = null;
  new MutationObserver(function () {
    clearTimeout(timer); timer = setTimeout(runAll, 180);
  }).observe(document.documentElement, {
    childList: true, subtree: true, characterData: true
  });
})();`;
}

module.exports = { PERSIAN_CSS, PERSIAN_JS };
