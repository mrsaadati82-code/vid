'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * یادداشت‌ها: متن + چک‌لیست + تصویر.
 *
 * تصاویر روی دیسک ذخیره می‌شوند (نه داخل JSON) تا فایل داده بی‌رویه
 * بزرگ نشود. در متن یادداشت فقط با `![](note-img:ID)` ارجاع داده
 * می‌شوند و موقع نمایش به data URL تبدیل می‌گردند.
 */
class Notes {

  constructor(userDataDir) {
    this.dir = path.join(userDataDir, 'notes');
    this.imgDir = path.join(this.dir, 'images');
    fs.mkdirSync(this.imgDir, { recursive: true });
    this.file = path.join(this.dir, 'notes.json');
    this.data = this._load();
  }

  _load() {
    try {
      if (!fs.existsSync(this.file)) return { notes: [] };
      return JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch { return { notes: [] }; }
  }

  _save() {
    try { fs.writeFileSync(this.file, JSON.stringify(this.data), 'utf8'); }
    catch (e) { console.error('ذخیره‌ی یادداشت ناموفق:', e.message); }
  }

  list(query = '') {
    let all = this.data.notes;
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      all = all.filter(n =>
        (n.title || '').toLowerCase().includes(q) ||
        (n.body || '').toLowerCase().includes(q) ||
        (n.items || []).some(i => (i.text || '').toLowerCase().includes(q))
      );
    }
    return all
      .slice()
      .sort((a, b) => (b.pinned - a.pinned) || (b.updatedAt - a.updatedAt))
      .map(n => ({
        id: n.id,
        title: n.title || 'بدون عنوان',
        preview: (n.body || '').slice(0, 110).replace(/\s+/g, ' '),
        itemCount: (n.items || []).length,
        doneCount: (n.items || []).filter(i => i.done).length,
        imageCount: (n.images || []).length,
        pinned: !!n.pinned,
        updatedAt: n.updatedAt
      }));
  }

  get(id) {
    const n = this.data.notes.find(x => x.id === id);
    if (!n) return null;
    // تصاویر را به data URL تبدیل کن تا در رابط کاربری نمایش داده شوند
    const images = (n.images || []).map(img => {
      try {
        const p = path.join(this.imgDir, img.file);
        const b64 = fs.readFileSync(p).toString('base64');
        return { id: img.id, dataUrl: `data:${img.mime};base64,${b64}` };
      } catch { return null; }
    }).filter(Boolean);
    return { ...n, images };
  }

  save(note) {
    const now = Date.now();
    if (note.id) {
      const i = this.data.notes.findIndex(x => x.id === note.id);
      if (i >= 0) {
        // images را از ورودی نگیر — مدیریتش جداست
        const keep = this.data.notes[i].images || [];
        this.data.notes[i] = {
          ...this.data.notes[i], ...note, images: keep, updatedAt: now
        };
        this._save();
        return this.data.notes[i].id;
      }
    }
    const id = crypto.randomUUID();
    this.data.notes.unshift({
      id,
      title: note.title || '',
      body: note.body || '',
      items: note.items || [],
      images: [],
      pinned: false,
      createdAt: now,
      updatedAt: now
    });
    this._save();
    return id;
  }

  remove(id) {
    const n = this.data.notes.find(x => x.id === id);
    if (n) {
      (n.images || []).forEach(img => {
        try { fs.unlinkSync(path.join(this.imgDir, img.file)); } catch {}
      });
    }
    this.data.notes = this.data.notes.filter(x => x.id !== id);
    this._save();
  }

  togglePin(id) {
    const n = this.data.notes.find(x => x.id === id);
    if (n) { n.pinned = !n.pinned; n.updatedAt = Date.now(); this._save(); }
    return !!(n && n.pinned);
  }

  /** افزودن تصویر از مسیر فایل. */
  addImage(noteId, srcPath) {
    const n = this.data.notes.find(x => x.id === noteId);
    if (!n) throw new Error('یادداشت پیدا نشد');

    const ext = (path.extname(srcPath) || '.png').toLowerCase();
    const mime = {
      '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
      '.gif': 'image/gif', '.webp': 'image/webp'
    }[ext] || 'image/png';

    const id = crypto.randomUUID().slice(0, 8);
    const file = `${id}${ext}`;
    fs.copyFileSync(srcPath, path.join(this.imgDir, file));

    n.images = n.images || [];
    n.images.push({ id, file, mime });
    n.updatedAt = Date.now();
    this._save();
    return id;
  }

  /** افزودن تصویر از data URL (چسباندن از کلیپ‌بورد). */
  addImageFromDataUrl(noteId, dataUrl) {
    const n = this.data.notes.find(x => x.id === noteId);
    if (!n) throw new Error('یادداشت پیدا نشد');

    const m = /^data:([^;]+);base64,(.+)$/s.exec(dataUrl);
    if (!m) throw new Error('داده‌ی تصویر نامعتبر است');
    const mime = m[1];
    const ext = { 'image/png': '.png', 'image/jpeg': '.jpg',
                  'image/gif': '.gif', 'image/webp': '.webp' }[mime] || '.png';

    const id = crypto.randomUUID().slice(0, 8);
    const file = `${id}${ext}`;
    fs.writeFileSync(path.join(this.imgDir, file), Buffer.from(m[2], 'base64'));

    n.images = n.images || [];
    n.images.push({ id, file, mime });
    n.updatedAt = Date.now();
    this._save();
    return id;
  }

  removeImage(noteId, imageId) {
    const n = this.data.notes.find(x => x.id === noteId);
    if (!n) return;
    const img = (n.images || []).find(i => i.id === imageId);
    if (img) {
      try { fs.unlinkSync(path.join(this.imgDir, img.file)); } catch {}
      n.images = n.images.filter(i => i.id !== imageId);
      n.updatedAt = Date.now();
      this._save();
    }
  }

  /** خروجی Markdown — قابل آپلود در Arena. */
  toMarkdown(id) {
    const n = this.data.notes.find(x => x.id === id);
    if (!n) return '';
    const out = [`# ${n.title || 'بدون عنوان'}`, ''];
    if (n.body) { out.push(n.body, ''); }
    if ((n.items || []).length) {
      out.push('## چک‌لیست', '');
      n.items.forEach(i => out.push(`- [${i.done ? 'x' : ' '}] ${i.text}`));
      out.push('');
    }
    if ((n.images || []).length) {
      out.push(`_${n.images.length} تصویر پیوست (در متن گنجانده نشده)_`);
    }
    return out.join('\n');
  }

  stats() {
    return {
      count: this.data.notes.length,
      images: this.data.notes.reduce((s, n) => s + (n.images || []).length, 0),
      items: this.data.notes.reduce((s, n) => s + (n.items || []).length, 0)
    };
  }
}

module.exports = Notes;
