'use strict';

const { Menu, MenuItem, clipboard, shell, BrowserWindow } = require('electron');

/**
 * منوی راست‌کلیک وابسته به زمینه.
 *
 * BrowserView یک context نیتیو جداست — منوی مرورگر را خودکار نمی‌سازد.
 * باید روی رویداد `context-menu` بسازیمش.
 */

function buildMenu(wc, params, hooks = {}) {
  const menu = new Menu();
  const {
    isEditable, editFlags, selectionText, linkURL, srcURL,
    mediaType, misspelledWord, dictionarySuggestions
  } = params;

  const hasSelection = (selectionText || '').trim().length > 0;
  const add = (opts) => menu.append(new MenuItem(opts));
  const sep = () => menu.append(new MenuItem({ type: 'separator' }));

  // ── پیشنهاد املایی ──
  if (misspelledWord && (dictionarySuggestions || []).length) {
    dictionarySuggestions.slice(0, 4).forEach(w =>
      add({ label: w, click: () => wc.replaceMisspelling(w) }));
    sep();
  }

  // ── لینک ──
  if (linkURL) {
    add({
      label: 'باز کردن در تب جدید',
      click: () => hooks.openInNewTab && hooks.openInNewTab(linkURL)
    });
    add({
      label: 'باز کردن در مرورگر',
      click: () => shell.openExternal(linkURL)
    });
    add({
      label: 'کپی نشانی لینک',
      click: () => clipboard.writeText(linkURL)
    });
    sep();
  }

  // ── تصویر ──
  if (mediaType === 'image' && srcURL) {
    add({
      label: 'ذخیره‌ی تصویر',
      click: () => hooks.saveImage && hooks.saveImage(srcURL)
    });
    add({
      label: 'کپی تصویر',
      click: () => wc.copyImageAt(params.x, params.y)
    });
    add({
      label: 'کپی نشانی تصویر',
      click: () => clipboard.writeText(srcURL)
    });
    sep();
  }

  // ── ویرایش ──
  // 🔴 role روی BrowserView کار نمی‌کند (به webContents پنجره می‌رود).
  // مستقیم روی همین wc صدا می‌زنیم.
  if (isEditable) {
    add({ label: 'واگرد', accelerator: 'CmdOrCtrl+Z',
          enabled: editFlags.canUndo, click: () => wc.undo() });
    add({ label: 'ازنو', accelerator: 'Shift+CmdOrCtrl+Z',
          enabled: editFlags.canRedo, click: () => wc.redo() });
    sep();
    add({ label: 'برش', accelerator: 'CmdOrCtrl+X',
          enabled: editFlags.canCut, click: () => wc.cut() });
    add({ label: 'کپی', accelerator: 'CmdOrCtrl+C',
          enabled: editFlags.canCopy, click: () => wc.copy() });
    add({ label: 'چسباندن', accelerator: 'CmdOrCtrl+V',
          enabled: editFlags.canPaste, click: () => wc.paste() });
    add({ label: 'چسباندن بدون قالب', accelerator: 'Shift+CmdOrCtrl+V',
          enabled: editFlags.canPaste, click: () => wc.pasteAndMatchStyle() });
    sep();
    add({ label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A',
          click: () => wc.selectAll() });
  } else if (hasSelection) {
    add({ label: 'کپی', accelerator: 'CmdOrCtrl+C', click: () => wc.copy() });
    add({
      label: 'جست‌وجوی این متن در گوگل',
      click: () => shell.openExternal(
        'https://www.google.com/search?q=' + encodeURIComponent(selectionText))
    });
    add({
      label: 'درج در کادر چت',
      click: () => hooks.insertToChat && hooks.insertToChat(selectionText)
    });
    sep();
    add({ label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A',
          click: () => wc.selectAll() });
  }

  // ── ناوبری صفحه ──
  if (!isEditable && !linkURL && mediaType !== 'image') {
    if (menu.items.length) sep();
    add({
      label: 'عقب', accelerator: 'CmdOrCtrl+[',
      enabled: wc.canGoBack(), click: () => wc.goBack()
    });
    add({
      label: 'جلو', accelerator: 'CmdOrCtrl+]',
      enabled: wc.canGoForward(), click: () => wc.goForward()
    });
    add({
      label: 'بارگذاری مجدد', accelerator: 'CmdOrCtrl+R',
      click: () => wc.reload()
    });
    sep();
    add({ label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A',
          click: () => wc.selectAll() });
    add({
      label: 'کپی نشانی صفحه',
      click: () => clipboard.writeText(wc.getURL())
    });
  }

  // ── همیشه ──
  sep();
  add({
    label: 'بازرسی عنصر',
    click: () => wc.inspectElement(params.x, params.y)
  });

  return menu;
}

/**
 * نصب منو روی یک webContents.
 *
 * 🔴 باگی که اینجا رفع شد:
 * قبلاً `menu.popup({ window: hooks.window })` صدا زده می‌شد، اما
 * hooks.window در زمان createTab هنوز null بود (پنجره‌ی اصلی بعداً
 * ساخته می‌شود). popup با window نامعتبر بی‌صدا شکست می‌خورد.
 *
 * حالا پنجره را در لحظه‌ی راست‌کلیک پیدا می‌کنیم.
 */
function attachContextMenu(wc, hooks = {}) {
  wc.on('context-menu', (_e, params) => {
    try {
      const menu = buildMenu(wc, params, hooks);
      if (!menu.items.length) return;
      const win =
        (typeof hooks.getWindow === 'function' && hooks.getWindow()) ||
        BrowserWindow.fromWebContents(wc) ||
        BrowserWindow.getFocusedWindow() ||
        BrowserWindow.getAllWindows()[0];
      if (win) menu.popup({ window: win, x: params.x, y: params.y });
      else menu.popup();
    } catch (e) {
      console.error('منوی راست‌کلیک:', e.message);
    }
  });
}

module.exports = { attachContextMenu, buildMenu };
