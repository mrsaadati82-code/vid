'use strict';

const COLORS = [
  '#4285F4', '#EA4335', '#34A853', '#FBBC04',
  '#9C27B0', '#00ACC1', '#FF7043', '#5E35B1'
];

const BOARDS = [
  ['کلی', 'text', 'overall'], ['کدنویسی', 'text', 'coding'],
  ['ریاضی', 'text', 'math'], ['نویسندگی', 'text', 'creative_writing'],
  ['پرامپت سخت', 'text', 'hard_prompts'], ['انگلیسی', 'text', 'english'],
  ['غیرانگلیسی', 'text', 'non_english'], ['توسعه وب', 'webdev', 'overall'],
  ['بینایی', 'vision', 'overall'], ['اسناد', 'document', 'overall'],
  ['جست‌وجو', 'search', 'overall'], ['ایجنت', 'agent', 'overall'],
  ['تولید تصویر', 'text_to_image', 'overall'],
  ['ویرایش تصویر', 'image_edit', 'overall'],
  ['تولید ویدیو', 'text_to_video', 'overall']
];

let state = { profiles: [], activeProfileId: null, tabs: [], activeTabId: null };

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g,
  c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

if (navigator.platform.toLowerCase().includes('mac')) {
  document.body.classList.add('mac');
}

// ─────────────────────────────────────────────
//  آواتار و تب
// ─────────────────────────────────────────────

async function renderAvatars() {
  const el = $('avatars');
  el.innerHTML = '';
  state.profiles.forEach(p => {
    const d = document.createElement('div');
    d.className = 'avatar' + (p.id === state.activeProfileId ? ' active' : '');
    d.style.background = COLORS[(p.color || 0) % COLORS.length];
    d.textContent = (p.label || '?').trim().charAt(0).toUpperCase();
    d.title = p.label;
    d.onclick = async () => {
      if (p.id === state.activeProfileId) { openProfilesPanel(); return; }
      await AP.profiles.switch(p.id);
      state.activeProfileId = p.id;
      renderAvatars();
      refreshTabs();
    };
    d.oncontextmenu = (e) => { e.preventDefault(); openProfilesPanel(); };
    el.appendChild(d);
  });

  const add = document.createElement('button');
  add.className = 'avatar-add';
  add.innerHTML = '<svg><use href="#i-plus"/></svg>';
  add.title = 'افزودن اکانت';
  add.onclick = addProfile;
  el.appendChild(add);
}

async function renderTabs() {
  const el = $('tabbar');
  el.innerHTML = '';
  state.tabs.forEach(t => {
    const d = document.createElement('div');
    d.className = 'tab' + (t.id === state.activeTabId ? ' active' : '');
    d.innerHTML = `<span>${esc(t.title || 'تب')}</span>` +
      (state.tabs.length > 1
        ? `<div class="close"><svg><use href="#i-close"/></svg></div>` : '');
    d.onclick = async (e) => {
      if (e.target.closest('.close')) {
        await AP.tabs.close(t.id);
      } else {
        await AP.tabs.show(t.id);
      }
      refreshTabs();
    };
    el.appendChild(d);
  });

  const add = document.createElement('button');
  add.className = 'tab-add';
  add.innerHTML = '<svg><use href="#i-plus"/></svg>';
  add.title = 'تب جدید (⌘T)';
  add.onclick = async () => { await AP.tabs.open(); refreshTabs(); };
  el.appendChild(add);
}

async function refreshTabs() {
  const r = await AP.tabs.list();
  state.tabs = r.tabs;
  state.activeTabId = r.activeTabId;
  renderTabs();
}

async function addProfile() {
  const label = await promptDialog('نام اکانت جدید', 'مثلاً: اکانت کاری');
  if (label === null) return;
  const profiles = await AP.profiles.add(label);
  const r = await AP.profiles.list();
  state.profiles = profiles;
  state.activeProfileId = r.activeProfileId;
  renderAvatars();
  refreshTabs();
  toast('اکانت ساخته شد');
}

// ─────────────────────────────────────────────
//  پنل
// ─────────────────────────────────────────────

async function openPanel(title, html) {
  // 🔴 حیاتی: BrowserView یک لایه‌ی نیتیو روی HTML است. اگر کنارش نزنیم
  // پنل زیرش دفن می‌شود و نه دیده می‌شود نه کلیک می‌گیرد.
  await AP.panel.open();
  $('panelTitle').textContent = title;
  $('panelBody').innerHTML = html;
  $('overlay').classList.remove('hidden');
}

async function closePanel() {
  $('overlay').classList.add('hidden');
  await AP.panel.close();
}

$('panelClose').onclick = closePanel;
$('overlay').onclick = (e) => { if (e.target.id === 'overlay') closePanel(); };
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closePanel();
});

/**
 * پیام کوتاه. با `actions` یک دکمه‌ی ⋯ کنارش می‌آید که منوی عملیات
 * باز می‌کند. تا وقتی منو باز است، پیام محو نمی‌شود.
 */
function toast(msg, ms = 2600, actions = null) {
  const t = $('toast');
  const m = $('toastMenu');
  m.classList.add('hidden');

  t.innerHTML = '';
  const span = document.createElement('span');
  span.style.flex = '1';
  span.textContent = msg;
  t.appendChild(span);

  if (actions && actions.length) {
    const btn = document.createElement('button');
    btn.className = 'toast-act';
    btn.textContent = '⋯';
    btn.title = 'عملیات';
    btn.onclick = (e) => {
      e.stopPropagation();
      if (!m.classList.contains('hidden')) { m.classList.add('hidden'); return; }
      m.innerHTML = actions.map((a, i) =>
        `<div data-i="${i}">${esc(a.label)}</div>`).join('');
      m.classList.remove('hidden');
      clearTimeout(t._timer);              // تا منو باز است محو نشود
      m.querySelectorAll('[data-i]').forEach(el => {
        el.onclick = async () => {
          m.classList.add('hidden');
          t.classList.add('hidden');
          await actions[+el.dataset.i].run();
        };
      });
    };
    t.appendChild(btn);
  }

  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => {
    if (m.classList.contains('hidden')) t.classList.add('hidden');
  }, ms);
}

// کلیک بیرون → بستن منوی toast
document.addEventListener('click', (e) => {
  const m = $('toastMenu');
  if (m.classList.contains('hidden')) return;
  if (!e.target.closest('#toastMenu') && !e.target.closest('.toast-act')) {
    m.classList.add('hidden');
    $('toast').classList.add('hidden');
  }
});

/** دیالوگ ورودی ساده (بدون prompt نیتیو که در Electron کار نمی‌کند) */
function promptDialog(title, placeholder, initial = '') {
  return new Promise(async (resolve) => {
    await openPanel(title, `
      <input class="search" id="pdInput" placeholder="${esc(placeholder)}"
             value="${esc(initial)}">
      <div style="display:flex;gap:8px;margin-top:6px">
        <button class="btn" id="pdOk">تأیید</button>
        <button class="btn ghost" id="pdCancel">انصراف</button>
      </div>`);
    const input = $('pdInput');
    input.focus();
    const done = async (v) => { await closePanel(); resolve(v); };
    $('pdOk').onclick = () => done(input.value.trim());
    $('pdCancel').onclick = () => done(null);
    input.onkeydown = (e) => {
      if (e.key === 'Enter') done(input.value.trim());
      if (e.key === 'Escape') done(null);
    };
  });
}

// ─────────────────────────────────────────────
//  اکانت‌ها
// ─────────────────────────────────────────────

async function openProfilesPanel() {
  const { profiles, activeProfileId } = await AP.profiles.list();
  const html = profiles.map(p => `
    <div class="card" data-id="${p.id}">
      <div style="display:flex;align-items:center;gap:12px">
        <div class="avatar active" style="background:${COLORS[(p.color||0)%COLORS.length]};
             opacity:1;width:36px;height:36px;box-shadow:none">
          ${esc((p.label||'?').charAt(0).toUpperCase())}
        </div>
        <div style="flex:1">
          <div class="card-title">${esc(p.label)}</div>
          <div class="card-sub">${p.id === activeProfileId ? 'فعال' : 'برای سوییچ کلیک کنید'}</div>
        </div>
      </div>
      <div style="display:flex;gap:6px;margin-top:11px">
        <button class="btn ghost" data-act="rename" data-id="${p.id}"
                style="font-size:11px;padding:6px 12px">تغییر نام</button>
        <button class="btn ghost" data-act="signout" data-id="${p.id}"
                style="font-size:11px;padding:6px 12px">خروج از حساب</button>
        ${profiles.length > 1 ? `<button class="btn danger" data-act="delete" data-id="${p.id}"
                style="font-size:11px;padding:6px 12px">حذف</button>` : ''}
      </div>
    </div>`).join('');

  await openPanel('اکانت‌ها', html +
    `<button class="btn" id="apAdd" style="width:100%;margin-top:10px">+ افزودن اکانت</button>`);

  $('apAdd').onclick = () => { closePanel(); addProfile(); };

  $('panelBody').querySelectorAll('[data-act]').forEach(btn => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      if (btn.dataset.act === 'rename') {
        const p = profiles.find(x => x.id === id);
        const label = await promptDialog('تغییر نام', '', p.label);
        if (label) { state.profiles = await AP.profiles.rename(id, label); renderAvatars(); }
        openProfilesPanel();
      } else if (btn.dataset.act === 'signout') {
        await AP.profiles.signOut(id);
        toast('از حساب خارج شدید');
        closePanel();
      } else if (btn.dataset.act === 'delete') {
        const r = await AP.profiles.remove(id);
        if (r.ok) {
          const l = await AP.profiles.list();
          state.profiles = l.profiles;
          state.activeProfileId = l.activeProfileId;
          renderAvatars(); refreshTabs();
          toast('اکانت حذف شد');
        }
        closePanel();
      }
    };
  });

  $('panelBody').querySelectorAll('.card').forEach(c => {
    c.onclick = async () => {
      await AP.profiles.switch(c.dataset.id);
      state.activeProfileId = c.dataset.id;
      renderAvatars(); refreshTabs(); closePanel();
    };
  });
}

// ─────────────────────────────────────────────
//  لیدربورد
// ─────────────────────────────────────────────

let boardIndex = 0;

async function openLeaderboard() {
  const chips = BOARDS.map((b, i) =>
    `<div class="chip${i === boardIndex ? ' active' : ''}" data-i="${i}">${esc(b[0])}</div>`
  ).join('');
  await openPanel('لیدربورد', `<div class="chips">${chips}</div>
    <div id="lbBody"><div class="empty">در حال بارگذاری…</div></div>`);

  $('panelBody').querySelectorAll('.chip').forEach(c => {
    c.onclick = () => { boardIndex = +c.dataset.i; openLeaderboard(); };
  });

  try {
    const [, config, category] = BOARDS[boardIndex];
    const rows = await AP.leaderboard.fetch(config, category);
    $('lbBody').innerHTML = rows.length === 0
      ? `<div class="empty">داده‌ای یافت نشد</div>`
      : rows.map(r => {
          const medal = r.rank === 1 ? '🥇' : r.rank === 2 ? '🥈'
            : r.rank === 3 ? '🥉' : r.rank;
          return `<div class="lb-row">
            <div class="lb-rank">${medal}</div>
            <div style="flex:1;min-width:0">
              <div class="lb-name">${esc(r.model_name)}</div>
              <div class="lb-org">${esc(r.organization)} · ${(r.vote_count||0).toLocaleString('fa')} رأی</div>
            </div>
            <div class="lb-score">${Math.round(r.rating || 0)}</div>
          </div>`;
        }).join('');
  } catch (e) {
    $('lbBody').innerHTML =
      `<div class="empty"><span class="big">⚠️</span>بارگذاری ناموفق بود<br>${esc(e.message)}</div>`;
  }
}

// ─────────────────────────────────────────────
//  آرشیو
// ─────────────────────────────────────────────

async function openArchive(query = '') {
  const items = await AP.archive.list({ query });
  const list = items.length === 0
    ? `<div class="empty"><span class="big">🗂</span>
       ${query ? 'نتیجه‌ای یافت نشد' : 'هنوز مکالمه‌ای ذخیره نشده.<br>گفت‌وگوها خودکار اینجا می‌آیند.'}</div>`
    : items.map(c => `
      <div class="card" data-id="${c.id}">
        <div class="card-title">${c.starred ? '⭐ ' : ''}${esc(c.title)}</div>
        <div class="card-sub">${esc(c.snippet)}</div>
        <div class="card-sub" style="margin-top:6px;opacity:.65">
          ${new Date(c.savedAt).toLocaleString('fa-IR')}
        </div>
      </div>`).join('');

  await openPanel('آرشیو مکالمات',
    `<input class="search" id="arQ" placeholder="جست‌وجو…" value="${esc(query)}">
     <div id="arList">${list}</div>`);

  const q = $('arQ');
  q.focus();
  q.value = query;
  let t = null;
  q.oninput = () => {
    clearTimeout(t);
    t = setTimeout(() => openArchive(q.value), 320);
  };

  $('panelBody').querySelectorAll('.card').forEach(c => {
    c.onclick = async () => {
      const full = await AP.archive.get(c.dataset.id);
      if (!full) return;
      await openPanel(full.title, `
        <div style="display:flex;gap:8px;margin-bottom:14px">
          <button class="btn ghost" id="arStar">${full.starred ? '★ حذف ستاره' : '☆ ستاره‌دار'}</button>
          <button class="btn danger" id="arDel">حذف</button>
          <button class="btn ghost" id="arBack">بازگشت</button>
        </div>
        <div style="white-space:pre-wrap;line-height:1.95;font-size:13px">${esc(full.bodyText)}</div>`);
      $('arStar').onclick = async () => {
        await AP.archive.star(full.id, !full.starred); openArchive(query);
      };
      $('arDel').onclick = async () => {
        await AP.archive.remove([full.id]); openArchive(query); toast('حذف شد');
      };
      $('arBack').onclick = () => openArchive(query);
    };
  });
}

// ─────────────────────────────────────────────
//  پرامپت
// ─────────────────────────────────────────────

function extractVars(body) {
  const re = /\{([\p{L}\p{N}_][\p{L}\p{N}_ \-]{0,40})\}/gu;
  const out = [];
  let m;
  while ((m = re.exec(body))) {
    const v = m[1].trim();
    if (v && !out.includes(v)) out.push(v);
  }
  return out;
}

async function openPrompts() {
  const list = await AP.prompts.list();
  await openPanel('کتابخانه‌ی پرامپت',
    list.map(p => {
      const vars = extractVars(p.body);
      return `<div class="card" data-id="${p.id}">
        <div class="card-title">${esc(p.title)}</div>
        <div class="card-sub">${esc(p.body.slice(0, 110).replace(/\n/g, ' '))}</div>
        <div class="card-sub" style="margin-top:6px;color:var(--primary)">
          ${esc(p.category)}${vars.length ? ` · ${vars.length} متغیر` : ''}
        </div>
      </div>`;
    }).join('') +
    `<button class="btn" id="pAdd" style="width:100%;margin-top:10px">+ پرامپت جدید</button>`);

  $('pAdd').onclick = async () => {
    const title = await promptDialog('عنوان پرامپت', 'مثلاً: خلاصه‌ساز');
    if (!title) return;
    const body = await promptDialog('متن پرامپت', 'با {نام} می‌توانی متغیر بسازی');
    if (!body) return;
    await AP.prompts.save({ title, body, category: 'عمومی' });
    openPrompts();
  };

  $('panelBody').querySelectorAll('.card').forEach(c => {
    c.onclick = async () => {
      const p = list.find(x => String(x.id) === c.dataset.id);
      let text = p.body;
      const vars = extractVars(text);
      for (const v of vars) {
        const val = await promptDialog(`مقدار «${v}»`, v);
        if (val === null) return;
        if (val) text = text.split(`{${v}}`).join(val);
      }
      const ok = await AP.prompts.inject(text);
      closePanel();
      toast(ok ? 'در کادر متن درج شد' : 'کادر متن پیدا نشد — اول وارد صفحه‌ی چت شو');
    };
  });
}

// ─────────────────────────────────────────────
//  دانلود
// ─────────────────────────────────────────────

function humanSize(b) {
  if (!b) return '—';
  if (b < 1024) return b + ' B';
  if (b < 1048576) return Math.round(b / 1024) + ' KB';
  if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB';
  return (b / 1073741824).toFixed(2) + ' GB';
}

function fileIcon(mime, name) {
  const n = (name || '').toLowerCase();
  if ((mime || '').startsWith('image/')) return '🖼️';
  if ((mime || '').startsWith('video/')) return '🎬';
  if ((mime || '').startsWith('audio/')) return '🎵';
  if (n.endsWith('.pdf')) return '📕';
  if (n.endsWith('.zip') || n.endsWith('.rar')) return '🗜️';
  if (n.endsWith('.json') || n.endsWith('.csv')) return '📊';
  return '📄';
}

async function openDownloads() {
  const items = await AP.downloads.list();
  await openPanel('دانلودها',
    `<div style="display:flex;gap:8px;margin-bottom:14px">
       <button class="btn ghost" id="dlFolder">📁 باز کردن پوشه</button>
       ${items.length ? `<button class="btn ghost" id="dlClear">پاک کردن فهرست</button>` : ''}
     </div>` +
    (items.length === 0
      ? `<div class="empty"><span class="big">📥</span>
         هنوز چیزی دانلود نشده.<br>فایل‌ها در پوشه‌ی «Arena Plus» ذخیره می‌شوند.</div>`
      : items.map(d => `
        <div class="card" data-path="${esc(d.localPath)}">
          <div style="display:flex;align-items:center;gap:12px">
            <div style="font-size:22px">${fileIcon(d.mimeType, d.fileName)}</div>
            <div style="flex:1;min-width:0">
              <div class="card-title" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                ${esc(d.fileName)}</div>
              <div class="card-sub">${humanSize(d.sizeBytes)} ·
                ${new Date(d.createdAt).toLocaleString('fa-IR')}</div>
            </div>
          </div>
        </div>`).join('')));

  $('dlFolder').onclick = () => AP.downloads.folder();
  const clr = $('dlClear');
  if (clr) clr.onclick = async () => { await AP.downloads.clear(); openDownloads(); };

  $('panelBody').querySelectorAll('.card').forEach(c => {
    c.onclick = () => AP.downloads.open(c.dataset.path);
    c.oncontextmenu = (e) => { e.preventDefault(); AP.downloads.reveal(c.dataset.path); };
  });
}

// ─────────────────────────────────────────────
//  تنظیمات
// ─────────────────────────────────────────────

async function openSettings() {
  const s = await AP.settings.get();
  const st = await AP.storage.stats();
  const u = await AP.usage.stats();

  await openPanel('تنظیمات', `
    <div class="section-title">متن و چیدمان</div>

    <div class="row">
      <div style="flex:1">
        <div class="row-label">اصلاح چیدمان راست‌چین</div>
        <div class="row-desc">جمله‌های فارسی با کلمه‌ی انگلیسی درست بچینند</div>
      </div>
      <label class="switch"><input type="checkbox" id="sRtl" ${s.rtlFix ? 'checked' : ''}>
        <span class="slider"></span></label>
    </div>

    <div class="row">
      <div style="flex:1">
        <div class="row-label">فونت وزیرمتن</div>
        <div class="row-desc">فونت فارسی خوانا</div>
      </div>
      <label class="switch"><input type="checkbox" id="sFont" ${s.persianFont ? 'checked' : ''}>
        <span class="slider"></span></label>
    </div>

    <div class="row">
      <div style="width:112px">
        <div class="row-label">اندازه‌ی فونت</div>
        <div class="row-desc" id="sScaleLbl">${s.fontScale}٪</div>
      </div>
      <input type="range" id="sScale" min="80" max="150" value="${s.fontScale}">
    </div>

    <div class="row">
      <div style="flex:1">
        <div class="row-label">چیدمان فشرده</div>
        <div class="row-desc">فاصله‌ی کمتر بین پاراگراف‌ها</div>
      </div>
      <label class="switch"><input type="checkbox" id="sCompact" ${s.compact ? 'checked' : ''}>
        <span class="slider"></span></label>
    </div>

    <div class="section-title">آمار</div>
    <div style="display:flex;gap:8px;margin-bottom:6px">
      ${[['امروز', u.today], ['۷ روز', u.week], ['آرشیو', st.conversations]]
        .map(([l, v]) => `<div style="flex:1;text-align:center;padding:14px;
          background:var(--surface-2);border-radius:var(--radius)">
          <div style="font-size:21px;font-weight:700;color:var(--primary)">${v}</div>
          <div style="font-size:11px;color:var(--text-dim);margin-top:2px">${l}</div>
        </div>`).join('')}
    </div>
    <div class="card-sub" style="padding:4px">حجم آرشیو: ${humanSize(st.bytes)}</div>

    <div class="section-title">تشخیص شبکه</div>
    <div class="card" id="diagRun">
      <div class="card-title">🩺 بررسی دسترسی سرویس‌ها</div>
      <div class="card-sub">اگر لاگین گوگل کار نمی‌کند، اول این را بزن</div>
    </div>
    <div id="diagOut"></div>

    <div class="section-title">پاکسازی</div>
    ${[['old30', 'حذف مکالمات قدیمی‌تر از ۳۰ روز'],
       ['old7', 'حذف مکالمات قدیمی‌تر از ۷ روز'],
       ['unstarred', 'حذف مکالمات بدون ستاره'],
       ['usage', 'پاک کردن آمار مصرف']]
      .map(([k, l]) => `<div class="card" data-clear="${k}">
        <div class="card-title" style="font-weight:400;font-size:13px">${l}</div></div>`).join('')}
    <div class="card" data-clear="all">
      <div class="card-title" style="color:#DC2626">🗑 پاک کردن همه‌ی داده‌ها</div>
      <div class="card-sub">اکانت‌ها و لاگین‌ها باقی می‌مانند</div>
    </div>
  `);

  const setNow = (patch) => AP.settings.set(patch);
  $('sRtl').onchange     = e => setNow({ rtlFix: e.target.checked });
  $('sFont').onchange    = e => setNow({ persianFont: e.target.checked });
  $('sCompact').onchange = e => setNow({ compact: e.target.checked });
  $('sScale').oninput    = e => {
    $('sScaleLbl').textContent = e.target.value + '٪';
    setNow({ fontScale: +e.target.value });
  };

  $('diagRun').onclick = async () => {
    $('diagOut').innerHTML = '<div class="card-sub" style="padding:8px 4px">در حال بررسی…</div>';
    const rows = await AP.diag.network();
    $('diagOut').innerHTML = rows.map(r => `
      <div style="display:flex;align-items:center;gap:10px;padding:8px 6px;
           border-bottom:1px solid var(--border)">
        <span style="font-size:15px">${r.ok ? '✅' : '❌'}</span>
        <span style="flex:1;font-size:12.5px">${esc(r.name)}</span>
        <span style="font-size:11px;color:var(--text-dim)">
          ${r.ok ? r.ms + 'ms' : esc(r.error || 'مسدود')}</span>
      </div>`).join('') +
      (rows.find(r => r.name === 'reCAPTCHA اصلی' && !r.ok)
        ? `<div class="card" style="background:var(--primary-soft);margin-top:10px">
             <div class="card-sub" style="line-height:1.9">
             ℹ️ reCAPTCHA اصلی مسدود است. اپ خودکار به آینه‌ی رسمی
             <b>recaptcha.net</b> هدایت می‌کند. اگر آن هم ❌ است،
             لاگین گوگل بدون VPN کار نخواهد کرد.</div></div>`
        : '');
  };

  $('panelBody').querySelectorAll('[data-clear]').forEach(c => {
    c.onclick = async () => {
      const what = c.dataset.clear;
      if (what === 'all' && !confirm('همه‌ی داده‌ها پاک شود؟ برگشت‌پذیر نیست.')) return;
      await AP.storage.clear(what);
      toast('پاک شد');
      openSettings();
    };
  });
}


// ─────────────────────────────────────────────
//  صادرات پروژه به Markdown (Arena زیپ نمی‌پذیرد)
// ─────────────────────────────────────────────

async function openExport() {
  await openPanel('صادرات پروژه', `
    <div class="card-sub" style="line-height:1.9;margin-bottom:16px;padding:0 4px">
      سرور Arena فایل ZIP نمی‌پذیرد — فقط متن، تصویر، JSON و PDF.
      این ابزار پروژه‌ات را به یک فایل <b>Markdown</b> تبدیل می‌کند که
      Arena قبول می‌کند و برای مدل هم خواناتر است: درخت پوشه‌ها و
      محتوای همه‌ی فایل‌ها یکجا.
    </div>

    <div class="card" id="exZip">
      <div class="card-title">📦 از فایل ZIP</div>
      <div class="card-sub">یک زیپ انتخاب کن</div>
    </div>
    <div class="card" id="exFolder">
      <div class="card-title">📁 از پوشه</div>
      <div class="card-sub">مستقیم از پوشه‌ی پروژه</div>
    </div>
    <div class="card" id="exRepo">
      <div class="card-title">🐙 از مخزن GitHub</div>
      <div class="card-sub">نیاز به اتصال GitHub</div>
    </div>

    <div id="exResult" style="margin-top:14px"></div>
  `);

  const show = (r) => {
    if (!r) return;
    $('exResult').innerHTML = `
      <div class="card" style="background:var(--primary-soft)">
        <div class="card-title">✅ ${esc(r.name)}</div>
        <div class="card-sub">${r.sizeKB} کیلوبایت · پوشه‌ی Arena Plus</div>
        <div class="card-sub" style="margin-top:8px">
          حالا در Arena روی آیکون پیوست بزن و همین فایل را انتخاب کن.
        </div>
      </div>`;
    toast('فایل Markdown ساخته شد', 4000);
  };

  $('exZip').onclick    = async () => show(await AP.exportMd.fromZip());
  $('exFolder').onclick = async () => show(await AP.exportMd.fromFolder());
  $('exRepo').onclick   = () => openGitHub();
}

// ─────────────────────────────────────────────
//  GitHub
// ─────────────────────────────────────────────

let ghCtx = { owner: '', repo: '', branch: '', path: '' };

async function openGitHub() {
  const st = await AP.gh.status();

  if (!st.connected) {
    await openPanel('GitHub', `
      <div class="card-sub" style="line-height:2;margin-bottom:16px;padding:0 4px">
        برای اتصال یک <b>Personal Access Token</b> بساز:
        <br><br>
        ۱. <span style="color:var(--primary);cursor:pointer" id="ghLink">
             github.com/settings/tokens</span> را باز کن
        <br>۲. <b>Generate new token (classic)</b>
        <br>۳. دسترسی <code>repo</code>، <code>delete_repo</code> و
             <code>gist</code> را تیک بزن
        <br>۴. توکن را کپی و اینجا بچسبان
      </div>
      <input class="search" id="ghToken" placeholder="ghp_..." type="password">
      <button class="btn" id="ghGo" style="width:100%">اتصال</button>
      <div id="ghErr" style="margin-top:12px"></div>`);

    $('ghLink').onclick = () => AP.nav.external('https://github.com/settings/tokens');
    $('ghGo').onclick = async () => {
      const t = $('ghToken').value.trim();
      if (!t) return;
      $('ghGo').textContent = 'در حال بررسی…';
      const r = await AP.gh.connect(t);
      if (r.ok) { toast(`متصل شد: ${r.login}`); openGitHub(); }
      else {
        $('ghGo').textContent = 'اتصال';
        $('ghErr').innerHTML = `<div class="card" style="background:#DC262622">
          <div class="card-sub">❌ ${esc(r.error)}</div></div>`;
      }
    };
    $('ghToken').onkeydown = (e) => { if (e.key === 'Enter') $('ghGo').click(); };
    return;
  }

  await openPanel('GitHub', `
    <div class="card" style="background:var(--primary-soft)">
      <div style="display:flex;align-items:center;gap:12px">
        ${st.avatar ? `<img src="${esc(st.avatar)}"
          style="width:40px;height:40px;border-radius:50%">` : ''}
        <div style="flex:1">
          <div class="card-title">${esc(st.name || st.login)}</div>
          <div class="card-sub">@${esc(st.login)}</div>
        </div>
      </div>
    </div>

    <div style="display:flex;gap:6px;margin:12px 0">
      <button class="btn" id="ghNew" style="flex:1;font-size:12px">+ مخزن جدید</button>
      <button class="btn ghost" id="ghOut" style="font-size:12px">قطع</button>
    </div>

    <input class="search" id="ghFilter" placeholder="فیلتر مخزن‌ها…">
    <div id="ghRepos"><div class="empty">در حال بارگذاری…</div></div>`);

  $('ghOut').onclick = async () => {
    if (!confirm('اتصال GitHub قطع شود؟')) return;
    await AP.gh.disconnect(); toast('قطع شد'); openGitHub();
  };
  $('ghNew').onclick = () => createRepoDialog(st.login);

  let all = [];
  try {
    all = await AP.gh.repos();
  } catch (e) {
    $('ghRepos').innerHTML = `<div class="empty">خطا: ${esc(e.message)}</div>`;
    return;
  }

  const render = (list) => {
    $('ghRepos').innerHTML = list.length === 0
      ? '<div class="empty">مخزنی نیست</div>'
      : list.map(r => `
        <div class="card" data-o="${esc(r.owner.login)}" data-r="${esc(r.name)}"
             data-b="${esc(r.default_branch || 'main')}">
          <div class="card-title">${r.private ? '🔒 ' : '📂 '}${esc(r.name)}</div>
          <div class="card-sub">${esc(r.description || 'بدون توضیح')}</div>
          <div class="card-sub" style="margin-top:5px;color:var(--primary)">
            ${esc(r.language || '—')} · ⭐ ${r.stargazers_count} ·
            ${new Date(r.updated_at).toLocaleDateString('fa-IR')}
          </div>
        </div>`).join('');

    $('ghRepos').querySelectorAll('.card').forEach(c => {
      c.onclick = () => openRepo(c.dataset.o, c.dataset.r, c.dataset.b);
    });
  };
  render(all);

  $('ghFilter').oninput = (e) => {
    const q = e.target.value.trim().toLowerCase();
    render(q ? all.filter(r =>
      r.name.toLowerCase().includes(q) ||
      (r.description || '').toLowerCase().includes(q)) : all);
  };
}

async function createRepoDialog(login) {
  const name = await promptDialog('نام مخزن جدید', 'my-project');
  if (!name) return;
  const desc = await promptDialog('توضیح (اختیاری)', '');
  if (desc === null) return;
  const isPrivate = confirm('مخزن خصوصی باشد؟\n\nOK = خصوصی · Cancel = عمومی');
  try {
    const r = await AP.gh.createRepo({
      name, description: desc || '', isPrivate, autoInit: true
    });
    toast(`✅ ${r.full_name} ساخته شد`, 4000);
    openRepo(login, name, r.default_branch || 'main');
  } catch (e) { toast('خطا: ' + e.message, 5000); }
}

// ───────── مرورگر مخزن ─────────

const ghSelected = new Set();

async function openRepo(owner, repo, branch = '', dir = '') {
  ghCtx = { owner, repo, branch, path: dir };
  ghSelected.clear();

  await openPanel(`${repo}`, `
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">
      <button class="btn ghost" id="rBack" style="font-size:11.5px">‹ مخزن‌ها</button>
      <button class="btn ghost" id="rUpFiles" style="font-size:11.5px">⬆ آپلود فایل</button>
      <button class="btn ghost" id="rUpFolder" style="font-size:11.5px">📁 آپلود پوشه</button>
      <button class="btn ghost" id="rExport" style="font-size:11.5px">📤 به Markdown</button>
      <button class="btn ghost" id="rWeb" style="font-size:11.5px">🌐 باز کردن</button>
    </div>

    <div id="rCrumb" class="card-sub" style="padding:0 4px 10px"></div>

    <div id="rBar" style="display:none;gap:6px;margin-bottom:10px">
      <span id="rCount" class="card-sub" style="flex:1;align-self:center"></span>
      <button class="btn danger" id="rDelSel" style="font-size:11.5px">حذف انتخاب‌شده‌ها</button>
      <button class="btn ghost" id="rClearSel" style="font-size:11.5px">لغو</button>
    </div>

    <div id="rList"><div class="empty">در حال بارگذاری…</div></div>`);

  $('rBack').onclick   = () => openGitHub();
  $('rWeb').onclick    = () => AP.nav.external(`https://github.com/${owner}/${repo}`);
  $('rExport').onclick = async () => {
    toast('در حال دریافت مخزن…', 6000);
    try {
      const r = await AP.gh.exportRepo(owner, repo);
      toast(`✅ ${r.name} (${r.sizeKB} KB) در پوشه‌ی Arena Plus`, 5000);
    } catch (e) { toast('خطا: ' + e.message, 5000); }
  };
  $('rUpFiles').onclick = async () => {
    try {
      const r = await AP.gh.uploadFiles(owner, repo, branch, dir);
      if (r) { toast(`✅ ${r.count} فایل آپلود شد`, 4000); openRepo(owner, repo, branch, dir); }
    } catch (e) { toast('خطا: ' + e.message, 5000); }
  };
  $('rUpFolder').onclick = async () => {
    if (!confirm('کل پوشه آپلود شود؟\nnode_modules و .git رد می‌شوند.')) return;
    toast('در حال آپلود…', 8000);
    try {
      const r = await AP.gh.uploadFolder(owner, repo, branch);
      if (r) { toast(`✅ ${r.count} فایل آپلود شد`, 4000); openRepo(owner, repo, branch, dir); }
    } catch (e) { toast('خطا: ' + e.message, 5000); }
  };

  // مسیر شکسته
  const parts = dir ? dir.split('/') : [];
  $('rCrumb').innerHTML = `<span style="cursor:pointer;color:var(--primary)"
      data-p="">${esc(repo)}</span>` +
    parts.map((seg, i) => ` / <span style="cursor:pointer;color:var(--primary)"
      data-p="${esc(parts.slice(0, i + 1).join('/'))}">${esc(seg)}</span>`).join('');
  $('rCrumb').querySelectorAll('[data-p]').forEach(x => {
    x.onclick = () => openRepo(owner, repo, branch, x.dataset.p);
  });

  function updateBar() {
    const n = ghSelected.size;
    $('rBar').style.display = n ? 'flex' : 'none';
    $('rCount').textContent = `${n} مورد انتخاب شد`;
  }

  $('rClearSel').onclick = () => { ghSelected.clear(); openRepo(owner, repo, branch, dir); };

  $('rDelSel').onclick = async () => {
    const files = [...ghSelected];
    if (!files.length) return;
    if (!confirm(`${files.length} فایل حذف شود؟\n\nاین کار یک commit می‌سازد و برگشت‌پذیر نیست.`)) return;
    toast('در حال حذف…', 6000);
    try {
      const r = await AP.gh.batch(owner, repo,
        files.map(p => ({ path: p, delete: true })),
        `حذف ${files.length} فایل از Arena Plus`, branch);
      toast(`✅ ${r.count} فایل حذف شد`, 4000);
      ghSelected.clear();
      openRepo(owner, repo, branch, dir);
    } catch (e) { toast('خطا: ' + e.message, 6000); }
  };

  // محتوای پوشه
  try {
    const items = await AP.gh.tree(owner, repo, branch);
    const prefix = dir ? dir + '/' : '';
    const depth = prefix ? prefix.split('/').length - 1 : 0;

    const dirs = new Set();
    const files = [];
    items.items.forEach(it => {
      if (!it.path.startsWith(prefix)) return;
      const rest = it.path.slice(prefix.length);
      if (!rest) return;
      const segs = rest.split('/');
      if (segs.length > 1) dirs.add(segs[0]);
      else if (it.type === 'blob') files.push(it);
    });

    $('rList').innerHTML =
      [...dirs].sort().map(d => `
        <div class="card" data-dir="${esc(d)}" style="padding:11px 14px">
          <div class="card-title" style="font-weight:400">📁 ${esc(d)}</div>
        </div>`).join('') +
      files.sort((a, b) => a.path.localeCompare(b.path)).map(f => {
        const name = f.path.slice(prefix.length);
        return `
        <div class="card" data-file="${esc(f.path)}" style="padding:11px 14px">
          <div style="display:flex;align-items:center;gap:10px">
            <input type="checkbox" data-sel="${esc(f.path)}"
                   style="width:16px;height:16px;accent-color:var(--primary);cursor:pointer">
            <div style="flex:1;min-width:0">
              <div class="card-title" style="font-weight:400;overflow:hidden;
                   text-overflow:ellipsis;white-space:nowrap">📄 ${esc(name)}</div>
              <div class="card-sub">${f.size ? Math.round(f.size / 1024) + ' KB' : ''}</div>
            </div>
          </div>
        </div>`;
      }).join('') ||
      '<div class="empty">این پوشه خالی است</div>';

    $('rList').querySelectorAll('[data-dir]').forEach(c => {
      c.onclick = () => openRepo(owner, repo, branch,
        (dir ? dir + '/' : '') + c.dataset.dir);
    });

    $('rList').querySelectorAll('[data-sel]').forEach(cb => {
      cb.checked = ghSelected.has(cb.dataset.sel);
      cb.onclick = (e) => e.stopPropagation();
      cb.onchange = () => {
        if (cb.checked) ghSelected.add(cb.dataset.sel);
        else ghSelected.delete(cb.dataset.sel);
        updateBar();
      };
    });

    $('rList').querySelectorAll('[data-file]').forEach(c => {
      c.onclick = (e) => {
        if (e.target.type === 'checkbox') return;
        viewFile(owner, repo, branch, c.dataset.file, dir);
      };
    });

    updateBar();
  } catch (e) {
    $('rList').innerHTML = `<div class="empty">خطا: ${esc(e.message)}</div>`;
  }
}

async function viewFile(owner, repo, branch, p, backDir) {
  await openPanel(p.split('/').pop(), `<div class="empty">در حال بارگذاری…</div>`);
  try {
    const txt = await AP.gh.file(owner, repo, p, branch);
    await openPanel(p.split('/').pop(), `
      <div style="display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap">
        <button class="btn ghost" id="fBack" style="font-size:11.5px">‹ بازگشت</button>
        <button class="btn ghost" id="fCopy" style="font-size:11.5px">📋 کپی</button>
        <button class="btn ghost" id="fToChat" style="font-size:11.5px">💬 درج در چت</button>
        <button class="btn danger" id="fDel" style="font-size:11.5px">حذف</button>
      </div>
      <div class="card-sub" style="padding:0 4px 10px">${esc(p)}</div>
      <pre style="background:var(--surface-2);padding:14px;border-radius:10px;
           overflow-x:auto;font-size:11.5px;line-height:1.7;direction:ltr;
           text-align:left;white-space:pre-wrap;word-break:break-word;
           max-height:60vh;overflow-y:auto">${esc(txt.slice(0, 60000))}</pre>`);

    $('fBack').onclick = () => openRepo(owner, repo, branch, backDir);
    $('fCopy').onclick = () => {
      navigator.clipboard.writeText(txt); toast('کپی شد');
    };
    $('fToChat').onclick = async () => {
      const ok = await AP.prompts.inject('```\n' + txt.slice(0, 20000) + '\n```\n\n');
      await closePanel();
      toast(ok ? 'در چت درج شد' : 'کادر متن پیدا نشد');
    };
    $('fDel').onclick = async () => {
      if (!confirm(`«${p}» حذف شود؟`)) return;
      try {
        await AP.gh.deleteFile(owner, repo, p, `حذف ${p}`, branch);
        toast('حذف شد');
        openRepo(owner, repo, branch, backDir);
      } catch (e) { toast('خطا: ' + e.message, 5000); }
    };
  } catch (e) {
    await openPanel('خطا', `<div class="empty">${esc(e.message)}</div>`);
  }
}

// ─────────────────────────────────────────────
//  یادداشت‌ها
// ─────────────────────────────────────────────

async function openNotes(query = '') {
  const list = await AP.notes.list(query);
  await openPanel('یادداشت‌ها', `
    <input class="search" id="nQ" placeholder="جست‌وجو…" value="${esc(query)}">
    <button class="btn" id="nAdd" style="width:100%;margin-bottom:12px">
      + یادداشت جدید</button>
    <div id="nList">${
      list.length === 0
        ? `<div class="empty"><span class="big">📝</span>
           ${query ? 'نتیجه‌ای نیست' : 'هنوز یادداشتی نداری'}</div>`
        : list.map(n => `
          <div class="card" data-id="${n.id}">
            <div class="card-title">${n.pinned ? '📌 ' : ''}${esc(n.title)}</div>
            ${n.preview ? `<div class="card-sub">${esc(n.preview)}</div>` : ''}
            <div class="card-sub" style="margin-top:6px;color:var(--primary)">
              ${n.itemCount ? `☑ ${n.doneCount}/${n.itemCount}` : ''}
              ${n.imageCount ? ` 🖼 ${n.imageCount}` : ''}
              ${!n.itemCount && !n.imageCount
                ? new Date(n.updatedAt).toLocaleDateString('fa-IR') : ''}
            </div>
          </div>`).join('')
    }</div>
  `);

  const q = $('nQ');
  let t = null;
  q.oninput = () => { clearTimeout(t); t = setTimeout(() => openNotes(q.value), 300); };

  $('nAdd').onclick = async () => {
    const id = await AP.notes.save({ title: 'یادداشت جدید', body: '', items: [] });
    openNoteEditor(id);
  };

  $('nList').querySelectorAll('.card').forEach(c => {
    c.onclick = () => openNoteEditor(c.dataset.id);
  });
}

async function openNoteEditor(id) {
  const n = await AP.notes.get(id);
  if (!n) return openNotes();

  await openPanel('ویرایش یادداشت', `
    <input class="search" id="neTitle" placeholder="عنوان"
           value="${esc(n.title)}" style="font-weight:700;font-size:15px">

    <textarea class="search" id="neBody" placeholder="متن یادداشت…
(می‌توانی تصویر را مستقیم اینجا Paste کنی)"
      style="min-height:130px;resize:vertical;line-height:1.9">${esc(n.body)}</textarea>

    <div class="section-title">چک‌لیست</div>
    <div id="neItems"></div>
    <div style="display:flex;gap:6px;margin-top:6px">
      <input class="search" id="neNew" placeholder="مورد جدید…"
             style="margin:0;flex:1">
      <button class="btn ghost" id="neAddItem">+</button>
    </div>

    <div class="section-title">تصاویر</div>
    <div id="neImages" style="display:flex;flex-wrap:wrap;gap:8px"></div>
    <button class="btn ghost" id="neAddImg" style="width:100%;margin-top:8px">
      🖼 افزودن تصویر</button>

    <div style="display:flex;gap:8px;margin-top:20px">
      <button class="btn" id="neSave" style="flex:1">ذخیره</button>
      <button class="btn ghost" id="nePin">${n.pinned ? '📌 برداشتن' : '📌 سنجاق'}</button>
      <button class="btn ghost" id="neExport">⬇ md</button>
      <button class="btn danger" id="neDel">حذف</button>
    </div>
  `);

  let items = (n.items || []).slice();

  function renderItems() {
    $('neItems').innerHTML = items.length === 0
      ? `<div class="card-sub" style="padding:4px">موردی نیست</div>`
      : items.map((it, i) => `
        <div style="display:flex;align-items:center;gap:10px;padding:8px 4px">
          <input type="checkbox" data-i="${i}" ${it.done ? 'checked' : ''}
                 style="width:17px;height:17px;accent-color:var(--primary);cursor:pointer">
          <span contenteditable="true" data-edit="${i}"
                style="flex:1;font-size:13.5px;outline:none;padding:2px 4px;
                       border-radius:5px;${it.done
            ? 'text-decoration:line-through;opacity:.5' : ''}">${esc(it.text)}</span>
          <span data-del="${i}" style="cursor:pointer;opacity:.45;padding:0 6px">✕</span>
        </div>`).join('');

    $('neItems').querySelectorAll('input[type=checkbox]').forEach(cb => {
      cb.onchange = () => { items[+cb.dataset.i].done = cb.checked; renderItems(); };
    });
    $('neItems').querySelectorAll('[data-del]').forEach(x => {
      x.onclick = () => { items.splice(+x.dataset.del, 1); renderItems(); };
    });
    // ویرایش درجا
    $('neItems').querySelectorAll('[data-edit]').forEach(sp => {
      sp.onblur = () => {
        const t = sp.textContent.trim();
        if (t) items[+sp.dataset.edit].text = t;
        else { items.splice(+sp.dataset.edit, 1); renderItems(); }
      };
      sp.onkeydown = (e) => {
        if (e.key === 'Enter') { e.preventDefault(); sp.blur(); $('neNew').focus(); }
      };
    });
  }
  renderItems();

  function renderImages() {
    $('neImages').innerHTML = (n.images || []).map(img => `
      <div style="position:relative">
        <img src="${img.dataUrl}" style="width:78px;height:78px;object-fit:cover;
             border-radius:9px;border:1px solid var(--border)">
        <div data-img="${img.id}" style="position:absolute;top:-5px;left:-5px;
             width:20px;height:20px;border-radius:50%;background:#DC2626;color:#fff;
             font-size:12px;display:flex;align-items:center;justify-content:center;
             cursor:pointer">✕</div>
      </div>`).join('') ||
      `<div class="card-sub" style="padding:4px">تصویری نیست</div>`;

    $('neImages').querySelectorAll('[data-img]').forEach(x => {
      x.onclick = async () => {
        await AP.notes.removeImage(id, x.dataset.img);
        openNoteEditor(id);
      };
    });
  }
  renderImages();

  /** یک متن را به چند مورد تبدیل می‌کند. */
  function parseLines(raw) {
    return String(raw)
      .split(/\r?\n/)
      .map(l => l
        // پیشوندهای رایج لیست را پاک کن
        .replace(/^\s*[-*•‣▪]\s+/, '')
        .replace(/^\s*\d+[.)]\s+/, '')
        .replace(/^\s*\[[ xX]\]\s*/, '')
        .trim())
      .filter(Boolean);
  }

  const addItem = () => {
    const raw = $('neNew').value;
    const lines = parseLines(raw);
    if (!lines.length) return;
    lines.forEach(t => items.push({ text: t, done: false }));
    $('neNew').value = '';
    renderItems();
    if (lines.length > 1) toast(`${lines.length} مورد اضافه شد`);
    $('neNew').focus();
  };

  $('neAddItem').onclick = addItem;

  // Enter → مورد بعدی · Shift+Enter → خط جدید در همان مورد
  $('neNew').onkeydown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addItem(); }
  };

  // 📋 چسباندن چندخطی → هر خط یک مورد
  $('neNew').onpaste = (e) => {
    const text = (e.clipboardData || window.clipboardData).getData('text');
    if (!text || !/\r?\n/.test(text.trim())) return;   // تک‌خطی: رفتار عادی
    e.preventDefault();
    const lines = parseLines(text);
    if (!lines.length) return;
    lines.forEach(t => items.push({ text: t, done: false }));
    renderItems();
    toast(`${lines.length} مورد از کلیپ‌بورد اضافه شد`);
  };

  // چسباندن تصویر از کلیپ‌بورد
  $('neBody').onpaste = async (e) => {
    const item = [...(e.clipboardData?.items || [])]
      .find(i => i.type.startsWith('image/'));
    if (!item) return;
    e.preventDefault();
    const blob = item.getAsFile();
    const reader = new FileReader();
    reader.onloadend = async () => {
      await AP.notes.save({ id, title: $('neTitle').value,
                            body: $('neBody').value, items });
      await AP.notes.pasteImage(id, String(reader.result));
      toast('تصویر اضافه شد');
      openNoteEditor(id);
    };
    reader.readAsDataURL(blob);
  };

  $('neAddImg').onclick = async () => {
    await AP.notes.save({ id, title: $('neTitle').value,
                          body: $('neBody').value, items });
    const r = await AP.notes.addImage(id);
    if (r) openNoteEditor(id);
  };

  $('neSave').onclick = async () => {
    await AP.notes.save({ id, title: $('neTitle').value.trim() || 'بدون عنوان',
                          body: $('neBody').value, items });
    toast('ذخیره شد');
    openNotes();
  };

  $('nePin').onclick = async () => { await AP.notes.pin(id); openNoteEditor(id); };

  $('neExport').onclick = async () => {
    await AP.notes.save({ id, title: $('neTitle').value,
                          body: $('neBody').value, items });
    const p = await AP.notes.exportFile(id);
    if (p) toast('ذخیره شد: ' + p.split('/').pop(), 4000);
  };

  $('neDel').onclick = async () => {
    if (!confirm('این یادداشت حذف شود؟')) return;
    await AP.notes.remove(id);
    toast('حذف شد');
    openNotes();
  };
}

// ─────────────────────────────────────────────
//  اتصال دکمه‌ها
// ─────────────────────────────────────────────


$('btnBack').onclick    = () => AP.nav.back();
$('btnForward').onclick = () => AP.nav.forward();
$('btnReload').onclick  = () => AP.nav.reload();
$('btnHome').onclick    = () => AP.nav.home();
$('btnBoard').onclick     = openLeaderboard;
$('btnArchive').onclick   = () => openArchive('');
$('btnPrompts').onclick   = openPrompts;
$('btnDownloads').onclick = openDownloads;
$('btnSettings').onclick  = openSettings;
$('btnNotes').onclick     = () => openNotes('');
$('btnExport').onclick    = openExport;
$('btnGithub').onclick    = openGitHub;

// ─────────────────────────────────────────────
//  رویدادها
// ─────────────────────────────────────────────

AP.on('profiles-changed', (p) => {
  state.profiles = p.profiles;
  state.activeProfileId = p.activeProfileId;
  renderAvatars();
});

AP.on('tabs-changed', (t) => {
  state.tabs = t.tabs;
  state.activeTabId = t.activeTabId;
  renderTabs();
});

AP.on('download-started', (d) => toast(`دانلود «${d.fileName}» شروع شد`));
AP.on('download-done', (d) => {
  toast(`✅ ${d.fileName}`, 7000, [
    { label: '📂 باز کردن فایل',      run: () => AP.downloads.open(d.path) },
    { label: '📁 نمایش در Finder',    run: () => AP.downloads.reveal(d.path) },
    { label: '📋 کپی مسیر',
      run: () => { navigator.clipboard.writeText(d.path); toast('کپی شد'); } },
    { label: '⬇ فهرست دانلودها',      run: () => openDownloads() },
    { label: '🗑 حذف فایل', run: async () => {
        const list = await AP.downloads.list();
        const item = list.find(x => x.localPath === d.path);
        if (item) { await AP.downloads.remove(item.id); toast('حذف شد'); }
      } }
  ]);
});
AP.on('download-failed', () => toast('دانلود ناموفق بود'));
AP.on('load-error', (e) => toast(`بارگذاری ناموفق: ${e.desc}`, 4000));

// باز کردن پنل از منوی برنامه (شورت‌کات‌ها)
AP.on('open-panel', (which) => {
  ({
    notes:     () => openNotes(''),
    archive:   () => openArchive(''),
    prompts:   openPrompts,
    downloads: openDownloads,
    github:    openGitHub,
    board:     openLeaderboard,
    settings:  openSettings,
    export:    openExport
  }[which] || (() => {}))();
});

(async function init() {
  const p = await AP.profiles.list();
  state.profiles = p.profiles;
  state.activeProfileId = p.activeProfileId;
  renderAvatars();
  await refreshTabs();
})();
