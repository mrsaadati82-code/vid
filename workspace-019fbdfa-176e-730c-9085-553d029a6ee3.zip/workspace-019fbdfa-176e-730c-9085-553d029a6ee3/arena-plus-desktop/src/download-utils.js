'use strict';

const MIME_EXT = {
  'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp',
  'image/gif': 'gif', 'image/svg+xml': 'svg',
  'application/pdf': 'pdf', 'application/json': 'json',
  'application/zip': 'zip', 'text/plain': 'txt',
  'text/markdown': 'md', 'text/csv': 'csv',
  'video/mp4': 'mp4', 'audio/mpeg': 'mp3'
};

/** نام فایل تمیز و امن. */
function resolveFileName(rawName, mimeType, url) {
  let name = (rawName || '').trim();

  if (!name && url) {
    try {
      const p = new URL(url).pathname.split('/').pop();
      if (p) name = decodeURIComponent(p);
    } catch { /* ignore */ }
  }
  if (!name) name = `arena_${Date.now()}`;

  if (!name.includes('.')) {
    const ext = MIME_EXT[(mimeType || '').split(';')[0].trim()];
    if (ext) name = `${name}.${ext}`;
  }

  // کاراکترهای غیرمجاز در ویندوز و مک
  name = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim();
  name = name.replace(/^\.+/, '');            // فایل مخفی نشود
  if (!name) name = `arena_${Date.now()}`;
  return name.slice(0, 150);
}

function humanSize(bytes) {
  if (!bytes || bytes <= 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${Math.round(bytes / 1024)} KB`;
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${(bytes / 1073741824).toFixed(2)} GB`;
}

module.exports = { resolveFileName, humanSize };
