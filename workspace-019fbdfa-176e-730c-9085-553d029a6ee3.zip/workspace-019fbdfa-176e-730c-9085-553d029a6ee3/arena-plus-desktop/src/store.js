'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * ذخیره‌سازی ساده مبتنی بر JSON.
 *
 * چرا SQLite نه؟ better-sqlite3 یک ماژول نیتیو است و برای هر پلتفرم و هر
 * نسخه‌ی Electron باید جداگانه کامپایل شود — که build چندسکویی را شکننده
 * می‌کند. حجم داده‌ی این اپ (چند هزار مکالمه) با JSON کاملاً قابل مدیریت
 * است و هیچ وابستگی نیتیوی لازم ندارد.
 */
class Store {

  constructor(userDataDir) {
    this.dir = userDataDir;
    if (!fs.existsSync(this.dir)) fs.mkdirSync(this.dir, { recursive: true });
    this.file = path.join(this.dir, 'arena-plus-data.json');
    this.data = this._load();
  }

  _load() {
    const fallback = {
      profiles: [
        { id: 'acct_1', label: 'اکانت اول', color: 0 },
        { id: 'acct_2', label: 'اکانت دوم', color: 1 }
      ],
      activeProfile: 'acct_1',
      settings: {
        rtlFix: true, persianFont: true, fontScale: 100, compact: false
      },
      conversations: [],
      prompts: [],
      usage: [],
      downloads: [],
      windowBounds: { width: 1280, height: 860, x: undefined, y: undefined },
      githubToken: ''
    };
    try {
      if (!fs.existsSync(this.file)) return fallback;
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      return { ...fallback, ...parsed,
        settings: { ...fallback.settings, ...(parsed.settings || {}) } };
    } catch {
      return fallback;
    }
  }

  _save() {
    try {
      fs.writeFileSync(this.file, JSON.stringify(this.data), 'utf8');
    } catch (e) {
      console.error('ذخیره‌سازی ناموفق:', e.message);
    }
  }

  // ── پنجره ──
  getWindowBounds() { return this.data.windowBounds; }
  setWindowBounds(b) { this.data.windowBounds = b; this._save(); }

  // ── GitHub ──
  getGithubToken() { return this.data.githubToken || ''; }
  setGithubToken(t) { this.data.githubToken = t || ''; this._save(); }

  // ── پروفایل ──
  getProfiles() { return this.data.profiles; }
  getActiveProfile() {
    const ok = this.data.profiles.some(p => p.id === this.data.activeProfile);
    return ok ? this.data.activeProfile : this.data.profiles[0].id;
  }
  setActiveProfile(id) { this.data.activeProfile = id; this._save(); }

  addProfile(label) {
    const p = {
      id: `acct_${Date.now()}`,
      label: (label || '').trim() || `اکانت ${this.data.profiles.length + 1}`,
      color: this.data.profiles.length % 8
    };
    this.data.profiles.push(p);
    this.data.activeProfile = p.id;
    this._save();
    return p;
  }

  renameProfile(id, label) {
    const p = this.data.profiles.find(x => x.id === id);
    if (p && label.trim()) { p.label = label.trim(); this._save(); }
  }

  deleteProfile(id) {
    if (this.data.profiles.length <= 1) return false;
    this.data.profiles = this.data.profiles.filter(p => p.id !== id);
    this.data.conversations = this.data.conversations.filter(c => c.profileId !== id);
    if (this.data.activeProfile === id) {
      this.data.activeProfile = this.data.profiles[0].id;
    }
    this._save();
    return true;
  }

  // ── تنظیمات ──
  getSettings() { return this.data.settings; }
  setSettings(patch) {
    this.data.settings = { ...this.data.settings, ...patch };
    this._save();
    return this.data.settings;
  }

  // ── آرشیو ──
  saveConversation({ title, bodyText, url, profileId }) {
    if (!bodyText || bodyText.length < 60) return;
    const id = crypto.createHash('sha1')
      .update(`${url}|${title}`).digest('hex');
    const existing = this.data.conversations.find(c => c.id === id);
    if (existing) {
      existing.bodyText = bodyText;
      existing.savedAt = Date.now();
    } else {
      this.data.conversations.unshift({
        id, title: title || 'بدون عنوان', bodyText, url,
        profileId, savedAt: Date.now(), starred: false
      });
      // سقف منطقی تا فایل بی‌نهایت بزرگ نشود
      if (this.data.conversations.length > 3000) {
        this.data.conversations = this.data.conversations
          .filter(c => c.starred)
          .concat(this.data.conversations.filter(c => !c.starred).slice(0, 2500));
      }
    }
    this._save();
  }

  listConversations(q) {
    const { query = '', starredOnly = false } = q || {};
    let list = this.data.conversations;
    if (starredOnly) list = list.filter(c => c.starred);
    if (query && query.trim()) {
      const needle = query.trim().toLowerCase();
      list = list.filter(c =>
        (c.title || '').toLowerCase().includes(needle) ||
        (c.bodyText || '').toLowerCase().includes(needle)
      );
    }
    return list.slice(0, 300).map(c => ({
      id: c.id, title: c.title, savedAt: c.savedAt, starred: c.starred,
      snippet: (c.bodyText || '').slice(0, 160).replace(/\s+/g, ' ')
    }));
  }

  getConversation(id) {
    return this.data.conversations.find(c => c.id === id) || null;
  }

  starConversation(id, value) {
    const c = this.data.conversations.find(x => x.id === id);
    if (c) { c.starred = !!value; this._save(); }
  }

  deleteConversations(ids) {
    const set = new Set(ids);
    this.data.conversations = this.data.conversations.filter(c => !set.has(c.id));
    this._save();
  }

  // ── پرامپت ──
  listPrompts() {
    if (this.data.prompts.length === 0) this._seedPrompts();
    return this.data.prompts;
  }

  _seedPrompts() {
    this.data.prompts = [
      { id: 1, title: 'خلاصه‌ی فارسی', category: 'نویسندگی', uses: 0,
        body: 'متن زیر را به فارسی روان و دقیق خلاصه کن. نکات کلیدی را بولت کن:\n\n' },
      { id: 2, title: 'بازبینی کد', category: 'کدنویسی', uses: 0,
        body: 'این کد را بررسی کن. باگ‌ها، مشکلات امنیتی و نکات کارایی را با اولویت‌بندی بگو:\n\n```\n\n```' },
      { id: 3, title: 'توضیح ساده', category: 'آموزش', uses: 0,
        body: 'مفهوم {موضوع} را طوری توضیح بده که یک {مخاطب} بفهمد. از مثال روزمره استفاده کن.' },
      { id: 4, title: 'ترجمه‌ی طبیعی', category: 'نویسندگی', uses: 0,
        body: 'متن زیر را به {زبان} ترجمه کن. ترجمه باید طبیعی و روان باشد، نه تحت‌اللفظی:\n\n' },
      { id: 5, title: 'مقایسه‌ی فنی', category: 'تحقیق', uses: 0,
        body: '{گزینه اول} را با {گزینه دوم} مقایسه کن. جدول مزایا و معایب بده و بگو برای {کاربرد} کدام بهتر است.' }
    ];
    this._save();
  }

  savePrompt(p) {
    if (p.id) {
      const i = this.data.prompts.findIndex(x => x.id === p.id);
      if (i >= 0) this.data.prompts[i] = { ...this.data.prompts[i], ...p };
    } else {
      const maxId = this.data.prompts.reduce((m, x) => Math.max(m, x.id || 0), 0);
      this.data.prompts.push({ ...p, id: maxId + 1, uses: 0 });
    }
    this._save();
  }

  deletePrompt(id) {
    this.data.prompts = this.data.prompts.filter(p => p.id !== id);
    this._save();
  }

  // ── مصرف ──
  recordUsage(profileId) {
    const day = new Date().toISOString().slice(0, 10);
    this.data.usage.push({ profileId, day, ts: Date.now() });
    if (this.data.usage.length > 20000) {
      this.data.usage = this.data.usage.slice(-15000);
    }
    this._save();
  }

  usageStats() {
    const today = new Date().toISOString().slice(0, 10);
    const week = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      week.push({ day: d, count: this.data.usage.filter(u => u.day === d).length });
    }
    const perProfile = {};
    this.data.usage.forEach(u => {
      perProfile[u.profileId] = (perProfile[u.profileId] || 0) + 1;
    });
    return {
      today: this.data.usage.filter(u => u.day === today).length,
      week: week.reduce((s, d) => s + d.count, 0),
      chart: week,
      perProfile,
      profiles: this.data.profiles,
      archived: this.data.conversations.length
    };
  }

  // ── دانلود ──
  addDownload(d) {
    this.data.downloads.unshift({ ...d, id: Date.now() + Math.random(), createdAt: Date.now() });
    if (this.data.downloads.length > 500) this.data.downloads.length = 500;
    this._save();
  }
  listDownloads() { return this.data.downloads; }
  removeDownload(id) {
    this.data.downloads = this.data.downloads.filter(d => d.id !== id);
    this._save();
  }
  clearDownloads() { this.data.downloads = []; this._save(); }

  // ── مدیریت حافظه ──
  storageStats() {
    const chars = this.data.conversations
      .reduce((s, c) => s + (c.bodyText || '').length, 0);
    return {
      conversations: this.data.conversations.length,
      starred: this.data.conversations.filter(c => c.starred).length,
      prompts: this.data.prompts.length,
      usage: this.data.usage.length,
      downloads: this.data.downloads.length,
      bytes: chars * 2
    };
  }

  clearData(what) {
    const now = Date.now();
    switch (what) {
      case 'old30':
        this.data.conversations = this.data.conversations.filter(
          c => c.starred || c.savedAt > now - 30 * 86400000);
        break;
      case 'old7':
        this.data.conversations = this.data.conversations.filter(
          c => c.starred || c.savedAt > now - 7 * 86400000);
        break;
      case 'unstarred':
        this.data.conversations = this.data.conversations.filter(c => c.starred);
        break;
      case 'usage': this.data.usage = []; break;
      case 'prompts': this.data.prompts = []; break;
      case 'downloads': this.data.downloads = []; break;
      case 'all':
        this.data.conversations = [];
        this.data.usage = [];
        this.data.prompts = [];
        this.data.downloads = [];
        break;
    }
    this._save();
    return this.storageStats();
  }
}

module.exports = Store;
