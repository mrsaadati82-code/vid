'use strict';

const {
  app, BrowserWindow, BrowserView, session, ipcMain,
  dialog, shell, Menu, nativeTheme
} = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

const Store = require('./store');
const { attachContextMenu } = require('./context-menu');
const Notes = require('./notes');
const GitHub = require('./github');
const { zipToMarkdown, folderToMarkdown } = require('./zip-to-md');
const { PERSIAN_CSS, PERSIAN_JS } = require('./persian');
const { resolveFileName, humanSize } = require('./download-utils');

// ── بهینه‌سازی برای اپل سیلیکون ──
// شتاب‌دهی سخت‌افزاری Metal و رمزگشایی ویدیو روی GPU
app.commandLine.appendSwitch('enable-features',
  'Metal,CanvasOopRasterization,AcceleratedVideoDecodeLinuxGL');
// صرفه‌جویی حافظه: تب‌های پس‌زمینه منابع کمتری بگیرند
app.commandLine.appendSwitch('enable-features', 'CalculateNativeWinOcclusion');
// جلوگیری از throttle شدن تب پس‌زمینه (تب‌های ما زنده می‌مانند)
app.commandLine.appendSwitch('disable-renderer-backgrounding');

const ARENA_HOME = 'https://arena.ai/';

/** اگر reCAPTCHA اصلی مسدود باشد، به آینه‌ی رسمی هدایت می‌شود. */
let RECAPTCHA_FALLBACK = true;
const CHROME_UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

/** ارتفاع نوار بالای اپ (نوار پروفایل + تب) */
const CHROME_HEIGHT = 96;

let win = null;
let store = null;
let notes = null;
let gh = null;

/** همه‌ی تب‌ها: { id, profileId, title, url, view } */
const tabs = new Map();
/** وقتی پنل باز است، BrowserView از پنجره جدا می‌شود تا پنل دیده شود. */
let panelOpen = false;
let nextTabId = 1;
let activeTabId = null;

// ─────────────────────────────────────────────────────────────
//  پوشه‌ی دانلود اختصاصی
// ─────────────────────────────────────────────────────────────

function downloadDir() {
  const base = app.getPath('downloads');
  const dir = path.join(base, 'Arena Plus');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function uniquePath(dir, name) {
  let p = path.join(dir, name);
  if (!fs.existsSync(p)) return p;
  const ext = path.extname(name);
  const base = path.basename(name, ext);
  let i = 1;
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`);
  return p;
}

// ─────────────────────────────────────────────────────────────
//  session هر پروفایل — کوکی‌ها کاملاً مستقل
// ─────────────────────────────────────────────────────────────

const preparedSessions = new Set();

function sessionFor(profileId) {
  // persist: یعنی روی دیسک ذخیره شود؛ هر نام = یک کوکی‌جار جدا
  const ses = session.fromPartition(`persist:profile_${profileId}`);
  if (preparedSessions.has(profileId)) return ses;
  preparedSessions.add(profileId);

  // UA مرورگر واقعی — گوگل «disallowed_useragent» نمی‌دهد
  ses.setUserAgent(CHROME_UA);

  /**
   * 🔴 رفع مسدودی reCAPTCHA — با اصلاح CORS
   *
   * Arena برای لاگین از reCAPTCHA استفاده می‌کند. اگر gstatic.com
   * مسدود باشد، دکمه‌ی لاگین هیچ کاری نمی‌کند.
   *
   * تلاش اول (redirect ساده) شکست خورد: وقتی درخواست به دامنه‌ی
   * دیگری redirect می‌شود، مرورگر آن را cross-origin می‌بیند و هدر
   * Access-Control-Allow-Origin می‌خواهد — که recaptcha.net نمی‌دهد.
   *     "blocked by CORS policy: No 'Access-Control-Allow-Origin'"
   *
   * حالا علاوه بر redirect، هدرهای CORS را هم خودمان اضافه می‌کنیم.
   */
  ses.webRequest.onBeforeRequest(
    { urls: ['https://www.google.com/recaptcha/*',
             'https://www.gstatic.com/recaptcha/*'] },
    (details, cb) => {
      if (!RECAPTCHA_FALLBACK) return cb({});
      const redirectURL = details.url
        .replace('https://www.google.com/recaptcha/',
                 'https://www.recaptcha.net/recaptcha/')
        .replace('https://www.gstatic.com/recaptcha/',
                 'https://www.recaptcha.net/recaptcha/');
      cb({ redirectURL });
    }
  );

  /**
   * دستکاری هدرهای پاسخ:
   *  • حذف CSP سایت Arena (تا اتصال به recaptcha.net بلاک نشود)
   *  • افزودن CORS به پاسخ recaptcha.net (چون redirect کرده‌ایم)
   */
  ses.webRequest.onHeadersReceived({ urls: ['<all_urls>'] }, (details, cb) => {
    const h = { ...details.responseHeaders };
    let host = '';
    try { host = new URL(details.url).hostname; } catch { /* ignore */ }

    // CSP فقط روی دامنه‌های Arena حذف می‌شود
    if (host.endsWith('arena.ai')) {
      for (const k of Object.keys(h)) {
        const lk = k.toLowerCase();
        if (lk === 'content-security-policy' ||
            lk === 'content-security-policy-report-only') delete h[k];
      }
    }

    // CORS برای منابعی که خودمان redirect کرده‌ایم
    if (host === 'www.recaptcha.net' || host === 'recaptcha.net') {
      for (const k of Object.keys(h)) {
        if (k.toLowerCase().startsWith('access-control-')) delete h[k];
      }
      h['Access-Control-Allow-Origin'] = ['*'];
      h['Access-Control-Allow-Credentials'] = ['true'];
      h['Access-Control-Allow-Headers'] = ['*'];
      h['Access-Control-Allow-Methods'] = ['GET, POST, OPTIONS'];
      // Timing-Allow-Origin هم لازم است وگرنه هشدار می‌دهد
      h['Timing-Allow-Origin'] = ['*'];
    }

    cb({ responseHeaders: h });
  });

  // دانلود → پوشه‌ی اختصاصی، بدون دیالوگ
  ses.on('will-download', (event, item) => {
    const name = resolveFileName(
      item.getFilename(), item.getMimeType(), item.getURL()
    );
    const target = uniquePath(downloadDir(), name);
    item.setSavePath(target);

    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    send('download-started', {
      id, fileName: path.basename(target), total: item.getTotalBytes()
    });

    item.on('updated', (_e, state) => {
      if (state === 'progressing' && !item.isPaused()) {
        send('download-progress', {
          id, received: item.getReceivedBytes(), total: item.getTotalBytes()
        });
      }
    });

    item.once('done', (_e, state) => {
      if (state === 'completed') {
        store.addDownload({
          fileName: path.basename(target),
          mimeType: item.getMimeType() || '',
          sourceUrl: item.getURL(),
          localPath: target,
          sizeBytes: item.getTotalBytes(),
          profileId
        });
        send('download-done', { id, fileName: path.basename(target), path: target });
      } else {
        send('download-failed', { id, reason: state });
      }
    });
  });

  return ses;
}

// ─────────────────────────────────────────────────────────────
//  تب‌ها
// ─────────────────────────────────────────────────────────────

function createTab(profileId, url = ARENA_HOME, title = '') {
  const id = nextTabId++;
  const ses = sessionFor(profileId);

  const view = new BrowserView({
    webPreferences: {
      session: ses,
      preload: path.join(__dirname, 'preload-web.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: true
    }
  });

  const wc = view.webContents;

  wc.on('page-title-updated', (_e, t) => {
    const tab = tabs.get(id);
    if (tab) { tab.title = (t || '').slice(0, 40); pushTabs(); }
  });

  wc.on('did-navigate', (_e, u) => {
    const tab = tabs.get(id);
    if (tab) tab.url = u;
  });

  // منوی راست‌کلیک وابسته به زمینه
  attachContextMenu(wc, {
    getWindow: () => win,
    openInNewTab: (u) => { const t = createTab(profileId, u); showTab(t.id); },
    saveImage: (u) => wc.downloadURL(u),
    insertToChat: (text) => {
      const esc = JSON.stringify(text);
      wc.executeJavaScript(`
        (function(){
          var el = document.querySelector('textarea') ||
                   document.querySelector('[contenteditable="true"]');
          if (!el) return;
          if (el.tagName === 'TEXTAREA') {
            var st = Object.getOwnPropertyDescriptor(
              window.HTMLTextAreaElement.prototype, 'value').set;
            st.call(el, (el.value || '') + ${esc});
            el.dispatchEvent(new Event('input', { bubbles: true }));
          } else {
            el.textContent = (el.textContent || '') + ${esc};
            el.dispatchEvent(new Event('input', { bubbles: true }));
          }
          el.focus();
        })();`, true).catch(() => {});
    }
  });

  wc.on('did-finish-load', () => applyPersian(wc));
  wc.on('dom-ready', () => applyPersian(wc));

  wc.on('did-fail-load', (_e, code, desc, u, isMain) => {
    if (isMain && code !== -3) send('load-error', { code, desc, url: u });
  });

  // 🔴 رفع باگ لاگین گوگل:
  // { action: 'allow' } یک BrowserWindow با session *پیش‌فرض* می‌سازد،
  // نه session پروفایل فعال. پس کوکی‌ها مشترک نیستند و چرخه‌ی OAuth
  // بسته نمی‌شود. حالا پنجره را خودمان با همان session می‌سازیم.
  wc.setWindowOpenHandler(({ url: target, disposition }) => {
    // «باز کردن در تب جدید» → واقعاً یک تب جدید بساز
    if (disposition === 'background-tab' || disposition === 'foreground-tab') {
      const t = createTab(profileId, target);
      if (disposition === 'foreground-tab') showTab(t.id);
      pushTabs();
      return { action: 'deny' };
    }
    // پنجره‌ی پاپ‌آپ (شامل کل جریان OAuth) داخل اپ با همان session
    if (isInternal(target)) {
      openAuthPopup(target, ses, profileId);
      return { action: 'deny' };
    }
    shell.openExternal(target);
    return { action: 'deny' };
  });

  // فقط لینک‌های آشکارا بیرونی به مرورگر می‌روند.
  // ناوبری‌های داخلی (از جمله کل جریان OAuth) دست‌نخورده می‌مانند.
  wc.on('will-navigate', (e, target) => {
    if (!isInternal(target)) {
      e.preventDefault();
      shell.openExternal(target);
    }
  });

  const tab = { id, profileId, title: title || 'تب جدید', url, view };
  tabs.set(id, tab);
  wc.loadURL(url);
  return tab;
}

/**
 * پنجره‌ی پاپ‌آپ برای جریان OAuth.
 *
 * نکته‌ی حیاتی: همان `session` والد پاس داده می‌شود. بدون این، کوکی‌های
 * ساخته‌شده در پاپ‌آپ به تب اصلی منتقل نمی‌شوند و لاگین کامل نمی‌شود.
 */
function openAuthPopup(url, ses, profileId) {
  const popup = new BrowserWindow({
    width: 520,
    height: 680,
    parent: win,
    modal: false,
    show: false,
    autoHideMenuBar: true,
    title: 'ورود',
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#141218' : '#FFFFFF',
    webPreferences: {
      session: ses,          // ← همان کوکی‌جار پروفایل
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  attachContextMenu(popup.webContents, { getWindow: () => popup });
  popup.once('ready-to-show', () => popup.show());
  popup.loadURL(url);

  // پاپ‌آپ تودرتو (گوگل گاهی می‌سازد)
  popup.webContents.setWindowOpenHandler(({ url: nested }) => {
    if (isInternal(nested)) { openAuthPopup(nested, ses, profileId); }
    else shell.openExternal(nested);
    return { action: 'deny' };
  });

  // وقتی به arena.ai برگشتیم یعنی لاگین تمام شده
  popup.webContents.on('did-navigate', (_e, u) => {
    try {
      const h = new URL(u).hostname;
      if (h.endsWith('arena.ai')) {
        setTimeout(() => {
          if (!popup.isDestroyed()) popup.close();
        }, 700);
      }
    } catch { /* ignore */ }
  });

  popup.on('closed', () => {
    // تب فعال را تازه کن تا وضعیت لاگین اعمال شود
    const t = activeTabId && tabs.get(activeTabId);
    if (t && !t.view.webContents.isDestroyed()) t.view.webContents.reload();
  });

  return popup;
}

/**
 * آیا این آدرس باید داخل اپ بماند؟
 *
 * 🔴 درس گرفته‌شده: فهرست سخت‌گیرانه باعث شد لاگین گوگل کار نکند.
 * Arena از Clerk برای احراز هویت استفاده می‌کند و جریان OAuth از چند
 * دامنه عبور می‌کند (accounts.google.com، clerk.arena.ai،
 * *.clerk.accounts.dev و…). هر کدام که در فهرست نباشد، به مرورگر
 * بیرونی می‌رود و کاربر «هیچ اتفاقی نمی‌افتد» می‌بیند.
 *
 * حالا سیاست برعکس است: همه‌چیز داخل می‌ماند مگر اینکه آشکارا یک
 * لینک بیرونی باشد که کاربر عمداً کلیک کرده.
 */
const INTERNAL_HOSTS = [
  'arena.ai', 'lmarena.ai',
  'google.com', 'googleapis.com', 'gstatic.com', 'googleusercontent.com',
  'youtube.com', 'ggpht.com', 'googlesyndication.com',
  'clerk.com', 'clerk.dev', 'clerk.accounts.dev', 'clerk.services',
  'cloudflare.com', 'cloudflareinsights.com',
  'hcaptcha.com', 'recaptcha.net',
  'vercel.live', 'vercel.com',
  'huggingface.co', 'hf.space',
  'posthog.com', 'datadoghq.com', 'pusher.com',
  'r2.cloudflarestorage.com', 'jsdelivr.net'
];

function isInternal(u) {
  try {
    const url = new URL(u);
    if (url.protocol === 'about:' || url.protocol === 'data:' ||
        url.protocol === 'blob:') return true;
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return true;
    const h = url.hostname.toLowerCase();
    // زیردامنه هم پذیرفته می‌شود: accounts.google.com ⊂ google.com
    return INTERNAL_HOSTS.some(d => h === d || h.endsWith('.' + d));
  } catch { return false; }
}

function applyPersian(wc) {
  const s = store.getSettings();
  wc.insertCSS(PERSIAN_CSS(s)).catch(() => {});
  wc.executeJavaScript(PERSIAN_JS(s), true).catch(() => {});
}

function showTab(id) {
  const tab = tabs.get(id);
  if (!tab || !win) return;
  if (activeTabId && tabs.has(activeTabId)) {
    win.removeBrowserView(tabs.get(activeTabId).view);
  }
  if (!panelOpen) win.addBrowserView(tab.view);
  activeTabId = id;
  store.setActiveProfile(tab.profileId);
  layoutActiveView();
  pushTabs();
}

function closeTab(id) {
  const tab = tabs.get(id);
  if (!tab) return;
  const sameProfile = [...tabs.values()].filter(t => t.profileId === tab.profileId);
  if (sameProfile.length <= 1) return;   // آخرین تب پروفایل بسته نشود

  if (activeTabId === id) win.removeBrowserView(tab.view);
  tab.view.webContents.destroy();
  tabs.delete(id);

  if (activeTabId === id) {
    const next = [...tabs.values()].find(t => t.profileId === tab.profileId);
    if (next) showTab(next.id);
  }
  pushTabs();
}

function layoutActiveView() {
  if (!win || !activeTabId || panelOpen) return;
  const tab = tabs.get(activeTabId);
  if (!tab) return;
  const [w, h] = win.getContentSize();
  tab.view.setBounds({
    x: 0, y: CHROME_HEIGHT, width: w, height: Math.max(0, h - CHROME_HEIGHT)
  });
  tab.view.setAutoResize({ width: true, height: true });
}

function pushTabs() {
  const activeProfile = store.getActiveProfile();
  send('tabs-changed', {
    tabs: [...tabs.values()]
      .filter(t => t.profileId === activeProfile)
      .map(t => ({ id: t.id, title: t.title, url: t.url })),
    activeTabId
  });
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function activeWc() {
  const t = activeTabId && tabs.get(activeTabId);
  return t ? t.view.webContents : null;
}

// ─────────────────────────────────────────────────────────────
//  پنجره‌ی اصلی
// ─────────────────────────────────────────────────────────────

function createWindow() {
  const bounds = store.getWindowBounds();

  win = new BrowserWindow({
    width: bounds.width, height: bounds.height,
    x: bounds.x, y: bounds.y,
    minWidth: 900, minHeight: 600,
    title: 'Arena Plus',
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#141218' : '#FAFAFC',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    trafficLightPosition: { x: 14, y: 18 },
    webPreferences: {
      preload: path.join(__dirname, 'preload-ui.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  attachContextMenu(win.webContents, { getWindow: () => win });

  win.on('resize', layoutActiveView);
  win.on('enter-full-screen', layoutActiveView);
  win.on('leave-full-screen', layoutActiveView);

  win.on('close', () => {
    const b = win.getBounds();
    store.setWindowBounds(b);
  });

  win.on('closed', () => {
    tabs.forEach(t => { try { t.view.webContents.destroy(); } catch {} });
    tabs.clear();
    win = null;
  });

  win.webContents.once('did-finish-load', () => {
    const profiles = store.getProfiles();
    const active = store.getActiveProfile() || profiles[0].id;
    const tab = createTab(active);
    showTab(tab.id);
    send('profiles-changed', {
      profiles, activeProfileId: active
    });
  });
}

// ─────────────────────────────────────────────────────────────
//  IPC
// ─────────────────────────────────────────────────────────────

function registerIpc() {
  // ── پروفایل ──
  ipcMain.handle('profiles:list', () => ({
    profiles: store.getProfiles(),
    activeProfileId: store.getActiveProfile()
  }));

  ipcMain.handle('profiles:switch', (_e, profileId) => {
    const existing = [...tabs.values()].find(t => t.profileId === profileId);
    if (existing) showTab(existing.id);
    else showTab(createTab(profileId).id);
    return true;
  });

  ipcMain.handle('profiles:add', (_e, label) => {
    const p = store.addProfile(label);
    showTab(createTab(p.id).id);
    return store.getProfiles();
  });

  ipcMain.handle('profiles:rename', (_e, { id, label }) => {
    store.renameProfile(id, label); return store.getProfiles();
  });

  ipcMain.handle('profiles:delete', async (_e, id) => {
    if (store.getProfiles().length <= 1) return { ok: false, reason: 'last' };
    [...tabs.values()].filter(t => t.profileId === id).forEach(t => {
      if (activeTabId === t.id) win.removeBrowserView(t.view);
      try { t.view.webContents.destroy(); } catch {}
      tabs.delete(t.id);
    });
    store.deleteProfile(id);
    const next = store.getProfiles()[0];
    const nt = [...tabs.values()].find(t => t.profileId === next.id)
      || createTab(next.id);
    showTab(nt.id);
    return { ok: true, profiles: store.getProfiles() };
  });

  ipcMain.handle('profiles:signout', async (_e, id) => {
    const ses = sessionFor(id);
    await ses.clearStorageData({
      storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage']
    });
    [...tabs.values()].filter(t => t.profileId === id)
      .forEach(t => t.view.webContents.loadURL(ARENA_HOME));
    return true;
  });

  // ── تب ──
  ipcMain.handle('tabs:list', () => {
    const ap = store.getActiveProfile();
    return {
      tabs: [...tabs.values()].filter(t => t.profileId === ap)
        .map(t => ({ id: t.id, title: t.title, url: t.url })),
      activeTabId
    };
  });
  ipcMain.handle('tabs:new', () => {
    const t = createTab(store.getActiveProfile()); showTab(t.id); return t.id;
  });
  ipcMain.handle('tabs:show', (_e, id) => { showTab(id); return true; });
  ipcMain.handle('tabs:close', (_e, id) => { closeTab(id); return true; });

  // ── پنل: BrowserView را کنار بزن تا رابط کاربری دیده شود ──
  ipcMain.handle('panel:open', () => {
    if (panelOpen) return true;
    panelOpen = true;
    const t = activeTabId && tabs.get(activeTabId);
    if (t && win) win.removeBrowserView(t.view);
    return true;
  });

  ipcMain.handle('panel:close', () => {
    if (!panelOpen) return true;
    panelOpen = false;
    const t = activeTabId && tabs.get(activeTabId);
    if (t && win) { win.addBrowserView(t.view); layoutActiveView(); }
    return true;
  });

  // ── ناوبری ──
  ipcMain.handle('nav:home', () => { activeWc()?.loadURL(ARENA_HOME); });
  ipcMain.handle('nav:reload', () => { activeWc()?.reload(); });
  ipcMain.handle('nav:back', () => {
    const wc = activeWc(); if (wc?.canGoBack()) wc.goBack();
  });
  ipcMain.handle('nav:forward', () => {
    const wc = activeWc(); if (wc?.canGoForward()) wc.goForward();
  });
  ipcMain.handle('nav:url', () => activeWc()?.getURL() || '');
  ipcMain.handle('nav:open-external', (_e, u) => shell.openExternal(u));

  // ── تنظیمات ظاهر ──
  ipcMain.handle('settings:get', () => store.getSettings());
  ipcMain.handle('settings:set', (_e, patch) => {
    const s = store.setSettings(patch);
    tabs.forEach(t => applyPersian(t.view.webContents));
    return s;
  });

  // ── دانلود ──
  ipcMain.handle('downloads:list', () => store.listDownloads());
  ipcMain.handle('downloads:open', (_e, p) => shell.openPath(p));
  ipcMain.handle('downloads:reveal', (_e, p) => shell.showItemInFolder(p));
  ipcMain.handle('downloads:folder', () => shell.openPath(downloadDir()));
  ipcMain.handle('downloads:remove', (_e, id) => {
    store.removeDownload(id); return store.listDownloads();
  });
  ipcMain.handle('downloads:clear', () => {
    store.clearDownloads(); return [];
  });

  // ── آرشیو ──
  ipcMain.handle('archive:list', (_e, q) => store.listConversations(q));
  ipcMain.handle('archive:star', (_e, { id, value }) => {
    store.starConversation(id, value); return true;
  });
  ipcMain.handle('archive:delete', (_e, ids) => {
    store.deleteConversations(ids); return true;
  });
  ipcMain.handle('archive:get', (_e, id) => store.getConversation(id));
  ipcMain.handle('archive:save', (_e, c) => {
    store.saveConversation(c); return true;
  });

  // ── پرامپت ──
  ipcMain.handle('prompts:list', () => store.listPrompts());
  ipcMain.handle('prompts:save', (_e, p) => { store.savePrompt(p); return store.listPrompts(); });
  ipcMain.handle('prompts:delete', (_e, id) => { store.deletePrompt(id); return store.listPrompts(); });
  ipcMain.handle('prompts:inject', (_e, text) => {
    const wc = activeWc();
    if (!wc) return false;
    const esc = JSON.stringify(text);
    return wc.executeJavaScript(`
      (function(){
        var el = document.querySelector('textarea') ||
                 document.querySelector('[contenteditable="true"]');
        if (!el) return false;
        if (el.tagName === 'TEXTAREA') {
          var setter = Object.getOwnPropertyDescriptor(
            window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(el, ${esc});
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          el.textContent = ${esc};
          el.dispatchEvent(new Event('input', { bubbles: true }));
        }
        el.focus();
        return true;
      })();
    `, true);
  });

  // ── مصرف ──
  ipcMain.handle('usage:stats', () => store.usageStats());
  ipcMain.handle('usage:record', (_e, profileId) => {
    store.recordUsage(profileId); return true;
  });

  // ── لیدربورد ──
  ipcMain.handle('leaderboard:fetch', async (_e, { config, category }) => {
    const where = encodeURIComponent(`"category"='${category}'`);
    const url = 'https://datasets-server.huggingface.co/filter' +
      '?dataset=lmarena-ai%2Fleaderboard-dataset' +
      `&config=${config}&split=latest&where=${where}&limit=150`;
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    return (j.rows || []).map(r => r.row).sort(
      (a, b) => (a.rank || 1e9) - (b.rank || 1e9)
    );
  });

  // ── تشخیص شبکه ──
  ipcMain.handle('diag:network', async () => {
    const targets = [
      ['arena.ai',        'https://arena.ai/'],
      ['clerk (لاگین)',   'https://clerk.arena.ai/v1/environment'],
      ['گوگل',            'https://accounts.google.com/'],
      ['reCAPTCHA اصلی',  'https://www.gstatic.com/recaptcha/api.js'],
      ['reCAPTCHA جایگزین','https://www.recaptcha.net/recaptcha/api.js'],
      ['Hugging Face',    'https://datasets-server.huggingface.co/valid'],
      ['GitHub API',      'https://api.github.com/']
    ];
    const out = [];
    await Promise.all(targets.map(async ([name, url]) => {
      const t0 = Date.now();
      try {
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), 8000);
        const r = await fetch(url, { method: 'GET', signal: ctl.signal });
        clearTimeout(timer);
        out.push({ name, ok: r.status < 500, status: r.status,
                   ms: Date.now() - t0 });
      } catch (e) {
        out.push({ name, ok: false, status: 0,
                   ms: Date.now() - t0,
                   error: (e.message || '').slice(0, 60) });
      }
    }));
    return targets.map(([n]) => out.find(o => o.name === n));
  });

  // ── مدیریت حافظه ──
  ipcMain.handle('storage:stats', () => store.storageStats());
  ipcMain.handle('storage:clear', (_e, what) => store.clearData(what));

  // ── تبدیل پروژه به Markdown (چون Arena زیپ نمی‌پذیرد) ──
  ipcMain.handle('export:pick-zip', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب فایل ZIP',
      filters: [{ name: 'ZIP', extensions: ['zip'] }],
      properties: ['openFile']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    return convertAndSave(() => zipToMarkdown(r.filePaths[0]),
                          path.basename(r.filePaths[0], '.zip'));
  });

  ipcMain.handle('export:pick-folder', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب پوشه‌ی پروژه',
      properties: ['openDirectory']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    return convertAndSave(() => folderToMarkdown(r.filePaths[0]),
                          path.basename(r.filePaths[0]));
  });

  // ── GitHub ──
  ipcMain.handle('gh:status', async () => {
    if (!gh.connected) return { connected: false };
    try {
      const u = await gh.me();
      return { connected: true, login: u.login, name: u.name, avatar: u.avatar_url };
    } catch (e) { return { connected: false, error: e.message }; }
  });

  ipcMain.handle('gh:connect', async (_e, token) => {
    gh.setToken(token);
    try {
      const u = await gh.me();
      store.setGithubToken(token);
      return { ok: true, login: u.login, name: u.name };
    } catch (e) {
      gh.setToken(store.getGithubToken());
      return { ok: false, error: e.message };
    }
  });

  ipcMain.handle('gh:disconnect', () => {
    gh.setToken(''); store.setGithubToken(''); return true;
  });

  ipcMain.handle('gh:repos', () => gh.repos());
  ipcMain.handle('gh:repo', (_e, { owner, repo }) => gh.repo(owner, repo));
  ipcMain.handle('gh:branches', (_e, { owner, repo }) => gh.branches(owner, repo));
  ipcMain.handle('gh:commits', (_e, { owner, repo, branch }) =>
    gh.commits(owner, repo, branch));

  ipcMain.handle('gh:tree', (_e, { owner, repo, branch }) =>
    gh.tree(owner, repo, branch));

  ipcMain.handle('gh:file', (_e, { owner, repo, path: p, ref }) =>
    gh.fileText(owner, repo, p, ref));

  ipcMain.handle('gh:create-repo', (_e, opts) => gh.createRepo(opts));

  ipcMain.handle('gh:delete-repo', (_e, { owner, repo }) =>
    gh.deleteRepo(owner, repo));

  ipcMain.handle('gh:put-file', (_e, { owner, repo, path: p, content, message, branch }) =>
    gh.putFile(owner, repo, p, content, message, branch));

  ipcMain.handle('gh:delete-file', (_e, { owner, repo, path: p, message, branch }) =>
    gh.deleteFile(owner, repo, p, message, branch));

  /** حذف/آپلود دسته‌جمعی — یک commit برای همه. */
  ipcMain.handle('gh:batch', (_e, { owner, repo, changes, message, branch }) =>
    gh.batchCommit(owner, repo, changes, message, branch));

  /** آپلود فایل‌های محلی به مخزن. */
  ipcMain.handle('gh:upload-files', async (_e, { owner, repo, branch, destDir }) => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب فایل برای آپلود',
      properties: ['openFile', 'multiSelections']
    });
    if (r.canceled || !r.filePaths.length) return null;

    const changes = r.filePaths.map(fp => ({
      path: (destDir ? destDir.replace(/\/+$/, '') + '/' : '') + path.basename(fp),
      content: fs.readFileSync(fp, 'utf8')
    }));
    return gh.batchCommit(owner, repo, changes,
      `آپلود ${changes.length} فایل از Arena Plus`, branch);
  });

  /** آپلود کل یک پوشه. */
  ipcMain.handle('gh:upload-folder', async (_e, { owner, repo, branch }) => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب پوشه', properties: ['openDirectory']
    });
    if (r.canceled || !r.filePaths[0]) return null;

    const base = r.filePaths[0];
    const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'out',
                          '.gradle', '.idea', '__pycache__', '.next']);
    const changes = [];
    (function walk(d) {
      for (const it of fs.readdirSync(d, { withFileTypes: true })) {
        if (SKIP.has(it.name) || it.name.startsWith('.DS')) continue;
        const full = path.join(d, it.name);
        if (it.isDirectory()) { walk(full); continue; }
        if (!it.isFile()) continue;
        const st = fs.statSync(full);
        if (st.size > 900 * 1024) continue;         // فایل‌های بزرگ رد شوند
        let txt;
        try { txt = fs.readFileSync(full, 'utf8'); } catch { return; }
        if (txt.includes('\u0000')) continue;      // باینری
        changes.push({
          path: path.relative(base, full).split(path.sep).join('/'),
          content: txt
        });
      }
    })(base);

    if (!changes.length) throw new Error('فایل متنی‌ای پیدا نشد');
    return gh.batchCommit(owner, repo, changes,
      `آپلود ${path.basename(base)} از Arena Plus`, branch);
  });

  ipcMain.handle('gh:issues', (_e, { owner, repo, state }) =>
    gh.issues(owner, repo, state));

  ipcMain.handle('gh:create-issue', (_e, { owner, repo, title, body }) =>
    gh.createIssue(owner, repo, title, body));

  ipcMain.handle('gh:rate', () => gh.rateLimit());

  /** کل مخزن → یک فایل Markdown قابل آپلود در Arena. */
  ipcMain.handle('gh:export-repo', async (_e, { owner, repo }) => {
    const t = await gh.tree(owner, repo);
    const files = [];
    let budget = 3.5 * 1024 * 1024;
    for (const it of t.items) {
      if (it.type !== 'blob') continue;
      if (it.size > 200 * 1024 || budget - it.size < 0) {
        files.push({ path: it.path, content: null, size: it.size });
        continue;
      }
      try {
        const txt = await gh.fileText(owner, repo, it.path, t.branch);
        files.push({ path: it.path, content: Buffer.from(txt, 'utf8'), size: it.size });
        budget -= it.size;
      } catch {
        files.push({ path: it.path, content: null, size: it.size });
      }
    }
    const { filesToMarkdown } = require('./zip-to-md');
    return convertAndSave(
      () => filesToMarkdown(files, `${owner}/${repo}`), `${owner}-${repo}`);
  });

  ipcMain.handle('gh:gist', async (_e, { filename, content, description }) => {
    const g = await gh.createGist(filename, content, description, false);
    return { url: g.html_url };
  });

  // ── یادداشت ──  // ── یادداشت ──
  ipcMain.handle('notes:list',   (_e, q)  => notes.list(q || ''));
  ipcMain.handle('notes:get',    (_e, id) => notes.get(id));
  ipcMain.handle('notes:save',   (_e, n)  => notes.save(n));
  ipcMain.handle('notes:delete', (_e, id) => { notes.remove(id); return true; });
  ipcMain.handle('notes:pin',    (_e, id) => notes.togglePin(id));
  ipcMain.handle('notes:markdown', (_e, id) => notes.toMarkdown(id));

  ipcMain.handle('notes:add-image', async (_e, noteId) => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب تصویر',
      filters: [{ name: 'تصویر', extensions: ['png','jpg','jpeg','gif','webp'] }],
      properties: ['openFile']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    return notes.addImage(noteId, r.filePaths[0]);
  });

  ipcMain.handle('notes:paste-image', (_e, { noteId, dataUrl }) =>
    notes.addImageFromDataUrl(noteId, dataUrl));

  ipcMain.handle('notes:remove-image', (_e, { noteId, imageId }) => {
    notes.removeImage(noteId, imageId); return true;
  });

  ipcMain.handle('notes:export-file', async (_e, id) => {
    const md = notes.toMarkdown(id);
    const n = notes.get(id);
    const r = await dialog.showSaveDialog(win, {
      title: 'ذخیره‌ی یادداشت',
      defaultPath: path.join(downloadDir(), `${(n.title||'note').slice(0,40)}.md`),
      filters: [{ name: 'Markdown', extensions: ['md'] }]
    });
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, md, 'utf8');
    return r.filePath;
  });

  // ── از صفحه‌ی وب ──
  ipcMain.on('web:conversation', (e, data) => {
    const tab = [...tabs.values()].find(
      t => t.view.webContents.id === e.sender.id
    );
    if (tab) store.saveConversation({ ...data, profileId: tab.profileId });
  });

  // ── دانلود رهگیری‌شده از صفحه (blob: و data:) ──
  ipcMain.on('web:download-start', (_e, fileName) => {
    send('download-started', { id: 'js', fileName, total: 0 });
  });

  ipcMain.on('web:download-data', (e, { dataUrl, mime, fileName }) => {
    try {
      const m = /^data:([^;]*);base64,(.+)$/s.exec(dataUrl);
      if (!m) throw new Error('داده‌ی نامعتبر');
      const realMime = mime || m[1] || 'application/octet-stream';
      const buf = Buffer.from(m[2], 'base64');
      if (!buf.length) throw new Error('فایل خالی است');

      const name = resolveFileName(fileName, realMime, '');
      const target = uniquePath(downloadDir(), name);
      fs.writeFileSync(target, buf);

      const tab = [...tabs.values()].find(
        t => t.view.webContents.id === e.sender.id);

      store.addDownload({
        fileName: path.basename(target),
        mimeType: realMime,
        sourceUrl: 'blob',
        localPath: target,
        sizeBytes: buf.length,
        profileId: tab ? tab.profileId : store.getActiveProfile()
      });

      send('download-done', {
        id: 'js', fileName: path.basename(target), path: target
      });
    } catch (err) {
      send('download-failed', { id: 'js', reason: err.message });
    }
  });

  ipcMain.on('web:download-error', (_e, msg) => {
    send('download-failed', { id: 'js', reason: msg });
  });

  ipcMain.on('web:send', (e) => {
    const tab = [...tabs.values()].find(
      t => t.view.webContents.id === e.sender.id
    );
    if (tab) store.recordUsage(tab.profileId);
  });
}

/** تبدیل را اجرا و در پوشه‌ی Arena Plus ذخیره می‌کند. */
function convertAndSave(fn, baseName) {
  const md = fn();
  const safe = baseName.replace(/[\\/:*?"<>|]/g, '_').slice(0, 60);
  const out = uniquePath(downloadDir(), `${safe}.md`);
  fs.writeFileSync(out, md, 'utf8');
  return {
    path: out,
    name: path.basename(out),
    sizeKB: Math.round(Buffer.byteLength(md, 'utf8') / 1024)
  };
}

// ─────────────────────────────────────────────────────────────
//  منوی برنامه
// ─────────────────────────────────────────────────────────────

function buildMenu() {
  const isMac = process.platform === 'darwin';

  /**
   * 🔴 نکته‌ی مهم درباره‌ی شورت‌کات‌ها:
   * وقتی BrowserView فوکوس دارد، roleهای استاندارد منو (undo/copy/…)
   * به webContents *پنجره* می‌روند نه به BrowserView. نتیجه: ⌘Z و ⌘C
   * در صفحه‌ی Arena کار نمی‌کنند.
   *
   * راه‌حل: به‌جای role، خودمان روی webContents فوکوس‌شده صدا می‌زنیم.
   */
  /**
   * 🔴 کدام webContents باید فرمان ویرایش را بگیرد؟
   *
   * وقتی BrowserView فوکوس دارد، roleهای منو به webContents *پنجره*
   * می‌روند نه به view — پس ⌘Z و ⌘C در صفحه‌ی Arena کار نمی‌کنند.
   *
   * ترتیب اولویت:
   *  ۱. پنجره‌ی پاپ‌آپ (لاگین) اگر فوکوس دارد
   *  ۲. رابط کاربری اصلی اگر پنل باز است
   *  ۳. BrowserView تب فعال (حالت پیش‌فرض)
   */
  const focused = () => {
    const bw = BrowserWindow.getFocusedWindow();
    if (bw && bw !== win) return bw.webContents;          // پاپ‌آپ
    if (panelOpen && win) return win.webContents;         // پنل باز
    const t = activeTabId && tabs.get(activeTabId);
    if (t && !t.view.webContents.isDestroyed()) return t.view.webContents;
    return win ? win.webContents : null;
  };
  const edit = (fn) => () => { const wc = focused(); if (wc) wc[fn](); };
  const zoom = (delta) => () => {
    const wc = focused(); if (!wc) return;
    wc.setZoomLevel(delta === 0 ? 0 : wc.getZoomLevel() + delta);
  };

  const template = [
    ...(isMac ? [{
      label: 'Arena Plus',
      submenu: [
        { role: 'about', label: 'درباره‌ی Arena Plus' },
        { type: 'separator' },
        { role: 'hide', label: 'مخفی کردن' },
        { role: 'hideOthers', label: 'مخفی کردن بقیه' },
        { role: 'unhide', label: 'نمایش همه' },
        { type: 'separator' },
        { role: 'quit', label: 'خروج از Arena Plus' }
      ]
    }] : []),
    {
      label: 'فایل',
      submenu: [
        { label: 'تب جدید', accelerator: 'CmdOrCtrl+T',
          click: () => { const t = createTab(store.getActiveProfile()); showTab(t.id); } },
        { label: 'بستن تب', accelerator: 'CmdOrCtrl+W',
          click: () => activeTabId && closeTab(activeTabId) },
        { type: 'separator' },
        { label: 'اکانت بعدی', accelerator: 'CmdOrCtrl+Shift+A',
          click: () => {
            const ps = store.getProfiles();
            const i = ps.findIndex(p => p.id === store.getActiveProfile());
            const next = ps[(i + 1) % ps.length];
            const ex = [...tabs.values()].find(t => t.profileId === next.id);
            showTab(ex ? ex.id : createTab(next.id).id);
            send('profiles-changed',
              { profiles: ps, activeProfileId: next.id });
          } },
        ...(isMac ? [] : [{ type: 'separator' }, { role: 'quit', label: 'خروج' }])
      ]
    },
    {
      label: 'ویرایش',
      submenu: [
        { label: 'واگرد',  accelerator: 'CmdOrCtrl+Z',       click: edit('undo') },
        { label: 'ازنو',   accelerator: 'Shift+CmdOrCtrl+Z', click: edit('redo') },
        { type: 'separator' },
        { label: 'برش',    accelerator: 'CmdOrCtrl+X', click: edit('cut') },
        { label: 'کپی',    accelerator: 'CmdOrCtrl+C', click: edit('copy') },
        { label: 'چسباندن', accelerator: 'CmdOrCtrl+V', click: edit('paste') },
        { label: 'چسباندن بدون قالب', accelerator: 'Shift+CmdOrCtrl+V',
          click: edit('pasteAndMatchStyle') },
        { label: 'حذف', click: edit('delete') },
        { type: 'separator' },
        { label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A', click: edit('selectAll') },
        { type: 'separator' },
        { label: 'جست‌وجو در صفحه', accelerator: 'CmdOrCtrl+F',
          click: () => send('find-open') }
      ]
    },
    {
      label: 'نمایش',
      submenu: [
        { label: 'بارگذاری مجدد', accelerator: 'CmdOrCtrl+R',
          click: () => { const wc = focused(); if (wc) wc.reload(); } },
        { label: 'بارگذاری کامل', accelerator: 'Shift+CmdOrCtrl+R',
          click: () => { const wc = focused(); if (wc) wc.reloadIgnoringCache(); } },
        { type: 'separator' },
        { label: 'عقب', accelerator: 'CmdOrCtrl+[',
          click: () => { const wc = focused(); if (wc && wc.canGoBack()) wc.goBack(); } },
        { label: 'جلو', accelerator: 'CmdOrCtrl+]',
          click: () => { const wc = focused(); if (wc && wc.canGoForward()) wc.goForward(); } },
        { type: 'separator' },
        { label: 'بزرگ‌تر', accelerator: 'CmdOrCtrl+Plus',  click: zoom(0.5) },
        { label: 'بزرگ‌تر ', accelerator: 'CmdOrCtrl+=',    click: zoom(0.5),
          visible: false },
        { label: 'کوچک‌تر', accelerator: 'CmdOrCtrl+-',      click: zoom(-0.5) },
        { label: 'اندازه‌ی عادی', accelerator: 'CmdOrCtrl+0', click: zoom(0) },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'تمام‌صفحه' },
        { label: 'ابزار توسعه‌دهنده', accelerator: isMac ? 'Alt+Cmd+I' : 'F12',
          click: () => { const wc = focused(); if (wc) wc.toggleDevTools(); } }
      ]
    },
    {
      label: 'ابزار',
      submenu: [
        { label: 'یادداشت‌ها',    accelerator: 'CmdOrCtrl+Shift+N',
          click: () => send('open-panel', 'notes') },
        { label: 'آرشیو',        accelerator: 'CmdOrCtrl+Shift+H',
          click: () => send('open-panel', 'archive') },
        { label: 'پرامپت‌ها',     accelerator: 'CmdOrCtrl+Shift+P',
          click: () => send('open-panel', 'prompts') },
        { label: 'دانلودها',     accelerator: 'CmdOrCtrl+Shift+J',
          click: () => send('open-panel', 'downloads') },
        { label: 'GitHub',       accelerator: 'CmdOrCtrl+Shift+G',
          click: () => send('open-panel', 'github') },
        { label: 'لیدربورد',     accelerator: 'CmdOrCtrl+Shift+L',
          click: () => send('open-panel', 'board') },
        { type: 'separator' },
        { label: 'تنظیمات', accelerator: 'CmdOrCtrl+,',
          click: () => send('open-panel', 'settings') }
      ]
    },
    {
      label: 'پنجره',
      submenu: [
        { role: 'minimize', label: 'کوچک کردن' },
        { role: 'zoom', label: 'بزرگ کردن' },
        ...(isMac ? [{ type: 'separator' }, { role: 'front', label: 'همه به جلو' }] : [])
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ─────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  store = new Store(app.getPath('userData'));
  notes = new Notes(app.getPath('userData'));
  gh = new GitHub(store.getGithubToken());
  registerIpc();
  buildMenu();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// آزادسازی حافظه‌ی تب‌های غیرفعال وقتی سیستم تحت فشار است
app.on('render-process-gone', (_e, wc, details) => {
  console.warn('پروسه‌ی رندر از دست رفت:', details.reason);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
