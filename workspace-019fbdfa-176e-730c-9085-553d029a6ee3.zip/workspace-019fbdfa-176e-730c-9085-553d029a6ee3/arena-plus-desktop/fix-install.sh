#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  تعمیر قطعی «Electron failed to install correctly»
#
#  اجرا:
#      cd ~/Downloads/arena-plus-desktop
#      bash fix-install.sh
#
#  این اسکریپت به‌جای اتکا به npm، باینری Electron را مستقیم با curl
#  دانلود می‌کند و دستی در جای درست باز می‌کند. اگر یک آینه جواب نداد،
#  آینه‌ی بعدی را امتحان می‌کند.
# ═══════════════════════════════════════════════════════════════

set -e
cd "$(dirname "$0")" 2>/dev/null || {
  echo "❌ نمی‌توانم وارد پوشه شوم."
  echo "   اول این را بزن:  cd ~/Downloads/arena-plus-desktop"
  exit 1
}

echo ""
echo "🔧 تعمیر نصب Electron"
echo "════════════════════════════════════════"

# ── تشخیص معماری ──
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then
  EARCH="arm64"; echo "   مک: Apple Silicon"
else
  EARCH="x64";   echo "   مک: Intel"
fi

# ── نسخه‌ی مورد نیاز ──
VER=$(node -p "require('./package.json').devDependencies.electron.replace(/[^0-9.]/g,'')" 2>/dev/null || echo "33.2.1")
echo "   نسخه‌ی Electron: $VER"
echo ""

# ── ۱) نصب وابستگی‌ها بدون باینری ──
echo "→ ۱/۴  نصب وابستگی‌های JS…"
rm -rf node_modules package-lock.json
export ELECTRON_SKIP_BINARY_DOWNLOAD=1
npm install --no-audit --no-fund --loglevel=error
unset ELECTRON_SKIP_BINARY_DOWNLOAD
echo "      ✅ انجام شد"
echo ""

# ── ۲) دانلود باینری ──
ZIP="electron-v${VER}-darwin-${EARCH}.zip"
TMP="/tmp/$ZIP"

MIRRORS=(
  "https://npmmirror.com/mirrors/electron/${VER}/${ZIP}"
  "https://registry.npmmirror.com/-/binary/electron/${VER}/${ZIP}"
  "https://github.com/electron/electron/releases/download/v${VER}/${ZIP}"
)

echo "→ ۲/۴  دانلود باینری Electron (~۱۰۰ مگابایت)…"
OK=0
if [ -f "$TMP" ] && [ "$(stat -f%z "$TMP" 2>/dev/null || echo 0)" -gt 50000000 ]; then
  echo "      از فایل دانلودشده‌ی قبلی استفاده می‌کنم"
  OK=1
else
  for M in "${MIRRORS[@]}"; do
    echo "      امتحان: $(echo "$M" | cut -d/ -f3)"
    if curl -L --fail --progress-bar --connect-timeout 25 --max-time 900 \
            -o "$TMP" "$M"; then
      SIZE=$(stat -f%z "$TMP" 2>/dev/null || echo 0)
      if [ "$SIZE" -gt 50000000 ]; then
        echo "      ✅ دانلود شد ($(( SIZE / 1048576 )) مگابایت)"
        OK=1; break
      fi
      echo "      ⚠️ فایل ناقص بود، آینه‌ی بعدی…"
    else
      echo "      ⚠️ در دسترس نبود"
    fi
    rm -f "$TMP"
  done
fi

if [ "$OK" -ne 1 ]; then
  echo ""
  echo "❌ هیچ آینه‌ای جواب نداد."
  echo ""
  echo "   VPN را روشن (یا اگر روشن است خاموش) کن و دوباره بزن."
  echo "   یا فایل را دستی دانلود کن و در /tmp بگذار:"
  echo "      $ZIP"
  exit 1
fi
echo ""

# ── ۳) باز کردن در جای درست ──
echo "→ ۳/۴  نصب باینری…"
DEST="node_modules/electron/dist"
rm -rf "$DEST"
mkdir -p "$DEST"
unzip -q -o "$TMP" -d "$DEST"
# 🔴 حتماً printf نه echo — echo یک \n اضافه می‌کند و کتابخانه‌ی
# electron محتوای path.txt را خام (بدون trim) می‌خواند، پس مسیر
# می‌شود ".../Electron\n" که وجود ندارد → ENOENT
printf 'Electron.app/Contents/MacOS/Electron' > node_modules/electron/path.txt
xattr -cr "$DEST/Electron.app" 2>/dev/null || true
chmod +x "$DEST/Electron.app/Contents/MacOS/Electron" 2>/dev/null || true
echo "      ✅ نصب شد"
echo ""

# ── ۴) بررسی ──
echo "→ ۴/۴  بررسی…"
BIN="$DEST/Electron.app/Contents/MacOS/Electron"
# اطمینان از نبود newline در path.txt
PT=$(cat node_modules/electron/path.txt)
if [ "$PT" != "Electron.app/Contents/MacOS/Electron" ]; then
  printf 'Electron.app/Contents/MacOS/Electron' > node_modules/electron/path.txt
fi
if [ -x "$BIN" ]; then
  echo "      ✅ باینری در جای خود است"
  echo ""
  echo "════════════════════════════════════════"
  echo "✅ آماده است. حالا بزن:"
  echo ""
  echo "    npm start"
  echo ""
  rm -f "$TMP"
  exit 0
fi

echo "      ❌ باینری پیدا نشد"
echo "         محتوای $DEST:"
ls -la "$DEST" | head -5
exit 1
