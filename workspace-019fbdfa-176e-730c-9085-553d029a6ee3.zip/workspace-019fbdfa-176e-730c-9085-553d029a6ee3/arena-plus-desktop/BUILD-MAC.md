# ساخت نسخه‌ی مک — قدم به قدم

⏱ **بار اول: ۱۰ تا ۲۰ دقیقه** (بیشترش دانلود Electron است). دفعات بعد: ۲ دقیقه.

---

## پیش‌نیاز: فقط Node.js

توی ترمینال بزن:

```bash
node --version
```

اگر عددی مثل `v20.x` یا `v22.x` دیدی، آماده‌ای — برو مرحله‌ی ۱.

اگر `command not found` گرفتی، نصبش کن:

**راه ساده:** از [nodejs.org](https://nodejs.org) نسخه‌ی **LTS** را دانلود و نصب کن.

**یا با Homebrew:**
```bash
brew install node
```

> نیازی به Xcode نیست. فقط اگر خواستی اپ را رسماً امضا کنی لازم می‌شود.

---

## مرحله ۱ — رفتن به پوشه‌ی پروژه

```bash
cd ~/Downloads/arena-plus-desktop
```

مسیر را با جایی که اکسترکت کردی عوض کن. برای اطمینان:

```bash
ls
```

باید `package.json` و پوشه‌های `src` و `resources` را ببینی.

> 💡 **ترفند:** به‌جای تایپ مسیر، بنویس `cd ` (با فاصله) و پوشه را از
> Finder بکش داخل ترمینال. مسیر خودکار پر می‌شود.

---

## مرحله ۲ — نصب وابستگی‌ها

```bash
npm install
```

حدود ۳۰۰ مگابایت دانلود می‌کند (خود Electron). **۵ تا ۱۵ دقیقه** طول می‌کشد.

هشدارهای زرد `npm warn` طبیعی‌اند — نادیده بگیر.

> ✅ **فایل `.npmrc` در پروژه هست** و npm را خودکار به آینه‌ای هدایت می‌کند
> که در ایران باز است. پس معمولاً بدون VPN هم کار می‌کند.

### ⚠️ اگر خطای «Electron failed to install correctly» گرفتی

بسته‌ی `electron` دو مرحله دارد: فایل‌های جاوااسکریپت (از npm) و باینری
واقعی ~۱۰۰ مگابایتی (از GitHub Releases). مرحله‌ی دوم در ایران بلاک است
و **npm این شکست را بی‌صدا رد می‌کند** — پس نصب موفق به نظر می‌رسد ولی
`npm start` خطا می‌دهد.

**راه‌حل — یک دستور:**

```bash
cd ~/Downloads/arena-plus-desktop
bash fix-install.sh
```

این اسکریپت به npm اتکا نمی‌کند. باینری را **مستقیم با curl** دانلود
می‌کند، سه آینه را به ترتیب امتحان می‌کند، و دستی در جای درست باز
می‌کند. نوار پیشرفت هم نشان می‌دهد تا بدانی گیر نکرده.

**اگر گفت هیچ آینه‌ای جواب نداد:**

۱. VPN را روشن کن (یا اگر روشن است **خاموش** کن — گاهی برعکس بهتر است)
۲. دوباره `bash fix-install.sh`

اسکریپت فایل نیمه‌دانلودشده را نگه می‌دارد، پس بار دوم از همان‌جا
ادامه می‌دهد.

**دانلود دستی (آخرین راه):**

اگر ترمینال اصلاً دانلود نمی‌کند، این لینک را در مرورگر باز کن:

```
https://npmmirror.com/mirrors/electron/33.2.1/electron-v33.2.1-darwin-arm64.zip
```

> برای مک اینتل، `arm64` را با `x64` عوض کن.
> نمی‌دانی کدام؟ در ترمینال بزن `uname -m` — اگر `arm64` داد یعنی
> اپل سیلیکون.

فایل دانلودشده را در `/tmp` بگذار و دوباره `bash fix-install.sh` بزن —
خودش تشخیص می‌دهد و از همان استفاده می‌کند.

### 🔴 خطای «getcwd: Operation not permitted»

اگر این را دیدی:

```
shell-init: error retrieving current directory: getcwd
bash: fix-install.sh: No such file or directory
```

یعنی پوشه را دوباره اکسترکت کرده‌ای و ترمینال هنوز به پوشه‌ی **حذف‌شده**
اشاره می‌کند. ربطی به کد ندارد.

```bash
cd ~/Downloads/arena-plus-desktop
```

همین. حالا دستورها کار می‌کنند.

---

## مرحله ۳ — تست قبل از build (مهم)

```bash
npm start
```

اپ باید باز شود. چند ثانیه صبر کن تا arena.ai لود شود.

**اینها را چک کن:**
- ✅ صفحه‌ی Arena می‌آید
- ✅ آواتارهای رنگی بالا سمت راست هست
- ✅ روی آواتار دوم بزن → پروفایل عوض می‌شود
- ✅ لاگین گوگل کار می‌کند
- ✅ متن فارسی درست چیده می‌شود

اگر همه‌چیز خوب بود، پنجره را ببند و برو مرحله‌ی بعد.

اگر ارور داد، همان متن ترمینال را برای من بفرست.

---

## مرحله ۴ — ساخت فایل نصبی

```bash
npm run dist:mac
```

**۳ تا ۸ دقیقه** طول می‌کشد. آخرش:

```
• building        target=DMG arch=universal
• building block map
```

### خروجی کجاست؟

```bash
open dist
```

پوشه‌ی Finder باز می‌شود. فایل اصلی:

```
Arena Plus-1.0.0-universal.dmg
```

این همان فایلی است که نصب می‌کنی یا به بقیه می‌دهی.

> **universal یعنی چه؟** یک فایل که هم روی مک‌های اپل سیلیکون (M1/M2/M3/M4)
> و هم روی مک‌های اینتل کار می‌کند. کاربر نیازی به انتخاب ندارد.
>
> اگر فقط برای مک خودت می‌خواهی و حجم کمتری بخواهی:
> ```bash
> npm run dist:mac:arm     # فقط اپل سیلیکون، نصف حجم
> npm run dist:mac:intel   # فقط اینتل
> ```

---

## مرحله ۵ — نصب

۱. روی `.dmg` دابل‌کلیک کن
۲. آیکون **Arena Plus** را بکش روی پوشه‌ی **Applications**
۳. `.dmg` را ببند و از Launchpad اجرا کن

### ⚠️ بار اول: هشدار امنیتی

مک می‌گوید:

> «Arena Plus» cannot be opened because it is from an unidentified developer

**این طبیعی است** — اپ با گواهی ۹۹ دلاری اپل امضا نشده. اپ سالم است.

**راه‌حل (فقط بار اول):**

**روش ۱:** روی اپ در Applications **راست‌کلیک** → **Open** → در دیالوگ
دوباره **Open** بزن.

**روش ۲:** اگر روش اول جواب نداد:
**System Settings → Privacy & Security** → پایین صفحه پیام مربوط به
Arena Plus را می‌بینی → **Open Anyway**

**روش ۳ (اگر هیچ‌کدام نشد):**
```bash
xattr -cr "/Applications/Arena Plus.app"
```
این دستور برچسب قرنطینه را برمی‌دارد.

از دفعه‌ی دوم به بعد عادی باز می‌شود.

---

## 🔧 خطاهای رایج

| خطا | راه‌حل |
|---|---|
| `command not found: npm` | Node.js نصب نیست — بالا را ببین |
| `EACCES: permission denied` | `sudo chown -R $(whoami) ~/.npm` |
| `Electron failed to install correctly` | `bash fix-install.sh` |
| دانلود Electron گیر کرد | `bash fix-install.sh` یا VPN |
| `Cannot find module 'electron'` | `npm install` کامل نشده — دوباره بزن |
| `icon.icns is not a valid icon` | `resources/` را چک کن که وجود دارد |
| اپ باز می‌شود ولی سفید است | ۱۰ ثانیه صبر کن؛ اگر نشد `npm start` و `F12` |

### شروع تمیز

اگر همه‌چیز به هم ریخت:

```bash
rm -rf node_modules dist package-lock.json
npm install
npm run dist:mac
```

---

## 📍 محل فایل‌ها بعد از نصب

| چه چیزی | کجا |
|---|---|
| دانلودها | `~/Downloads/Arena Plus/` |
| آرشیو و تنظیمات | `~/Library/Application Support/Arena Plus/` |
| کوکی هر اکانت | همان مسیر، زیر `Partitions/` |

برای پاک کردن کامل اپ: اپ را حذف کن + پوشه‌ی
`~/Library/Application Support/Arena Plus/` را پاک کن.

---

## 🪟 نسخه‌ی ویندوز از روی مک؟

فنی ممکن است ولی به Wine نیاز دارد و شکننده است:

```bash
brew install --cask wine-stable
npm run dist:win
```

**بهتر:** از GitHub Actions استفاده کن (در `README.md` توضیح داده‌ام) —
هر دو نسخه را روی سرور می‌سازد، رایگان و بدون دردسر.

---

## خلاصه — چهار دستور

```bash
cd ~/Downloads/arena-plus-desktop
npm install
npm start          # تست
npm run dist:mac   # ساخت
```
