#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Arena Plus — اجرای هوشمند
#
#      bash run.sh
#
#  خودش تشخیص می‌دهد چه چیزی کم است و فقط همان را انجام می‌دهد:
#   • node_modules نیست      → نصب می‌کند
#   • باینری Electron نیست   → از آینه دانلود می‌کند
#   • همه‌چیز هست            → مستقیم اجرا می‌کند
#
#  کش دانلود در ~/.arena-plus-cache نگه داشته می‌شود، پس اگر پوشه‌ی
#  پروژه را دوباره اکسترکت کنی، نیازی به دانلود مجدد ۱۰۰ مگابایت نیست.
# ═══════════════════════════════════════════════════════════════

set -e
cd "$(dirname "$0")" 2>/dev/null || {
  echo "❌ نمی‌توانم وارد پوشه شوم."
  echo "   اول بزن:  cd ~/Downloads/arena-plus-desktop"
  exit 1
}

CACHE="$HOME/.arena-plus-cache"
mkdir -p "$CACHE"

echo ""
echo "🚀 Arena Plus"
echo "═══════════════════════════════════"

# ── معماری و نسخه ──
if [ "$(uname -m)" = "arm64" ]; then EARCH="arm64"; else EARCH="x64"; fi
VER=$(node -p "require('./package.json').devDependencies.electron.replace(/[^0-9.]/g,'')" 2>/dev/null || echo "33.2.1")

BIN="node_modules/electron/dist/Electron.app/Contents/MacOS/Electron"

# ── ۱) وابستگی‌های JS ──
if [ ! -d "node_modules/electron" ]; then
  echo "→ نصب وابستگی‌ها…"
  export ELECTRON_SKIP_BINARY_DOWNLOAD=1
  npm install --no-audit --no-fund --loglevel=error
  unset ELECTRON_SKIP_BINARY_DOWNLOAD
  echo "  ✅ نصب شد"
else
  echo "✅ وابستگی‌ها موجودند"
fi

# ── ۲) باینری Electron ──
if [ -x "$BIN" ]; then
  echo "✅ Electron نصب است"
else
  ZIP="electron-v${VER}-darwin-${EARCH}.zip"
  CACHED="$CACHE/$ZIP"

  if [ -f "$CACHED" ] && [ "$(stat -f%z "$CACHED" 2>/dev/null || echo 0)" -gt 50000000 ]; then
    echo "✅ از کش استفاده می‌کنم ($ZIP)"
  else
    echo "→ دانلود Electron (~۱۰۰ مگابایت، یک‌بار برای همیشه)…"
    OK=0
    for M in \
      "https://npmmirror.com/mirrors/electron/${VER}/${ZIP}" \
      "https://registry.npmmirror.com/-/binary/electron/${VER}/${ZIP}" \
      "https://github.com/electron/electron/releases/download/v${VER}/${ZIP}"
    do
      echo "   $(echo "$M" | cut -d/ -f3)…"
      if curl -L --fail --progress-bar --connect-timeout 25 --max-time 900 \
              -o "$CACHED.part" "$M"; then
        if [ "$(stat -f%z "$CACHED.part" 2>/dev/null || echo 0)" -gt 50000000 ]; then
          mv "$CACHED.part" "$CACHED"; OK=1; break
        fi
      fi
      rm -f "$CACHED.part"
    done

    if [ "$OK" -ne 1 ]; then
      echo ""
      echo "❌ دانلود نشد. VPN را روشن (یا خاموش) کن و دوباره بزن."
      exit 1
    fi
    echo "  ✅ دانلود شد"
  fi

  echo "→ نصب باینری…"
  DEST="node_modules/electron/dist"
  rm -rf "$DEST"; mkdir -p "$DEST"
  unzip -q -o "$CACHED" -d "$DEST"
  # 🔴 printf نه echo — echo یک \n اضافه می‌کند و مسیر خراب می‌شود
  printf 'Electron.app/Contents/MacOS/Electron' > node_modules/electron/path.txt
  xattr -cr "$DEST/Electron.app" 2>/dev/null || true
  chmod +x "$BIN" 2>/dev/null || true
  echo "  ✅ نصب شد"
fi

# ── ۳) بررسی نهایی ──
if [ ! -x "$BIN" ]; then
  echo ""
  echo "❌ باینری پیدا نشد: $BIN"
  exit 1
fi

# ── ۴) اجرا ──
echo ""
echo "═══════════════════════════════════"
echo "▶️  در حال اجرا…"
echo ""
exec "$BIN" .
