'use strict';

const { ipcRenderer } = require('electron');

/**
 * داخل صفحه‌ی arena.ai اجرا می‌شود.
 * فقط DOM را می‌خواند — هیچ اتوماسیون یا ارسال خودکاری در کار نیست.
 */

function collect() {
  const main = document.querySelector('main') || document.body;
  if (!main) return null;
  const body = (main.innerText || '').trim();
  if (body.length < 60) return null;

  let title = document.title || '';
  const h = main.querySelector('h1, h2');
  if (h && (h.innerText || '').trim().length > 3) title = h.innerText.trim();
  if (!title || title.length < 3) {
    title = body.slice(0, 60).replace(/\s+/g, ' ');
  }

  return {
    title: title.slice(0, 200),
    bodyText: body.slice(0, 200000),
    url: location.href
  };
}

function push() {
  try {
    const d = collect();
    if (d) ipcRenderer.send('web:conversation', d);
  } catch { /* ignore */ }
}

/**
 * 🔴 رهگیری دانلود blob:
 *
 * Electron رویداد `will-download` را فقط برای ناوبری واقعی صادر می‌کند.
 * اما Arena تصاویر را این‌طور دانلود می‌کند:
 *     const url = URL.createObjectURL(blob)
 *     a.href = url; a.download = 'x.png'; a.click()
 *
 * این یک کلیک DOM است، نه ناوبری — پس will-download صدا زده نمی‌شود
 * و هیچ دانلودی شروع نمی‌شود. اینجا خودمان می‌قاپیمش و محتوا را به
 * پروسه‌ی اصلی می‌فرستیم.
 */
function installDownloadHook() {
  if (window.__apDlHook) return;
  window.__apDlHook = true;

  // revokeObjectURL را به تعویق بینداز تا فرصت خواندن blob باشد
  const origRevoke = URL.revokeObjectURL.bind(URL);
  URL.revokeObjectURL = (u) => {
    setTimeout(() => { try { origRevoke(u); } catch {} }, 15000);
  };

  function nameFrom(a) {
    let n = (a && a.getAttribute && a.getAttribute('download')) || '';
    n = String(n).trim();
    if (!n && a && a.href) {
      try {
        const p = new URL(a.href, location.href).pathname.split('/').pop();
        if (p && p.includes('.')) n = decodeURIComponent(p);
      } catch {}
    }
    return n || `arena_${Date.now()}`;
  }

  function sendBlob(blobUrl, fileName) {
    ipcRenderer.send('web:download-start', fileName);
    fetch(blobUrl)
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.blob(); })
      .then(b => {
        if (b.size > 80 * 1024 * 1024) throw new Error('فایل بزرگ‌تر از ۸۰ مگابایت');
        const fr = new FileReader();
        fr.onloadend = () => ipcRenderer.send('web:download-data', {
          dataUrl: String(fr.result), mime: b.type || '', fileName
        });
        fr.onerror = () => ipcRenderer.send('web:download-error', 'خواندن فایل ناموفق');
        fr.readAsDataURL(b);
      })
      .catch(e => ipcRenderer.send('web:download-error', String(e.message || e)));
  }

  // کلیک روی <a download> یا blob:/data:
  document.addEventListener('click', (ev) => {
    let el = ev.target;
    for (let i = 0; i < 6 && el; i++) {
      if (el.tagName === 'A' && el.href) {
        const href = el.href;
        if (el.hasAttribute('download') ||
            href.startsWith('blob:') || href.startsWith('data:')) {
          ev.preventDefault();
          ev.stopPropagation();
          const fname = nameFrom(el);
          if (href.startsWith('data:')) {
            ipcRenderer.send('web:download-data',
              { dataUrl: href, mime: '', fileName: fname });
          } else {
            sendBlob(href, fname);
          }
          return;
        }
      }
      el = el.parentElement;
    }
  }, true);

  // a.click() برنامه‌نویسی‌شده (بدون افزودن به DOM)
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      const href = this.href || '';
      if (this.hasAttribute('download') ||
          href.startsWith('blob:') || href.startsWith('data:')) {
        const fname = nameFrom(this);
        if (href.startsWith('data:')) {
          ipcRenderer.send('web:download-data',
            { dataUrl: href, mime: '', fileName: fname });
        } else {
          sendBlob(href, fname);
        }
        return;
      }
    } catch {}
    return origClick.apply(this, arguments);
  };
}

/**
 * 🔴 رهگیری راست‌کلیک در فاز capture
 *
 * اپ‌های React مثل Arena روی contextmenu ‏preventDefault() می‌زنند.
 * وقتی صفحه جلوی منوی پیش‌فرض را بگیرد، Chromium رویداد
 * `context-menu` را به Electron نمی‌فرستد و هندلر ما هرگز اجرا
 * نمی‌شود.
 *
 * راه‌حل: در فاز capture (قبل از هندلرهای صفحه) رویداد را می‌گیریم
 * و اطلاعات لازم را مستقیم به پروسه‌ی اصلی می‌فرستیم.
 */
function installContextMenuHook() {
  if (window.__apCtxHook) return;
  window.__apCtxHook = true;

  document.addEventListener('contextmenu', (e) => {
    // جلوی preventDefault صفحه را می‌گیریم
    e.stopPropagation();

    const t = e.target;
    const link = t && t.closest ? t.closest('a[href]') : null;
    const img = t && t.tagName === 'IMG' ? t
      : (t && t.closest ? t.closest('img') : null);

    const editable = !!(t && (
      t.tagName === 'TEXTAREA' ||
      (t.tagName === 'INPUT' && !/^(button|checkbox|radio|submit|file)$/i
        .test(t.type || '')) ||
      t.isContentEditable
    ));

    let selection = '';
    try { selection = String(window.getSelection() || '').trim(); } catch {}

    ipcRenderer.send('web:context-menu', {
      x: Math.round(e.clientX),
      y: Math.round(e.clientY),
      linkURL: link ? link.href : '',
      srcURL: img ? img.src : '',
      isImage: !!img,
      isEditable: editable,
      selectionText: selection.slice(0, 2000),
      canUndo: editable, canRedo: editable,
      canCut: editable && !!selection,
      canCopy: !!selection,
      canPaste: editable
    });
  }, true);   // ← capture = true، حیاتی است
}

/**
 * 🔴 باگی که اینجا رفع شد:
 *
 * قبلاً همه‌ی هوک‌ها داخل `DOMContentLoaded` نصب می‌شدند. اما preload
 * گاهی *بعد* از آن رویداد اجرا می‌شود (به‌ویژه در SPAها). در آن حالت
 * رویداد هرگز fire نمی‌شد و هیچ هوکی نصب نمی‌گشت — به همین دلیل
 * راست‌کلیک و دانلود کار نمی‌کردند.
 *
 * حالا فوراً نصب می‌کنیم و اگر DOM آماده نیست، هم منتظر رویداد
 * می‌مانیم و هم با یک تایمر کوتاه دوباره تلاش می‌کنیم.
 */
function installAll() {
  try { installDownloadHook(); } catch (e) {}
  try { installContextMenuHook(); } catch (e) {}
}

function installObservers() {
  if (!document.body || window.__apObs) return;
  window.__apObs = true;

  let timer = null;
  const obs = new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(push, 2500);
  });
  obs.observe(document.body, {
    childList: true, subtree: true, characterData: true
  });

  // شمارش پیام‌های ارسالی
  document.addEventListener('keydown', (e) => {
    const t = e.target;
    if (!t) return;
    const isInput = t.tagName === 'TEXTAREA' ||
      (t.getAttribute && t.getAttribute('contenteditable') === 'true');
    if (isInput && e.key === 'Enter' && !e.shiftKey) {
      ipcRenderer.send('web:send');
    }
  }, true);

  document.addEventListener('click', (e) => {
    let el = e.target;
    for (let i = 0; i < 4 && el; i++) {
      const label = ((el.getAttribute && el.getAttribute('aria-label')) || '') +
        ' ' + (el.textContent || '');
      if (el.tagName === 'BUTTON' && /send|ارسال|submit/i.test(label)) {
        ipcRenderer.send('web:send');
        break;
      }
      el = el.parentElement;
    }
  }, true);

  setTimeout(push, 3000);
}

// ── نصب فوری (بدون انتظار برای رویداد) ──
installAll();

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    installAll();
    installObservers();
  });
} else {
  installObservers();
}

// تور ایمنی: اگر به هر دلیلی نصب نشد، تا ۵ ثانیه تلاش کن
let tries = 0;
const retry = setInterval(() => {
  tries++;
  installAll();
  installObservers();
  if ((window.__apCtxHook && window.__apObs) || tries > 10) {
    clearInterval(retry);
  }
}, 500);
