'use strict';

const { contextBridge, ipcRenderer } = require('electron');

/** پل امن بین رابط کاربری و پروسه‌ی اصلی. */
contextBridge.exposeInMainWorld('AP', {
  profiles: {
    list:    ()        => ipcRenderer.invoke('profiles:list'),
    switch:  (id)      => ipcRenderer.invoke('profiles:switch', id),
    add:     (label)   => ipcRenderer.invoke('profiles:add', label),
    rename:  (id, l)   => ipcRenderer.invoke('profiles:rename', { id, label: l }),
    remove:  (id)      => ipcRenderer.invoke('profiles:delete', id),
    signOut: (id)      => ipcRenderer.invoke('profiles:signout', id)
  },
  tabs: {
    list:  ()   => ipcRenderer.invoke('tabs:list'),
    open:  ()   => ipcRenderer.invoke('tabs:new'),
    show:  (id) => ipcRenderer.invoke('tabs:show', id),
    close: (id) => ipcRenderer.invoke('tabs:close', id)
  },
  panel: {
    open:  () => ipcRenderer.invoke('panel:open'),
    close: () => ipcRenderer.invoke('panel:close')
  },
  nav: {
    home:     () => ipcRenderer.invoke('nav:home'),
    reload:   () => ipcRenderer.invoke('nav:reload'),
    back:     () => ipcRenderer.invoke('nav:back'),
    forward:  () => ipcRenderer.invoke('nav:forward'),
    url:      () => ipcRenderer.invoke('nav:url'),
    external: (u) => ipcRenderer.invoke('nav:open-external', u)
  },
  settings: {
    get: ()      => ipcRenderer.invoke('settings:get'),
    set: (patch) => ipcRenderer.invoke('settings:set', patch)
  },
  downloads: {
    list:   ()   => ipcRenderer.invoke('downloads:list'),
    open:   (p)  => ipcRenderer.invoke('downloads:open', p),
    reveal: (p)  => ipcRenderer.invoke('downloads:reveal', p),
    folder: ()   => ipcRenderer.invoke('downloads:folder'),
    remove: (id) => ipcRenderer.invoke('downloads:remove', id),
    clear:  ()   => ipcRenderer.invoke('downloads:clear')
  },
  archive: {
    list:   (q)   => ipcRenderer.invoke('archive:list', q),
    get:    (id)  => ipcRenderer.invoke('archive:get', id),
    star:   (id, v) => ipcRenderer.invoke('archive:star', { id, value: v }),
    remove: (ids) => ipcRenderer.invoke('archive:delete', ids)
  },
  prompts: {
    list:   ()   => ipcRenderer.invoke('prompts:list'),
    save:   (p)  => ipcRenderer.invoke('prompts:save', p),
    remove: (id) => ipcRenderer.invoke('prompts:delete', id),
    inject: (t)  => ipcRenderer.invoke('prompts:inject', t)
  },
  usage: {
    stats: () => ipcRenderer.invoke('usage:stats')
  },
  leaderboard: {
    fetch: (config, category) =>
      ipcRenderer.invoke('leaderboard:fetch', { config, category })
  },
  auth: {
    openExternal:  () => ipcRenderer.invoke('auth:open-external'),
    emailLogin:    () => ipcRenderer.invoke('auth:email-login'),
    importCookies: (profileId, cookieString) =>
      ipcRenderer.invoke('auth:import-cookies', { profileId, cookieString }),
    check: (profileId) => ipcRenderer.invoke('auth:check', profileId)
  },
  diag: {
    network: () => ipcRenderer.invoke('diag:network')
  },
  storage: {
    stats: ()     => ipcRenderer.invoke('storage:stats'),
    clear: (what) => ipcRenderer.invoke('storage:clear', what)
  },
  exportMd: {
    fromZip:    () => ipcRenderer.invoke('export:pick-zip'),
    fromFolder: () => ipcRenderer.invoke('export:pick-folder')
  },
  gh: {
    status:     ()  => ipcRenderer.invoke('gh:status'),
    connect:    (t) => ipcRenderer.invoke('gh:connect', t),
    disconnect: ()  => ipcRenderer.invoke('gh:disconnect'),
    rate:       ()  => ipcRenderer.invoke('gh:rate'),

    repos:    ()          => ipcRenderer.invoke('gh:repos'),
    repo:     (o, r)      => ipcRenderer.invoke('gh:repo', { owner: o, repo: r }),
    branches: (o, r)      => ipcRenderer.invoke('gh:branches', { owner: o, repo: r }),
    commits:  (o, r, b)   => ipcRenderer.invoke('gh:commits',
                              { owner: o, repo: r, branch: b }),
    tree:     (o, r, b)   => ipcRenderer.invoke('gh:tree',
                              { owner: o, repo: r, branch: b }),
    file:     (o, r, p, ref) => ipcRenderer.invoke('gh:file',
                              { owner: o, repo: r, path: p, ref }),

    createRepo: (opts) => ipcRenderer.invoke('gh:create-repo', opts),
    deleteRepo: (o, r) => ipcRenderer.invoke('gh:delete-repo', { owner: o, repo: r }),

    putFile: (o, r, p, content, message, branch) =>
      ipcRenderer.invoke('gh:put-file',
        { owner: o, repo: r, path: p, content, message, branch }),
    deleteFile: (o, r, p, message, branch) =>
      ipcRenderer.invoke('gh:delete-file',
        { owner: o, repo: r, path: p, message, branch }),

    batch: (o, r, changes, message, branch) =>
      ipcRenderer.invoke('gh:batch',
        { owner: o, repo: r, changes, message, branch }),

    uploadFiles:  (o, r, b, destDir) => ipcRenderer.invoke('gh:upload-files',
                    { owner: o, repo: r, branch: b, destDir }),
    uploadFolder: (o, r, b) => ipcRenderer.invoke('gh:upload-folder',
                    { owner: o, repo: r, branch: b }),

    exportRepo: (o, r) => ipcRenderer.invoke('gh:export-repo',
                            { owner: o, repo: r }),
    gist: (f, c, d) => ipcRenderer.invoke('gh:gist',
                          { filename: f, content: c, description: d }),

    issues:      (o, r, st) => ipcRenderer.invoke('gh:issues',
                                 { owner: o, repo: r, state: st }),
    createIssue: (o, r, t, b) => ipcRenderer.invoke('gh:create-issue',
                                 { owner: o, repo: r, title: t, body: b })
  },
  notes: {
    list:        (q)  => ipcRenderer.invoke('notes:list', q),
    get:         (id) => ipcRenderer.invoke('notes:get', id),
    save:        (n)  => ipcRenderer.invoke('notes:save', n),
    remove:      (id) => ipcRenderer.invoke('notes:delete', id),
    pin:         (id) => ipcRenderer.invoke('notes:pin', id),
    markdown:    (id) => ipcRenderer.invoke('notes:markdown', id),
    addImage:    (id) => ipcRenderer.invoke('notes:add-image', id),
    pasteImage:  (id, d) => ipcRenderer.invoke('notes:paste-image',
                     { noteId: id, dataUrl: d }),
    removeImage: (id, img) => ipcRenderer.invoke('notes:remove-image',
                     { noteId: id, imageId: img }),
    exportFile:  (id) => ipcRenderer.invoke('notes:export-file', id)
  },
  on: (channel, cb) => {
    const allowed = [
      'profiles-changed', 'tabs-changed', 'load-error',
      'download-started', 'download-progress', 'download-done', 'download-failed',
      'open-panel', 'find-open'
    ];
    if (!allowed.includes(channel)) return;
    ipcRenderer.on(channel, (_e, payload) => cb(payload));
  }
});
