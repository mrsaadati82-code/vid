'use strict';

const {
  app, BrowserWindow, BrowserView, session, ipcMain,
  dialog, shell, Menu, nativeTheme
} = require('electron');
const path = require('path');
const fs = require('fs');

const Store = require('./store');
const Notes = require('./notes');
const GitHub = require('./github');
const { attachContextMenu, popupFromPreload } = require('./context-menu');
const { PERSIAN_CSS, PERSIAN_JS } = require('./persian');
const { resolveFileName } = require('./download-utils');
const { buildStealthScript } = require('./stealth');
const { zipToMarkdown, folderToMarkdown, filesToMarkdown } = require('./zip-to-md');

// ─── بهینه‌سازی اپل سیلیکون ───
app.commandLine.appendSwitch('enable-features', 'Metal,CanvasOopRasterization');
app.commandLine.appendSwitch('disable-renderer-backgrounding');

const ARENA_HOME = 'https://arena.ai/';
/**
 * 🔴 User-Agent باید با نسخه‌ی *واقعی* Chromium داخل Electron بخواند.
 *
 * گوگل «Couldn't sign you in — This browser may not be secure» را وقتی
 * می‌دهد که ردپای مرورگر تعبیه‌شده ببیند. یکی از سیگنال‌ها ناهماهنگی
 * بین نسخه‌ی اعلام‌شده در UA و ویژگی‌های واقعی موتور است.
 *
 * process.versions.chrome نسخه‌ی دقیق را می‌دهد، پس همان را اعلام
 * می‌کنیم و رشته‌ی Electron را حذف می‌کنیم.
 */
const CHROMIUM_VERSION = process.versions.chrome || '130.0.0.0';
const CHROME_UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 ' +
  `(KHTML, like Gecko) Chrome/${CHROMIUM_VERSION} Safari/537.36`;

/** ارتفاع نوار بالا (پروفایل + تب) */
const CHROME_HEIGHT = 96;

let win = null;
let store = null;
let notes = null;
let gh = null;

const tabs = new Map();
let nextTabId = 1;
let activeTabId = null;

/** وقتی پنل باز است BrowserView کنار می‌رود تا پنل دیده شود. */
let panelOpen = false;

// ═══════════════════════════════════════════════════════
//  پوشه‌ی دانلود
// ═══════════════════════════════════════════════════════

function downloadDir() {
  const dir = path.join(app.getPath('downloads'), 'Arena Plus');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function uniquePath(dir, name) {
  let p = path.join(dir, name);
  if (!fs.existsSync(p)) return p;
  const ext = path.extname(name);
  const base = path.basename(name, ext);
  let i = 1;
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`);
  return p;
}

// ═══════════════════════════════════════════════════════
//  دامنه‌های داخلی
// ═══════════════════════════════════════════════════════

/**
 * جریان لاگین Arena از چند دامنه عبور می‌کند (Clerk + Google).
 * اگر هرکدام را به مرورگر بیرونی بفرستیم، لاگین نیمه‌کاره می‌ماند.
 * پس فهرست را سخاوتمندانه نگه می‌داریم.
 */
const INTERNAL_HOSTS = [
  'arena.ai', 'lmarena.ai',
  'google.com', 'googleapis.com', 'gstatic.com', 'googleusercontent.com',
  'youtube.com', 'ggpht.com', 'recaptcha.net',
  'clerk.com', 'clerk.dev', 'clerk.accounts.dev', 'clerk.services',
  'cloudflare.com', 'cloudflareinsights.com', 'hcaptcha.com',
  'vercel.live', 'vercel.com', 'huggingface.co', 'hf.space',
  'posthog.com', 'datadoghq.com', 'pusher.com',
  'r2.cloudflarestorage.com', 'jsdelivr.net', 'trigger.dev'
];

function isInternal(u) {
  try {
    const url = new URL(u);
    if (['about:', 'data:', 'blob:'].includes(url.protocol)) return true;
    if (!['http:', 'https:'].includes(url.protocol)) return true;
    const h = url.hostname.toLowerCase();
    return INTERNAL_HOSTS.some(d => h === d || h.endsWith('.' + d));
  } catch { return false; }
}

// ═══════════════════════════════════════════════════════
//  session هر پروفایل
// ═══════════════════════════════════════════════════════

const preparedSessions = new Set();

function sessionFor(profileId) {
  const ses = session.fromPartition(`persist:profile_${profileId}`);
  if (preparedSessions.has(profileId)) return ses;
  preparedSessions.add(profileId);

  ses.setUserAgent(CHROME_UA);

  /**
   * 🔴 چرا نسخه‌ی اندروید کار کرد ولی دسکتاپ نه؟
   *
   * در اندروید فقط UA را تمیز می‌کردیم و کافی بود، چون WebView
   * اندروید هدرهای Client Hints نمی‌فرستد.
   *
   * اما Chromium دسکتاپ این هدرها را می‌فرستد:
   *     Sec-CH-UA: "Chromium";v="130", "Electron";v="33", ...
   *                                     ^^^^^^^^^^
   * گوگل دقیقاً همین را می‌خواند. UA جعلی بی‌فایده است وقتی
   * Electron برند خودش را در Client Hints اعلام می‌کند.
   *
   * اینجا هدرها را بازنویسی می‌کنیم تا دقیقاً مثل Chrome واقعی باشند.
   */
  const major = CHROMIUM_VERSION.split('.')[0];
  const SEC_CH_UA =
    `"Chromium";v="${major}", "Google Chrome";v="${major}", ` +
    `"Not?A_Brand";v="99"`;

  ses.webRequest.onBeforeSendHeaders((details, cb) => {
    const h = { ...details.requestHeaders };
    // هر ردپای Electron را پاک کن
    for (const k of Object.keys(h)) {
      const lk = k.toLowerCase();
      if (lk === 'sec-ch-ua') h[k] = SEC_CH_UA;
      else if (lk === 'sec-ch-ua-mobile') h[k] = '?0';
      else if (lk === 'sec-ch-ua-platform') h[k] = '"macOS"';
      else if (lk === 'sec-ch-ua-full-version') h[k] = `"${CHROMIUM_VERSION}"`;
      else if (lk === 'sec-ch-ua-full-version-list') {
        h[k] = `"Chromium";v="${CHROMIUM_VERSION}", ` +
               `"Google Chrome";v="${CHROMIUM_VERSION}", ` +
               `"Not?A_Brand";v="99.0.0.0"`;
      } else if (lk === 'user-agent') h[k] = CHROME_UA;
    }
    // اگر اصلاً نبودند، اضافه کن
    if (!Object.keys(h).some(k => k.toLowerCase() === 'sec-ch-ua')) {
      h['sec-ch-ua'] = SEC_CH_UA;
      h['sec-ch-ua-mobile'] = '?0';
      h['sec-ch-ua-platform'] = '"macOS"';
    }
    cb({ requestHeaders: h });
  });

  /**
   * 🔴 درس گرفته‌شده: reCAPTCHA را redirect نکن!
   *
   * تلاش قبلی: gstatic.com/recaptcha/* → recaptcha.net/recaptcha/*
   * نتیجه: 403 و «MIME type text/html is not executable».
   *
   * چون recaptcha.net فقط /recaptcha/api.js را آینه می‌کند، نه
   * /recaptcha/releases/ را. آن مسیر روی آینه 404 است و یک صفحه‌ی
   * HTML خطا برمی‌گرداند که به‌جای اسکریپت اجرا نمی‌شود.
   *
   * پس هیچ redirect ای نمی‌زنیم. اگر gstatic مسدود باشد، تنها
   * راه‌حل واقعی VPN است — نه ترفند سمت اپ.
   */

  // فقط CSP سایت را کنار می‌گذاریم تا فونت جاسازی‌شده و منابع ما بلاک نشوند
  ses.webRequest.onHeadersReceived(
    { urls: ['https://arena.ai/*', 'https://*.arena.ai/*'] },
    (details, cb) => {
      const h = { ...details.responseHeaders };
      for (const k of Object.keys(h)) {
        const lk = k.toLowerCase();
        if (lk === 'content-security-policy' ||
            lk === 'content-security-policy-report-only') delete h[k];
      }
      cb({ responseHeaders: h });
    }
  );

  // دانلود مستقیم (ناوبری واقعی)
  ses.on('will-download', (_event, item) => {
    const name = resolveFileName(item.getFilename(), item.getMimeType(), item.getURL());
    const target = uniquePath(downloadDir(), name);
    item.setSavePath(target);

    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    send('download-started', { id, fileName: path.basename(target) });

    item.once('done', (_e, state) => {
      if (state === 'completed') {
        store.addDownload({
          fileName: path.basename(target),
          mimeType: item.getMimeType() || '',
          sourceUrl: item.getURL(),
          localPath: target,
          sizeBytes: item.getTotalBytes(),
          profileId
        });
        send('download-done', { id, fileName: path.basename(target), path: target });
      } else {
        send('download-failed', { id, reason: state });
      }
    });
  });

  return ses;
}

// ═══════════════════════════════════════════════════════
//  تب‌ها
// ═══════════════════════════════════════════════════════

function createTab(profileId, url = ARENA_HOME, title = '') {
  const id = nextTabId++;
  const ses = sessionFor(profileId);

  const view = new BrowserView({
    webPreferences: {
      session: ses,
      preload: path.join(__dirname, 'preload-web.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: true
    }
  });

  const wc = view.webContents;

  // منوی راست‌کلیک
  attachContextMenu(wc, {
    getWindow: () => win,
    openInNewTab: (u) => { const t = createTab(profileId, u); showTab(t.id); },
    saveImage: (u) => wc.downloadURL(u),
    insertToChat: (text) => injectText(wc, text)
  });

  wc.on('page-title-updated', (_e, t) => {
    const tab = tabs.get(id);
    if (tab) { tab.title = (t || '').slice(0, 40); pushTabs(); }
  });

  wc.on('did-navigate', (_e, u) => {
    const tab = tabs.get(id);
    if (tab) tab.url = u;
  });

  // 🔴 پاک‌سازی ردپای Electron — باید *قبل* از کد صفحه اجرا شود
  const STEALTH = buildStealthScript(CHROMIUM_VERSION);
  wc.on('did-start-loading', () => {
    wc.executeJavaScript(STEALTH, true).catch(() => {});
  });

  const apply = () => { applyPersian(wc); };
  wc.on('dom-ready', () => {
    wc.executeJavaScript(STEALTH, true).catch(() => {});
    apply();
  });
  wc.on('did-finish-load', apply);

  wc.on('did-fail-load', (_e, code, desc, u, isMain) => {
    if (isMain && code !== -3) send('load-error', { code, desc, url: u });
  });

  wc.setWindowOpenHandler(({ url: target, disposition }) => {
    if (disposition === 'background-tab' || disposition === 'foreground-tab') {
      const t = createTab(profileId, target);
      if (disposition === 'foreground-tab') showTab(t.id);
      pushTabs();
      return { action: 'deny' };
    }
    if (isInternal(target)) {
      openAuthPopup(target, ses);
      return { action: 'deny' };
    }
    shell.openExternal(target);
    return { action: 'deny' };
  });

  wc.on('will-navigate', (e, target) => {
    if (!isInternal(target)) { e.preventDefault(); shell.openExternal(target); }
  });

  const tab = { id, profileId, title: title || 'تب جدید', url, view };
  tabs.set(id, tab);
  wc.loadURL(url);
  return tab;
}

/** درج متن در کادر چت — با native setter تا React هم بفهمد. */
function injectText(wc, text) {
  const esc = JSON.stringify(text);
  return wc.executeJavaScript(`
    (function(){
      var el = document.querySelector('textarea') ||
               document.querySelector('[contenteditable="true"]');
      if (!el) return false;
      if (el.tagName === 'TEXTAREA') {
        var st = Object.getOwnPropertyDescriptor(
          window.HTMLTextAreaElement.prototype, 'value').set;
        st.call(el, ${esc});
        el.dispatchEvent(new Event('input', { bubbles: true }));
      } else {
        el.textContent = ${esc};
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
      el.focus();
      return true;
    })();`, true).catch(() => false);
}

/**
 * پنجره‌ی پاپ‌آپ برای OAuth — با **همان session** والد.
 * بدون این، کوکی‌های لاگین به تب اصلی منتقل نمی‌شوند.
 */
function openAuthPopup(url, ses) {
  const popup = new BrowserWindow({
    width: 520, height: 680,
    parent: win, show: false, autoHideMenuBar: true,
    title: 'ورود',
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#141218' : '#FFFFFF',
    webPreferences: {
      session: ses, contextIsolation: true, nodeIntegration: false
    }
  });

  attachContextMenu(popup.webContents, { getWindow: () => popup });

  // 🔴 حیاتی: صفحه‌ی لاگین گوگل باید هیچ ردپایی از Electron نبیند
  const STEALTH = buildStealthScript(CHROMIUM_VERSION);
  popup.webContents.on('did-start-loading', () => {
    popup.webContents.executeJavaScript(STEALTH, true).catch(() => {});
  });
  popup.webContents.on('dom-ready', () => {
    popup.webContents.executeJavaScript(STEALTH, true).catch(() => {});
  });

  popup.once('ready-to-show', () => popup.show());
  popup.loadURL(url);

  popup.webContents.setWindowOpenHandler(({ url: nested }) => {
    if (isInternal(nested)) openAuthPopup(nested, ses);
    else shell.openExternal(nested);
    return { action: 'deny' };
  });

  popup.webContents.on('did-navigate', (_e, u) => {
    try {
      if (new URL(u).hostname.endsWith('arena.ai')) {
        setTimeout(() => { if (!popup.isDestroyed()) popup.close(); }, 700);
      }
    } catch { /* ignore */ }
  });

  popup.on('closed', () => {
    const t = activeTabId && tabs.get(activeTabId);
    if (t && !t.view.webContents.isDestroyed()) t.view.webContents.reload();
  });

  return popup;
}

function applyPersian(wc) {
  const s = store.getSettings();
  wc.insertCSS(PERSIAN_CSS(s)).catch(() => {});
  wc.executeJavaScript(PERSIAN_JS(s), true).catch(() => {});
}

function showTab(id) {
  const tab = tabs.get(id);
  if (!tab || !win) return;
  if (activeTabId && tabs.has(activeTabId)) {
    win.removeBrowserView(tabs.get(activeTabId).view);
  }
  if (!panelOpen) win.addBrowserView(tab.view);
  activeTabId = id;
  store.setActiveProfile(tab.profileId);
  layoutActiveView();
  pushTabs();
}

function closeTab(id) {
  const tab = tabs.get(id);
  if (!tab) return;
  const same = [...tabs.values()].filter(t => t.profileId === tab.profileId);
  if (same.length <= 1) return;

  if (activeTabId === id && win) win.removeBrowserView(tab.view);
  tab.view.webContents.destroy();
  tabs.delete(id);

  if (activeTabId === id) {
    const next = [...tabs.values()].find(t => t.profileId === tab.profileId);
    if (next) showTab(next.id);
  }
  pushTabs();
}

function layoutActiveView() {
  if (!win || !activeTabId || panelOpen) return;
  const tab = tabs.get(activeTabId);
  if (!tab) return;
  const [w, h] = win.getContentSize();
  tab.view.setBounds({
    x: 0, y: CHROME_HEIGHT, width: w, height: Math.max(0, h - CHROME_HEIGHT)
  });
  tab.view.setAutoResize({ width: true, height: true });
}

function pushTabs() {
  const ap = store.getActiveProfile();
  send('tabs-changed', {
    tabs: [...tabs.values()].filter(t => t.profileId === ap)
      .map(t => ({ id: t.id, title: t.title, url: t.url })),
    activeTabId
  });
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function activeWc() {
  const t = activeTabId && tabs.get(activeTabId);
  return t ? t.view.webContents : null;
}

// ═══════════════════════════════════════════════════════
//  پنجره‌ی اصلی
// ═══════════════════════════════════════════════════════

function createWindow() {
  const b = store.getWindowBounds();

  win = new BrowserWindow({
    width: b.width, height: b.height, x: b.x, y: b.y,
    minWidth: 900, minHeight: 600,
    title: 'Arena Plus',
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#0F0E12' : '#FAFAFC',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    trafficLightPosition: { x: 14, y: 18 },
    webPreferences: {
      preload: path.join(__dirname, 'preload-ui.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  attachContextMenu(win.webContents, { getWindow: () => win });

  win.on('resize', layoutActiveView);
  win.on('enter-full-screen', layoutActiveView);
  win.on('leave-full-screen', layoutActiveView);
  win.on('close', () => store.setWindowBounds(win.getBounds()));

  win.on('closed', () => {
    tabs.forEach(t => { try { t.view.webContents.destroy(); } catch {} });
    tabs.clear();
    win = null;
  });

  win.webContents.once('did-finish-load', () => {
    const profiles = store.getProfiles();
    const active = store.getActiveProfile() || profiles[0].id;
    showTab(createTab(active).id);
    send('profiles-changed', { profiles, activeProfileId: active });
  });
}

/** تبدیل پروژه به Markdown و ذخیره در پوشه‌ی Arena Plus. */
function convertAndSave(fn, baseName) {
  const md = fn();
  const safe = String(baseName).replace(/[\\/:*?"<>|]/g, '_').slice(0, 60);
  const out = uniquePath(downloadDir(), `${safe}.md`);
  fs.writeFileSync(out, md, 'utf8');
  return {
    path: out, name: path.basename(out),
    sizeKB: Math.round(Buffer.byteLength(md, 'utf8') / 1024)
  };
}

// ═══════════════════════════════════════════════════════
//  IPC
// ═══════════════════════════════════════════════════════

function registerIpc() {
  // ─── پنل ───
  ipcMain.handle('panel:open', () => {
    if (panelOpen) return true;
    panelOpen = true;
    const t = activeTabId && tabs.get(activeTabId);
    if (t && win) win.removeBrowserView(t.view);
    return true;
  });

  ipcMain.handle('panel:close', () => {
    if (!panelOpen) return true;
    panelOpen = false;
    const t = activeTabId && tabs.get(activeTabId);
    if (t && win) { win.addBrowserView(t.view); layoutActiveView(); }
    return true;
  });

  // ─── پروفایل ───
  ipcMain.handle('profiles:list', () => ({
    profiles: store.getProfiles(), activeProfileId: store.getActiveProfile()
  }));

  ipcMain.handle('profiles:switch', (_e, id) => {
    const ex = [...tabs.values()].find(t => t.profileId === id);
    showTab(ex ? ex.id : createTab(id).id);
    return true;
  });

  ipcMain.handle('profiles:add', (_e, label) => {
    const p = store.addProfile(label);
    showTab(createTab(p.id).id);
    return store.getProfiles();
  });

  ipcMain.handle('profiles:rename', (_e, { id, label }) => {
    store.renameProfile(id, label); return store.getProfiles();
  });

  ipcMain.handle('profiles:delete', (_e, id) => {
    if (store.getProfiles().length <= 1) return { ok: false, reason: 'last' };
    [...tabs.values()].filter(t => t.profileId === id).forEach(t => {
      if (activeTabId === t.id && win) win.removeBrowserView(t.view);
      try { t.view.webContents.destroy(); } catch {}
      tabs.delete(t.id);
    });
    store.deleteProfile(id);
    const next = store.getProfiles()[0];
    const nt = [...tabs.values()].find(t => t.profileId === next.id) || createTab(next.id);
    showTab(nt.id);
    return { ok: true, profiles: store.getProfiles() };
  });

  ipcMain.handle('profiles:signout', async (_e, id) => {
    await sessionFor(id).clearStorageData({
      storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage']
    });
    [...tabs.values()].filter(t => t.profileId === id)
      .forEach(t => t.view.webContents.loadURL(ARENA_HOME));
    return true;
  });

  // ─── تب ───
  ipcMain.handle('tabs:list', () => {
    const ap = store.getActiveProfile();
    return {
      tabs: [...tabs.values()].filter(t => t.profileId === ap)
        .map(t => ({ id: t.id, title: t.title, url: t.url })),
      activeTabId
    };
  });
  ipcMain.handle('tabs:new',   () => { const t = createTab(store.getActiveProfile()); showTab(t.id); return t.id; });
  ipcMain.handle('tabs:show',  (_e, id) => { showTab(id); return true; });
  ipcMain.handle('tabs:close', (_e, id) => { closeTab(id); return true; });

  // ─── ناوبری ───
  ipcMain.handle('nav:home',    () => activeWc()?.loadURL(ARENA_HOME));
  ipcMain.handle('nav:reload',  () => activeWc()?.reload());
  ipcMain.handle('nav:back', () => {
    const w = activeWc(); if (!w) return;
    try {
      const nh = w.navigationHistory;
      if (nh && nh.canGoBack()) nh.goBack();
      else if (typeof w.canGoBack === 'function' && w.canGoBack()) w.goBack();
    } catch {}
  });
  ipcMain.handle('nav:forward', () => {
    const w = activeWc(); if (!w) return;
    try {
      const nh = w.navigationHistory;
      if (nh && nh.canGoForward()) nh.goForward();
      else if (typeof w.canGoForward === 'function' && w.canGoForward()) w.goForward();
    } catch {}
  });
  ipcMain.handle('nav:url',     () => activeWc()?.getURL() || '');
  ipcMain.handle('nav:open-external', (_e, u) => shell.openExternal(u));

  // ─── تنظیمات ───
  ipcMain.handle('settings:get', () => store.getSettings());
  ipcMain.handle('settings:set', (_e, patch) => {
    const s = store.setSettings(patch);
    tabs.forEach(t => applyPersian(t.view.webContents));
    return s;
  });

  // ─── دانلود ───
  ipcMain.handle('downloads:list',   () => store.listDownloads());
  ipcMain.handle('downloads:open',   (_e, p) => shell.openPath(p));
  ipcMain.handle('downloads:reveal', (_e, p) => shell.showItemInFolder(p));
  ipcMain.handle('downloads:folder', () => shell.openPath(downloadDir()));
  ipcMain.handle('downloads:remove', (_e, id) => { store.removeDownload(id); return store.listDownloads(); });
  ipcMain.handle('downloads:clear',  () => { store.clearDownloads(); return []; });

  // ─── آرشیو ───
  ipcMain.handle('archive:list',   (_e, q) => store.listConversations(q));
  ipcMain.handle('archive:get',    (_e, id) => store.getConversation(id));
  ipcMain.handle('archive:star',   (_e, { id, value }) => { store.starConversation(id, value); return true; });
  ipcMain.handle('archive:delete', (_e, ids) => { store.deleteConversations(ids); return true; });

  // ─── پرامپت ───
  ipcMain.handle('prompts:list',   () => store.listPrompts());
  ipcMain.handle('prompts:save',   (_e, p) => { store.savePrompt(p); return store.listPrompts(); });
  ipcMain.handle('prompts:delete', (_e, id) => { store.deletePrompt(id); return store.listPrompts(); });
  ipcMain.handle('prompts:inject', (_e, text) => {
    const wc = activeWc();
    return wc ? injectText(wc, text) : false;
  });

  // ─── مصرف ───
  ipcMain.handle('usage:stats', () => store.usageStats());

  // ─── لیدربورد ───
  ipcMain.handle('leaderboard:fetch', async (_e, { config, category }) => {
    const where = encodeURIComponent(`"category"='${category}'`);
    const url = 'https://datasets-server.huggingface.co/filter' +
      '?dataset=lmarena-ai%2Fleaderboard-dataset' +
      `&config=${config}&split=latest&where=${where}&limit=150`;
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    return (j.rows || []).map(r => r.row)
      .sort((a, b) => (a.rank || 1e9) - (b.rank || 1e9));
  });

  // ─── صادرات ───
  ipcMain.handle('export:pick-zip', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب فایل ZIP',
      filters: [{ name: 'ZIP', extensions: ['zip'] }],
      properties: ['openFile']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    return convertAndSave(() => zipToMarkdown(r.filePaths[0]),
      path.basename(r.filePaths[0], '.zip'));
  });

  ipcMain.handle('export:pick-folder', async () => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب پوشه', properties: ['openDirectory']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    return convertAndSave(() => folderToMarkdown(r.filePaths[0]),
      path.basename(r.filePaths[0]));
  });

  // ─── GitHub ───
  ipcMain.handle('gh:status', async () => {
    if (!gh.connected) return { connected: false };
    try {
      const u = await gh.me();
      return { connected: true, login: u.login, name: u.name, avatar: u.avatar_url };
    } catch (e) { return { connected: false, error: e.message }; }
  });

  ipcMain.handle('gh:connect', async (_e, token) => {
    gh.setToken(token);
    try {
      const u = await gh.me();
      store.setGithubToken(token);
      return { ok: true, login: u.login, name: u.name };
    } catch (e) {
      gh.setToken(store.getGithubToken());
      return { ok: false, error: e.message };
    }
  });

  ipcMain.handle('gh:disconnect', () => { gh.setToken(''); store.setGithubToken(''); return true; });
  ipcMain.handle('gh:rate',      () => gh.rateLimit());
  ipcMain.handle('gh:repos',     () => gh.repos());
  ipcMain.handle('gh:repo',      (_e, { owner, repo }) => gh.repo(owner, repo));
  ipcMain.handle('gh:branches',  (_e, { owner, repo }) => gh.branches(owner, repo));
  ipcMain.handle('gh:commits',   (_e, { owner, repo, branch }) => gh.commits(owner, repo, branch));
  ipcMain.handle('gh:tree',      (_e, { owner, repo, branch }) => gh.tree(owner, repo, branch));
  ipcMain.handle('gh:file',      (_e, { owner, repo, path: p, ref }) => gh.fileText(owner, repo, p, ref));
  ipcMain.handle('gh:create-repo', (_e, o) => gh.createRepo(o));
  ipcMain.handle('gh:delete-repo', (_e, { owner, repo }) => gh.deleteRepo(owner, repo));
  ipcMain.handle('gh:put-file',    (_e, a) => gh.putFile(a.owner, a.repo, a.path, a.content, a.message, a.branch));
  ipcMain.handle('gh:delete-file', (_e, a) => gh.deleteFile(a.owner, a.repo, a.path, a.message, a.branch));
  ipcMain.handle('gh:batch',       (_e, a) => gh.batchCommit(a.owner, a.repo, a.changes, a.message, a.branch));
  ipcMain.handle('gh:issues',      (_e, a) => gh.issues(a.owner, a.repo, a.state));
  ipcMain.handle('gh:create-issue', (_e, a) => gh.createIssue(a.owner, a.repo, a.title, a.body));

  ipcMain.handle('gh:gist', async (_e, { filename, content, description }) => {
    const g = await gh.createGist(filename, content, description, false);
    return { url: g.html_url };
  });

  ipcMain.handle('gh:upload-files', async (_e, { owner, repo, branch, destDir }) => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب فایل', properties: ['openFile', 'multiSelections']
    });
    if (r.canceled || !r.filePaths.length) return null;
    const changes = r.filePaths.map(fp => ({
      path: (destDir ? destDir.replace(/\/+$/, '') + '/' : '') + path.basename(fp),
      content: fs.readFileSync(fp, 'utf8')
    }));
    return gh.batchCommit(owner, repo, changes,
      `آپلود ${changes.length} فایل از Arena Plus`, branch);
  });

  ipcMain.handle('gh:upload-folder', async (_e, { owner, repo, branch }) => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب پوشه', properties: ['openDirectory']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    const base = r.filePaths[0];
    const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'out',
                          '.gradle', '.idea', '__pycache__', '.next']);
    const changes = [];
    (function walk(d) {
      for (const it of fs.readdirSync(d, { withFileTypes: true })) {
        if (SKIP.has(it.name) || it.name.startsWith('.DS')) continue;
        const full = path.join(d, it.name);
        if (it.isDirectory()) { walk(full); continue; }
        if (!it.isFile()) continue;
        if (fs.statSync(full).size > 900 * 1024) continue;
        let txt;
        try { txt = fs.readFileSync(full, 'utf8'); } catch { continue; }
        if (txt.includes('\u0000')) continue;
        changes.push({
          path: path.relative(base, full).split(path.sep).join('/'), content: txt
        });
      }
    })(base);
    if (!changes.length) throw new Error('فایل متنی‌ای پیدا نشد');
    return gh.batchCommit(owner, repo, changes,
      `آپلود ${path.basename(base)} از Arena Plus`, branch);
  });

  ipcMain.handle('gh:export-repo', async (_e, { owner, repo }) => {
    const t = await gh.tree(owner, repo);
    const files = [];
    let budget = 3.5 * 1024 * 1024;
    for (const it of t.items) {
      if (it.type !== 'blob') continue;
      if (it.size > 200 * 1024 || budget - it.size < 0) {
        files.push({ path: it.path, content: null, size: it.size });
        continue;
      }
      try {
        const txt = await gh.fileText(owner, repo, it.path, t.branch);
        files.push({ path: it.path, content: Buffer.from(txt, 'utf8'), size: it.size });
        budget -= it.size;
      } catch {
        files.push({ path: it.path, content: null, size: it.size });
      }
    }
    return convertAndSave(() => filesToMarkdown(files, `${owner}/${repo}`),
      `${owner}-${repo}`);
  });

  // ─── یادداشت ───
  ipcMain.handle('notes:list',     (_e, q) => notes.list(q || ''));
  ipcMain.handle('notes:get',      (_e, id) => notes.get(id));
  ipcMain.handle('notes:save',     (_e, n) => notes.save(n));
  ipcMain.handle('notes:delete',   (_e, id) => { notes.remove(id); return true; });
  ipcMain.handle('notes:pin',      (_e, id) => notes.togglePin(id));
  ipcMain.handle('notes:markdown', (_e, id) => notes.toMarkdown(id));

  ipcMain.handle('notes:add-image', async (_e, noteId) => {
    const r = await dialog.showOpenDialog(win, {
      title: 'انتخاب تصویر',
      filters: [{ name: 'تصویر', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }],
      properties: ['openFile']
    });
    if (r.canceled || !r.filePaths[0]) return null;
    return notes.addImage(noteId, r.filePaths[0]);
  });

  ipcMain.handle('notes:paste-image', (_e, { noteId, dataUrl }) =>
    notes.addImageFromDataUrl(noteId, dataUrl));
  ipcMain.handle('notes:remove-image', (_e, { noteId, imageId }) => {
    notes.removeImage(noteId, imageId); return true;
  });

  ipcMain.handle('notes:export-file', async (_e, id) => {
    const md = notes.toMarkdown(id);
    const n = notes.get(id);
    const r = await dialog.showSaveDialog(win, {
      title: 'ذخیره‌ی یادداشت',
      defaultPath: path.join(downloadDir(), `${(n.title || 'note').slice(0, 40)}.md`),
      filters: [{ name: 'Markdown', extensions: ['md'] }]
    });
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, md, 'utf8');
    return r.filePath;
  });

  /**
   * راه‌حل پشتیبان لاگین: مرورگر سیستم.
   *
   * اگر گوگل همچنان «This browser may not be secure» بدهد، کاربر در
   * Safari/Chrome واقعی لاگین می‌کند و ما کوکی‌های نشست را از آنجا
   * برنمی‌داریم (ممکن نیست) — بلکه به او می‌گوییم که پس از ورود،
   * صفحه را در اپ رفرش کند. چون Arena از Clerk استفاده می‌کند و
   * نشست روی دامنه ذخیره می‌شود، این روش برای بعضی کاربران کار
   * می‌کند. در غیر این صورت لاگین با ایمیل تنها راه است.
   */
  ipcMain.handle('auth:open-external', () => {
    shell.openExternal('https://arena.ai/');
    return true;
  });

  /**
   * 🔑 راه‌حل قطعی لاگین گوگل: انتقال کوکی از مرورگر سیستم.
   *
   * گوگل ورود از مرورگر تعبیه‌شده را می‌بندد و هر ترفندی را دیر یا
   * زود تشخیص می‌دهد. اما وقتی کاربر در Safari/Chrome واقعی لاگین
   * کرد، کوکی‌های نشست روی دامنه‌ی arena.ai ذخیره می‌شوند.
   *
   * این تابع آن کوکی‌ها را از کاربر می‌گیرد و در session پروفایل
   * تزریق می‌کند — نتیجه: بدون هیچ تعامل با گوگل، وارد شده‌ای.
   */
  ipcMain.handle('auth:import-cookies', async (_e, { profileId, cookieString }) => {
    if (!cookieString || !cookieString.trim()) {
      return { ok: false, error: 'رشته‌ی کوکی خالی است' };
    }
    const ses = sessionFor(profileId || store.getActiveProfile());
    const pairs = cookieString.split(';').map(x => x.trim()).filter(Boolean);
    let n = 0;
    const errors = [];

    for (const pair of pairs) {
      const i = pair.indexOf('=');
      if (i < 1) continue;
      const name = pair.slice(0, i).trim();
      const value = pair.slice(i + 1).trim();
      if (!name) continue;

      // کوکی‌های __Host- باید دقیقاً روی دامنه و بدون domain باشند
      const isHost = name.startsWith('__Host-');
      const base = {
        url: 'https://arena.ai/',
        name, value,
        path: '/',
        secure: true,
        httpOnly: false,
        expirationDate: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30
      };
      if (!isHost) base.domain = '.arena.ai';

      try {
        await ses.cookies.set(base);
        n++;
      } catch (err) {
        // تلاش دوم بدون domain
        try {
          const { domain, ...rest } = base;
          await ses.cookies.set(rest);
          n++;
        } catch (e2) {
          errors.push(`${name}: ${e2.message}`);
        }
      }
    }

    // تب‌های این پروفایل را تازه کن
    [...tabs.values()]
      .filter(t => t.profileId === (profileId || store.getActiveProfile()))
      .forEach(t => t.view.webContents.reload());

    return { ok: n > 0, count: n, errors: errors.slice(0, 3) };
  });

  /** فهرست کوکی‌های فعلی — برای بررسی وضعیت ورود. */
  ipcMain.handle('auth:check', async (_e, profileId) => {
    const ses = sessionFor(profileId || store.getActiveProfile());
    try {
      const cookies = await ses.cookies.get({ domain: 'arena.ai' });
      const sessionCookie = cookies.find(c =>
        /session|__session|clerk|auth|token/i.test(c.name));
      return {
        total: cookies.length,
        loggedIn: !!sessionCookie,
        names: cookies.map(c => c.name).slice(0, 12)
      };
    } catch (e) {
      return { total: 0, loggedIn: false, error: e.message };
    }
  });

  /** ورود با ایمیل — پنجره‌ی مستقیم Clerk بدون گوگل. */
  ipcMain.handle('auth:email-login', () => {
    const t = activeTabId && tabs.get(activeTabId);
    if (!t) return false;
    return t.view.webContents.executeJavaScript(`
      (function(){
        // دکمه‌ی ورود را پیدا و کلیک کن
        var btns = Array.from(document.querySelectorAll('button, a'));
        var login = btns.find(function(b){
          var t = (b.textContent || '').toLowerCase();
          return /sign in|log in|ورود/.test(t);
        });
        if (login) { login.click(); return true; }
        return false;
      })();
    `, true).catch(() => false);
  });

  // ─── تشخیص شبکه ───
  ipcMain.handle('diag:network', async () => {
    const targets = [
      ['arena.ai',           'https://arena.ai/'],
      ['گوگل',               'https://accounts.google.com/'],
      ['reCAPTCHA (gstatic)', 'https://www.gstatic.com/recaptcha/api.js'],
      ['Hugging Face',       'https://datasets-server.huggingface.co/valid'],
      ['GitHub API',         'https://api.github.com/']
    ];
    const out = [];
    await Promise.all(targets.map(async ([name, url]) => {
      const t0 = Date.now();
      try {
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), 9000);
        const r = await fetch(url, { signal: ctl.signal });
        clearTimeout(timer);
        out.push({ name, ok: r.status < 500, status: r.status, ms: Date.now() - t0 });
      } catch (e) {
        out.push({ name, ok: false, status: 0, ms: Date.now() - t0,
                   error: (e.message || '').slice(0, 50) });
      }
    }));
    return targets.map(([n]) => out.find(o => o.name === n));
  });

  // ─── مدیریت حافظه ───
  ipcMain.handle('storage:stats', () => store.storageStats());
  ipcMain.handle('storage:clear', (_e, w) => store.clearData(w));

  // ─── از صفحه‌ی وب ───
  ipcMain.on('web:conversation', (e, data) => {
    const tab = [...tabs.values()].find(t => t.view.webContents.id === e.sender.id);
    if (tab) store.saveConversation({ ...data, profileId: tab.profileId });
  });

  ipcMain.on('web:send', (e) => {
    const tab = [...tabs.values()].find(t => t.view.webContents.id === e.sender.id);
    if (tab) store.recordUsage(tab.profileId);
  });

  ipcMain.on('web:download-start', (_e, fileName) =>
    send('download-started', { id: 'js', fileName }));

  ipcMain.on('web:download-data', (e, { dataUrl, mime, fileName }) => {
    try {
      const m = /^data:([^;]*);base64,(.+)$/s.exec(dataUrl);
      if (!m) throw new Error('داده‌ی نامعتبر');
      const realMime = mime || m[1] || 'application/octet-stream';
      const buf = Buffer.from(m[2], 'base64');
      if (!buf.length) throw new Error('فایل خالی است');

      const target = uniquePath(downloadDir(), resolveFileName(fileName, realMime, ''));
      fs.writeFileSync(target, buf);

      const tab = [...tabs.values()].find(t => t.view.webContents.id === e.sender.id);
      store.addDownload({
        fileName: path.basename(target), mimeType: realMime,
        sourceUrl: 'blob', localPath: target, sizeBytes: buf.length,
        profileId: tab ? tab.profileId : store.getActiveProfile()
      });
      send('download-done', { id: 'js', fileName: path.basename(target), path: target });
    } catch (err) {
      send('download-failed', { id: 'js', reason: err.message });
    }
  });

  ipcMain.on('web:download-error', (_e, msg) =>
    send('download-failed', { id: 'js', reason: msg }));

  /** راست‌کلیک رهگیری‌شده از داخل صفحه (وقتی سایت preventDefault می‌کند). */
  ipcMain.on('web:context-menu', (e, data) => {
    console.log('[ArenaPlus] راست‌کلیک در', data.x, data.y,
                '| editable:', data.isEditable, '| link:', !!data.linkURL);
    const tab = [...tabs.values()].find(t => t.view.webContents.id === e.sender.id);
    const wc = e.sender;
    popupFromPreload(wc, data, {
      getWindow: () => win,
      openInNewTab: (u) => {
        const pid = tab ? tab.profileId : store.getActiveProfile();
        const t = createTab(pid, u); showTab(t.id);
      },
      saveImage: (u) => wc.downloadURL(u),
      insertToChat: (text) => injectText(wc, text)
    }, CHROME_HEIGHT);
  });
}

// ═══════════════════════════════════════════════════════
//  منو و شورت‌کات
// ═══════════════════════════════════════════════════════

function buildAppMenu() {
  const isMac = process.platform === 'darwin';

  /**
   * 🔴 نکته: roleهای استاندارد منو وقتی BrowserView فوکوس دارد به
   * webContents *پنجره* می‌روند، نه به view. پس ⌘Z و ⌘C در صفحه‌ی
   * Arena کار نمی‌کنند. به‌جای role مستقیم روی wc درست صدا می‌زنیم.
   */
  const focused = () => {
    const bw = BrowserWindow.getFocusedWindow();
    if (bw && bw !== win) return bw.webContents;      // پاپ‌آپ لاگین
    if (panelOpen && win) return win.webContents;     // پنل باز
    const t = activeTabId && tabs.get(activeTabId);
    if (t && !t.view.webContents.isDestroyed()) return t.view.webContents;
    return win ? win.webContents : null;
  };
  const edit = (fn) => () => { const wc = focused(); if (wc) wc[fn](); };

  /** ناوبری امن — Electron 32+ متدها را به navigationHistory برده. */
  const navGo = (dir) => {
    const wc = focused(); if (!wc) return;
    const nh = wc.navigationHistory;
    try {
      if (dir < 0) {
        if (nh && nh.canGoBack()) nh.goBack();
        else if (typeof wc.canGoBack === 'function' && wc.canGoBack()) wc.goBack();
      } else {
        if (nh && nh.canGoForward()) nh.goForward();
        else if (typeof wc.canGoForward === 'function' && wc.canGoForward()) wc.goForward();
      }
    } catch {}
  };
  const zoom = (d) => () => {
    const wc = focused(); if (!wc) return;
    wc.setZoomLevel(d === 0 ? 0 : wc.getZoomLevel() + d);
  };

  const template = [
    ...(isMac ? [{
      label: 'Arena Plus',
      submenu: [
        { role: 'about', label: 'درباره‌ی Arena Plus' },
        { type: 'separator' },
        { label: 'تنظیمات…', accelerator: 'Cmd+,', click: () => send('open-panel', 'settings') },
        { type: 'separator' },
        { role: 'hide', label: 'مخفی کردن' },
        { role: 'hideOthers', label: 'مخفی کردن بقیه' },
        { type: 'separator' },
        { role: 'quit', label: 'خروج' }
      ]
    }] : []),
    {
      label: 'فایل',
      submenu: [
        { label: 'تب جدید', accelerator: 'CmdOrCtrl+T',
          click: () => { const t = createTab(store.getActiveProfile()); showTab(t.id); } },
        { label: 'بستن تب', accelerator: 'CmdOrCtrl+W',
          click: () => activeTabId && closeTab(activeTabId) },
        { type: 'separator' },
        { label: 'اکانت بعدی', accelerator: 'CmdOrCtrl+Shift+A',
          click: () => {
            const ps = store.getProfiles();
            const i = ps.findIndex(p => p.id === store.getActiveProfile());
            const next = ps[(i + 1) % ps.length];
            const ex = [...tabs.values()].find(t => t.profileId === next.id);
            showTab(ex ? ex.id : createTab(next.id).id);
            send('profiles-changed', { profiles: ps, activeProfileId: next.id });
          } },
        ...(isMac ? [] : [{ type: 'separator' }, { role: 'quit', label: 'خروج' }])
      ]
    },
    {
      label: 'ویرایش',
      submenu: [
        { label: 'واگرد',  accelerator: 'CmdOrCtrl+Z',       click: edit('undo') },
        { label: 'ازنو',   accelerator: 'Shift+CmdOrCtrl+Z', click: edit('redo') },
        { type: 'separator' },
        { label: 'برش',     accelerator: 'CmdOrCtrl+X', click: edit('cut') },
        { label: 'کپی',     accelerator: 'CmdOrCtrl+C', click: edit('copy') },
        { label: 'چسباندن', accelerator: 'CmdOrCtrl+V', click: edit('paste') },
        { label: 'چسباندن بدون قالب', accelerator: 'Shift+CmdOrCtrl+V',
          click: edit('pasteAndMatchStyle') },
        { type: 'separator' },
        { label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A', click: edit('selectAll') }
      ]
    },
    {
      label: 'نمایش',
      submenu: [
        { label: 'بارگذاری مجدد', accelerator: 'CmdOrCtrl+R',
          click: () => { const w = focused(); if (w) w.reload(); } },
        { label: 'بارگذاری کامل', accelerator: 'Shift+CmdOrCtrl+R',
          click: () => { const w = focused(); if (w) w.reloadIgnoringCache(); } },
        { type: 'separator' },
        { label: 'عقب', accelerator: 'CmdOrCtrl+[', click: () => navGo(-1) },
        { label: 'جلو', accelerator: 'CmdOrCtrl+]', click: () => navGo(1) },
        { type: 'separator' },
        { label: 'بزرگ‌تر',       accelerator: 'CmdOrCtrl+Plus', click: zoom(0.5) },
        { label: 'کوچک‌تر',       accelerator: 'CmdOrCtrl+-',    click: zoom(-0.5) },
        { label: 'اندازه‌ی عادی', accelerator: 'CmdOrCtrl+0',    click: zoom(0) },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'تمام‌صفحه' },
        { label: 'ابزار توسعه‌دهنده', accelerator: isMac ? 'Alt+Cmd+I' : 'F12',
          click: () => { const w = focused(); if (w) w.toggleDevTools(); } }
      ]
    },
    {
      label: 'ابزار',
      submenu: [
        { label: 'یادداشت‌ها', accelerator: 'CmdOrCtrl+Shift+N', click: () => send('open-panel', 'notes') },
        { label: 'آرشیو',      accelerator: 'CmdOrCtrl+Shift+H', click: () => send('open-panel', 'archive') },
        { label: 'پرامپت‌ها',   accelerator: 'CmdOrCtrl+Shift+P', click: () => send('open-panel', 'prompts') },
        { label: 'دانلودها',   accelerator: 'CmdOrCtrl+Shift+J', click: () => send('open-panel', 'downloads') },
        { label: 'GitHub',     accelerator: 'CmdOrCtrl+Shift+G', click: () => send('open-panel', 'github') },
        { label: 'لیدربورد',   accelerator: 'CmdOrCtrl+Shift+L', click: () => send('open-panel', 'board') },
        { type: 'separator' },
        { label: 'صادرات پروژه', click: () => send('open-panel', 'export') },
        { label: 'تنظیمات',      click: () => send('open-panel', 'settings') }
      ]
    },
    {
      label: 'پنجره',
      submenu: [
        { role: 'minimize', label: 'کوچک کردن' },
        { role: 'zoom', label: 'بزرگ کردن' }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ═══════════════════════════════════════════════════════

app.whenReady().then(() => {
  store = new Store(app.getPath('userData'));
  notes = new Notes(app.getPath('userData'));
  gh = new GitHub(store.getGithubToken());

  registerIpc();
  buildAppMenu();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
