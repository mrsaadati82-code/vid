'use strict';

/**
 * پاک‌سازی ردپای Electron در سطح جاوااسکریپت.
 *
 * ═══ چرا لازم است؟ ═══
 * گوگل برای تشخیص «embedded browser» چند سیگنال را می‌خواند. جعل
 * User-Agent تنها بخشی از ماجراست:
 *
 *   navigator.userAgentData.brands  →  شامل "Electron" است
 *   navigator.webdriver             →  گاهی true
 *   window.process                  →  فقط در Electron وجود دارد
 *   navigator.plugins               →  در Electron خالی است
 *   navigator.languages             →  گاهی خالی
 *
 * این اسکریپت قبل از هر کد صفحه اجرا می‌شود و همه را اصلاح می‌کند.
 *
 * ⚠️ توجه: این کار خلاف سیاست گوگل است. برای اپ شخصی قابل قبول
 * است ولی برای اپ منتشرشده مسیر درست OAuth رسمی است.
 */

function buildStealthScript(chromiumVersion) {
  const major = String(chromiumVersion).split('.')[0];

  return `
(function () {
  if (window.__apStealth) return;
  window.__apStealth = true;

  const def = (obj, prop, value) => {
    try {
      Object.defineProperty(obj, prop, {
        get: () => value, configurable: true, enumerable: true
      });
    } catch (e) {}
  };

  // ── ۱) webdriver ──
  def(navigator, 'webdriver', undefined);

  // ── ۲) userAgentData — مهم‌ترین سیگنال ──
  try {
    const brands = [
      { brand: 'Chromium',      version: '${major}' },
      { brand: 'Google Chrome', version: '${major}' },
      { brand: 'Not?A_Brand',   version: '99' }
    ];
    const fullVersionList = [
      { brand: 'Chromium',      version: '${chromiumVersion}' },
      { brand: 'Google Chrome', version: '${chromiumVersion}' },
      { brand: 'Not?A_Brand',   version: '99.0.0.0' }
    ];
    const uad = {
      brands,
      mobile: false,
      platform: 'macOS',
      getHighEntropyValues: (hints) => Promise.resolve({
        architecture: 'arm',
        bitness: '64',
        brands,
        fullVersionList,
        mobile: false,
        model: '',
        platform: 'macOS',
        platformVersion: '15.0.0',
        uaFullVersion: '${chromiumVersion}',
        wow64: false
      }),
      toJSON: () => ({ brands, mobile: false, platform: 'macOS' })
    };
    def(navigator, 'userAgentData', uad);
  } catch (e) {}

  // ── ۳) حذف نشانه‌های Node/Electron ──
  try { delete window.process; } catch (e) {}
  try { delete window.require; } catch (e) {}
  try { delete window.module; } catch (e) {}
  try { delete window.global; } catch (e) {}
  try { delete window.Buffer; } catch (e) {}

  // ── ۴) plugins و mimeTypes — Chrome واقعی خالی نیست ──
  try {
    const pdf = {
      name: 'Chrome PDF Plugin',
      filename: 'internal-pdf-viewer',
      description: 'Portable Document Format'
    };
    const arr = [pdf, {
      name: 'Chrome PDF Viewer',
      filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai',
      description: ''
    }];
    arr.item = (i) => arr[i];
    arr.namedItem = (n) => arr.find(p => p.name === n);
    arr.refresh = () => {};
    def(navigator, 'plugins', arr);
  } catch (e) {}

  // ── ۵) زبان‌ها ──
  try {
    if (!navigator.languages || !navigator.languages.length) {
      def(navigator, 'languages', ['en-US', 'en']);
    }
  } catch (e) {}

  // ── ۶) permissions.query — Electron گاهی رفتار متفاوت دارد ──
  try {
    const orig = navigator.permissions && navigator.permissions.query;
    if (orig) {
      navigator.permissions.query = function (p) {
        if (p && p.name === 'notifications') {
          return Promise.resolve({ state: Notification.permission });
        }
        return orig.call(navigator.permissions, p);
      };
    }
  } catch (e) {}

  // ── ۷) chrome.runtime — در Chrome واقعی وجود دارد ──
  try {
    if (!window.chrome) window.chrome = {};
    if (!window.chrome.runtime) window.chrome.runtime = {};
    if (!window.chrome.app) {
      window.chrome.app = {
        isInstalled: false,
        InstallState: { DISABLED: 'disabled', INSTALLED: 'installed',
                        NOT_INSTALLED: 'not_installed' },
        RunningState: { CANNOT_RUN: 'cannot_run',
                        READY_TO_RUN: 'ready_to_run', RUNNING: 'running' }
      };
    }
    if (!window.chrome.csi) window.chrome.csi = () => ({});
    if (!window.chrome.loadTimes) window.chrome.loadTimes = () => ({});
  } catch (e) {}
})();
`;
}

module.exports = { buildStealthScript };
