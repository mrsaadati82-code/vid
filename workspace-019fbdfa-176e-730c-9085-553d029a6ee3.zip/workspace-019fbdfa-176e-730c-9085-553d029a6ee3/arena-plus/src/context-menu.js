'use strict';

const { Menu, MenuItem, clipboard, shell, BrowserWindow } = require('electron');

/**
 * 🔴 در Electron 32+ متدهای ناوبری به navigationHistory منتقل شده‌اند.
 * فراخوانی مستقیم canGoBack() ممکن است throw کند و چون کل buildMenu
 * داخل try/catch است، منو **بی‌صدا** نمایش داده نمی‌شود.
 * این توابع هر دو حالت را پوشش می‌دهند.
 */
const navCanBack = (wc) => {
  try {
    if (wc.navigationHistory && typeof wc.navigationHistory.canGoBack === 'function')
      return wc.navigationHistory.canGoBack();
    if (typeof wc.canGoBack === 'function') return wc.canGoBack();
  } catch {}
  return false;
};
const navCanFwd = (wc) => {
  try {
    if (wc.navigationHistory && typeof wc.navigationHistory.canGoForward === 'function')
      return wc.navigationHistory.canGoForward();
    if (typeof wc.canGoForward === 'function') return wc.canGoForward();
  } catch {}
  return false;
};
const navBack = (wc) => {
  try {
    if (wc.navigationHistory && typeof wc.navigationHistory.goBack === 'function')
      return wc.navigationHistory.goBack();
    if (typeof wc.goBack === 'function') return wc.goBack();
  } catch {}
};
const navFwd = (wc) => {
  try {
    if (wc.navigationHistory && typeof wc.navigationHistory.goForward === 'function')
      return wc.navigationHistory.goForward();
    if (typeof wc.goForward === 'function') return wc.goForward();
  } catch {}
};

/**
 * منوی راست‌کلیک وابسته به زمینه.
 *
 * BrowserView یک context نیتیو جداست — منوی مرورگر را خودکار نمی‌سازد.
 * باید روی رویداد `context-menu` بسازیمش.
 */

function buildMenu(wc, params, hooks = {}) {
  const menu = new Menu();
  const {
    isEditable, editFlags, selectionText, linkURL, srcURL,
    mediaType, misspelledWord, dictionarySuggestions
  } = params;

  const hasSelection = (selectionText || '').trim().length > 0;
  const add = (opts) => menu.append(new MenuItem(opts));
  const sep = () => menu.append(new MenuItem({ type: 'separator' }));

  // ── پیشنهاد املایی ──
  if (misspelledWord && (dictionarySuggestions || []).length) {
    dictionarySuggestions.slice(0, 4).forEach(w =>
      add({ label: w, click: () => wc.replaceMisspelling(w) }));
    sep();
  }

  // ── لینک ──
  if (linkURL) {
    add({
      label: 'باز کردن در تب جدید',
      click: () => hooks.openInNewTab && hooks.openInNewTab(linkURL)
    });
    add({
      label: 'باز کردن در مرورگر',
      click: () => shell.openExternal(linkURL)
    });
    add({
      label: 'کپی نشانی لینک',
      click: () => clipboard.writeText(linkURL)
    });
    sep();
  }

  // ── تصویر ──
  if (mediaType === 'image' && srcURL) {
    add({
      label: 'ذخیره‌ی تصویر',
      click: () => hooks.saveImage && hooks.saveImage(srcURL)
    });
    add({
      label: 'کپی تصویر',
      click: () => wc.copyImageAt(params.x, params.y)
    });
    add({
      label: 'کپی نشانی تصویر',
      click: () => clipboard.writeText(srcURL)
    });
    sep();
  }

  // ── ویرایش ──
  // 🔴 role روی BrowserView کار نمی‌کند (به webContents پنجره می‌رود).
  // مستقیم روی همین wc صدا می‌زنیم.
  if (isEditable) {
    add({ label: 'واگرد', accelerator: 'CmdOrCtrl+Z',
          enabled: editFlags.canUndo, click: () => wc.undo() });
    add({ label: 'ازنو', accelerator: 'Shift+CmdOrCtrl+Z',
          enabled: editFlags.canRedo, click: () => wc.redo() });
    sep();
    add({ label: 'برش', accelerator: 'CmdOrCtrl+X',
          enabled: editFlags.canCut, click: () => wc.cut() });
    add({ label: 'کپی', accelerator: 'CmdOrCtrl+C',
          enabled: editFlags.canCopy, click: () => wc.copy() });
    add({ label: 'چسباندن', accelerator: 'CmdOrCtrl+V',
          enabled: editFlags.canPaste, click: () => wc.paste() });
    add({ label: 'چسباندن بدون قالب', accelerator: 'Shift+CmdOrCtrl+V',
          enabled: editFlags.canPaste, click: () => wc.pasteAndMatchStyle() });
    sep();
    add({ label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A',
          click: () => wc.selectAll() });
  } else if (hasSelection) {
    add({ label: 'کپی', accelerator: 'CmdOrCtrl+C', click: () => wc.copy() });
    add({
      label: 'جست‌وجوی این متن در گوگل',
      click: () => shell.openExternal(
        'https://www.google.com/search?q=' + encodeURIComponent(selectionText))
    });
    add({
      label: 'درج در کادر چت',
      click: () => hooks.insertToChat && hooks.insertToChat(selectionText)
    });
    sep();
    add({ label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A',
          click: () => wc.selectAll() });
  }

  // ── ناوبری صفحه ──
  if (!isEditable && !linkURL && mediaType !== 'image') {
    if (menu.items.length) sep();
    add({
      label: 'عقب', accelerator: 'CmdOrCtrl+[',
      enabled: navCanBack(wc), click: () => navBack(wc)
    });
    add({
      label: 'جلو', accelerator: 'CmdOrCtrl+]',
      enabled: navCanFwd(wc), click: () => navFwd(wc)
    });
    add({
      label: 'بارگذاری مجدد', accelerator: 'CmdOrCtrl+R',
      click: () => wc.reload()
    });
    sep();
    add({ label: 'انتخاب همه', accelerator: 'CmdOrCtrl+A',
          click: () => wc.selectAll() });
    add({
      label: 'کپی نشانی صفحه',
      click: () => clipboard.writeText(wc.getURL())
    });
  }

  // ── همیشه ──
  sep();
  add({
    label: 'بازرسی عنصر',
    click: () => wc.inspectElement(params.x, params.y)
  });

  return menu;
}

/**
 * نصب منو روی یک webContents.
 *
 * 🔴 باگی که اینجا رفع شد:
 * قبلاً `menu.popup({ window: hooks.window })` صدا زده می‌شد، اما
 * hooks.window در زمان createTab هنوز null بود (پنجره‌ی اصلی بعداً
 * ساخته می‌شود). popup با window نامعتبر بی‌صدا شکست می‌خورد.
 *
 * حالا پنجره را در لحظه‌ی راست‌کلیک پیدا می‌کنیم.
 */
function attachContextMenu(wc, hooks = {}) {
  wc.on('context-menu', (_e, params) => {
    try {
      const menu = buildMenu(wc, params, hooks);
      if (!menu.items.length) return;
      const win =
        (typeof hooks.getWindow === 'function' && hooks.getWindow()) ||
        BrowserWindow.fromWebContents(wc) ||
        BrowserWindow.getFocusedWindow() ||
        BrowserWindow.getAllWindows()[0];
      if (win) menu.popup({ window: win, x: params.x, y: params.y });
      else menu.popup();
    } catch (e) {
      console.error('[ArenaPlus] منوی راست‌کلیک:', e.message, e.stack);
    }
  });
}

/**
 * ساخت منو از داده‌های ارسالی preload (وقتی صفحه preventDefault کرده).
 * @param offsetY فاصله‌ی BrowserView از بالای پنجره — مختصات popup
 *                نسبت به پنجره تفسیر می‌شود، نه نسبت به view.
 */
/** منوی اضطراری — اگر ساخت منوی کامل شکست خورد. */
function fallbackMenu(wc) {
  const m = new Menu();
  m.append(new MenuItem({ label: 'کپی', click: () => wc.copy() }));
  m.append(new MenuItem({ label: 'چسباندن', click: () => wc.paste() }));
  m.append(new MenuItem({ label: 'انتخاب همه', click: () => wc.selectAll() }));
  m.append(new MenuItem({ type: 'separator' }));
  m.append(new MenuItem({ label: 'بارگذاری مجدد', click: () => wc.reload() }));
  return m;
}

function popupFromPreload(wc, data, hooks = {}, offsetY = 0) {
  const params = {
    x: data.x, y: data.y,
    linkURL: data.linkURL || '',
    srcURL: data.srcURL || '',
    mediaType: data.isImage ? 'image' : 'none',
    isEditable: !!data.isEditable,
    selectionText: data.selectionText || '',
    misspelledWord: '',
    dictionarySuggestions: [],
    editFlags: {
      canUndo: !!data.canUndo, canRedo: !!data.canRedo,
      canCut: !!data.canCut, canCopy: !!data.canCopy,
      canPaste: !!data.canPaste
    }
  };

  let menu;
  try {
    menu = buildMenu(wc, params, hooks);
    if (!menu.items.length) menu = fallbackMenu(wc);
  } catch (e) {
    console.error('[ArenaPlus] ساخت منو شکست خورد:', e.message);
    menu = fallbackMenu(wc);
  }

  const win =
    (typeof hooks.getWindow === 'function' && hooks.getWindow()) ||
    BrowserWindow.fromWebContents(wc) ||
    BrowserWindow.getFocusedWindow();

  try {
    if (win) {
      // 🔴 مختصات popup نسبت به *پنجره* است، ولی data.x/y نسبت به
      // BrowserView. پس offsetY (ارتفاع نوار بالا) اضافه می‌شود.
      menu.popup({ window: win, x: data.x, y: data.y + offsetY });
    } else {
      menu.popup();
    }
  } catch (e) {
    console.error('[ArenaPlus] popup شکست خورد:', e.message);
    try { menu.popup(); } catch {}
  }
}

module.exports = { attachContextMenu, buildMenu, popupFromPreload };
