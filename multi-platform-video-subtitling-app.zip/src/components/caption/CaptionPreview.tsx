"use client";

import { useMemo, type CSSProperties, type ReactNode } from "react";
import { hexToRgba } from "@/lib/color";
import type { CaptionStyleConfig, WordTiming } from "@/lib/types";

const ANIMATION_CLASS: Record<string, string> = {
  fade: "animate-caption-fade",
  pop: "animate-caption-pop",
  bounce: "animate-caption-bounce",
  "slide-up": "animate-caption-slide-up",
};

interface CaptionPreviewProps {
  config: CaptionStyleConfig;
  text: string;
  words?: WordTiming[] | null;
  scale?: number;
  currentTime?: number;
  segmentStart?: number;
  segmentEnd?: number;
  animateKey?: string | number;
  className?: string;
}

function chunk<T>(arr: T[], size: number): T[][] {
  if (size <= 0) return [arr];
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

export default function CaptionPreview({
  config,
  text,
  words,
  scale = 0.32,
  currentTime,
  segmentStart = 0,
  segmentEnd = 1,
  animateKey,
  className = "",
}: CaptionPreviewProps) {
  const rawWords = useMemo(() => text.trim().split(/\s+/).filter(Boolean), [text]);

  const positionClass =
    config.position === "top" ? "items-start pt-[6%]" : config.position === "middle" ? "items-center" : "items-end pb-[8%]";

  const containerStyle: CSSProperties = {
    fontFamily: `${config.fontFamily}, Tahoma, sans-serif`,
    fontWeight: config.fontWeight,
    fontSize: `${config.fontSize * scale}px`,
    letterSpacing: `${config.letterSpacing * scale}px`,
    color: config.textColor,
    textTransform: config.uppercase ? "uppercase" : "none",
    WebkitTextStroke: config.stroke ? `${config.strokeWidth * scale}px ${config.strokeColor}` : undefined,
    textShadow: config.shadow ? "0 4px 18px rgba(0,0,0,0.55)" : undefined,
    backgroundColor:
      config.backgroundOpacity > 0 ? hexToRgba(config.backgroundColor, config.backgroundOpacity) : "transparent",
    borderRadius: `${config.borderRadius * scale}px`,
    padding: `${config.paddingY * scale}px ${config.paddingX * scale}px`,
    lineHeight: 1.35,
    maxWidth: "92%",
    textAlign: "center",
    whiteSpace: "pre-line",
  };

  let content: ReactNode = null;

  if (config.animation === "karaoke") {
    const duration = Math.max(segmentEnd - segmentStart, 0.01);
    const lines = chunk(rawWords, Math.max(config.wordsPerLine, 1));
    let globalIndex = 0;
    content = lines.map((line, li) => (
      <div key={li}>
        {line.map((word) => {
          const idx = globalIndex++;
          let active = false;
          if (words && words[idx]) {
            active = (currentTime ?? -1) >= words[idx].start && (currentTime ?? -1) < words[idx].end;
          } else {
            const wordStart = segmentStart + (idx / rawWords.length) * duration;
            const wordEnd = segmentStart + ((idx + 1) / rawWords.length) * duration;
            active = (currentTime ?? -1) >= wordStart && (currentTime ?? -1) < wordEnd;
          }
          return (
            <span key={idx} style={{ color: active ? config.highlightColor : config.textColor, transition: "color .08s" }}>
              {word}{" "}
            </span>
          );
        })}
      </div>
    ));
  } else if (config.animation === "typewriter") {
    const duration = Math.max(segmentEnd - segmentStart, 0.01);
    const progress = Math.min(Math.max(((currentTime ?? segmentEnd) - segmentStart) / duration, 0), 1);
    const revealed = text.slice(0, Math.ceil(text.length * progress));
    content = (
      <span>
        {revealed}
        <span className="opacity-60">▍</span>
      </span>
    );
  } else {
    const lines = chunk(rawWords, Math.max(config.wordsPerLine, 1));
    content = lines.map((line, li) => <div key={li}>{line.join(" ")}</div>);
  }

  const animationClass = config.animation !== "karaoke" && config.animation !== "typewriter" ? ANIMATION_CLASS[config.animation] ?? "" : "";

  return (
    <div className={`pointer-events-none absolute inset-0 flex justify-center ${positionClass} ${className}`}>
      <div key={animateKey} style={containerStyle} className={animationClass}>
        {content}
      </div>
    </div>
  );
}
