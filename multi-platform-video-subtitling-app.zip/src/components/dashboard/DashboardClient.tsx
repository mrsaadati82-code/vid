"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Captions,
  Clapperboard,
  Clock,
  FilePlus2,
  Film,
  Loader2,
  Plus,
  Trash2,
  UploadCloud,
  X,
} from "lucide-react";
import type { AspectRatio, ProjectListItem } from "@/lib/types";

const ASPECTS: { value: AspectRatio; label: string }[] = [
  { value: "9:16", label: "عمودی ۹:۱۶ (ریلز/استوری)" },
  { value: "16:9", label: "افقی ۱۶:۹ (یوتیوب)" },
  { value: "1:1", label: "مربع ۱:۱ (پست)" },
  { value: "4:5", label: "عمودی ۴:۵ (پست اینستاگرام)" },
];

function statusLabel(status: string) {
  if (status === "ready") return { text: "آماده", cls: "bg-emerald-500/15 text-emerald-300" };
  if (status === "processing") return { text: "در حال پردازش", cls: "bg-amber-500/15 text-amber-300" };
  return { text: "پیش‌نویس", cls: "bg-slate-500/15 text-slate-300" };
}

function formatRelative(dateIso: string) {
  const date = new Date(dateIso);
  const diffMs = Date.now() - date.getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return "همین الان";
  if (minutes < 60) return `${minutes} دقیقه پیش`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} ساعت پیش`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} روز پیش`;
  return date.toLocaleDateString("fa-IR");
}

export default function DashboardClient({ initialProjects }: { initialProjects: ProjectListItem[] }) {
  const router = useRouter();
  const [projects, setProjects] = useState(initialProjects);
  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState("");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("9:16");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sorted = useMemo(
    () => [...projects].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()),
    [projects]
  );

  function resetModal() {
    setShowModal(false);
    setTitle("");
    setFile(null);
    setProgress(0);
    setError(null);
    setAspectRatio("9:16");
  }

  async function readVideoMeta(videoFile: File) {
    return new Promise<{ duration: number }>((resolve) => {
      const url = URL.createObjectURL(videoFile);
      const video = document.createElement("video");
      video.preload = "metadata";
      video.onloadedmetadata = () => {
        resolve({ duration: video.duration || 0 });
        URL.revokeObjectURL(url);
      };
      video.onerror = () => resolve({ duration: 0 });
      video.src = url;
    });
  }

  async function handleCreate() {
    setError(null);
    setUploading(true);
    try {
      let videoUrl: string | null = null;
      let videoName: string | null = null;
      let durationSeconds = 0;

      if (file) {
        const meta = await readVideoMeta(file);
        durationSeconds = meta.duration;

        const uploaded = await uploadWithProgress(file, setProgress);
        videoUrl = uploaded.url;
        videoName = uploaded.name;
      }

      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title || (file ? file.name.replace(/\.[^/.]+$/, "") : "پروژه بدون عنوان"),
          videoUrl,
          videoName,
          durationSeconds,
          aspectRatio,
        }),
      });
      if (!res.ok) throw new Error("خطا در ساخت پروژه");
      const data = await res.json();
      router.push(`/editor/${data.project.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای ناشناخته رخ داد.");
      setUploading(false);
    }
  }

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await fetch(`/api/projects/${id}`, { method: "DELETE" });
      setProjects((prev) => prev.filter((p) => p.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-white/5 bg-[#08090f]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400">
              <Captions className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-extrabold">زیرنویس‌ساز</span>
          </Link>
          <Link href="/templates" className="text-sm text-slate-300 hover:text-white">
            گالری قالب‌ها
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-10">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold md:text-3xl">پروژه‌های من</h1>
            <p className="mt-1 text-sm text-slate-400">مدیریت و ادامه‌ی ساخت زیرنویس ویدیوهایت</p>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2.5 text-sm font-bold text-slate-950 shadow-lg shadow-violet-500/25 transition hover:opacity-90"
          >
            <Plus className="h-4 w-4" />
            پروژه جدید
          </button>
        </div>

        {sorted.length === 0 ? (
          <div className="mt-16 flex flex-col items-center justify-center rounded-3xl border border-dashed border-white/10 bg-white/[0.02] py-24 text-center">
            <Film className="h-12 w-12 text-slate-600" />
            <p className="mt-4 text-lg font-bold text-slate-200">هنوز پروژه‌ای نساختی</p>
            <p className="mt-1 text-sm text-slate-500">اولین ویدیوی خودت رو آپلود کن و بذار زیرنویس‌ساز کارشو انجام بده</p>
            <button
              onClick={() => setShowModal(true)}
              className="mt-6 flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-6 py-3 text-sm font-bold text-slate-950"
            >
              <FilePlus2 className="h-4 w-4" />
              ساخت اولین پروژه
            </button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {sorted.map((project) => {
              const status = statusLabel(project.status);
              return (
                <div
                  key={project.id}
                  className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] transition hover:border-violet-400/40"
                >
                  <Link href={`/editor/${project.id}`} className="block">
                    <div className="relative flex aspect-[9/12] items-center justify-center overflow-hidden bg-gradient-to-br from-[#191b2c] to-[#0d0e18]">
                      {project.videoUrl ? (
                        <video src={project.videoUrl} className="h-full w-full object-cover opacity-70" muted />
                      ) : (
                        <Clapperboard className="h-10 w-10 text-slate-600" />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                      <span className={`absolute right-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-bold ${status.cls}`}>
                        {status.text}
                      </span>
                      <span className="absolute bottom-3 left-3 flex items-center gap-1 rounded-full bg-black/50 px-2 py-1 text-[11px] text-slate-200">
                        <Captions className="h-3 w-3" />
                        {project.captionsCount} بخش
                      </span>
                    </div>
                  </Link>
                  <div className="p-4">
                    <p className="truncate font-bold text-slate-100">{project.title}</p>
                    <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {formatRelative(project.updatedAt)}
                      </span>
                      <span>{project.aspectRatio}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDelete(project.id)}
                    disabled={deletingId === project.id}
                    className="absolute left-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-black/50 text-slate-300 opacity-0 transition hover:bg-red-500/80 hover:text-white group-hover:opacity-100"
                    title="حذف پروژه"
                  >
                    {deletingId === project.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Trash2 className="h-4 w-4" />
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-white/10 bg-[#12131f] p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold">پروژه جدید</h2>
              <button onClick={resetModal} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-5 space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-bold text-slate-400">عنوان پروژه</label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثلا: معرفی محصول جدید"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm outline-none focus:border-violet-400"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-bold text-slate-400">قاب ویدیو</label>
                <div className="grid grid-cols-2 gap-2">
                  {ASPECTS.map((a) => (
                    <button
                      key={a.value}
                      onClick={() => setAspectRatio(a.value)}
                      className={`rounded-xl border px-3 py-2 text-xs font-bold transition ${
                        aspectRatio === a.value
                          ? "border-violet-400 bg-violet-500/10 text-violet-200"
                          : "border-white/10 bg-white/5 text-slate-400 hover:border-white/20"
                      }`}
                    >
                      {a.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-bold text-slate-400">فایل ویدیو / صوت (اختیاری)</label>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.02] px-4 py-8 text-sm text-slate-400 transition hover:border-violet-400/50"
                >
                  <UploadCloud className="h-6 w-6" />
                  {file ? file.name : "برای انتخاب فایل کلیک کن"}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/*,audio/*"
                  className="hidden"
                  onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                />
                <p className="mt-1 text-[11px] text-slate-500">
                  می‌توانید بعداً هم از داخل ادیتور ویدیو آپلود کنید. حداکثر حجم ۳۰۰ مگابایت.
                </p>
              </div>

              {uploading && (
                <div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="mt-1 text-xs text-slate-500">در حال آپلود... {progress}%</p>
                </div>
              )}

              {error && <p className="text-sm text-red-400">{error}</p>}
            </div>

            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={handleCreate}
                disabled={uploading}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-3 text-sm font-bold text-slate-950 disabled:opacity-60"
              >
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                {uploading ? "در حال ساخت..." : "ساخت پروژه و ورود به ادیتور"}
              </button>
              <button
                onClick={resetModal}
                disabled={uploading}
                className="rounded-xl border border-white/10 px-4 py-3 text-sm text-slate-300 hover:bg-white/5"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function uploadWithProgress(file: File, onProgress: (percent: number) => void) {
  return new Promise<{ url: string; name: string }>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload");
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        onProgress(Math.round((event.loaded / event.total) * 100));
      }
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText));
        } catch {
          reject(new Error("پاسخ نامعتبر از سرور"));
        }
      } else {
        reject(new Error("آپلود فایل ناموفق بود"));
      }
    };
    xhr.onerror = () => reject(new Error("خطا در اتصال هنگام آپلود"));
    const formData = new FormData();
    formData.append("file", file);
    xhr.send(formData);
  });
}
