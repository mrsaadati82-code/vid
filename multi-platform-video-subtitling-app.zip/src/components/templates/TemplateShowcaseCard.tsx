"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Crown, Loader2, Play } from "lucide-react";
import CaptionPreview from "@/components/caption/CaptionPreview";
import type { TemplateRecord } from "@/lib/types";

const DEMO_TEXT = "این یک نمونه از قالب زیرنویس شماست";
const DEMO_DURATION = 3.2;

export default function TemplateShowcaseCard({ template }: { template: TemplateRecord }) {
  const [time, setTime] = useState(0);
  const [creating, setCreating] = useState(false);
  const rafRef = useRef<number | undefined>(undefined);
  const startRef = useRef<number | undefined>(undefined);
  const router = useRouter();

  useEffect(() => {
    function tick(ts: number) {
      if (startRef.current === undefined) startRef.current = ts;
      const elapsed = ((ts - startRef.current) / 1000) % DEMO_DURATION;
      setTime(elapsed);
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  async function useTemplate() {
    setCreating(true);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: `پروژه با قالب ${template.name}`, templateId: template.id }),
      });
      const data = await res.json();
      router.push(`/editor/${data.project.id}`);
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] transition hover:border-violet-400/40">
      <div className="relative flex aspect-[9/14] items-center justify-center overflow-hidden bg-gradient-to-br from-[#181a2b] to-[#0c0d15]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(124,92,255,0.16),transparent_60%)]" />
        <CaptionPreview
          config={template.config}
          text={DEMO_TEXT}
          scale={0.34}
          currentTime={time}
          segmentStart={0}
          segmentEnd={DEMO_DURATION}
          animateKey={Math.floor(time / DEMO_DURATION)}
        />
        {template.isPro && (
          <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-amber-400/90 px-2 py-1 text-[10px] font-extrabold text-black">
            <Crown className="h-3 w-3" /> ویژه
          </span>
        )}
        <button
          onClick={useTemplate}
          disabled={creating}
          className="absolute inset-x-3 bottom-3 flex items-center justify-center gap-2 rounded-xl bg-white/10 py-2 text-xs font-bold text-white opacity-0 backdrop-blur-md transition group-hover:opacity-100"
        >
          {creating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
          استفاده از این قالب
        </button>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate font-bold text-slate-100">{template.name}</p>
          <span className="shrink-0 rounded-full bg-white/5 px-2 py-0.5 text-[10px] text-slate-400">{template.category}</span>
        </div>
        <p className="mt-1.5 line-clamp-2 text-xs leading-5 text-slate-500">{template.description}</p>
      </div>
    </div>
  );
}
