"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowRight, Captions, Check, Loader2 } from "lucide-react";
import ExportMenu from "@/components/editor/ExportMenu";
import type { AspectRatio, ProjectStatus } from "@/lib/types";

const ASPECTS: AspectRatio[] = ["9:16", "16:9", "1:1", "4:5"];

interface TopBarProps {
  title: string;
  status: ProjectStatus;
  aspectRatio: AspectRatio;
  saving: boolean;
  onTitleChange: (title: string) => void;
  onAspectChange: (aspect: AspectRatio) => void;
  onExport: (kind: "srt" | "vtt" | "txt" | "json") => void;
}

export default function TopBar({ title, status, aspectRatio, saving, onTitleChange, onAspectChange, onExport }: TopBarProps) {
  const [localTitle, setLocalTitle] = useState(title);

  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-white/5 bg-[#0b0c16] px-4">
      <div className="flex min-w-0 items-center gap-3">
        <Link href="/dashboard" className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/5 text-slate-300 hover:bg-white/10">
          <ArrowRight className="h-4 w-4 rotate-180" />
        </Link>
        <div className="hidden h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 sm:grid">
          <Captions className="h-5 w-5 text-white" />
        </div>
        <input
          value={localTitle}
          onChange={(e) => setLocalTitle(e.target.value)}
          onBlur={() => onTitleChange(localTitle)}
          className="w-40 truncate rounded-lg bg-transparent px-2 py-1.5 text-sm font-extrabold text-slate-100 outline-none hover:bg-white/5 focus:bg-white/5 sm:w-64"
        />
        <span className="hidden items-center gap-1 text-[11px] text-slate-500 sm:flex">
          {saving ? (
            <>
              <Loader2 className="h-3 w-3 animate-spin" /> در حال ذخیره...
            </>
          ) : (
            <>
              <Check className="h-3 w-3 text-emerald-400" /> ذخیره شد
            </>
          )}
        </span>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden items-center gap-1 rounded-full border border-white/10 bg-white/5 p-1 md:flex">
          {ASPECTS.map((a) => (
            <button
              key={a}
              onClick={() => onAspectChange(a)}
              className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                aspectRatio === a ? "bg-violet-500 text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {a}
            </button>
          ))}
        </div>
        <span
          className={`rounded-full px-3 py-1.5 text-[11px] font-bold ${
            status === "ready"
              ? "bg-emerald-500/15 text-emerald-300"
              : status === "processing"
              ? "bg-amber-500/15 text-amber-300"
              : "bg-slate-500/15 text-slate-300"
          }`}
        >
          {status === "ready" ? "آماده" : status === "processing" ? "در حال پردازش" : "پیش‌نویس"}
        </span>
        <ExportMenu onExport={onExport} />
      </div>
    </header>
  );
}
