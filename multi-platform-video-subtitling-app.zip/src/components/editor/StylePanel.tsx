"use client";

import { useState, type ReactNode } from "react";
import { AlignCenter, AlignEndVertical, AlignStartVertical, Save } from "lucide-react";
import type { CaptionAnimation, CaptionPosition, CaptionStyleConfig } from "@/lib/types";

const FONTS = ["Vazirmatn", "Tahoma", "Arial", "Georgia", "Courier New"];
const ANIMATIONS: { value: CaptionAnimation; label: string }[] = [
  { value: "none", label: "بدون افکت" },
  { value: "fade", label: "محو شدن (Fade)" },
  { value: "pop", label: "ورود ضربه‌ای (Pop)" },
  { value: "karaoke", label: "کارائوکه کلمه‌به‌کلمه" },
  { value: "slide-up", label: "لغزش رو به بالا" },
  { value: "bounce", label: "پرشی (Bounce)" },
  { value: "typewriter", label: "تایپ‌رایتر" },
];
const POSITIONS: { value: CaptionPosition; label: string; icon: typeof AlignStartVertical }[] = [
  { value: "top", label: "بالا", icon: AlignStartVertical },
  { value: "middle", label: "وسط", icon: AlignCenter },
  { value: "bottom", label: "پایین", icon: AlignEndVertical },
];

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs font-bold text-slate-400">{label}</p>
      {children}
    </div>
  );
}

function ColorInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-2 py-1.5">
      <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-6 w-8 cursor-pointer rounded" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-transparent text-xs uppercase tabular-nums outline-none"
      />
    </div>
  );
}

interface StylePanelProps {
  config: CaptionStyleConfig;
  onChange: (patch: Partial<CaptionStyleConfig>) => void;
  onSaveAsTemplate: (name: string) => void;
}

export default function StylePanel({ config, onChange, onSaveAsTemplate }: StylePanelProps) {
  const [templateName, setTemplateName] = useState("");
  const [showSave, setShowSave] = useState(false);

  return (
    <div className="scrollbar-thin h-full space-y-5 overflow-y-auto p-4">
      <Row label="فونت">
        <select
          value={config.fontFamily}
          onChange={(e) => onChange({ fontFamily: e.target.value })}
          className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none"
        >
          {FONTS.map((f) => (
            <option key={f} value={f} className="bg-[#12131f]">
              {f}
            </option>
          ))}
        </select>
      </Row>

      <Row label={`اندازه فونت: ${config.fontSize}`}>
        <input
          type="range"
          min={16}
          max={90}
          value={config.fontSize}
          onChange={(e) => onChange({ fontSize: Number(e.target.value) })}
          style={{ ["--progress" as string]: `${((config.fontSize - 16) / (90 - 16)) * 100}%` }}
        />
      </Row>

      <Row label="ضخامت فونت">
        <select
          value={config.fontWeight}
          onChange={(e) => onChange({ fontWeight: Number(e.target.value) })}
          className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none"
        >
          {[400, 500, 600, 700, 800, 900].map((w) => (
            <option key={w} value={w} className="bg-[#12131f]">
              {w}
            </option>
          ))}
        </select>
      </Row>

      <div className="grid grid-cols-2 gap-3">
        <Row label="رنگ متن">
          <ColorInput value={config.textColor} onChange={(v) => onChange({ textColor: v })} />
        </Row>
        <Row label="رنگ هایلایت">
          <ColorInput value={config.highlightColor} onChange={(v) => onChange({ highlightColor: v })} />
        </Row>
      </div>

      <Row label="موقعیت زیرنویس">
        <div className="grid grid-cols-3 gap-2">
          {POSITIONS.map((p) => (
            <button
              key={p.value}
              onClick={() => onChange({ position: p.value })}
              className={`flex flex-col items-center gap-1 rounded-lg border py-2 text-[11px] font-bold transition ${
                config.position === p.value
                  ? "border-violet-400 bg-violet-500/10 text-violet-200"
                  : "border-white/10 bg-white/5 text-slate-400"
              }`}
            >
              <p.icon className="h-4 w-4" />
              {p.label}
            </button>
          ))}
        </div>
      </Row>

      <Row label="افکت انیمیشن">
        <select
          value={config.animation}
          onChange={(e) => onChange({ animation: e.target.value as CaptionAnimation })}
          className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none"
        >
          {ANIMATIONS.map((a) => (
            <option key={a.value} value={a.value} className="bg-[#12131f]">
              {a.label}
            </option>
          ))}
        </select>
      </Row>

      <Row label={`تعداد کلمه در هر خط: ${config.wordsPerLine}`}>
        <input
          type="range"
          min={1}
          max={8}
          value={config.wordsPerLine}
          onChange={(e) => onChange({ wordsPerLine: Number(e.target.value) })}
          style={{ ["--progress" as string]: `${((config.wordsPerLine - 1) / 7) * 100}%` }}
        />
      </Row>

      <div className="grid grid-cols-2 gap-3">
        <Row label="رنگ پس‌زمینه">
          <ColorInput value={config.backgroundColor} onChange={(v) => onChange({ backgroundColor: v })} />
        </Row>
        <Row label={`شفافیت پس‌زمینه: ${Math.round(config.backgroundOpacity * 100)}٪`}>
          <input
            type="range"
            min={0}
            max={100}
            value={config.backgroundOpacity * 100}
            onChange={(e) => onChange({ backgroundOpacity: Number(e.target.value) / 100 })}
            style={{ ["--progress" as string]: `${config.backgroundOpacity * 100}%` }}
          />
        </Row>
      </div>

      <Row label="خط دور متن (Stroke)">
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs text-slate-300">
            <input type="checkbox" checked={config.stroke} onChange={(e) => onChange({ stroke: e.target.checked })} />
            فعال
          </label>
          {config.stroke && (
            <>
              <ColorInput value={config.strokeColor} onChange={(v) => onChange({ strokeColor: v })} />
              <input
                type="range"
                min={1}
                max={12}
                value={config.strokeWidth}
                onChange={(e) => onChange({ strokeWidth: Number(e.target.value) })}
                className="w-20"
                style={{ ["--progress" as string]: `${(config.strokeWidth / 12) * 100}%` }}
              />
            </>
          )}
        </div>
      </Row>

      <div className="grid grid-cols-2 gap-3">
        <Row label={`فاصله حروف: ${config.letterSpacing}`}>
          <input
            type="range"
            min={-2}
            max={10}
            value={config.letterSpacing}
            onChange={(e) => onChange({ letterSpacing: Number(e.target.value) })}
            style={{ ["--progress" as string]: `${((config.letterSpacing + 2) / 12) * 100}%` }}
          />
        </Row>
        <Row label={`گردی گوشه‌ها: ${config.borderRadius}`}>
          <input
            type="range"
            min={0}
            max={40}
            value={config.borderRadius}
            onChange={(e) => onChange({ borderRadius: Number(e.target.value) })}
            style={{ ["--progress" as string]: `${(config.borderRadius / 40) * 100}%` }}
          />
        </Row>
      </div>

      <div className="flex items-center gap-4">
        <label className="flex items-center gap-2 text-xs text-slate-300">
          <input type="checkbox" checked={config.uppercase} onChange={(e) => onChange({ uppercase: e.target.checked })} />
          حروف بزرگ (انگلیسی)
        </label>
        <label className="flex items-center gap-2 text-xs text-slate-300">
          <input type="checkbox" checked={config.shadow} onChange={(e) => onChange({ shadow: e.target.checked })} />
          سایه متن
        </label>
      </div>

      <div className="border-t border-white/5 pt-4">
        {!showSave ? (
          <button
            onClick={() => setShowSave(true)}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 bg-white/5 py-2.5 text-sm font-bold text-slate-200 hover:bg-white/10"
          >
            <Save className="h-4 w-4" />
            ذخیره به‌عنوان قالب جدید
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <input
              autoFocus
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="نام قالب..."
              className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-violet-400"
            />
            <button
              onClick={() => {
                if (!templateName.trim()) return;
                onSaveAsTemplate(templateName.trim());
                setTemplateName("");
                setShowSave(false);
              }}
              className="rounded-lg bg-gradient-to-r from-violet-500 to-cyan-400 px-3 py-2 text-xs font-extrabold text-slate-950"
            >
              ذخیره
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
