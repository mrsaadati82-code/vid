"use client";

import { useState } from "react";
import { ChevronDown, Clapperboard, Download, FileJson, FileText, FileType } from "lucide-react";

interface ExportMenuProps {
  onExport: (kind: "srt" | "vtt" | "txt" | "json") => void;
}

export default function ExportMenu({ onExport }: ExportMenuProps) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-slate-200 hover:bg-white/10"
      >
        <Download className="h-4 w-4" />
        خروجی
        <ChevronDown className="h-3.5 w-3.5" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute left-0 z-50 mt-2 w-64 overflow-hidden rounded-xl border border-white/10 bg-[#14151f] shadow-2xl">
            <button
              onClick={() => {
                onExport("srt");
                setOpen(false);
              }}
              className="flex w-full items-center gap-3 px-4 py-3 text-sm text-slate-200 hover:bg-white/5"
            >
              <FileType className="h-4 w-4 text-cyan-300" />
              دانلود زیرنویس SRT
            </button>
            <button
              onClick={() => {
                onExport("vtt");
                setOpen(false);
              }}
              className="flex w-full items-center gap-3 px-4 py-3 text-sm text-slate-200 hover:bg-white/5"
            >
              <FileType className="h-4 w-4 text-cyan-300" />
              دانلود زیرنویس VTT
            </button>
            <button
              onClick={() => {
                onExport("txt");
                setOpen(false);
              }}
              className="flex w-full items-center gap-3 px-4 py-3 text-sm text-slate-200 hover:bg-white/5"
            >
              <FileText className="h-4 w-4 text-cyan-300" />
              دانلود متن ساده
            </button>
            <button
              onClick={() => {
                onExport("json");
                setOpen(false);
              }}
              className="flex w-full items-center gap-3 px-4 py-3 text-sm text-slate-200 hover:bg-white/5"
            >
              <FileJson className="h-4 w-4 text-cyan-300" />
              دانلود پروژه (JSON)
            </button>
            <div className="border-t border-white/10 px-4 py-3">
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <Clapperboard className="h-4 w-4" />
                خروجی نهایی ویدیو (به‌زودی)
              </div>
              <p className="mt-1 text-[11px] leading-5 text-slate-600">
                برای رندر نهایی ویدیو با زیرنویس چسبیده، افزودن یک سرویس رندر ffmpeg در بک‌اند لازم است.
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
