"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Crown } from "lucide-react";
import CaptionPreview from "@/components/caption/CaptionPreview";
import type { TemplateRecord } from "@/lib/types";

const DEMO_TEXT = "نمونه‌ی قالب زیرنویس";
const DEMO_DURATION = 3;

function TemplateCard({ template, active, onSelect }: { template: TemplateRecord; active: boolean; onSelect: () => void }) {
  const [time, setTime] = useState(0);
  const rafRef = useRef<number | undefined>(undefined);
  const startRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    function tick(ts: number) {
      if (startRef.current === undefined) startRef.current = ts;
      setTime(((ts - startRef.current) / 1000) % DEMO_DURATION);
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <button
      onClick={onSelect}
      className={`relative overflow-hidden rounded-xl border text-right transition ${
        active ? "border-violet-400 ring-2 ring-violet-400/40" : "border-white/10 hover:border-white/25"
      }`}
    >
      <div className="relative flex aspect-[9/13] items-center justify-center bg-gradient-to-br from-[#181a2b] to-[#0c0d15]">
        <CaptionPreview
          config={template.config}
          text={DEMO_TEXT}
          scale={0.24}
          currentTime={time}
          segmentStart={0}
          segmentEnd={DEMO_DURATION}
          animateKey={Math.floor(time / DEMO_DURATION)}
        />
        {template.isPro && (
          <span className="absolute right-2 top-2 flex items-center gap-0.5 rounded-full bg-amber-400/90 px-1.5 py-0.5 text-[9px] font-extrabold text-black">
            <Crown className="h-2.5 w-2.5" />
          </span>
        )}
        {active && (
          <span className="absolute left-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-violet-500 text-white">
            <Check className="h-3 w-3" />
          </span>
        )}
      </div>
      <p className="truncate p-2 text-[11px] font-bold text-slate-200">{template.name}</p>
    </button>
  );
}

export default function TemplateGrid({
  templates,
  activeId,
  onSelect,
}: {
  templates: TemplateRecord[];
  activeId: string | null;
  onSelect: (id: string) => void;
}) {
  const categories = Array.from(new Set(templates.map((t) => t.category)));
  return (
    <div className="scrollbar-thin h-full space-y-6 overflow-y-auto p-4">
      {categories.map((category) => (
        <div key={category}>
          <p className="mb-2 text-xs font-extrabold text-slate-400">{category}</p>
          <div className="grid grid-cols-2 gap-2.5">
            {templates
              .filter((t) => t.category === category)
              .map((template) => (
                <TemplateCard key={template.id} template={template} active={template.id === activeId} onSelect={() => onSelect(template.id)} />
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}
