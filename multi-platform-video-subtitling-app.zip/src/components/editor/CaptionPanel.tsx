"use client";

import { Plus, Trash2, Wand2 } from "lucide-react";
import { formatClock, parseClock } from "@/lib/time";
import type { CaptionSegmentRecord } from "@/lib/types";

interface CaptionPanelProps {
  segments: CaptionSegmentRecord[];
  selectedId: string | null;
  generating: boolean;
  onSelect: (id: string) => void;
  onChangeText: (id: string, text: string) => void;
  onChangeTime: (id: string, field: "startTime" | "endTime", value: number) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
  onGenerate: () => void;
}

export default function CaptionPanel({
  segments,
  selectedId,
  generating,
  onSelect,
  onChangeText,
  onChangeTime,
  onDelete,
  onAdd,
  onGenerate,
}: CaptionPanelProps) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between gap-2 border-b border-white/5 p-4">
        <p className="text-sm font-extrabold text-slate-200">بخش‌های زیرنویس ({segments.length})</p>
        <div className="flex items-center gap-2">
          <button
            onClick={onAdd}
            className="grid h-8 w-8 place-items-center rounded-lg bg-white/5 text-slate-200 hover:bg-white/10"
            title="افزودن بخش"
          >
            <Plus className="h-4 w-4" />
          </button>
          <button
            onClick={onGenerate}
            disabled={generating}
            className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-violet-500 to-cyan-400 px-3 py-1.5 text-xs font-extrabold text-slate-950 disabled:opacity-60"
          >
            <Wand2 className="h-3.5 w-3.5" />
            {generating ? "در حال تولید..." : "زیرنویس خودکار"}
          </button>
        </div>
      </div>

      <div className="scrollbar-thin flex-1 space-y-2 overflow-y-auto p-3">
        {segments.length === 0 && (
          <p className="mt-10 text-center text-xs leading-6 text-slate-500">
            هنوز زیرنویسی وجود ندارد. از دکمه «زیرنویس خودکار» استفاده کن یا با «افزودن بخش» به‌صورت دستی بساز.
          </p>
        )}
        {segments.map((segment, index) => (
          <div
            key={segment.id}
            onClick={() => onSelect(segment.id)}
            className={`cursor-pointer rounded-xl border p-3 transition ${
              segment.id === selectedId
                ? "border-violet-400/60 bg-violet-500/10"
                : "border-white/5 bg-white/[0.02] hover:border-white/15"
            }`}
          >
            <div className="mb-2 flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-slate-500">#{index + 1}</span>
              <div className="flex items-center gap-1 text-[11px] text-slate-400">
                <input
                  value={formatClock(segment.startTime)}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => onChangeTime(segment.id, "startTime", parseClock(e.target.value))}
                  className="w-16 rounded-md border border-white/10 bg-black/30 px-1.5 py-0.5 text-center tabular-nums outline-none focus:border-violet-400"
                />
                <span>—</span>
                <input
                  value={formatClock(segment.endTime)}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => onChangeTime(segment.id, "endTime", parseClock(e.target.value))}
                  className="w-16 rounded-md border border-white/10 bg-black/30 px-1.5 py-0.5 text-center tabular-nums outline-none focus:border-violet-400"
                />
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(segment.id);
                }}
                className="text-slate-500 hover:text-red-400"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
            <textarea
              value={segment.text}
              onClick={(e) => e.stopPropagation()}
              onChange={(e) => onChangeText(segment.id, e.target.value)}
              rows={2}
              className="w-full resize-none rounded-lg border border-transparent bg-transparent text-sm leading-6 text-slate-100 outline-none focus:border-white/10 focus:bg-black/20"
              placeholder="متن زیرنویس..."
            />
          </div>
        ))}
      </div>
    </div>
  );
}
