"use client";

import { useMemo, useRef, useState, type MouseEvent, type PointerEvent as ReactPointerEvent } from "react";
import { Plus, ZoomIn, ZoomOut } from "lucide-react";
import { formatClock } from "@/lib/time";
import type { CaptionSegmentRecord } from "@/lib/types";

interface TimelineProps {
  segments: CaptionSegmentRecord[];
  selectedId: string | null;
  currentTime: number;
  duration: number;
  onSeek: (time: number) => void;
  onSelect: (id: string) => void;
  onUpdateSegment: (id: string, patch: { startTime?: number; endTime?: number }) => void;
  onAddSegment: () => void;
}

type DragMode = "move" | "resize-start" | "resize-end";

export default function Timeline({
  segments,
  selectedId,
  currentTime,
  duration,
  onSeek,
  onSelect,
  onUpdateSegment,
  onAddSegment,
}: TimelineProps) {
  const [pxPerSecond, setPxPerSecond] = useState(90);
  const trackRef = useRef<HTMLDivElement>(null);
  const dragState = useRef<{
    id: string;
    mode: DragMode;
    startX: number;
    originalStart: number;
    originalEnd: number;
  } | null>(null);

  const safeDuration = Math.max(duration, 1);
  const totalWidth = Math.max(safeDuration * pxPerSecond, 600);

  const ticks = useMemo(() => {
    const step = pxPerSecond < 50 ? 5 : pxPerSecond < 100 ? 2 : 1;
    const arr: number[] = [];
    for (let t = 0; t <= safeDuration; t += step) arr.push(t);
    return arr;
  }, [pxPerSecond, safeDuration]);

  function timeFromClientX(clientX: number) {
    const rect = trackRef.current?.getBoundingClientRect();
    if (!rect) return 0;
    const x = clientX - rect.left;
    return Math.min(Math.max(x / pxPerSecond, 0), safeDuration);
  }

  function handleTrackClick(e: MouseEvent) {
    if (dragState.current) return;
    onSeek(timeFromClientX(e.clientX));
  }

  function startDrag(e: ReactPointerEvent, segment: CaptionSegmentRecord, mode: DragMode) {
    e.stopPropagation();
    onSelect(segment.id);
    dragState.current = {
      id: segment.id,
      mode,
      startX: e.clientX,
      originalStart: segment.startTime,
      originalEnd: segment.endTime,
    };
    window.addEventListener("pointermove", handleDragMove);
    window.addEventListener("pointerup", handleDragEnd);
  }

  function handleDragMove(e: PointerEvent) {
    const drag = dragState.current;
    if (!drag) return;
    const deltaSeconds = (e.clientX - drag.startX) / pxPerSecond;
    const neighbors = segments.filter((s) => s.id !== drag.id);
    const prevEnd = Math.max(0, ...neighbors.filter((s) => s.endTime <= drag.originalStart + 0.001).map((s) => s.endTime));
    const nextStart = Math.min(
      safeDuration,
      ...neighbors.filter((s) => s.startTime >= drag.originalEnd - 0.001).map((s) => s.startTime),
      safeDuration
    );

    if (drag.mode === "move") {
      const length = drag.originalEnd - drag.originalStart;
      let newStart = drag.originalStart + deltaSeconds;
      newStart = Math.max(prevEnd, Math.min(newStart, nextStart - length));
      onUpdateSegment(drag.id, { startTime: Number(newStart.toFixed(2)), endTime: Number((newStart + length).toFixed(2)) });
    } else if (drag.mode === "resize-start") {
      let newStart = drag.originalStart + deltaSeconds;
      newStart = Math.max(prevEnd, Math.min(newStart, drag.originalEnd - 0.2));
      onUpdateSegment(drag.id, { startTime: Number(newStart.toFixed(2)) });
    } else {
      let newEnd = drag.originalEnd + deltaSeconds;
      newEnd = Math.min(nextStart, Math.max(newEnd, drag.originalStart + 0.2));
      onUpdateSegment(drag.id, { endTime: Number(newEnd.toFixed(2)) });
    }
  }

  function handleDragEnd() {
    dragState.current = null;
    window.removeEventListener("pointermove", handleDragMove);
    window.removeEventListener("pointerup", handleDragEnd);
  }

  return (
    <div className="flex h-56 flex-col border-t border-white/5 bg-[#0b0c16]">
      <div className="flex items-center justify-between gap-3 border-b border-white/5 px-4 py-2">
        <button
          onClick={onAddSegment}
          className="flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10"
        >
          <Plus className="h-3.5 w-3.5" />
          افزودن بخش در این لحظه
        </button>
        <div className="flex items-center gap-1 text-slate-400">
          <button onClick={() => setPxPerSecond((v) => Math.max(30, v - 20))} className="rounded-md p-1.5 hover:bg-white/10">
            <ZoomOut className="h-4 w-4" />
          </button>
          <button onClick={() => setPxPerSecond((v) => Math.min(240, v + 20))} className="rounded-md p-1.5 hover:bg-white/10">
            <ZoomIn className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="scrollbar-thin flex-1 overflow-x-auto overflow-y-hidden">
        <div
          ref={trackRef}
          onClick={handleTrackClick}
          className="relative h-full cursor-pointer select-none"
          style={{ width: totalWidth }}
        >
          {/* Ruler */}
          <div className="sticky top-0 z-10 h-6 border-b border-white/5 bg-[#0b0c16]">
            {ticks.map((t) => (
              <div
                key={t}
                className="absolute top-0 h-full border-r border-white/5 text-[10px] text-slate-500"
                style={{ right: t * pxPerSecond }}
              >
                <span className="absolute -top-0.5 right-1">{formatClock(t).slice(0, 5)}</span>
              </div>
            ))}
          </div>

          {/* Segments row */}
          <div className="relative h-24 border-b border-white/5">
            {segments.map((segment) => {
              const active = segment.id === selectedId;
              return (
                <div
                  key={segment.id}
                  onPointerDown={(e) => startDrag(e, segment, "move")}
                  className={`absolute top-3 flex h-16 items-center overflow-hidden rounded-lg border px-2 text-[11px] font-bold shadow-md transition ${
                    active
                      ? "border-violet-300 bg-gradient-to-b from-violet-500/90 to-fuchsia-500/80 text-white"
                      : "border-white/10 bg-gradient-to-b from-white/15 to-white/5 text-slate-200 hover:border-white/30"
                  }`}
                  style={{
                    right: segment.startTime * pxPerSecond,
                    width: Math.max((segment.endTime - segment.startTime) * pxPerSecond, 24),
                  }}
                >
                  <span className="truncate">{segment.text || "بدون متن"}</span>
                  <div
                    onPointerDown={(e) => startDrag(e, segment, "resize-start")}
                    className="absolute inset-y-0 right-0 w-2 cursor-ew-resize bg-white/30"
                  />
                  <div
                    onPointerDown={(e) => startDrag(e, segment, "resize-end")}
                    className="absolute inset-y-0 left-0 w-2 cursor-ew-resize bg-white/30"
                  />
                </div>
              );
            })}
          </div>

          {/* Waveform placeholder */}
          <div className="flex h-12 items-center gap-[3px] overflow-hidden px-1 opacity-40">
            {Array.from({ length: Math.floor(totalWidth / 6) }).map((_, i) => (
              <div
                key={i}
                className="w-[2px] shrink-0 rounded-full bg-cyan-300"
                style={{ height: `${8 + Math.abs(Math.sin(i * 0.5)) * 28}px` }}
              />
            ))}
          </div>

          {/* Playhead */}
          <div
            className="pointer-events-none absolute top-0 z-20 h-full w-[2px] bg-cyan-300 shadow-[0_0_8px_rgba(34,211,238,0.8)]"
            style={{ right: currentTime * pxPerSecond }}
          >
            <div className="absolute -top-1 right-1/2 h-3 w-3 translate-x-1/2 rounded-full bg-cyan-300" />
          </div>
        </div>
      </div>
    </div>
  );
}
