"use client";

import { useRef, type RefObject } from "react";
import { Loader2, Pause, Play, UploadCloud, Volume2, VolumeX } from "lucide-react";
import CaptionPreview from "@/components/caption/CaptionPreview";
import { useElementSize } from "@/lib/hooks";
import { formatClock } from "@/lib/time";
import type { AspectRatio, CaptionSegmentRecord, CaptionStyleConfig } from "@/lib/types";

const ASPECT_MAP: Record<AspectRatio, string> = {
  "9:16": "9 / 16",
  "16:9": "16 / 9",
  "1:1": "1 / 1",
  "4:5": "4 / 5",
};

interface VideoStageProps {
  videoRef: RefObject<HTMLVideoElement | null>;
  videoUrl: string | null;
  aspectRatio: AspectRatio;
  effectiveConfig: CaptionStyleConfig;
  activeSegment: CaptionSegmentRecord | null;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  muted: boolean;
  uploading: boolean;
  onTogglePlay: () => void;
  onToggleMute: () => void;
  onSeek: (time: number) => void;
  onUploadFile: (file: File) => void;
}

export default function VideoStage({
  videoRef,
  videoUrl,
  aspectRatio,
  effectiveConfig,
  activeSegment,
  currentTime,
  duration,
  isPlaying,
  muted,
  uploading,
  onTogglePlay,
  onToggleMute,
  onSeek,
  onUploadFile,
}: VideoStageProps) {
  const { ref, size } = useElementSize<HTMLDivElement>();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scale = size.width ? size.width / 1080 : 0.35;

  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-4">
      <div
        ref={ref}
        className="relative max-h-full max-w-full overflow-hidden rounded-2xl border border-white/10 bg-black shadow-2xl"
        style={{ aspectRatio: ASPECT_MAP[aspectRatio], height: "min(72vh, 900px)" }}
      >
        {videoUrl ? (
          <video
            ref={videoRef}
            src={videoUrl}
            className="h-full w-full object-contain bg-black"
            onClick={onTogglePlay}
            playsInline
          />
        ) : (
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-[#181a2b] to-[#0b0c14] text-slate-400 transition hover:text-slate-200"
          >
            {uploading ? <Loader2 className="h-8 w-8 animate-spin" /> : <UploadCloud className="h-10 w-10" />}
            <span className="text-sm font-bold">{uploading ? "در حال آپلود ویدیو..." : "برای آپلود ویدیو کلیک کنید"}</span>
            <span className="text-xs text-slate-600">MP4 ،MOV ،WEBM تا ۳۰۰ مگابایت</span>
          </button>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onUploadFile(file);
          }}
        />

        {videoUrl && activeSegment && (
          <CaptionPreview
            config={{ ...effectiveConfig, ...(activeSegment.styleOverride ?? {}) }}
            text={activeSegment.text}
            words={activeSegment.words}
            scale={scale}
            currentTime={currentTime}
            segmentStart={activeSegment.startTime}
            segmentEnd={activeSegment.endTime}
            animateKey={activeSegment.id}
          />
        )}

        {videoUrl && (
          <div className="absolute inset-x-0 bottom-0 flex items-center gap-3 bg-gradient-to-t from-black/80 to-transparent px-4 py-3">
            <button
              onClick={onTogglePlay}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/15 text-white backdrop-blur transition hover:bg-white/25"
            >
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <input
              type="range"
              min={0}
              max={duration || 0}
              step={0.01}
              value={Math.min(currentTime, duration || 0)}
              onChange={(e) => onSeek(Number(e.target.value))}
              style={{ ["--progress" as string]: `${duration ? (currentTime / duration) * 100 : 0}%` }}
              className="flex-1"
            />
            <span className="w-24 shrink-0 text-center text-[11px] tabular-nums text-slate-200">
              {formatClock(currentTime)} / {formatClock(duration)}
            </span>
            <button
              onClick={onToggleMute}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/15 text-white backdrop-blur transition hover:bg-white/25"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
