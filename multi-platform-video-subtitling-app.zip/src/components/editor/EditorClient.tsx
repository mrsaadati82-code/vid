"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Captions, Palette, Type } from "lucide-react";
import TopBar from "@/components/editor/TopBar";
import VideoStage from "@/components/editor/VideoStage";
import Timeline from "@/components/editor/Timeline";
import CaptionPanel from "@/components/editor/CaptionPanel";
import StylePanel from "@/components/editor/StylePanel";
import TemplateGrid from "@/components/editor/TemplateGrid";
import { useDebouncedCallback } from "@/lib/hooks";
import { buildPlainText, buildSrt, buildVtt } from "@/lib/captions-export";
import type {
  AspectRatio,
  CaptionSegmentRecord,
  CaptionStyleConfig,
  ProjectRecord,
  ProjectStatus,
  TemplateRecord,
} from "@/lib/types";

type Tab = "captions" | "templates" | "style";

function downloadBlob(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default function EditorClient({
  project: initialProject,
  initialSegments,
  templates,
}: {
  project: ProjectRecord;
  initialSegments: CaptionSegmentRecord[];
  templates: TemplateRecord[];
}) {
  const [project, setProject] = useState(initialProject);
  const [templateList, setTemplateList] = useState(templates);
  const [segments, setSegments] = useState<CaptionSegmentRecord[]>(
    [...initialSegments].sort((a, b) => a.startTime - b.startTime)
  );
  const [selectedId, setSelectedId] = useState<string | null>(initialSegments[0]?.id ?? null);
  const [tab, setTab] = useState<Tab>("captions");
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [savingProject, setSavingProject] = useState(false);
  const [savingCaptions, setSavingCaptions] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const skipFirstCaptionSave = useRef(true);
  const skipFirstProjectSave = useRef(true);

  const activeTemplate = useMemo(
    () => templateList.find((t) => t.id === project.templateId) ?? templateList[0],
    [templateList, project.templateId]
  );

  const effectiveConfig: CaptionStyleConfig = useMemo(
    () => ({ ...activeTemplate.config, ...(project.styleOverrides ?? {}) }),
    [activeTemplate, project.styleOverrides]
  );

  const activeSegment = useMemo(
    () => segments.find((s) => currentTime >= s.startTime && currentTime < s.endTime) ?? null,
    [segments, currentTime]
  );

  // --- Video element wiring ---
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => setCurrentTime(video.currentTime);
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onLoaded = () => {
      if (video.duration && Number.isFinite(video.duration) && video.duration !== project.durationSeconds) {
        setProject((p) => ({ ...p, durationSeconds: video.duration }));
      }
    };
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("loadedmetadata", onLoaded);
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("loadedmetadata", onLoaded);
    };
  }, [project.durationSeconds, project.videoUrl]);

  // --- Autosave project fields ---
  const debouncedSaveProject = useDebouncedCallback(async (patch: Partial<ProjectRecord>) => {
    setSavingProject(true);
    try {
      await fetch(`/api/projects/${project.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
    } finally {
      setSavingProject(false);
    }
  }, 600);

  useEffect(() => {
    if (skipFirstProjectSave.current) {
      skipFirstProjectSave.current = false;
      return;
    }
    debouncedSaveProject({
      title: project.title,
      templateId: project.templateId,
      styleOverrides: project.styleOverrides,
      aspectRatio: project.aspectRatio,
      durationSeconds: project.durationSeconds,
      videoUrl: project.videoUrl,
      videoName: project.videoName,
      status: project.status,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    project.title,
    project.templateId,
    project.styleOverrides,
    project.aspectRatio,
    project.durationSeconds,
    project.videoUrl,
    project.videoName,
    project.status,
  ]);

  // --- Autosave captions ---
  const debouncedSaveCaptions = useDebouncedCallback(async (list: CaptionSegmentRecord[]) => {
    setSavingCaptions(true);
    try {
      await fetch(`/api/projects/${project.id}/captions`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          segments: list.map((s) => ({
            startTime: s.startTime,
            endTime: s.endTime,
            text: s.text,
            words: s.words,
            styleOverride: s.styleOverride,
          })),
        }),
      });
    } finally {
      setSavingCaptions(false);
    }
  }, 700);

  useEffect(() => {
    if (skipFirstCaptionSave.current) {
      skipFirstCaptionSave.current = false;
      return;
    }
    debouncedSaveCaptions(segments);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [segments]);

  // --- Handlers ---
  const seek = useCallback((time: number) => {
    if (videoRef.current) videoRef.current.currentTime = time;
    setCurrentTime(time);
  }, []);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) video.play();
    else video.pause();
  }, []);

  const toggleMute = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setMuted(video.muted);
  }, []);

  async function handleUploadFile(file: File) {
    setUploadingVideo(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در آپلود");

      const durationSeconds: number = await new Promise((resolve) => {
        const v = document.createElement("video");
        v.preload = "metadata";
        v.onloadedmetadata = () => resolve(v.duration || 0);
        v.onerror = () => resolve(0);
        v.src = URL.createObjectURL(file);
      });

      setProject((p) => ({ ...p, videoUrl: data.url, videoName: data.name, durationSeconds }));
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "خطا در آپلود ویدیو");
    } finally {
      setUploadingVideo(false);
    }
  }

  async function handleGenerate() {
    if (!project.videoUrl) {
      setNotice("ابتدا یک ویدیو آپلود کنید.");
      return;
    }
    if (segments.length > 0) {
      const ok = window.confirm("زیرنویس‌های فعلی جایگزین خواهند شد. ادامه می‌دهید؟");
      if (!ok) return;
    }
    setGenerating(true);
    setProject((p) => ({ ...p, status: "processing" }));
    try {
      const res = await fetch(`/api/projects/${project.id}/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ durationSeconds: project.durationSeconds, language: "fa" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در تولید زیرنویس خودکار");
      skipFirstCaptionSave.current = true; // server already has the fresh data
      setSegments(data.segments.sort((a: CaptionSegmentRecord, b: CaptionSegmentRecord) => a.startTime - b.startTime));
      setSelectedId(data.segments[0]?.id ?? null);
      setProject((p) => ({ ...p, status: "ready" }));
      if (data.notice) setNotice(data.notice);
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "خطا در تولید زیرنویس");
      setProject((p) => ({ ...p, status: "draft" }));
    } finally {
      setGenerating(false);
    }
  }

  function addSegment() {
    const start = currentTime;
    const end = Math.min(start + 2, project.durationSeconds || start + 2);
    const newSegment: CaptionSegmentRecord = {
      id: crypto.randomUUID(),
      projectId: project.id,
      sortOrder: segments.length,
      startTime: start,
      endTime: end > start ? end : start + 1,
      text: "متن جدید را اینجا بنویسید",
      words: null,
      styleOverride: null,
    };
    setSegments((prev) => [...prev, newSegment].sort((a, b) => a.startTime - b.startTime));
    setSelectedId(newSegment.id);
  }

  function updateSegmentText(id: string, text: string) {
    setSegments((prev) => prev.map((s) => (s.id === id ? { ...s, text } : s)));
  }

  function updateSegmentTime(id: string, field: "startTime" | "endTime", value: number) {
    setSegments((prev) =>
      prev
        .map((s) => (s.id === id ? { ...s, [field]: value } : s))
        .sort((a, b) => a.startTime - b.startTime)
    );
  }

  function updateSegmentRange(id: string, patch: { startTime?: number; endTime?: number }) {
    setSegments((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function deleteSegment(id: string) {
    setSegments((prev) => prev.filter((s) => s.id !== id));
    if (selectedId === id) setSelectedId(null);
  }

  function handleStyleChange(patch: Partial<CaptionStyleConfig>) {
    setProject((p) => ({ ...p, styleOverrides: { ...(p.styleOverrides ?? {}), ...patch } }));
  }

  function handleSelectTemplate(templateId: string) {
    setProject((p) => ({ ...p, templateId, styleOverrides: {} }));
  }

  async function handleSaveAsTemplate(name: string) {
    const res = await fetch("/api/templates", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, category: "قالب‌های من", config: effectiveConfig }),
    });
    const data = await res.json();
    if (res.ok) {
      setTemplateList((prev) => [...prev, data.template]);
      setProject((p) => ({ ...p, templateId: data.template.id, styleOverrides: {} }));
      setNotice(`قالب «${name}» ذخیره شد.`);
    }
  }

  function handleExport(kind: "srt" | "vtt" | "txt" | "json") {
    const safeName = project.title.replace(/[^\w\u0600-\u06FF-]+/g, "_") || "captions";
    if (kind === "srt") downloadBlob(buildSrt(segments), `${safeName}.srt`, "text/plain;charset=utf-8");
    if (kind === "vtt") downloadBlob(buildVtt(segments), `${safeName}.vtt`, "text/vtt;charset=utf-8");
    if (kind === "txt") downloadBlob(buildPlainText(segments), `${safeName}.txt`, "text/plain;charset=utf-8");
    if (kind === "json")
      downloadBlob(
        JSON.stringify({ project, segments, style: effectiveConfig }, null, 2),
        `${safeName}.json`,
        "application/json"
      );
  }

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#08090f]">
      <TopBar
        title={project.title}
        status={project.status as ProjectStatus}
        aspectRatio={project.aspectRatio as AspectRatio}
        saving={savingProject || savingCaptions}
        onTitleChange={(title) => setProject((p) => ({ ...p, title }))}
        onAspectChange={(aspectRatio) => setProject((p) => ({ ...p, aspectRatio }))}
        onExport={handleExport}
      />

      {notice && (
        <div className="flex items-center justify-between gap-3 border-b border-amber-400/20 bg-amber-400/10 px-4 py-2 text-xs text-amber-200">
          <span>{notice}</span>
          <button onClick={() => setNotice(null)} className="font-bold">
            ✕
          </button>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        <aside className="flex w-[380px] shrink-0 flex-col border-e border-white/5 bg-[#0b0c16]">
          <div className="flex border-b border-white/5">
            {(
              [
                { key: "captions", label: "زیرنویس‌ها", icon: Captions },
                { key: "templates", label: "قالب‌ها", icon: Palette },
                { key: "style", label: "استایل", icon: Type },
              ] as const
            ).map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex flex-1 flex-col items-center gap-1 py-3 text-[11px] font-bold transition ${
                  tab === t.key ? "border-b-2 border-violet-400 text-violet-200" : "text-slate-500 hover:text-slate-300"
                }`}
              >
                <t.icon className="h-4 w-4" />
                {t.label}
              </button>
            ))}
          </div>

          <div className="min-h-0 flex-1">
            {tab === "captions" && (
              <CaptionPanel
                segments={segments}
                selectedId={selectedId}
                generating={generating}
                onSelect={(id) => {
                  setSelectedId(id);
                  const seg = segments.find((s) => s.id === id);
                  if (seg) seek(seg.startTime);
                }}
                onChangeText={updateSegmentText}
                onChangeTime={updateSegmentTime}
                onDelete={deleteSegment}
                onAdd={addSegment}
                onGenerate={handleGenerate}
              />
            )}
            {tab === "templates" && (
              <TemplateGrid templates={templateList} activeId={activeTemplate?.id ?? null} onSelect={handleSelectTemplate} />
            )}
            {tab === "style" && (
              <StylePanel config={effectiveConfig} onChange={handleStyleChange} onSaveAsTemplate={handleSaveAsTemplate} />
            )}
          </div>
        </aside>

        <main className="flex flex-1 flex-col overflow-hidden">
          <div className="flex flex-1 items-center justify-center overflow-auto p-6">
            <VideoStage
              videoRef={videoRef}
              videoUrl={project.videoUrl}
              aspectRatio={project.aspectRatio as AspectRatio}
              effectiveConfig={effectiveConfig}
              activeSegment={activeSegment}
              currentTime={currentTime}
              duration={project.durationSeconds}
              isPlaying={isPlaying}
              muted={muted}
              uploading={uploadingVideo}
              onTogglePlay={togglePlay}
              onToggleMute={toggleMute}
              onSeek={seek}
              onUploadFile={handleUploadFile}
            />
          </div>
          <Timeline
            segments={segments}
            selectedId={selectedId}
            currentTime={currentTime}
            duration={project.durationSeconds || 30}
            onSeek={seek}
            onSelect={setSelectedId}
            onUpdateSegment={updateSegmentRange}
            onAddSegment={addSegment}
          />
        </main>
      </div>
    </div>
  );
}
