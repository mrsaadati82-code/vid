import { boolean, index, integer, jsonb, pgTable, real, text, timestamp } from "drizzle-orm/pg-core";
import type { CaptionStyleConfig, WordTiming } from "@/lib/types";

export const templates = pgTable("templates", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  isPro: boolean("is_pro").notNull().default(false),
  config: jsonb("config").$type<CaptionStyleConfig>().notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const projects = pgTable("projects", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  title: text("title").notNull().default("پروژه بدون عنوان"),
  videoUrl: text("video_url"),
  videoName: text("video_name"),
  durationSeconds: real("duration_seconds").notNull().default(0),
  aspectRatio: text("aspect_ratio").notNull().default("9:16"),
  status: text("status").notNull().default("draft"),
  templateId: text("template_id").references(() => templates.id, { onDelete: "set null" }),
  styleOverrides: jsonb("style_overrides").$type<Partial<CaptionStyleConfig>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const captionSegments = pgTable(
  "caption_segments",
  {
    id: text("id")
      .primaryKey()
      .$defaultFn(() => crypto.randomUUID()),
    projectId: text("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    sortOrder: integer("sort_order").notNull().default(0),
    startTime: real("start_time").notNull().default(0),
    endTime: real("end_time").notNull().default(0),
    text: text("text").notNull().default(""),
    words: jsonb("words").$type<WordTiming[]>(),
    styleOverride: jsonb("style_override").$type<Partial<CaptionStyleConfig>>(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    projectIdx: index("caption_segments_project_idx").on(table.projectId),
  })
);
