export type CaptionPosition = "top" | "middle" | "bottom";

export type CaptionAnimation =
  | "none"
  | "fade"
  | "pop"
  | "karaoke"
  | "slide-up"
  | "bounce"
  | "typewriter";

export interface CaptionStyleConfig {
  fontFamily: string;
  fontWeight: number;
  fontSize: number;
  textColor: string;
  highlightColor: string;
  backgroundColor: string;
  backgroundOpacity: number;
  position: CaptionPosition;
  animation: CaptionAnimation;
  uppercase: boolean;
  stroke: boolean;
  strokeColor: string;
  strokeWidth: number;
  wordsPerLine: number;
  letterSpacing: number;
  borderRadius: number;
  paddingX: number;
  paddingY: number;
  shadow: boolean;
}

export interface WordTiming {
  word: string;
  start: number;
  end: number;
}

export type ProjectStatus = "draft" | "processing" | "ready";

export type AspectRatio = "9:16" | "16:9" | "1:1" | "4:5";

export interface TemplateRecord {
  id: string;
  name: string;
  category: string;
  description: string | null;
  isPro: boolean;
  config: CaptionStyleConfig;
  sortOrder: number;
}

export interface CaptionSegmentRecord {
  id: string;
  projectId: string;
  sortOrder: number;
  startTime: number;
  endTime: number;
  text: string;
  words: WordTiming[] | null;
  styleOverride: Partial<CaptionStyleConfig> | null;
}

export interface ProjectRecord {
  id: string;
  title: string;
  videoUrl: string | null;
  videoName: string | null;
  durationSeconds: number;
  aspectRatio: AspectRatio;
  status: ProjectStatus;
  templateId: string | null;
  styleOverrides: Partial<CaptionStyleConfig> | null;
  createdAt: string;
  updatedAt: string;
}

export interface ProjectListItem extends ProjectRecord {
  captionsCount: number;
}

export interface ProjectDetail {
  project: ProjectRecord;
  segments: CaptionSegmentRecord[];
  templates: TemplateRecord[];
}
