/** Formats seconds into a `mm:ss.d` compact display timestamp. */
export function formatClock(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) totalSeconds = 0;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds - minutes * 60;
  return `${minutes.toString().padStart(2, "0")}:${seconds.toFixed(1).padStart(4, "0")}`;
}

/** Formats seconds into an SRT-style `HH:MM:SS,mmm` timestamp. */
export function toSrtTimestamp(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) totalSeconds = 0;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const millis = Math.round((totalSeconds - Math.floor(totalSeconds)) * 1000);
  return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds
    .toString()
    .padStart(2, "0")},${millis.toString().padStart(3, "0")}`;
}

/** Formats seconds into a WebVTT `HH:MM:SS.mmm` timestamp. */
export function toVttTimestamp(totalSeconds: number): string {
  return toSrtTimestamp(totalSeconds).replace(",", ".");
}

/** Parses an editable `mm:ss.d` or `mm:ss` string back into seconds. */
export function parseClock(value: string): number {
  const trimmed = value.trim();
  const parts = trimmed.split(":");
  if (parts.length === 2) {
    const minutes = Number(parts[0]) || 0;
    const seconds = Number(parts[1]) || 0;
    return minutes * 60 + seconds;
  }
  const asNumber = Number(trimmed);
  return Number.isFinite(asNumber) ? asNumber : 0;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}
