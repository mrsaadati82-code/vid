import { toSrtTimestamp, toVttTimestamp } from "@/lib/time";
import type { CaptionSegmentRecord } from "@/lib/types";

export function buildSrt(segments: CaptionSegmentRecord[]): string {
  return segments
    .map((segment, index) => {
      return `${index + 1}\n${toSrtTimestamp(segment.startTime)} --> ${toSrtTimestamp(
        segment.endTime
      )}\n${segment.text}\n`;
    })
    .join("\n");
}

export function buildVtt(segments: CaptionSegmentRecord[]): string {
  const body = segments
    .map((segment) => {
      return `${toVttTimestamp(segment.startTime)} --> ${toVttTimestamp(segment.endTime)}\n${
        segment.text
      }\n`;
    })
    .join("\n");
  return `WEBVTT\n\n${body}`;
}

export function buildPlainText(segments: CaptionSegmentRecord[]): string {
  return segments.map((segment) => segment.text).join("\n");
}
