import { db } from "@/db";
import { templates } from "@/db/schema";
import { TEMPLATE_SEEDS } from "@/lib/templates-seed";
import { sql } from "drizzle-orm";

let seeded = false;

/** Ensures the templates table has the built-in starter templates. Runs once per server lifetime. */
export async function ensureTemplatesSeeded() {
  if (seeded) return;
  const result = await db.execute<{ count: string }>(sql`select count(*)::text as count from ${templates}`);
  const count = result.rows[0]?.count ?? "0";
  if (Number(count) === 0) {
    await db.insert(templates).values(
      TEMPLATE_SEEDS.map((seed) => ({
        name: seed.name,
        category: seed.category,
        description: seed.description,
        isPro: seed.isPro,
        sortOrder: seed.sortOrder,
        config: seed.config,
      }))
    );
  }
  seeded = true;
}
