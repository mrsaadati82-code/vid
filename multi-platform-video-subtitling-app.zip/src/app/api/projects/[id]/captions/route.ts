import { db } from "@/db";
import { captionSegments } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const rows = await db
    .select()
    .from(captionSegments)
    .where(eq(captionSegments.projectId, id))
    .orderBy(asc(captionSegments.sortOrder));
  return Response.json({ segments: rows });
}

interface IncomingSegment {
  startTime: number;
  endTime: number;
  text: string;
  words?: { word: string; start: number; end: number }[] | null;
  styleOverride?: Record<string, unknown> | null;
}

export async function PUT(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => ({}));
  const segments: IncomingSegment[] = Array.isArray(body?.segments) ? body.segments : [];

  await db.transaction(async (tx) => {
    await tx.delete(captionSegments).where(eq(captionSegments.projectId, id));
    if (segments.length > 0) {
      await tx.insert(captionSegments).values(
        segments.map((segment, index) => ({
          projectId: id,
          sortOrder: index,
          startTime: segment.startTime,
          endTime: segment.endTime,
          text: segment.text ?? "",
          words: segment.words ?? null,
          styleOverride: segment.styleOverride ?? null,
        }))
      );
    }
  });

  const rows = await db
    .select()
    .from(captionSegments)
    .where(eq(captionSegments.projectId, id))
    .orderBy(asc(captionSegments.sortOrder));
  return Response.json({ segments: rows });
}
