import { db } from "@/db";
import { captionSegments, projects } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import fs from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-dynamic";

async function loadProject(id: string) {
  const [project] = await db.select().from(projects).where(eq(projects.id, id));
  if (!project) return null;
  const segments = await db
    .select()
    .from(captionSegments)
    .where(eq(captionSegments.projectId, id))
    .orderBy(asc(captionSegments.sortOrder));
  return { project, segments };
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const data = await loadProject(id);
  if (!data) return Response.json({ error: "پروژه پیدا نشد." }, { status: 404 });
  return Response.json(data);
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => ({}));

  const updates: Partial<typeof projects.$inferInsert> = { updatedAt: new Date() };
  if (typeof body.title === "string") updates.title = body.title;
  if (typeof body.status === "string") updates.status = body.status;
  if (typeof body.templateId === "string" || body.templateId === null) updates.templateId = body.templateId;
  if (typeof body.aspectRatio === "string") updates.aspectRatio = body.aspectRatio;
  if (typeof body.durationSeconds === "number") updates.durationSeconds = body.durationSeconds;
  if (body.styleOverrides !== undefined) updates.styleOverrides = body.styleOverrides;
  if (typeof body.videoUrl === "string") updates.videoUrl = body.videoUrl;
  if (typeof body.videoName === "string") updates.videoName = body.videoName;

  const [row] = await db.update(projects).set(updates).where(eq(projects.id, id)).returning();
  if (!row) return Response.json({ error: "پروژه پیدا نشد." }, { status: 404 });
  return Response.json({ project: row });
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const [row] = await db.select().from(projects).where(eq(projects.id, id));
  if (row?.videoUrl?.startsWith("/uploads/")) {
    const filePath = path.join(process.cwd(), "public", row.videoUrl);
    await fs.unlink(filePath).catch(() => undefined);
  }
  await db.delete(projects).where(eq(projects.id, id));
  return Response.json({ ok: true });
}
