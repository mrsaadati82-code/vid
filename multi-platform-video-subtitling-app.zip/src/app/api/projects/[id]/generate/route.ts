import { db } from "@/db";
import { captionSegments, projects } from "@/db/schema";
import { eq } from "drizzle-orm";
import fs from "node:fs/promises";
import path from "node:path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

const MOCK_LINES = [
  "سلام و خوش آمدید به این ویدیو",
  "امروز می‌خوایم یه موضوع جذاب رو باهم بررسی کنیم",
  "لطفا تا انتهای این کلیپ با ما همراه باشید",
  "این نکته می‌تونه خیلی به شما کمک کنه",
  "حالا بریم سراغ قسمت اصلی ماجرا",
  "خیلی از افراد این موضوع رو نمی‌دونن",
  "با یک مثال ساده توضیح می‌دم",
  "نتیجه‌ای که گرفتیم واقعا جالب بود",
  "اگه این ویدیو مفید بود لایک فراموش نشه",
  "برای دیدن ادامه، ما رو دنبال کنید",
  "ممنون از اینکه وقت گذاشتید",
  "می‌بینمتون در ویدیوی بعدی",
];

const OPENAI_MAX_BYTES = 25 * 1024 * 1024;

interface WhisperWord {
  word: string;
  start: number;
  end: number;
}
interface WhisperSegment {
  start: number;
  end: number;
  text: string;
}
interface WhisperResponse {
  text?: string;
  segments?: WhisperSegment[];
  words?: WhisperWord[];
}

function chunkWordsIntoSegments(words: WhisperWord[], maxWordsPerSegment = 6) {
  const segments: { startTime: number; endTime: number; text: string; words: WhisperWord[] }[] = [];
  for (let i = 0; i < words.length; i += maxWordsPerSegment) {
    const chunk = words.slice(i, i + maxWordsPerSegment);
    if (chunk.length === 0) continue;
    segments.push({
      startTime: chunk[0].start,
      endTime: chunk[chunk.length - 1].end,
      text: chunk.map((w) => w.word.trim()).join(" ").trim(),
      words: chunk,
    });
  }
  return segments;
}

function buildMockSegments(duration: number) {
  const safeDuration = duration && duration > 1 ? duration : 30;
  const segmentLength = 2.6;
  const count = Math.max(3, Math.min(60, Math.round(safeDuration / segmentLength)));
  const segments = [];
  for (let i = 0; i < count; i++) {
    const startTime = Number((i * (safeDuration / count)).toFixed(2));
    const endTime = Number((((i + 1) * (safeDuration / count)) - 0.05).toFixed(2));
    segments.push({
      startTime,
      endTime: Math.max(endTime, startTime + 0.5),
      text: MOCK_LINES[i % MOCK_LINES.length],
      words: null as WhisperWord[] | null,
    });
  }
  return segments;
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => ({}));
  const clientDuration: number = Number(body?.durationSeconds) || 0;
  const language: string = typeof body?.language === "string" ? body.language : "fa";

  const [project] = await db.select().from(projects).where(eq(projects.id, id));
  if (!project) return Response.json({ error: "پروژه پیدا نشد." }, { status: 404 });

  await db.update(projects).set({ status: "processing", updatedAt: new Date() }).where(eq(projects.id, id));

  const duration = clientDuration || project.durationSeconds || 30;
  let generated: { startTime: number; endTime: number; text: string; words: WhisperWord[] | null }[] = [];
  let source: "openai" | "mock" = "mock";
  let notice: string | null = null;

  const apiKey = process.env.OPENAI_API_KEY;

  if (apiKey && project.videoUrl?.startsWith("/uploads/")) {
    try {
      const filePath = path.join(process.cwd(), "public", project.videoUrl);
      const stat = await fs.stat(filePath);

      if (stat.size > OPENAI_MAX_BYTES) {
        notice = "حجم فایل برای رونویسی خودکار با هوش مصنوعی بیش از حد مجاز (۲۵ مگابایت) است؛ زیرنویس نمونه ساخته شد.";
      } else {
        const buffer = await fs.readFile(filePath);
        const blob = new Blob([buffer]);
        const form = new FormData();
        form.append("file", blob, path.basename(filePath));
        form.append("model", "whisper-1");
        form.append("response_format", "verbose_json");
        form.append("timestamp_granularities[]", "word");
        form.append("timestamp_granularities[]", "segment");
        if (language && language !== "auto") form.append("language", language);

        const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
          method: "POST",
          headers: { Authorization: `Bearer ${apiKey}` },
          body: form,
        });

        if (!response.ok) {
          const errText = await response.text().catch(() => "");
          throw new Error(`OpenAI error ${response.status}: ${errText}`);
        }

        const data: WhisperResponse = await response.json();

        if (data.words && data.words.length > 0) {
          generated = chunkWordsIntoSegments(data.words).map((seg) => ({
            startTime: seg.startTime,
            endTime: seg.endTime,
            text: seg.text,
            words: seg.words,
          }));
        } else if (data.segments && data.segments.length > 0) {
          generated = data.segments.map((seg) => ({
            startTime: seg.start,
            endTime: seg.end,
            text: seg.text.trim(),
            words: null,
          }));
        } else if (data.text) {
          generated = [{ startTime: 0, endTime: duration, text: data.text.trim(), words: null }];
        }

        if (generated.length > 0) source = "openai";
      }
    } catch (error) {
      console.error("Whisper transcription failed, falling back to mock captions:", error);
      notice = "اتصال به سرویس هوش مصنوعی ناموفق بود؛ به‌جای آن یک زیرنویس نمونه برای شما ساخته شد.";
    }
  } else if (!apiKey) {
    notice = "برای رونویسی واقعی با هوش مصنوعی، کلید OPENAI_API_KEY را تنظیم کنید. فعلاً یک زیرنویس نمونه ساخته شد.";
  } else if (!project.videoUrl) {
    notice = "ابتدا یک فایل ویدیو/صوت آپلود کنید تا رونویسی واقعی انجام شود. فعلاً یک زیرنویس نمونه ساخته شد.";
  }

  if (generated.length === 0) {
    generated = buildMockSegments(duration);
  }

  await db.transaction(async (tx) => {
    await tx.delete(captionSegments).where(eq(captionSegments.projectId, id));
    await tx.insert(captionSegments).values(
      generated.map((segment, index) => ({
        projectId: id,
        sortOrder: index,
        startTime: segment.startTime,
        endTime: segment.endTime,
        text: segment.text,
        words: segment.words,
      }))
    );
    await tx
      .update(projects)
      .set({
        status: "ready",
        updatedAt: new Date(),
        durationSeconds: clientDuration || project.durationSeconds || duration,
      })
      .where(eq(projects.id, id));
  });

  const rows = await db.select().from(captionSegments).where(eq(captionSegments.projectId, id));

  return Response.json({ segments: rows, source, notice });
}
