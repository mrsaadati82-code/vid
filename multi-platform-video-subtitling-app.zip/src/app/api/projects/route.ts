import { db } from "@/db";
import { captionSegments, projects, templates } from "@/db/schema";
import { ensureTemplatesSeeded } from "@/lib/seed";
import { asc, desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select({
      id: projects.id,
      title: projects.title,
      videoUrl: projects.videoUrl,
      videoName: projects.videoName,
      durationSeconds: projects.durationSeconds,
      aspectRatio: projects.aspectRatio,
      status: projects.status,
      templateId: projects.templateId,
      styleOverrides: projects.styleOverrides,
      createdAt: projects.createdAt,
      updatedAt: projects.updatedAt,
      captionsCount: sql<number>`count(${captionSegments.id})::int`,
    })
    .from(projects)
    .leftJoin(captionSegments, eq(captionSegments.projectId, projects.id))
    .groupBy(projects.id)
    .orderBy(desc(projects.updatedAt));

  return Response.json({ projects: rows });
}

export async function POST(request: Request) {
  await ensureTemplatesSeeded();
  const body = await request.json().catch(() => ({}));

  let templateId: string | null = body?.templateId ?? null;
  if (!templateId) {
    const [firstTemplate] = await db.select({ id: templates.id }).from(templates).orderBy(asc(templates.sortOrder)).limit(1);
    templateId = firstTemplate?.id ?? null;
  }

  const [row] = await db
    .insert(projects)
    .values({
      title: body?.title || "پروژه بدون عنوان",
      videoUrl: body?.videoUrl ?? null,
      videoName: body?.videoName ?? null,
      durationSeconds: body?.durationSeconds ?? 0,
      aspectRatio: body?.aspectRatio ?? "9:16",
      status: body?.videoUrl ? "draft" : "draft",
      templateId,
    })
    .returning();

  return Response.json({ project: row }, { status: 201 });
}
