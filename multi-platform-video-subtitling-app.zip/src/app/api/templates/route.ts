import { db } from "@/db";
import { templates } from "@/db/schema";
import { ensureTemplatesSeeded } from "@/lib/seed";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureTemplatesSeeded();
  const rows = await db.select().from(templates).orderBy(asc(templates.sortOrder));
  return Response.json({ templates: rows });
}

export async function POST(request: Request) {
  await ensureTemplatesSeeded();
  const body = await request.json();
  if (!body?.name || !body?.config) {
    return Response.json({ error: "نام و تنظیمات قالب الزامی است." }, { status: 400 });
  }
  const [row] = await db
    .insert(templates)
    .values({
      name: body.name,
      category: body.category ?? "سفارشی من",
      description: body.description ?? "قالب سفارشی ساخته‌شده توسط شما",
      isPro: false,
      sortOrder: 999,
      config: body.config,
    })
    .returning();
  return Response.json({ template: row }, { status: 201 });
}
