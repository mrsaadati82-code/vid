import fs from "node:fs/promises";
import path from "node:path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_SIZE = 300 * 1024 * 1024; // 300MB

function safeExtension(name: string) {
  const ext = path.extname(name || "").toLowerCase();
  if (/^\.[a-z0-9]{2,5}$/.test(ext)) return ext;
  return ".mp4";
}

export async function POST(request: Request) {
  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");

  if (!file || !(file instanceof File)) {
    return Response.json({ error: "فایلی برای آپلود ارسال نشده است." }, { status: 400 });
  }

  if (!file.type.startsWith("video/") && !file.type.startsWith("audio/")) {
    return Response.json({ error: "فقط فایل‌های ویدیویی یا صوتی پشتیبانی می‌شوند." }, { status: 400 });
  }

  if (file.size > MAX_SIZE) {
    return Response.json({ error: "حجم فایل بیش از حد مجاز (۳۰۰ مگابایت) است." }, { status: 400 });
  }

  const uploadsDir = path.join(process.cwd(), "public", "uploads");
  await fs.mkdir(uploadsDir, { recursive: true });

  const fileName = `${crypto.randomUUID()}${safeExtension(file.name)}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(path.join(uploadsDir, fileName), buffer);

  return Response.json({
    url: `/uploads/${fileName}`,
    name: file.name,
    size: file.size,
    type: file.type,
  });
}
