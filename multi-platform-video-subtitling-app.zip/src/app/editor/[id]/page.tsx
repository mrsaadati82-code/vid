import { notFound } from "next/navigation";
import { db } from "@/db";
import { captionSegments, projects, templates } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureTemplatesSeeded } from "@/lib/seed";
import EditorClient from "@/components/editor/EditorClient";
import type { AspectRatio, CaptionSegmentRecord, ProjectRecord, ProjectStatus, TemplateRecord } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function EditorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await ensureTemplatesSeeded();

  const [projectRow] = await db.select().from(projects).where(eq(projects.id, id));
  if (!projectRow) notFound();

  const segmentRows = await db
    .select()
    .from(captionSegments)
    .where(eq(captionSegments.projectId, id))
    .orderBy(asc(captionSegments.sortOrder));

  const templateRows = await db.select().from(templates).orderBy(asc(templates.sortOrder));

  const project: ProjectRecord = {
    ...projectRow,
    aspectRatio: projectRow.aspectRatio as AspectRatio,
    status: projectRow.status as ProjectStatus,
    createdAt: projectRow.createdAt.toISOString(),
    updatedAt: projectRow.updatedAt.toISOString(),
  };

  const segments: CaptionSegmentRecord[] = segmentRows.map((row) => ({
    ...row,
    words: row.words ?? null,
    styleOverride: row.styleOverride ?? null,
  }));

  return (
    <EditorClient project={project} initialSegments={segments} templates={templateRows as unknown as TemplateRecord[]} />
  );
}
