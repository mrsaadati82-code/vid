import Link from "next/link";
import { ArrowRight, Captions } from "lucide-react";
import { db } from "@/db";
import { templates } from "@/db/schema";
import { ensureTemplatesSeeded } from "@/lib/seed";
import { asc } from "drizzle-orm";
import TemplateShowcaseCard from "@/components/templates/TemplateShowcaseCard";
import type { TemplateRecord } from "@/lib/types";

export const dynamic = "force-dynamic";

async function getTemplates(): Promise<TemplateRecord[]> {
  await ensureTemplatesSeeded();
  const rows = await db.select().from(templates).orderBy(asc(templates.sortOrder));
  return rows as unknown as TemplateRecord[];
}

export default async function TemplatesPage() {
  const items = await getTemplates();
  const categories = Array.from(new Set(items.map((t) => t.category)));

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-white/5 bg-[#08090f]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400">
              <Captions className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-extrabold">زیرنویس‌ساز</span>
          </Link>
          <Link href="/dashboard" className="flex items-center gap-1.5 text-sm text-slate-300 hover:text-white">
            رفتن به پروژه‌ها
            <ArrowRight className="h-4 w-4 rotate-180" />
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-12">
        <h1 className="text-3xl font-extrabold md:text-4xl">گالری قالب‌های زیرنویس</h1>
        <p className="mt-3 max-w-2xl text-slate-400">
          بیش از {items.length} قالب آماده با استایل‌های متفاوت. روی هر قالب کلیک کن تا پیش‌نمایش زنده‌اش را ببینی و
          مستقیم یک پروژه جدید با آن استایل بسازی.
        </p>

        {categories.map((category) => (
          <section key={category} className="mt-12">
            <h2 className="mb-5 text-lg font-extrabold text-slate-200">{category}</h2>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {items
                .filter((t) => t.category === category)
                .map((template) => (
                  <TemplateShowcaseCard key={template.id} template={template} />
                ))}
            </div>
          </section>
        ))}
      </div>
    </main>
  );
}
