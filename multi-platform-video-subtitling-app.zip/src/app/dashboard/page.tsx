import { db } from "@/db";
import { captionSegments, projects } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import DashboardClient from "@/components/dashboard/DashboardClient";
import type { ProjectListItem } from "@/lib/types";

export const dynamic = "force-dynamic";

async function getProjects(): Promise<ProjectListItem[]> {
  const rows = await db
    .select({
      id: projects.id,
      title: projects.title,
      videoUrl: projects.videoUrl,
      videoName: projects.videoName,
      durationSeconds: projects.durationSeconds,
      aspectRatio: projects.aspectRatio,
      status: projects.status,
      templateId: projects.templateId,
      styleOverrides: projects.styleOverrides,
      createdAt: projects.createdAt,
      updatedAt: projects.updatedAt,
      captionsCount: sql<number>`count(${captionSegments.id})::int`,
    })
    .from(projects)
    .leftJoin(captionSegments, eq(captionSegments.projectId, projects.id))
    .groupBy(projects.id)
    .orderBy(desc(projects.updatedAt));

  return rows.map((row) => ({
    ...row,
    aspectRatio: row.aspectRatio as ProjectListItem["aspectRatio"],
    status: row.status as ProjectListItem["status"],
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  }));
}

export default async function DashboardPage() {
  const items = await getProjects();
  return <DashboardClient initialProjects={items} />;
}
