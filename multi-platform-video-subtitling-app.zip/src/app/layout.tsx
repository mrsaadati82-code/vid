import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "زیرنویس‌ساز | ابزار حرفه‌ای زیرنویس خودکار ویدیو",
  description:
    "زیرنویس‌ساز، ابزاری حرفه‌ای برای تولید خودکار زیرنویس، ویرایش تایم‌لاین و استفاده از قالب‌های آماده برای ویدیوهای شبکه‌های اجتماعی.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b0c14",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#08090f] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
