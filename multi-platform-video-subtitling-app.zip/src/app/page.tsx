import Image from "next/image";
import Link from "next/link";
import {
  Captions,
  Clapperboard,
  Download,
  Globe,
  Laptop,
  Layers,
  Monitor,
  Palette,
  Scissors,
  Smartphone,
  Sparkles,
  Type,
  UploadCloud,
  Wand2,
  Zap,
} from "lucide-react";

const FEATURES = [
  {
    icon: Wand2,
    title: "زیرنویس خودکار با هوش مصنوعی",
    desc: "صدای ویدیوی شما را در چند ثانیه به زیرنویس دقیق فارسی و چندزبانه تبدیل می‌کنیم.",
  },
  {
    icon: Type,
    title: "ویرایش متن و تایم‌بندی",
    desc: "هر بخش از زیرنویس را به‌صورت جداگانه ویرایش، جابه‌جا و زمان‌بندی کنید.",
  },
  {
    icon: Palette,
    title: "بیش از ۱۲ قالب حرفه‌ای",
    desc: "قالب‌های آماده کارائوکه، نئون، مینیمال و کلمه‌به‌کلمه، دقیقاً مثل ویدیوهای وایرال.",
  },
  {
    icon: Layers,
    title: "تایم‌لاین حرفه‌ای",
    desc: "تایم‌لاین دقیق برای جابه‌جایی، برش و هماهنگ‌سازی زیرنویس با تصویر و صدا.",
  },
  {
    icon: Sparkles,
    title: "انیمیشن‌های متنوع",
    desc: "افکت‌های فید، پاپ، کارائوکه، بانس و تایپ‌رایتر برای جذاب‌تر شدن محتوا.",
  },
  {
    icon: Scissors,
    title: "قاب‌های مختلف",
    desc: "پشتیبانی از ابعاد ۹:۱۶، ۱۶:۹، ۱:۱ و ۴:۵ برای هر شبکه اجتماعی.",
  },
  {
    icon: Download,
    title: "خروجی SRT / VTT / متن",
    desc: "فایل زیرنویس را برای استفاده در هر نرم‌افزار ادیت دیگری دانلود کنید.",
  },
  {
    icon: Zap,
    title: "سرعت فوق‌العاده",
    desc: "کل فرآیند از آپلود تا آماده شدن زیرنویس تنها چند دقیقه زمان می‌برد.",
  },
];

const STEPS = [
  { icon: UploadCloud, title: "۱. آپلود ویدیو", desc: "فایل ویدیویی یا صوتی خودتان را آپلود کنید." },
  { icon: Wand2, title: "۲. تولید خودکار زیرنویس", desc: "هوش مصنوعی گفتار را تشخیص داده و زیرنویس می‌سازد." },
  { icon: Palette, title: "۳. انتخاب قالب و شخصی‌سازی", desc: "استایل، فونت، رنگ و انیمیشن دلخواه را انتخاب کنید." },
  { icon: Clapperboard, title: "۴. ویرایش در تایم‌لاین", desc: "متن‌ها را دقیق کنید و همه‌چیز را در تایم‌لاین هماهنگ کنید." },
  { icon: Download, title: "۵. خروجی گرفتن", desc: "فایل زیرنویس یا پروژه نهایی را دریافت کنید." },
];

const TEMPLATE_PREVIEWS = [
  { name: "کارائوکه زرد", bg: "from-fuchsia-500/20 to-amber-400/20", text: "text-white", chip: "bg-amber-400 text-black" },
  { name: "نئون صورتی", bg: "from-pink-500/20 to-purple-600/20", text: "text-pink-400", chip: "bg-sky-300 text-black" },
  { name: "مینیمال سفید", bg: "from-slate-200/10 to-slate-400/10", text: "text-slate-100", chip: "bg-blue-500 text-white" },
  { name: "درشت و بولد", bg: "from-emerald-500/20 to-teal-500/20", text: "text-white", chip: "bg-emerald-400 text-black" },
];

const PLATFORMS = [
  { icon: Monitor, label: "ویندوز" },
  { icon: Laptop, label: "مک" },
  { icon: Globe, label: "وب" },
  { icon: Smartphone, label: "اندروید" },
];

export default function HomePage() {
  return (
    <main className="min-h-screen overflow-x-hidden">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-[#08090f]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400">
              <Captions className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-extrabold">زیرنویس‌ساز</span>
          </div>
          <nav className="hidden items-center gap-8 text-sm text-slate-300 md:flex">
            <a href="#features" className="hover:text-white">امکانات</a>
            <Link href="/templates" className="hover:text-white">قالب‌ها</Link>
            <a href="#how-it-works" className="hover:text-white">نحوه کار</a>
            <a href="#platforms" className="hover:text-white">پلتفرم‌ها</a>
          </nav>
          <div className="flex items-center gap-3">
            <Link
              href="/dashboard"
              className="rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2 text-sm font-bold text-slate-950 shadow-lg shadow-violet-500/30 transition hover:opacity-90"
            >
              شروع رایگان
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative mx-auto max-w-7xl px-6 pb-20 pt-16 md:pt-24">
        <div className="pointer-events-none absolute -top-40 right-1/4 h-96 w-96 rounded-full bg-violet-600/30 blur-[120px]" />
        <div className="pointer-events-none absolute -top-20 left-1/4 h-96 w-96 rounded-full bg-cyan-500/20 blur-[120px]" />

        <div className="relative grid items-center gap-12 md:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs text-slate-300">
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              نسخه حرفه‌ای ابزار زیرنویس‌گذاری خودکار
            </span>
            <h1 className="mt-6 text-4xl font-extrabold leading-[1.25] md:text-6xl md:leading-[1.15]">
              زیرنویس ویدیوهاتو
              <span className="text-gradient"> خودکار و حرفه‌ای </span>
              بساز
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-slate-300">
              یک استودیوی کامل زیرنویس‌گذاری با هوش مصنوعی، تایم‌لاین حرفه‌ای، ده‌ها قالب آماده و ابزارهای
              ویرایش متن؛ دقیقاً شبیه اپلیکیشن‌های محبوب بین‌المللی، اما کاملاً فارسی.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link
                href="/dashboard"
                className="rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-7 py-3.5 text-base font-bold text-slate-950 shadow-xl shadow-violet-500/30 transition hover:scale-[1.02]"
              >
                ساخت پروژه جدید
              </Link>
              <Link
                href="/templates"
                className="rounded-full border border-white/15 bg-white/5 px-7 py-3.5 text-base font-bold text-white transition hover:bg-white/10"
              >
                مشاهده قالب‌ها
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-8 text-sm text-slate-400">
              <div><span className="text-xl font-extrabold text-white">+۱۲</span> قالب حرفه‌ای</div>
              <div><span className="text-xl font-extrabold text-white">۴</span> پلتفرم (وب، ویندوز، مک، اندروید)</div>
              <div><span className="text-xl font-extrabold text-white">۱۰۰٪</span> رابط کاربری فارسی</div>
            </div>
          </div>

          <div className="relative">
            <div className="animate-pulse-glow rounded-[2rem] border border-white/10 bg-white/5 p-3 shadow-2xl">
              <Image
                src="/images/hero-mockup.png"
                alt="پیش‌نمایش اپلیکیشن زیرنویس‌ساز"
                width={900}
                height={900}
                className="h-auto w-full rounded-[1.5rem]"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-extrabold md:text-4xl">همه ابزارهایی که برای زیرنویس حرفه‌ای لازم داری</h2>
          <p className="mt-4 text-slate-400">
            از تشخیص خودکار گفتار تا شخصی‌سازی کامل ظاهر متن، همه در یک استودیوی ساده و سریع.
          </p>
        </div>
        <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature) => (
            <div
              key={feature.title}
              className="glass-panel rounded-2xl p-6 transition hover:-translate-y-1 hover:border-violet-400/30"
            >
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-violet-500/20 to-cyan-400/20 text-violet-300">
                <feature.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-bold text-white">{feature.title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Templates showcase */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-extrabold md:text-4xl">قالب‌های آماده و متنوع</h2>
            <p className="mt-3 text-slate-400">با یک کلیک، استایل حرفه‌ای برای زیرنویس خود انتخاب کن.</p>
          </div>
          <Link href="/templates" className="text-sm font-bold text-violet-300 hover:text-violet-200">
            مشاهده همه قالب‌ها ←
          </Link>
        </div>
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {TEMPLATE_PREVIEWS.map((t) => (
            <div
              key={t.name}
              className={`relative flex aspect-[9/13] flex-col justify-end overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br ${t.bg} p-4`}
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(255,255,255,0.08),transparent_60%)]" />
              <div className={`relative text-center text-xl font-extrabold leading-8 ${t.text}`}>
                این یک <span className={`rounded-md px-1.5 py-0.5 ${t.chip}`}>نمونه</span> از قالب است
              </div>
              <p className="relative mt-3 text-center text-xs font-bold text-white/80">{t.name}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-extrabold md:text-4xl">فقط در ۵ قدم ساده</h2>
        </div>
        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-5">
          {STEPS.map((step) => (
            <div key={step.title} className="glass-panel rounded-2xl p-6 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 text-slate-950">
                <step.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-sm font-bold text-white">{step.title}</h3>
              <p className="mt-2 text-xs leading-6 text-slate-400">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Cross platform */}
      <section id="platforms" className="mx-auto max-w-7xl px-6 py-20">
        <div className="glass-panel grid gap-10 rounded-3xl p-8 md:grid-cols-2 md:p-14">
          <div>
            <h2 className="text-3xl font-extrabold md:text-4xl">روی هر دستگاهی که دوست داری</h2>
            <p className="mt-4 leading-8 text-slate-400">
              زیرنویس‌ساز به‌صورت وب‌اپلیکیشن ساخته شده تا بتوانی به‌سادگی آن را به نرم‌افزار دسکتاپ برای
              ویندوز و مک (با Electron یا Tauri) و اپلیکیشن اندروید (با Capacitor) تبدیل کنی. سورس کد کاملاً
              باز و بدون بیلد در اختیار توست تا هر بخشی را با کمک هوش مصنوعی توسعه دهی.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              {PLATFORMS.map((p) => (
                <div key={p.label} className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm">
                  <p.icon className="h-4 w-4 text-cyan-300" />
                  {p.label}
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <Image
              src="/images/cross-platform.png"
              alt="اجرای اپلیکیشن روی ویندوز، مک، وب و اندروید"
              width={900}
              height={700}
              className="h-auto w-full rounded-2xl"
            />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-5xl px-6 pb-24">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-violet-600 via-fuchsia-600 to-cyan-500 p-10 text-center md:p-16">
          <h2 className="text-3xl font-extrabold text-white md:text-4xl">همین حالا اولین پروژه‌ات رو بساز</h2>
          <p className="mx-auto mt-4 max-w-xl text-white/90">
            بدون نیاز به نصب چیزی، از داخل مرورگر شروع کن و در چند دقیقه زیرنویس حرفه‌ای بساز.
          </p>
          <Link
            href="/dashboard"
            className="mt-8 inline-block rounded-full bg-slate-950 px-8 py-4 text-base font-bold text-white shadow-xl transition hover:scale-105"
          >
            شروع رایگان
          </Link>
        </div>
      </section>

      <footer className="border-t border-white/5 py-10 text-center text-sm text-slate-500">
        <p>© {new Date().getFullYear()} زیرنویس‌ساز — ابزار حرفه‌ای زیرنویس خودکار ویدیو</p>
      </footer>
    </main>
  );
}
