<?php
if ( ! defined('ABSPATH') ) exit;

class CPTT_Report {

	private static $instance = null;

	public static function instance() {
		if (self::$instance === null) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action('admin_post_cptt_view_report', [$this, 'render_report_page']);
		add_action('admin_post_cptt_view_invoice', [$this, 'render_invoice_page']);
	}

	public static function is_project_complete($project_id) {
		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps) || empty($steps)) return false;

		foreach ($steps as $s) {
			if (($s['status'] ?? 'todo') !== 'done') return false;
		}
		return true;
	}

	public static function user_can_access($project_id, $user_id) {
		$user_id = (int)$user_id;
		if (!$user_id) return false;

		if (user_can($user_id, 'manage_options')) return true;

		$client_id = (int)get_post_meta($project_id, '_cptt_client_user_id', true);
		if ($client_id && $client_id === $user_id) return true;

		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'get_project_expert_ids')) {
			$experts = CPTT_Core::get_project_expert_ids($project_id);
			if (in_array($user_id, $experts, true)) return true;
		}

		return false;
	}

	private function user_name($id) {
		$u = $id ? get_user_by('id', (int)$id) : null;
		return $u ? $u->display_name : '';
	}

	private function branding() {
		if (class_exists('CPTT_Settings') && method_exists('CPTT_Settings', 'get')) {
			return CPTT_Settings::get();
		}

		return [
			'brand_name'    => get_bloginfo('name'),
			'site_url'      => home_url('/'),
			'primary_color' => '#6366f1',
			'footer_text'   => 'این گزارش به صورت خودکار تولید شده است.',
			'logo_id'       => 0,
			'sign_id'       => 0,
			'stamp_id'      => 0,
			'manager_name'  => '',
			'manager_title' => '',
		];
	}

	private function att_url($id) {
		$id = (int)$id;
		if (!$id) return '';
		$url = wp_get_attachment_image_url($id, 'large');
		return $url ? $url : '';
	}

	public function render_report_page() {
		if (!is_user_logged_in()) wp_die('برای مشاهده گزارش باید وارد شوید.');

		$project_id = isset($_GET['project_id']) ? absint($_GET['project_id']) : 0;
		if (!$project_id || get_post_type($project_id) !== 'cptt_project') wp_die('پروژه معتبر نیست.');

		check_admin_referer('cptt_view_report_' . $project_id);

		if (!self::user_can_access($project_id, get_current_user_id())) wp_die('شما به این گزارش دسترسی ندارید.');
		/* v9.2.45 — گزارش دیگر منوط به تکمیل پروژه نیست؛ کاربر هر زمان
		   بخواهد بتواند گزارش بگیرد. */

		$brand = $this->branding();
		$primary = $brand['primary_color'] ?: '#6366f1';

		$title = get_the_title($project_id);
		$project_code = class_exists('CPTT_Core') ? CPTT_Core::get_project_code($project_id) : (string)$project_id;
		$created_fa = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime((int) current_time('timestamp', true)) : date('Y-m-d H:i');

		$client_id = (int)get_post_meta($project_id, '_cptt_client_user_id', true);
		$client_name = $client_id ? $this->user_name($client_id) : '';

		$expert_names = [];
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'get_project_expert_ids')) {
			$ids = CPTT_Core::get_project_expert_ids($project_id);
			foreach ($ids as $id) {
				$n = $this->user_name($id);
				if ($n) $expert_names[] = $n;
			}
		}

		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) $steps = [];

		$last_update = (string)get_post_meta($project_id, '_cptt_last_update_fa', true);

		$logo = $this->att_url($brand['logo_id'] ?? 0);
		$sign = $this->att_url($brand['sign_id'] ?? 0);
		$stamp = $this->att_url($brand['stamp_id'] ?? 0);

		if (class_exists('CPTT_Core')) {
			$total_for_invoice = 0; foreach ($steps as $_s) $total_for_invoice += (float)($_s['cost'] ?? 0);
			CPTT_Core::ensure_invoice($project_id, !empty($_GET['final']) ? 'final' : 'proforma', $total_for_invoice);
		}

		// Get toggles
		$toggles = class_exists('CPTT_Settings') && method_exists('CPTT_Settings', 'get_branding_toggles') ? CPTT_Settings::get_branding_toggles() : [];

		/* v9.9.0 — همان payload داشبورد کارشناس برای غنای گزارش (اطلاعات تکمیلی پروژه) */
		$pl = null;
		try {
			if (class_exists('CPTT_Expert') && method_exists('CPTT_Expert', 'instance')) {
				$pl = CPTT_Expert::instance()->build_public_project_payload($project_id, true, false);
			}
		} catch (\Throwable $e) { $pl = null; }

		$style_settings = class_exists('CPTT_Settings') ? CPTT_Settings::get_styles() : [];
		$font_family_opt = !empty($style_settings['font_family']) ? $style_settings['font_family'] : 'vazir';
		$base_url_font = CPTT_URL . 'assets/fonts/';
		$font_faces_css = '';
		$font_stack_css = "'Vazirmatn', Tahoma, sans-serif";

		if ($font_family_opt === 'dana') {
			$font_faces_css = "
				@font-face { font-family: 'Dana'; src: url('{$base_url_font}Dana/Dana-FaNum-Regular.ttf') format('truetype'); font-weight: 400; }
				@font-face { font-family: 'Dana'; src: url('{$base_url_font}Dana/Dana-FaNum-Medium.ttf') format('truetype'); font-weight: 500; }
				@font-face { font-family: 'Dana'; src: url('{$base_url_font}Dana/Dana-FaNum-Bold.ttf') format('truetype'); font-weight: 700; }
			";
			$font_stack_css = "'Dana', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'iransans') {
			$font_faces_css = "
				@font-face { font-family: 'IranSans'; src: url('{$base_url_font}iransans/IRANSansWeb(FaNum).woff2') format('woff2'); font-weight: 400; }
				@font-face { font-family: 'IranSans'; src: url('{$base_url_font}iransans/IRANSansWeb(FaNum)_Medium.woff2') format('woff2'); font-weight: 500; }
				@font-face { font-family: 'IranSans'; src: url('{$base_url_font}iransans/IRANSansWeb(FaNum)_Bold.woff2') format('woff2'); font-weight: 700; }
			";
			$font_stack_css = "'IranSans', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'iranyekan') {
			$font_faces_css = "
				@font-face { font-family: 'IranYekan'; src: url('{$base_url_font}iranyekan/IRANYekanX-Regular.woff2') format('woff2'); font-weight: 400; }
				@font-face { font-family: 'IranYekan'; src: url('{$base_url_font}iranyekan/IRANYekanX-Bold.woff2') format('woff2'); font-weight: 700; }
			";
			$font_stack_css = "'IranYekan', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'kalameh') {
			$font_faces_css = "
				@font-face { font-family: 'Kalameh'; src: url('{$base_url_font}kalameh/KalamehWebFaNum-Medium.woff2') format('woff2'); font-weight: 400; }
				@font-face { font-family: 'Kalameh'; src: url('{$base_url_font}kalameh/KalamehWebFaNum-Bold.woff2') format('woff2'); font-weight: 700; }
			";
			$font_stack_css = "'Kalameh', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'peyda') {
			$font_faces_css = "
				@font-face { font-family: 'Peyda'; src: url('{$base_url_font}peyda/PeydaWeb-Regular.woff') format('woff'); font-weight: 400; }
				@font-face { font-family: 'Peyda'; src: url('{$base_url_font}peyda/PeydaWeb-Bold.woff') format('woff'); font-weight: 700; }
			";
			$font_stack_css = "'Peyda', Tahoma, sans-serif";
		} else {
			$font_faces_css = "
				@font-face { font-family: 'Vazirmatn'; src: url('{$base_url_font}Vazirmatn-Regular.ttf') format('truetype'); font-weight: 400; }
				@font-face { font-family: 'Vazirmatn'; src: url('{$base_url_font}Vazirmatn-Bold.ttf') format('truetype'); font-weight: 700; }
			";
			$font_stack_css = "'Vazirmatn', Tahoma, sans-serif";
		}

		header('Content-Type: text/html; charset=utf-8');
		?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html('گزارش پروژه - ' . $title); ?></title>
	<style>
		<?php echo $font_faces_css; ?>
		:root{
			--primary: <?php echo esc_html($primary); ?>;
			--primary-light: rgba(99, 102, 241, 0.08);
			--text: #1e293b;
			--muted: #475569;
			--border: #cbd5e1;
			--bg: #f8fafc;
			--white: #ffffff;
		}
		*{ box-sizing:border-box; margin: 0; padding: 0; font-family: <?php echo $font_stack_css; ?> !important; }
		body{
			background: var(--bg);
			color: var(--text);
			font-family: <?php echo $font_stack_css; ?> !important;
			font-size: 13px;
			line-height: 1.7;
			padding: 20px 10px;
		}
		.wrap{
			max-width: 800px;
			margin: 0 auto;
			background: var(--white);
			border: 2px solid var(--border);
			border-radius: 16px;
			box-shadow: 0 10px 30px rgba(0,0,0,0.03);
			overflow: hidden;
		}
		.print-header {
			background: linear-gradient(135deg, var(--primary), #4f46e5);
			color: var(--white);
			padding: 20px 24px;
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			gap: 15px;
		}
		.brand-info {
			display: flex;
			align-items: center;
			gap: 14px;
		}
		.brand-logo-img {
			max-height: 50px;
			max-width: 150px;
			object-fit: contain;
			background: var(--white);
			border-radius: 8px;
			padding: 4px;
		}
		.brand-title {
			font-size: 16px;
			font-weight: 950;
		}
		.brand-url {
			font-size: 11px;
			opacity: 0.85;
		}
		.document-title-box {
			text-align: left;
		}
		.document-title {
			font-size: 18px;
			font-weight: 950;
			letter-spacing: -0.5px;
		}
		.document-date {
			font-size: 11px;
			opacity: 0.9;
			margin-top: 4px;
		}
		.actions-bar {
			background: #f1f5f9;
			border-bottom: 1px solid var(--border);
			padding: 10px 24px;
			display: flex;
			justify-content: space-between;
			align-items: center;
			gap: 10px;
			flex-wrap: wrap;
		}
		.btn {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			padding: 8px 14px;
			font-size: 12px;
			font-weight: 800;
			color: #334155;
			background: var(--white);
			border: 1px solid #cbd5e1;
			border-radius: 8px;
			cursor: pointer;
			text-decoration: none;
			transition: all 0.15s ease;
		}
		.btn:hover {
			background: #e2e8f0;
			border-color: #94a3b8;
		}
		.btn-primary {
			background: var(--primary);
			color: var(--white);
			border-color: transparent;
		}
		.btn-primary:hover {
			background: #4f46e5;
			color: var(--white);
		}
		.main-content {
			padding: 24px;
		}
		.metadata-grid {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 12px;
			margin-bottom: 20px;
		}
		@media (max-width: 580px) {
			.metadata-grid {
				grid-template-columns: 1fr;
			}
		}
		.metadata-box {
			border: 1px solid #e2e8f0;
			background: #f8fafc;
			border-radius: 12px;
			padding: 12px 16px;
		}
		.metadata-item {
			margin-bottom: 8px;
			font-size: 13px;
		}
		.metadata-item:last-child {
			margin-bottom: 0;
		}
		.metadata-item b {
			color: #0f172a;
			font-weight: 900;
		}
		.section-title {
			font-size: 15px;
			font-weight: 950;
			color: #0f172a;
			margin-bottom: 14px;
			padding-bottom: 6px;
			border-bottom: 2px solid var(--primary);
			display: inline-block;
		}
		.step-card {
			border: 1px solid #e2e8f0;
			border-radius: 12px;
			padding: 14px 18px;
			margin-bottom: 12px;
			background: var(--white);
		}
		.step-card:last-child {
			margin-bottom: 0;
		}
		.step-header {
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			gap: 10px;
			margin-bottom: 8px;
		}
		.step-name {
			font-size: 14px;
			font-weight: 950;
			color: #0f172a;
		}
		.badge {
			display: inline-flex;
			padding: 4px 10px;
			border-radius: 999px;
			font-size: 11px;
			font-weight: 900;
			border: 1px solid transparent;
		}
		.badge-done { background: rgba(34,197,94,0.12); color:#065f46; border-color: rgba(34,197,94,0.2); }
		.badge-current { background: rgba(245,158,11,0.12); color:#92400e; border-color: rgba(245,158,11,0.2); }
		.badge-todo { background: rgba(148,163,184,0.14); color:#475569; border-color: rgba(148,163,184,0.2); }
		
		.step-desc {
			color: #334155;
			font-size: 12.5px;
			margin: 8px 0;
			background: #f8fafc;
			padding: 10px 14px;
			border-radius: 8px;
			border-right: 3px solid #cbd5e1;
		}
		.step-meta-row {
			font-size: 11.5px;
			color: var(--muted);
			margin-top: 6px;
		}
		.list-title {
			font-weight: 900;
			font-size: 12px;
			color: #334155;
			margin: 12px 0 6px;
			display: flex;
			align-items: center;
			gap: 6px;
		}
		.items-list {
			list-style: none;
			padding: 0;
			margin: 0;
			display: grid;
			gap: 6px;
		}
		.items-list li {
			padding: 8px 12px;
			background: #fafafa;
			border: 1px solid #f1f5f9;
			border-radius: 8px;
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-wrap: wrap;
			gap: 10px;
		}
		.items-list li.done-item {
			background: #f0fdf4;
			border-color: #d1fae5;
			color: #065f46;
		}
		.item-text {
			font-weight: 700;
			font-size: 12.5px;
		}
		.item-meta {
			font-size: 11px;
			color: var(--muted);
		}
		.item-link {
			color: var(--primary);
			text-decoration: underline;
			font-weight: 800;
			font-size: 11px;
			margin-right: 6px;
		}
		.final-sign-box {
			margin-top: 24px;
			border: 1px solid #e2e8f0;
			border-radius: 12px;
			padding: 16px 20px;
			background: #f8fafc;
		}
		.sign-stamp-grid {
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-wrap: wrap;
			gap: 20px;
		}
		.sign-stamp-grid > div {
			flex: 1 1 200px;
			text-align: center;
		}
		.sign-img, .stamp-img {
			max-height: 80px;
			max-width: 180px;
			object-fit: contain;
			margin: 0 auto;
			display: block;
		}
		.sign-label {
			font-size: 12px;
			font-weight: bold;
			color: #334155;
			margin-top: 8px;
		}
		.sign-title {
			font-size: 11px;
			color: var(--muted);
			margin-top: 2px;
		}
		.print-footer {
			text-align: center;
			padding: 15px 24px;
			background: #f8fafc;
			border-top: 1px solid var(--border);
			font-size: 11px;
			color: var(--muted);
		}
		/* v9.2.46 — چاپ تطبیقی با اندازه‌ی کاغذ: A4 و A5 هر دو صفحه را کامل پر می‌کنند.
		   پیش‌فرض auto (کاغذ انتخابی چاپگر) + صفحات نام‌دار برای ابعاد دقیق. */
		@page { size: auto; margin: 9mm; }
		@page cpttA4 { size: A4 portrait; margin: 10mm; }
		@page cpttA5 { size: A5 portrait; margin: 7mm; }
		body.cptt-paper-a4 .wrap { page: cpttA4; }
		body.cptt-paper-a5 .wrap { page: cpttA5; }
		@media print {
			html, body { width: 100% !important; height: auto !important; min-height: 0 !important; overflow: visible !important; }
			body { background: #fff; padding: 0; margin: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
			.wrap { border: none; box-shadow: none; max-width: 100% !important; width: 100% !important; border-radius: 0; overflow: visible; }
			.actions-bar { display: none !important; }
			.step-card { break-inside: avoid; page-break-inside: avoid; }
			.final-sign-box { break-inside: avoid; page-break-inside: avoid; }
			.invoice-table, .items-list { width: 100% !important; }
		}
		/* A4: تایپوگرافی خوانا و متناسب با عرض A4 (پر شدن کامل صفحه) */
		@media print and (min-width: 170mm) {
			body.cptt-paper-a4, body:not(.cptt-paper-a5) { font-size: 12px; line-height: 1.7; }
			body.cptt-paper-a4 .brand-title, body:not(.cptt-paper-a5) .brand-title { font-size: 16px; }
			body.cptt-paper-a4 .document-title, body:not(.cptt-paper-a5) .document-title { font-size: 18px; }
			body.cptt-paper-a4 .metadata-item, body:not(.cptt-paper-a5) .metadata-item { font-size: 11.5px; }
			body.cptt-paper-a4 .item-text, body:not(.cptt-paper-a5) .item-text { font-size: 12.5px; }
			body.cptt-paper-a4 .brand-logo-img, body:not(.cptt-paper-a5) .brand-logo-img { max-height: 46px; max-width: 130px; }
			body.cptt-paper-a4 .sign-img, body.cptt-paper-a4 .stamp-img,
			body:not(.cptt-paper-a5) .sign-img, body:not(.cptt-paper-a5) .stamp-img { max-height: 68px; max-width: 150px; }
		}
		/* A5: چیدمان فشرده‌تر برای کاغذ کوچک */
		@media print {
			body.cptt-paper-a5 { font-size: 9.5px; line-height: 1.45; }
			body.cptt-paper-a5 .print-header { padding: 5mm 0 4mm; }
			body.cptt-paper-a5 .brand-title { font-size: 11px; }
			body.cptt-paper-a5 .document-title { font-size: 12px; }
			body.cptt-paper-a5 .brand-url, body.cptt-paper-a5 .document-date { font-size: 8px; }
			body.cptt-paper-a5 .brand-logo-img { max-height: 28px; max-width: 80px; }
			body.cptt-paper-a5 .metadata-item { font-size: 9px; }
			body.cptt-paper-a5 .item-text { font-size: 10.5px; }
			body.cptt-paper-a5 .sign-img, body.cptt-paper-a5 .stamp-img { max-height: 42px; max-width: 95px; }
		}
		.cptt-paper-switch { display: inline-flex; align-items: center; gap: 0; border: 1px solid var(--border, #e2e8f0); border-radius: 10px; overflow: hidden; vertical-align: middle; }
		.cptt-paper-switch .paper-btn { border: none; background: #fff; color: #64748b; font: inherit; font-size: 12px; font-weight: 800; padding: 8px 13px; cursor: pointer; }
		.cptt-paper-switch .paper-btn.is-active { background: var(--primary, #4f46e5); color: #fff; }

	/* v9.9.0: بخش‌های تفصیلی گزارش */
	.rp-progress { margin: 0 0 16px 0; }
	.rp-progress-track { height: 12px; background: #e5e7eb; border-radius: 999px; overflow: hidden; }
	.rp-progress-track i { display: block; height: 100%; background: linear-gradient(90deg, #22c55e, #16a34a); border-radius: 999px; }
	.rp-progress-meta { display: flex; justify-content: space-between; margin-top: 6px; font-size: 12px; color: var(--text-secondary); }
	.rp-progress-meta strong { color: #166534; font-size: 14px; }
	.rp-finrow { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; margin-bottom: 16px; }
	.rp-finbox { background: #f9fafb; border: 1px solid var(--border); border-radius: 10px; padding: 12px 14px; }
	.rp-finbox .l { display: block; font-size: 11px; color: var(--text-secondary); margin-bottom: 6px; }
	.rp-finbox b { font-size: 15px; font-variant-numeric: tabular-nums; }
	.rp-finbox b small { font-size: 11px; font-weight: 400; color: var(--text-secondary); }
	.rp-finbox.ok b { color: #166534; }
	.rp-finbox.warn b { color: #b45309; }
	.rp-notes { display: grid; gap: 10px; margin-bottom: 18px; }
	.rp-note { background: #f9fafb; border: 1px solid var(--border); border-radius: 10px; padding: 12px 14px; }
	.rp-note-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 12px; color: var(--text-secondary); }
	.rp-note-head strong { color: var(--text-primary); font-size: 13px; }
	.rp-note-body { font-size: 13px; color: var(--text-primary); }
	.rp-note-body p { margin: 0 0 6px 0; }
	@media (max-width: 640px) { .rp-finrow { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
	@media print {
		.rp-finrow { grid-template-columns: repeat(4, minmax(0, 1fr)) !important; gap: 5px; }
		.rp-finbox { padding: 6px 8px; border-radius: 8px; }
		.rp-finbox b { font-size: 11px; }
		.rp-progress-track { background: #eee; }
	}
	</style>
</head>
<body>
	<div class="wrap">
		<!-- Header -->
		<div class="print-header">
			<div class="brand-info">
				<?php if ($logo && ($toggles['report_show_logo'] ?? '1') === '1'): ?>
					<img src="<?php echo esc_url($logo); ?>" class="brand-logo-img" alt="logo" />
				<?php endif; ?>
				<div>
					<div class="brand-title"><?php echo esc_html($brand['brand_name'] ?? get_bloginfo('name')); ?></div>
					<div class="brand-url"><?php echo esc_html($brand['site_url'] ?? home_url('/')); ?></div>
				</div>
			</div>
			<div class="document-title-box">
				<div class="document-title">گزارش نهایی پروژه</div>
				<?php if (($toggles['report_show_dates'] ?? '1') === '1'): ?>
					<div class="document-date">تاریخ صدور: <?php echo esc_html($created_fa); ?></div>
				<?php endif; ?>
			</div>
		</div>

		<!-- Actions -->
		<div class="actions-bar">
			<a class="btn" href="<?php echo esc_url(wp_get_referer() ?: home_url('/')); ?>">◀ بازگشت</a>
			<div>
				<?php /* v9.2.45 — دکمه‌ی «پیش‌فاکتور» از روی کارت پروژه به اینجا منتقل شد */ ?>
				<a class="btn" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=cptt_view_invoice&project_id=' . $project_id), 'cptt_view_invoice_' . $project_id)); ?>" target="_blank">📄 پیش‌فاکتور</a>
				<a class="btn" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=cptt_view_invoice&project_id=' . $project_id . '&final=1'), 'cptt_view_invoice_' . $project_id)); ?>" target="_blank">🧾 فاکتور</a>
				<?php /* v9.2.46 — انتخاب اندازه‌ی کاغذ پیش از چاپ (A4/A5 هر دو صفحه را پر می‌کنند) */ ?>
				<span class="cptt-paper-switch" role="group" aria-label="اندازه کاغذ چاپ">
					<button class="paper-btn" type="button" data-paper="a4">A4</button>
					<button class="paper-btn" type="button" data-paper="a5">A5</button>
				</span>
				<button class="btn btn-primary" type="button" onclick="window.print()">🖨 چاپ گزارش</button>
			</div>
		</div>
		<script>
		(function(){
			var KEY='cptt_print_paper';
			function setPaper(p){
				document.body.classList.toggle('cptt-paper-a4', p==='a4');
				document.body.classList.toggle('cptt-paper-a5', p==='a5');
				document.querySelectorAll('.paper-btn').forEach(function(b){ b.classList.toggle('is-active', b.getAttribute('data-paper')===p); });
				try{ localStorage.setItem(KEY,p); }catch(e){}
			}
			var init='a4'; try{ init=localStorage.getItem(KEY)||'a4'; }catch(e){}
			setPaper(init);
			document.querySelectorAll('.paper-btn').forEach(function(b){ b.addEventListener('click', function(){ setPaper(b.getAttribute('data-paper')); }); });
		})();
		</script>

		<!-- Main -->
		<div class="main-content">
			<!-- Meta details -->
			<div class="metadata-grid">
				<div class="metadata-box">
					<div class="metadata-item"><b>عنوان پروژه:</b> <?php echo esc_html($title); ?></div>
					<div class="metadata-item"><b>کد پیگیری:</b> #<?php echo esc_html($project_code); ?></div>
					<?php if ($client_name && ($toggles['report_show_client'] ?? '1') === '1'): ?>
						<div class="metadata-item"><b>مشتری:</b> <?php echo esc_html($client_name); ?></div>
					<?php endif; ?>
				</div>
				<div class="metadata-box">
					<?php if (!empty($expert_names) && ($toggles['report_show_experts'] ?? '1') === '1'): ?>
						<div class="metadata-item"><b>کارشناسان:</b> <?php echo esc_html(implode('، ', $expert_names)); ?></div>
					<?php endif; ?>
					<?php if ($last_update && (($toggles['report_show_dates'] ?? '1') === '1')): ?>
						<div class="metadata-item"><b>آخرین تغییر:</b> <?php echo esc_html($last_update); ?></div>
					<?php endif; ?>
				</div>
			</div>

		<?php if (is_array($pl)) :
			$__prog = isset($pl['progress']) && is_array($pl['progress']) ? $pl['progress'] : array('percent' => 0, 'done' => 0, 'total' => 0);
			$__fin = isset($pl['financial']) && is_array($pl['financial']) ? $pl['financial'] : array('cost' => 0, 'paid' => 0, 'remain' => 0);
			$__cats = isset($pl['categories']) && is_array($pl['categories']) ? $pl['categories'] : array();
			$__steps_pl = isset($pl['steps']) && is_array($pl['steps']) ? $pl['steps'] : array();
		?>
			<!-- v9.9.0: اطلاعات تکمیلی پروژه (همان داده‌های پاپ‌آپ «مشاهده جزئیات» ویترین) -->
			<div class="metadata-grid rp-extra">
				<div class="metadata-box">
					<?php if (($toggles['report_show_client'] ?? '1') === '1' && !empty($pl['customer_phone'])) : ?>
						<div class="metadata-item"><b>تلفن مشتری:</b> <span dir="ltr"><?php echo esc_html($pl['customer_phone']); ?></span></div>
					<?php endif; ?>
					<?php if (($toggles['report_show_client'] ?? '1') === '1' && !empty($pl['customer_email'])) : ?>
						<div class="metadata-item"><b>ایمیل مشتری:</b> <span dir="ltr"><?php echo esc_html($pl['customer_email']); ?></span></div>
					<?php endif; ?>
					<?php if (!empty($pl['product'])) : ?>
						<div class="metadata-item"><b>محصول:</b> <?php echo esc_html($pl['product']); ?></div>
					<?php endif; ?>
				</div>
				<div class="metadata-box">
					<?php if (!empty($__cats)) : ?>
						<div class="metadata-item"><b>دسته‌بندی:</b> <?php echo esc_html(implode('، ', $__cats)); ?></div>
					<?php endif; ?>
					<?php if (!empty($pl['deadline'])) : ?>
						<div class="metadata-item"><b>ددلاین:</b> <?php echo esc_html((string) $pl['deadline']); ?></div>
					<?php endif; ?>
					<?php if (($toggles['report_show_dates'] ?? '1') === '1' && !empty($pl['start_fa'])) : ?>
						<div class="metadata-item"><b>تاریخ شروع:</b> <?php echo esc_html($pl['start_fa']); ?></div>
					<?php endif; ?>
				</div>
			</div>

			<div class="section-title">پیشرفت کلی پروژه</div>
			<div class="rp-progress">
				<div class="rp-progress-track"><i style="width: <?php echo (int) $__prog['percent']; ?>%;"></i></div>
				<div class="rp-progress-meta">
					<strong><?php echo (int) $__prog['percent']; ?>٪</strong>
					<span><?php echo (int) $__prog['done']; ?> از <?php echo (int) $__prog['total']; ?> مرحله انجام شده</span>
				</div>
			</div>

			<?php if (($toggles['report_show_finance'] ?? '1') === '1') : ?>
				<div class="section-title">خلاصه مالی پروژه</div>
				<div class="rp-finrow">
					<div class="rp-finbox"><span class="l">مبلغ کل</span><b><?php echo function_exists('cptt_format_money') ? esc_html(cptt_format_money((float) $__fin['cost'])) : esc_html(number_format((float) $__fin['cost'])); ?> <small>تومان</small></b></div>
					<div class="rp-finbox ok"><span class="l">پرداخت‌شده</span><b><?php echo function_exists('cptt_format_money') ? esc_html(cptt_format_money((float) $__fin['paid'])) : esc_html(number_format((float) $__fin['paid'])); ?> <small>تومان</small></b></div>
					<div class="rp-finbox <?php echo (float) $__fin['remain'] > 0 ? 'warn' : 'ok'; ?>"><span class="l">مانده</span><b><?php echo function_exists('cptt_format_money') ? esc_html(cptt_format_money((float) $__fin['remain'])) : esc_html(number_format((float) $__fin['remain'])); ?> <small>تومان</small></b></div>
					<div class="rp-finbox"><span class="l">تسویه مراحل</span><b><?php echo (int) ($pl['settled'] ?? 0); ?> / <?php echo (int) $__prog['total']; ?></b></div>
				</div>
			<?php endif; ?>

			<?php
				$__has_delivery = !empty($pl['delivery_method_label']) || !empty($pl['delivery_province']) || !empty($pl['delivery_city']) || !empty($pl['delivery_address']);
			?>
			<?php if ($__has_delivery) : ?>
				<div class="section-title">تحویل پروژه</div>
				<div class="metadata-grid">
					<div class="metadata-box">
						<?php if (!empty($pl['delivery_method_label'])) : ?><div class="metadata-item"><b>روش تحویل:</b> <?php echo esc_html((string) $pl['delivery_method_label']); ?></div><?php endif; ?>
						<?php if (!empty($pl['delivery_province'])) : ?><div class="metadata-item"><b>استان:</b> <?php echo esc_html((string) $pl['delivery_province']); ?></div><?php endif; ?>
					</div>
					<div class="metadata-box">
						<?php if (!empty($pl['delivery_city'])) : ?><div class="metadata-item"><b>شهر:</b> <?php echo esc_html((string) $pl['delivery_city']); ?></div><?php endif; ?>
						<?php if (!empty($pl['delivery_address'])) : ?><div class="metadata-item"><b>آدرس:</b> <?php echo esc_html((string) $pl['delivery_address']); ?></div><?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if (!empty($pl['notes']) && is_array($pl['notes'])) : ?>
				<div class="section-title">یادداشت‌ها</div>
				<div class="rp-notes">
					<?php foreach (array_slice($pl['notes'], 0, 10) as $__n) : ?>
						<div class="rp-note">
							<div class="rp-note-head"><strong><?php echo esc_html(isset($__n['author']) ? $__n['author'] : ''); ?></strong><span><?php echo esc_html(isset($__n['time_fa']) ? $__n['time_fa'] : ''); ?></span></div>
							<div class="rp-note-body"><?php echo wp_kses_post(wpautop(isset($__n['content']) ? (string) $__n['content'] : '')); ?></div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>

			<!-- Steps -->
			<div class="section-title">روند انجام مراحل پروژه</div>
			<div class="steps-container">
				<?php foreach ($steps as $idx => $s):
					$st = $s['status'] ?? 'todo';
					$badgeClass = $st === 'done' ? 'badge-done' : ($st === 'current' ? 'badge-current' : 'badge-todo');
					$badgeText  = $st === 'done' ? 'انجام‌شده' : ($st === 'current' ? 'در حال انجام' : 'انجام‌نشده');

					$step_due_fa = (string)($s['due_at_fa'] ?? '');
					$desc = trim(wp_strip_all_tags((string)($s['desc'] ?? '')));

					$cl = isset($s['checklist']) && is_array($s['checklist']) ? $s['checklist'] : [];
					$uts = isset($s['user_tasks']) && is_array($s['user_tasks']) ? $s['user_tasks'] : [];
				?>
					<div class="step-card">
						<div class="step-header">
							<div class="step-name"><?php echo esc_html(($idx+1) . '. ' . ($s['title'] ?? '')); ?></div>
							<span class="badge <?php echo esc_attr($badgeClass); ?>"><?php echo esc_html($badgeText); ?></span>
						</div>

						<?php if ($step_due_fa && (($toggles['report_show_dates'] ?? '1') === '1')): ?>
							<div class="step-meta-row">📅 <b>مهلت مرحله:</b> <?php echo esc_html($step_due_fa); ?></div>
						<?php endif; ?>

						<?php if ($desc !== ''): ?>
							<div class="step-desc"><?php echo esc_html($desc); ?></div>
						<?php endif; ?>

					<?php
						$__rp_step = (is_array($pl) && isset($__steps_pl[$idx]) && is_array($__steps_pl[$idx])) ? $__steps_pl[$idx] : array();
						$__rp_experts = isset($__rp_step['experts']) && is_array($__rp_step['experts']) ? $__rp_step['experts'] : array();
					?>
					<?php if (!empty($__rp_experts) && ($toggles['report_show_experts'] ?? '1') === '1') : ?>
						<div class="step-meta-row">🧑‍💼 <b>کارشناسان مرحله:</b> <?php echo esc_html(implode('، ', wp_list_pluck($__rp_experts, 'name'))); ?></div>
					<?php endif; ?>
					<?php
						$__rp_cost = (float) ($__rp_step['cost'] ?? 0);
						$__rp_paid = (float) ($__rp_step['paid'] ?? 0);
						$__rp_remain = max(0.0, $__rp_cost - $__rp_paid);
					?>
					<?php if (!empty($__rp_step) && ($toggles['report_show_finance'] ?? '1') === '1' && ($__rp_cost > 0 || $__rp_paid > 0)) : ?>
						<div class="step-meta-row">
							💰 <b>مبلغ مرحله:</b> <?php echo function_exists('cptt_format_money') ? esc_html(cptt_format_money($__rp_cost)) : esc_html(number_format($__rp_cost)); ?> تومان
							&nbsp;|&nbsp; <b>پرداخت‌شده:</b> <?php echo function_exists('cptt_format_money') ? esc_html(cptt_format_money($__rp_paid)) : esc_html(number_format($__rp_paid)); ?> تومان
							<?php if ($__rp_remain > 0) : ?>&nbsp;|&nbsp; <b>مانده:</b> <?php echo function_exists('cptt_format_money') ? esc_html(cptt_format_money($__rp_remain)) : esc_html(number_format($__rp_remain)); ?> تومان<?php endif; ?>
						</div>
					<?php endif; ?>

						<!-- Checklist -->
						<?php if (!empty($cl) && ($toggles['report_show_checklist'] ?? '1') === '1'): ?>
							<div class="list-title">📋 چک‌لیست مرحله:</div>
							<ul class="items-list">
								<?php foreach ($cl as $it):
									$text = (string)($it['text'] ?? '');
									if ($text === '') continue;

									$done = !empty($it['done']);
									$done_at = (string)($it['done_at_fa'] ?? '');
									$url = trim((string)($it['url'] ?? ''));
								?>
									<li class="<?php echo $done ? 'done-item' : ''; ?>">
										<span class="item-text"><?php echo esc_html($text); ?></span>
										<div class="item-meta">
											<?php if ($done): ?>
												<span>✓ انجام شد</span>
												<?php if ($done_at && (($toggles['report_show_dates'] ?? '1') === '1')): ?>
													<span>(<?php echo esc_html($done_at); ?>)</span>
												<?php endif; ?>
												<?php if ($url && (strpos($url, 'http') === 0)): ?>
													<a href="<?php echo esc_url($url); ?>" class="item-link" target="_blank" rel="noopener">دانلود نتیجه</a>
												<?php endif; ?>
											<?php else: ?>
												<span>—</span>
											<?php endif; ?>
										</div>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>

						<!-- Customer Tasks -->
						<?php if (!empty($uts) && ($toggles['report_show_usertasks'] ?? '1') === '1'): ?>
							<div class="list-title">👤 تسک‌های سمت مشتری:</div>
							<ul class="items-list">
								<?php foreach ($uts as $ut):
									$ut_title = (string)($ut['title'] ?? '');
									if ($ut_title === '') continue;
									$ut_done = !empty($ut['done']);
									$ut_resp = (string)($ut['response'] ?? '');
									$ut_completed = (string)($ut['completed_at_fa'] ?? '');
									$ut_file_url = trim((string)($ut['response_file_url'] ?? ''));
									$ut_files = isset($ut['response_files']) && is_array($ut['response_files']) ? $ut['response_files'] : [];
								?>
									<li class="<?php echo $ut_done ? 'done-item' : ''; ?>">
										<div>
											<span class="item-text"><?php echo esc_html($ut_title); ?></span>
											<?php if ($ut_resp): ?><div style="font-size:11px; margin-top:3px; opacity:0.8;"><?php echo esc_html($ut_resp); ?></div><?php endif; ?>
										</div>
										<div class="item-meta">
											<?php if ($ut_done): ?>
												<span>✓ تکمیل شد</span>
												<?php if ($ut_completed && (($toggles['report_show_dates'] ?? '1') === '1')): ?>
													<span>(<?php echo esc_html($ut_completed); ?>)</span>
												<?php endif; ?>
												<?php if ($ut_file_url && (strpos($ut_file_url, 'http') === 0)): ?>
													<a href="<?php echo esc_url($ut_file_url); ?>" class="item-link" target="_blank" rel="noopener">مشاهده فایل</a>
												<?php endif; ?>
												<?php if (!empty($ut_files)): foreach ($ut_files as $rf): if (empty($rf['url'])) continue; ?>
													<a href="<?php echo esc_url($rf['url']); ?>" class="item-link" target="_blank" rel="noopener"><?php echo esc_html(!empty($rf['name']) ? $rf['name'] : 'فایل ارسالی'); ?></a>
												<?php endforeach; endif; ?>
											<?php else: ?>
												<span>در انتظار اقدام مشتری</span>
											<?php endif; ?>
										</div>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<!-- Approvals sign/stamp -->
			<?php if ((($toggles['report_show_sign_stamp'] ?? '1') === '1') && ($sign || $stamp || !empty($brand['manager_name']) || !empty($brand['manager_title']))): ?>
				<div class="final-sign-box">
					<div class="sign-stamp-grid">
						<div>
							<?php if ($sign): ?>
								<img src="<?php echo esc_url($sign); ?>" class="sign-img" alt="signature" />
							<?php endif; ?>
							<div class="sign-label"><?php echo esc_html($brand['manager_name'] ?: 'امضا مدیر مسئول'); ?></div>
							<?php if (!empty($brand['manager_title'])): ?>
								<div class="sign-title"><?php echo esc_html($brand['manager_title']); ?></div>
							<?php endif; ?>
						</div>
						<div>
							<?php if ($stamp): ?>
								<img src="<?php echo esc_url($stamp); ?>" class="stamp-img" alt="stamp" />
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>

		<!-- Footer -->
		<div class="print-footer">
			<?php echo esc_html($brand['footer_text'] ?? ''); ?>
		</div>
	</div>
</body>
</html>
		<?php
		exit;
	}

	public function render_invoice_page() {
		if (!is_user_logged_in()) wp_die('برای مشاهده پیش‌فاکتور باید وارد شوید.');

		$project_id = isset($_GET['project_id']) ? absint($_GET['project_id']) : 0;
		if (!$project_id || get_post_type($project_id) !== 'cptt_project') wp_die('پروژه معتبر نیست.');

		check_admin_referer('cptt_view_invoice_' . $project_id);

		if (!self::user_can_access($project_id, get_current_user_id())) wp_die('شما به این پیش‌فاکتور دسترسی ندارید.');
		$is_final_invoice = !empty($_GET['final']);
		$invoice_title = $is_final_invoice ? 'فاکتور نهایی پروژه' : 'پیش‌فاکتور پروژه';
		$invoice_short = $is_final_invoice ? 'فاکتور' : 'پیش‌فاکتور';

		$brand = $this->branding();
		$primary = $brand['primary_color'] ?: '#6366f1';

		$title = get_the_title($project_id);
		$project_code = class_exists('CPTT_Core') ? CPTT_Core::get_project_code($project_id) : (string)$project_id;
		$created_fa = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime((int) current_time('timestamp', true)) : date('Y-m-d H:i');

		$client_id = (int)get_post_meta($project_id, '_cptt_client_user_id', true);
		$client_name = $client_id ? $this->user_name($client_id) : '';
		$client_phone = $client_id ? get_user_meta($client_id, 'billing_phone', true) : '';

		$expert_names = [];
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'get_project_expert_ids')) {
			$ids = CPTT_Core::get_project_expert_ids($project_id);
			foreach ($ids as $id) {
				$n = $this->user_name($id);
				if ($n) $expert_names[] = $n;
			}
		}

		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) $steps = [];

		$logo = $this->att_url($brand['logo_id'] ?? 0);
		$sign = $this->att_url($brand['sign_id'] ?? 0);
		$stamp = $this->att_url($brand['stamp_id'] ?? 0);

		// Get delivery details
		$delivery_method = (string)get_post_meta($project_id, '_cptt_delivery_method', true);
		$delivery_method_label = $delivery_method === 'shipping' ? 'ارسال با پست/باربری' : ($delivery_method === 'in_person' ? 'تحویل حضوری' : '—');
		$delivery_province = (string)get_post_meta($project_id, '_cptt_delivery_province', true);
		$delivery_city = (string)get_post_meta($project_id, '_cptt_delivery_city', true);
		$delivery_address = (string)get_post_meta($project_id, '_cptt_delivery_address', true);

		// Get toggles
		$toggles = class_exists('CPTT_Settings') && method_exists('CPTT_Settings', 'get_branding_toggles') ? CPTT_Settings::get_branding_toggles() : [];

		$style_settings = class_exists('CPTT_Settings') ? CPTT_Settings::get_styles() : [];
		$font_family_opt = !empty($style_settings['font_family']) ? $style_settings['font_family'] : 'vazir';
		$base_url_font = CPTT_URL . 'assets/fonts/';
		$font_faces_css = '';
		$font_stack_css = "'Vazirmatn', Tahoma, sans-serif";

		if ($font_family_opt === 'dana') {
			$font_faces_css = "
				@font-face { font-family: 'Dana'; src: url('{$base_url_font}Dana/Dana-FaNum-Regular.ttf') format('truetype'); font-weight: 400; }
				@font-face { font-family: 'Dana'; src: url('{$base_url_font}Dana/Dana-FaNum-Medium.ttf') format('truetype'); font-weight: 500; }
				@font-face { font-family: 'Dana'; src: url('{$base_url_font}Dana/Dana-FaNum-Bold.ttf') format('truetype'); font-weight: 700; }
			";
			$font_stack_css = "'Dana', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'iransans') {
			$font_faces_css = "
				@font-face { font-family: 'IranSans'; src: url('{$base_url_font}iransans/IRANSansWeb(FaNum).woff2') format('woff2'); font-weight: 400; }
				@font-face { font-family: 'IranSans'; src: url('{$base_url_font}iransans/IRANSansWeb(FaNum)_Medium.woff2') format('woff2'); font-weight: 500; }
				@font-face { font-family: 'IranSans'; src: url('{$base_url_font}iransans/IRANSansWeb(FaNum)_Bold.woff2') format('woff2'); font-weight: 700; }
			";
			$font_stack_css = "'IranSans', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'iranyekan') {
			$font_faces_css = "
				@font-face { font-family: 'IranYekan'; src: url('{$base_url_font}iranyekan/IRANYekanX-Regular.woff2') format('woff2'); font-weight: 400; }
				@font-face { font-family: 'IranYekan'; src: url('{$base_url_font}iranyekan/IRANYekanX-Bold.woff2') format('woff2'); font-weight: 700; }
			";
			$font_stack_css = "'IranYekan', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'kalameh') {
			$font_faces_css = "
				@font-face { font-family: 'Kalameh'; src: url('{$base_url_font}kalameh/KalamehWebFaNum-Medium.woff2') format('woff2'); font-weight: 400; }
				@font-face { font-family: 'Kalameh'; src: url('{$base_url_font}kalameh/KalamehWebFaNum-Bold.woff2') format('woff2'); font-weight: 700; }
			";
			$font_stack_css = "'Kalameh', Tahoma, sans-serif";
		} elseif ($font_family_opt === 'peyda') {
			$font_faces_css = "
				@font-face { font-family: 'Peyda'; src: url('{$base_url_font}peyda/PeydaWeb-Regular.woff') format('woff'); font-weight: 400; }
				@font-face { font-family: 'Peyda'; src: url('{$base_url_font}peyda/PeydaWeb-Bold.woff') format('woff'); font-weight: 700; }
			";
			$font_stack_css = "'Peyda', Tahoma, sans-serif";
		} else {
			$font_faces_css = "
				@font-face { font-family: 'Vazirmatn'; src: url('{$base_url_font}Vazirmatn-Regular.ttf') format('truetype'); font-weight: 400; }
				@font-face { font-family: 'Vazirmatn'; src: url('{$base_url_font}Vazirmatn-Bold.ttf') format('truetype'); font-weight: 700; }
			";
			$font_stack_css = "'Vazirmatn', Tahoma, sans-serif";
		}

		header('Content-Type: text/html; charset=utf-8');
		?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html($invoice_short . ' - ' . $title); ?></title>
	<style>
		<?php echo $font_faces_css; ?>
		:root{
			--primary: <?php echo esc_html($primary); ?>;
			--text: #1e293b;
			--muted: #475569;
			--border: #cbd5e1;
			--bg: #f8fafc;
			--white: #ffffff;
		}
		*{ box-sizing:border-box; margin: 0; padding: 0; font-family: <?php echo $font_stack_css; ?> !important; }
		body{
			background: var(--bg);
			color: var(--text);
			font-family: <?php echo $font_stack_css; ?> !important;
			font-size: 13px;
			line-height: 1.7;
			padding: 20px 10px;
		}
		.wrap{
			max-width: 800px;
			margin: 0 auto;
			background: var(--white);
			border: 2px solid var(--border);
			border-radius: 16px;
			box-shadow: 0 10px 30px rgba(0,0,0,0.03);
			overflow: hidden;
		}
		.print-header {
			background: linear-gradient(135deg, var(--primary), #4f46e5);
			color: var(--white);
			padding: 20px 24px;
			display: flex;
			align-items: center;
			justify-content: space-between;
			flex-wrap: wrap;
			gap: 15px;
		}
		.brand-info {
			display: flex;
			align-items: center;
			gap: 14px;
		}
		.brand-logo-img {
			max-height: 50px;
			max-width: 150px;
			object-fit: contain;
			background: var(--white);
			border-radius: 8px;
			padding: 4px;
		}
		.brand-title {
			font-size: 16px;
			font-weight: 950;
		}
		.brand-url {
			font-size: 11px;
			opacity: 0.85;
		}
		.document-title-box {
			text-align: left;
		}
		.document-title {
			font-size: 18px;
			font-weight: 950;
			letter-spacing: -0.5px;
		}
		.document-date {
			font-size: 11px;
			opacity: 0.9;
			margin-top: 4px;
		}
		.actions-bar {
			background: #f1f5f9;
			border-bottom: 1px solid var(--border);
			padding: 10px 24px;
			display: flex;
			justify-content: space-between;
			align-items: center;
			gap: 10px;
			flex-wrap: wrap;
		}
		.btn {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			padding: 8px 14px;
			font-size: 12px;
			font-weight: 800;
			color: #334155;
			background: var(--white);
			border: 1px solid #cbd5e1;
			border-radius: 8px;
			cursor: pointer;
			text-decoration: none;
			transition: all 0.15s ease;
		}
		.btn:hover {
			background: #e2e8f0;
			border-color: #94a3b8;
		}
		.btn-primary {
			background: var(--primary);
			color: var(--white);
			border-color: transparent;
		}
		.btn-primary:hover {
			background: #4f46e5;
			color: var(--white);
		}
		.main-content {
			padding: 24px;
		}
		.metadata-grid {
			display: grid;
			grid-template-columns: 1.2fr 0.8fr;
			gap: 12px;
			margin-bottom: 20px;
		}
		@media (max-width: 580px) {
			.metadata-grid {
				grid-template-columns: 1fr;
			}
		}
		.metadata-box {
			border: 1px solid #e2e8f0;
			background: #f8fafc;
			border-radius: 12px;
			padding: 12px 16px;
		}
		.metadata-item {
			margin-bottom: 6px;
			font-size: 13px;
		}
		.metadata-item:last-child {
			margin-bottom: 0;
		}
		.metadata-item b {
			color: #0f172a;
			font-weight: 900;
		}
		.invoice-table {
			width: 100%;
			border-collapse: collapse;
			margin: 20px 0;
			table-layout: fixed;
		}
		.invoice-table .col-desc{width:34%;}
		.invoice-table .col-unit{width:13%;}
		.invoice-table .col-qty{width:8%;}
		.invoice-table .col-total{width:15%;}
		.invoice-table .col-paid{width:15%;}
		.invoice-table .col-remain{width:15%;}
		.invoice-table th, .invoice-table td {
			border: 1px solid var(--border);
			padding: 10px 14px;
			text-align: right;
		}
		.invoice-table th {
			background: #f1f5f9;
			font-weight: 900;
			color: #0f172a;
		}
		.text-left { text-align: left !important; }
		.text-center { text-align: center !important; }
		.totals-row {
			font-weight: bold;
			background: #f8fafc;
		}
		.totals-row td {
			font-size: 13.5px;
			border-top: 2px solid var(--primary);
		}
		.final-sign-box {
			margin-top: 24px;
			border: 1px solid #e2e8f0;
			border-radius: 12px;
			padding: 16px 20px;
			background: #f8fafc;
		}
		.sign-stamp-grid {
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-wrap: wrap;
			gap: 20px;
		}
		.sign-stamp-grid > div {
			flex: 1 1 200px;
			text-align: center;
		}
		.sign-img, .stamp-img {
			max-height: 80px;
			max-width: 180px;
			object-fit: contain;
			margin: 0 auto;
			display: block;
		}
		.sign-label {
			font-size: 12px;
			font-weight: bold;
			color: #334155;
			margin-top: 8px;
		}
		.sign-title {
			font-size: 11px;
			color: var(--muted);
			margin-top: 2px;
		}
		.print-footer {
			text-align: center;
			padding: 15px 24px;
			background: #f8fafc;
			border-top: 1px solid var(--border);
			font-size: 11px;
			color: var(--muted);
		}
		/* v9.2.46 — چاپ تطبیقی با اندازه‌ی کاغذ. قبلاً @page ثابت A5 بود و در نتیجه
		   هنگام چاپ روی A4 محتوا کوچک و گوشه‌ی صفحه باقی می‌ماند. حالا:
		   - @page پویا (auto) + صفحات نام‌دار A4/A5
		   - چیدمان سیال (عرض ۱۰۰٪) که هر کاغذی را کامل پر می‌کند
		   - تایپوگرافی A4 بزرگ‌تر، تایپوگرافی A5 فشرده (انتخاب با دکمه‌های A4/A5) */
		@page { size: auto; margin: 9mm; }
		@page cpttA4 { size: A4 portrait; margin: 10mm; }
		@page cpttA5 { size: A5 portrait; margin: 7mm; }
		body.cptt-paper-a4 .wrap { page: cpttA4; }
		body.cptt-paper-a5 .wrap { page: cpttA5; }
		@media print {
			html, body { width: 100% !important; height: auto !important; min-height: 0 !important; overflow: visible !important; }
			body { background: #fff; padding: 0; margin: 0; font-size: 11.5px; line-height: 1.6; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
			.wrap { border: none; box-shadow: none; max-width: 100% !important; width: 100% !important; border-radius: 0; overflow: visible; break-after: avoid; page-break-after: avoid; }
			.actions-bar { display: none !important; }
			.print-header { padding: 8mm 0 5mm; background: #fff !important; color: var(--text) !important; border-bottom: 1px solid #e2e8f0; gap: 6px; }
			.brand-logo-img { max-height: 44px; max-width: 125px; padding: 2px; }
			.brand-title { font-size: 15px; }
			.brand-url, .document-date { font-size: 10px; }
			.document-title { font-size: 17px; }
			.main-content { padding: 7mm 0 0; }
			.metadata-grid { grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 7mm; }
			.metadata-box { padding: 10px 12px; border-radius: 10px; }
			.metadata-item { font-size: 11px; margin-bottom: 4px; }
			.invoice-table { width: 100% !important; margin: 6mm 0; font-size: 10.5px; break-inside: auto; page-break-inside: auto; }
			.invoice-table th, .invoice-table td { padding: 7px 8px; line-height: 1.5; word-break: break-word; overflow-wrap: anywhere; }
			.invoice-table th { font-size: 10px; }
			.totals-row td { font-size: 11px; }
			.final-sign-box { margin-top: 8mm; padding: 12px 14px; break-inside: avoid; page-break-inside: avoid; }
			.sign-img, .stamp-img { max-height: 64px; max-width: 145px; }
			.print-footer { padding: 8px 0 0; font-size: 9.5px; background:#fff; break-after: avoid; page-break-after: avoid; }
			body > *:last-child { break-after: avoid; page-break-after: avoid; }
		}
		/* حالت A5: همان چیدمان فشرده‌ی قبلی */
		@media print {
			body.cptt-paper-a5 { font-size: 9.5px; line-height: 1.45; }
			body.cptt-paper-a5 .print-header { padding: 5mm 0 4mm; }
			body.cptt-paper-a5 .brand-logo-img { max-height: 28px; max-width: 80px; }
			body.cptt-paper-a5 .brand-title { font-size: 11px; }
			body.cptt-paper-a5 .brand-url, body.cptt-paper-a5 .document-date { font-size: 8px; }
			body.cptt-paper-a5 .document-title { font-size: 12px; }
			body.cptt-paper-a5 .main-content { padding: 5mm 0 0; }
			body.cptt-paper-a5 .metadata-grid { gap: 5px; margin-bottom: 6mm; }
			body.cptt-paper-a5 .metadata-box { padding: 6px 8px; border-radius: 8px; }
			body.cptt-paper-a5 .metadata-item { font-size: 9px; margin-bottom: 3px; }
			body.cptt-paper-a5 .invoice-table { margin: 5mm 0; font-size: 8.5px; }
			body.cptt-paper-a5 .invoice-table th, body.cptt-paper-a5 .invoice-table td { padding: 4px 5px; line-height: 1.35; }
			body.cptt-paper-a5 .invoice-table th { font-size: 8px; }
			body.cptt-paper-a5 .totals-row td { font-size: 8.7px; }
			body.cptt-paper-a5 .final-sign-box { margin-top: 7mm; padding: 8px 10px; }
			body.cptt-paper-a5 .sign-img, body.cptt-paper-a5 .stamp-img { max-height: 42px; max-width: 95px; }
			body.cptt-paper-a5 .print-footer { font-size: 8px; }
		}
		.cptt-paper-switch { display: inline-flex; align-items: center; gap: 0; border: 1px solid var(--border, #e2e8f0); border-radius: 10px; overflow: hidden; vertical-align: middle; }
		.cptt-paper-switch .paper-btn { border: none; background: #fff; color: #64748b; font: inherit; font-size: 12px; font-weight: 800; padding: 8px 13px; cursor: pointer; }
		.cptt-paper-switch .paper-btn.is-active { background: var(--primary, #4f46e5); color: #fff; }
	</style>
</head>
<body>
	<div class="wrap">
		<!-- Header -->
		<div class="print-header">
			<div class="brand-info">
				<?php if ($logo && ($toggles['invoice_show_logo'] ?? '1') === '1'): ?>
					<img src="<?php echo esc_url($logo); ?>" class="brand-logo-img" alt="logo" />
				<?php endif; ?>
				<div>
					<div class="brand-title"><?php echo esc_html($brand['brand_name'] ?? get_bloginfo('name')); ?></div>
					<div class="brand-url"><?php echo esc_html($brand['site_url'] ?? home_url('/')); ?></div>
				</div>
			</div>
			<div class="document-title-box">
				<div class="document-title"><?php echo esc_html($invoice_title); ?></div>
				<?php if (($toggles['invoice_show_dates'] ?? '1') === '1'): ?>
					<div class="document-date">تاریخ صدور: <?php echo esc_html($created_fa); ?></div>
				<?php endif; ?>
			</div>
		</div>

		<!-- Actions -->
		<div class="actions-bar">
			<a class="btn" href="<?php echo esc_url(wp_get_referer() ?: home_url('/')); ?>">◀ بازگشت</a>
			<div>
				<?php /* v9.2.46 — انتخاب اندازه‌ی کاغذ پیش از چاپ (A4/A5 هر دو صفحه را پر می‌کنند) */ ?>
				<span class="cptt-paper-switch" role="group" aria-label="اندازه کاغذ چاپ">
					<button class="paper-btn" type="button" data-paper="a4">A4</button>
					<button class="paper-btn" type="button" data-paper="a5">A5</button>
				</span>
				<button class="btn btn-primary" type="button" onclick="window.print()">🖨 چاپ <?php echo esc_html($invoice_short); ?></button>
			</div>
		</div>
		<script>
		(function(){
			var KEY='cptt_print_paper';
			function setPaper(p){
				document.body.classList.toggle('cptt-paper-a4', p==='a4');
				document.body.classList.toggle('cptt-paper-a5', p==='a5');
				document.querySelectorAll('.paper-btn').forEach(function(b){ b.classList.toggle('is-active', b.getAttribute('data-paper')===p); });
				try{ localStorage.setItem(KEY,p); }catch(e){}
			}
			var init='a4'; try{ init=localStorage.getItem(KEY)||'a4'; }catch(e){}
			setPaper(init);
			document.querySelectorAll('.paper-btn').forEach(function(b){ b.addEventListener('click', function(){ setPaper(b.getAttribute('data-paper')); }); });
		})();
		</script>

		<!-- Main -->
		<div class="main-content">
			<!-- Meta details -->
			<div class="metadata-grid">
				<div class="metadata-box">
					<div class="metadata-item"><b>عنوان پروژه:</b> <?php echo esc_html($title); ?></div>
					<div class="metadata-item"><b>کد پیگیری:</b> #<?php echo esc_html($project_code); ?></div>
					<?php if ($client_name && ($toggles['invoice_show_client'] ?? '1') === '1'): ?>
						<div class="metadata-item"><b>خریدار / مشتری:</b> <?php echo esc_html($client_name); ?></div>
					<?php endif; ?>
					<?php if ($client_phone && ($toggles['invoice_show_client'] ?? '1') === '1'): ?>
						<div class="metadata-item"><b>تلفن تماس:</b> <span style="direction:ltr; display:inline-block;"><?php echo esc_html($client_phone); ?></span></div>
					<?php endif; ?>
				</div>
				<div class="metadata-box">
					<?php if (!empty($expert_names) && ($toggles['invoice_show_experts'] ?? '1') === '1'): ?>
						<div class="metadata-item"><b>کارشناسان پروژه:</b> <?php echo esc_html(implode('، ', $expert_names)); ?></div>
					<?php endif; ?>
					<?php if ($delivery_method): ?>
						<div class="metadata-item"><b>روش تحویل:</b> <?php echo esc_html($delivery_method_label); ?></div>
					<?php endif; ?>
				</div>
			</div>

			<?php if ($delivery_method === 'shipping' && ($delivery_province || $delivery_address)): ?>
				<div class="metadata-box" style="margin-bottom:20px;">
					<b>📍 آدرس تحویل و ارسال:</b>
					<span style="font-size:12.5px; display:block; margin-top:4px;">
						<?php echo esc_html(($delivery_province ? $delivery_province : '') . ($delivery_city ? ' - ' . $delivery_city : '') . ($delivery_address ? ' - ' . $delivery_address : '')); ?>
					</span>
				</div>
			<?php endif; ?>

			<!-- Invoice Items table -->
			<?php if (($toggles['invoice_show_step_breakdown'] ?? '1') === '1'): ?>
				<table class="invoice-table">
					<thead>
						<tr>
							<th class="col-desc">شرح خدمات</th>
							<th class="text-left col-unit">فی (ریال)</th>
							<th class="text-center col-qty">تعداد</th>
							<th class="text-left col-total">جمع کل</th>
							<th class="text-left col-paid">دریافتی</th>
							<th class="text-left col-remain">مانده</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$total_cost = 0;
						$total_paid = 0;
						$total_remain = 0;
						$row_idx = 1;
						foreach ($steps as $s):
							$st_title = trim((string)($s['title'] ?? ''));
							if ($st_title === '') continue;
							$cost = (float)($s['cost'] ?? 0);
							$paid = (float)($s['paid'] ?? 0);
							$qty = isset($s['qty']) ? (float)$s['qty'] : 1.0;
							if ($qty <= 0) $qty = 1.0;
							$unit_price = isset($s['unit_price']) ? (float)$s['unit_price'] : ($cost / $qty);
							$remain = $cost - $paid;

							$total_cost += $cost;
							$total_paid += $paid;
							$total_remain += $remain;
						?>
							<tr>
								<td>
									<div style="font-weight:700; color:#0f172a;"><?php echo esc_html($st_title); ?></div>
									<?php /* v5.4.17: نمایش توضیحات مرحله از فاکتور حذف شد. */ ?>
								</td>
								<td class="text-left"><?php echo esc_html(number_format($unit_price)); ?></td>
								<td class="text-center"><?php echo esc_html(rtrim(rtrim(number_format($qty, 2), '0'), '.')); ?></td>
								<td class="text-left"><?php echo esc_html(number_format($cost)); ?></td>
								<td class="text-left" style="color:#059669;"><?php echo esc_html(number_format($paid)); ?></td>
								<td class="text-left" style="color:<?php echo $remain > 0 ? '#dc2626' : '#059669'; ?>; font-weight:700;"><?php echo esc_html(number_format($remain)); ?></td>
							</tr>
						<?php endforeach; ?>

						<!-- Totals -->
						<tr class="totals-row">
							<td colspan="3" style="text-align:left;">جمع کل <?php echo esc_html($invoice_short); ?> (ریال):</td>
							<td class="text-left"><?php echo esc_html(number_format($total_cost)); ?></td>
							<td class="text-left" style="color:#059669;"><?php echo esc_html(number_format($total_paid)); ?></td>
							<td class="text-left" style="color:<?php echo $total_remain > 0 ? '#dc2626' : '#059669'; ?>;"><?php echo esc_html(number_format($total_remain)); ?></td>
						</tr>
					</tbody>
				</table>
			<?php else: 
				// Just print total summary if step breakdown is disabled
				$total_cost = 0;
				$total_paid = 0;
				foreach ($steps as $s) {
					$total_cost += (float)($s['cost'] ?? 0);
					$total_paid += (float)($s['paid'] ?? 0);
				}
				$total_remain = $total_cost - $total_paid;
			?>
				<div class="metadata-box" style="margin-bottom:20px; display:flex; justify-content:space-between; gap:20px; text-align:center;">
					<div><span>جمع کل هزینه:</span> <strong style="font-size:16px; display:block; margin-top:4px;"><?php echo esc_html(number_format($total_cost)); ?> ریال</strong></div>
					<div><span>جمع پرداختی:</span> <strong style="font-size:16px; display:block; margin-top:4px; color:#059669;"><?php echo esc_html(number_format($total_paid)); ?> ریال</strong></div>
					<div><span>مانده حساب:</span> <strong style="font-size:16px; display:block; margin-top:4px; color:<?php echo $total_remain > 0 ? '#dc2626' : '#059669'; ?>;"><?php echo esc_html(number_format($total_remain)); ?> ریال</strong></div>
				</div>
			<?php endif; ?>

			<!-- Approvals sign/stamp -->
			<?php if ((($toggles['invoice_show_sign_stamp'] ?? '1') === '1') && ($sign || $stamp || !empty($brand['manager_name'] || !empty($brand['manager_title'])))): ?>
				<div class="final-sign-box">
					<div class="sign-stamp-grid">
						<div>
							<?php if ($sign): ?>
								<img src="<?php echo esc_url($sign); ?>" class="sign-img" alt="signature" />
							<?php endif; ?>
							<div class="sign-label"><?php echo esc_html($brand['manager_name'] ?: ($is_final_invoice ? 'امضا صادرکننده فاکتور' : 'امضا صادرکننده پیش‌فاکتور')); ?></div>
							<?php if (!empty($brand['manager_title'])): ?>
								<div class="sign-title"><?php echo esc_html($brand['manager_title']); ?></div>
							<?php endif; ?>
						</div>
						<div>
							<?php if ($stamp): ?>
								<img src="<?php echo esc_url($stamp); ?>" class="stamp-img" alt="stamp" />
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>

		<!-- Footer -->
		<div class="print-footer">
			<?php echo esc_html($brand['footer_text'] ?? ''); ?>
		</div>
	</div>
</body>
</html>
		<?php
		exit;
	}
}
