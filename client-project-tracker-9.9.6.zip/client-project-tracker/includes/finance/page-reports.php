<?php
if (!defined('ABSPATH')) exit;

/**
 * Reports Center (مرکز گزارشات) — v9.3.0 (فاز ۳) → v9.4.0 (گزارشات پیشرفته + چاپ اختصاصی)
 *
 * فقط‌خواندنی: همه‌ی اعداد از همان منابع رسمی (دفتر مالی + فاکتورها + چک‌ها) و با
 * همان قانون «خنثی‌سازی جفت‌آگاه برگشت» محاسبه می‌شوند؛ هیچ محاسبه‌ی موازیِ جدیدی
 * معرفی نشده و هیچ داده‌ای تغییر نمی‌کند.
 *  - 📅 گزارش سنی مطالبات (بر پایه‌ی سررسید فاکتورهای فروش باز)
 *  - تراز اشخاص (بدهکاران / بستانکاران)
 *  - 💰 تراز خزانه (مانده‌ی حساب‌های بانکی/صندوق)
 *  - 📆 گردش ۶ ماه اخیر (درآمد/هزینه ماهانه)
 *  - 🔥 فاکتورهای سررسید گذشته (به‌همراه روزهای تاخیر)
 *  - 🏦 چک‌های سررسید نزدیکِ در انتظار
 *  - آخرین اسناد دفتر
 *  - 🖨 «نسخه‌ی چاپی»: سند چاپی مستقلِ برنددار (نه چاپ از روی صفحه‌ی ادمین)
 */

/* ──────────────────────────── داده‌های مشترک ──────────────────────────── */
/* تاریخ بدون ساعت — مستقل از فایل فاکتورها (v9.4.0) */
if (!function_exists('cpttf_rpt_jdate')) {
	function cpttf_rpt_jdate($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		if (class_exists('CPTT_Core')) {
			$fa = '';
			if (method_exists('CPTT_Core', 'jalali_datetime_en'))    $fa = (string)CPTT_Core::jalali_datetime_en($ts);
			elseif (method_exists('CPTT_Core', 'jalali_datetime'))   $fa = (string)CPTT_Core::jalali_datetime($ts);
			if ($fa !== '') { $parts = preg_split('/\s+/u', $fa); return (string)($parts[0] ?? $fa); }
		}
		return date('Y-m-d', $ts);
	}
}

function cpttf_reports_data(){
	global $wpdb;
	$now = (int)current_time('timestamp', true);
	$f_person = isset($_GET['fperson']) ? (int)$_GET['fperson'] : 0; // v9.9.0 — فیلتر شخص در مرکز گزارشات (بخش‌های فردمحور)

	$aging  = CPTT_Finance::invoice_aging();
	$people = CPTT_Finance::person_balances();
	$fperson_label = '';
	if ($f_person > 0) { // v9.9.0 — گزارش سنی و تراز اشخاص فقط برای آن شخص
		$aging['rows'] = array_values(array_filter((array)$aging['rows'], function($r) use ($f_person){ return (int)($r['person_id'] ?? 0) === $f_person; }));
		$tot = ['cur'=>0.0,'b30'=>0.0,'b60'=>0.0,'b90'=>0.0,'b90p'=>0.0,'total'=>0.0];
		foreach ($aging['rows'] as $r) { foreach ($tot as $bk => $_) { if (isset($r[$bk])) $tot[$bk] += (float)$r[$bk]; } }
		$aging['totals'] = $tot;
		$people = array_values(array_filter((array)$people, function($pp) use ($f_person){ return (int)($pp['id'] ?? $pp['person_id'] ?? 0) === $f_person; }));
		foreach (CPTT_Finance::get_person_options_list() as $po) { if ((int)$po['id'] === $f_person) { $fperson_label = (string)$po['label']; break; } }
	}
	$debtors   = array_values(array_filter($people, function($p){ return $p['bal'] > 0.005; }));
	$creditors = array_values(array_filter($people, function($p){ return $p['bal'] < -0.005; }));
	usort($debtors,   function($a,$b){ return $b['bal'] <=> $a['bal']; });
	usort($creditors, function($a,$b){ return $a['bal'] <=> $b['bal']; });
	$sum_receiv  = array_sum(array_map(function($p){ return (float)$p['bal']; }, $debtors));
	$sum_payable = -array_sum(array_map(function($p){ return (float)$p['bal']; }, $creditors));

	$chq_kpi = CPTT_Finance::cheque_kpis();

	/* 💰 تراز خزانه — از همان تابع رسمی مانده‌ی حساب */
	$accounts  = CPTT_Finance::get_accounts(true);
	$treasury  = [];
	$treasury_sum = 0.0;
	foreach ((array)$accounts as $acc) {
		$b = CPTT_Finance::account_balance((int)$acc->id);
		$treasury[] = ['name' => (string)$acc->name, 'balance' => $b];
		$treasury_sum += $b;
	}

	/* 📆 گردش ۶ ماه اخیر — همان سری رسمی داشبورد */
	$monthly = CPTT_Finance::monthly_series();

	/* 🔥 فاکتورهای فروشِ سررسید گذشته‌ی باز — از جدول فاکتورها، بدون دست‌کاری */
	$t_inv = CPTT_Finance::tbl_invoices();
	$overdue = $wpdb->get_results($wpdb->prepare(
		"SELECT i.* FROM $t_inv i WHERE i.kind='sale' AND i.status IN ('issued','partial') AND i.due_ts > 0 AND i.due_ts < %d " . ($f_person > 0 ? $wpdb->prepare('AND i.person_id = %d ', $f_person) : '') . "ORDER BY i.due_ts ASC LIMIT 8",
		$now
	)) ?: [];
	foreach ($overdue as $oi) {
		$u = get_user_by('id', (int)$oi->person_id);
		$oi->person_name = $u ? (string)$u->display_name : ('#' . (int)$oi->person_id);
		$oi->remain      = max(0.0, (float)$oi->amount - (float)$oi->settled);
		$oi->days_late   = (int)floor(max(0, $now - (int)$oi->due_ts) / 86400);
	}

	/* 🏦 چک‌های در انتظارِ سررسید نزدیک (۱۴ روز آینده + سررسید گذشته) */
	$chq_upcoming = [];
	foreach ((array)CPTT_Finance::get_cheques(['status' => 'pending']) as $c) {
		if ((int)$c->due_ts > 0 && (int)$c->due_ts <= $now + 14 * 86400) $chq_upcoming[] = $c;
		if (count($chq_upcoming) >= 8) break;
	}

	$A = CPTT_Finance::sql_active_cond('l'); // Reserved for parity with other queries
	unset($A);
	$t_lgr = CPTT_Finance::tbl_ledger();
	$recent = $wpdb->get_results(
		"SELECT l.id, l.customer_id, l.expert_id, l.voucher_no, l.voucher_kind, l.type, l.direction, l.amount, l.status, l.reversed_by, l.date_fa, l.description
		 FROM $t_lgr l WHERE l.status IN ('posted','reversed','reversal') AND (l.customer_id > 0 OR l.expert_id > 0) "
 . ($f_person > 0 ? $wpdb->prepare('AND (l.customer_id = %d OR l.expert_id = %d) ', $f_person, $f_person) : '') . "ORDER BY l.date_at DESC, l.id DESC LIMIT 10"
	) ?: [];

	return compact(
		'now','aging','debtors','creditors','sum_receiv','sum_payable','chq_kpi',
		'treasury','treasury_sum','monthly','overdue','chq_upcoming','recent','f_person','fperson_label'
	);
}

/* ──────────────────────────── صفحه‌ی روی‌صفحه ──────────────────────────── */
function cpttf_render_reports(){
	$d = cpttf_reports_data();
	extract($d, EXTR_SKIP);
	$cur = CPTT_Finance::currency_label();

	// v9.9.0 — نوار فیلتر «شخص» (فقط بخش‌های فردمحور فیلتر می‌شوند؛ خزانه/گردش ماهانه سراسری است)
	ob_start(); CPTT_Finance::render_person_combo((int)$f_person); $__pc_html = ob_get_clean();
	echo '<form class="cpttf-filters" method="get" action="" data-cpttf-autoapply style="margin-bottom:10px;">'
		. '<input type="hidden" name="page" value="cptt-finance-reports">'
		. $__pc_html
		. '<span class="cpttf-filters__actions"><noscript><button class="cpttf-btn cpttf-btn--primary" type="submit">اعمال</button></noscript>'
		. ($f_person > 0 ? '<a class="cpttf-btn cpttf-btn--ghost" href="' . esc_url(admin_url('admin.php?page=cptt-finance-reports')) . '">حذف فیلتر</a>' : '')
		. '</span></form>';
	CPTT_Finance::person_combo_assets();
	if ($f_person > 0 && $fperson_label !== '') {
		echo '<div class="cpttf-kpi" style="--c:#6366f1;margin-bottom:10px;"><div class="cpttf-kpi__icon">👤</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">فیلتر شخص فعال است</span><strong class="cpttf-kpi__value" style="font-size:14px;">' . esc_html($fperson_label) . '</strong><small class="cpttf-kpi__sub">گزارش سنی، تراز اشخاص، فاکتورهای سررسید گذشته و آخرین اسناد فقط برای این شخص است.</small></div></div>';
	}

	$k = function($icon, $label, $value, $color = '', $sub = ''){
		return '<div class="cpttf-kpi" style="--c:' . esc_attr($color ?: '#64748b') . '"><div class="cpttf-kpi__icon">' . $icon . '</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">' . esc_html($label) . '</span><strong class="cpttf-kpi__value">' . $value . '</strong>' . ($sub !== '' ? '<small class="cpttf-kpi__sub">' . esc_html($sub) . '</small>' : '') . '</div></div>';
	};
	$bucket_head  = '<th class="cpttf-num">سررسید نرسیده</th><th class="cpttf-num">۱–۳۰ روز</th><th class="cpttf-num">۳۱–۶۰ روز</th><th class="cpttf-num">۶۱–۹۰ روز</th><th class="cpttf-num">+۹۰ روز</th>';
	$bucket_cells = function($r) use ($cur){
		$o = '';
		foreach (['cur','b30','b60','b90','b90p'] as $b) {
			$o .= '<td class="cpttf-num">' . ((float)$r[$b] > 0 ? '<b>' . CPTT_Finance::fmt($r[$b]) . '</b>' : '<span style="color:#cbd5e1;">۰</span>') . '</td>';
		}
		return $o;
	};
	?>

	<div class="cpttf-reports-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:4px;">
		<small style="color:#64748b;">گزارش «لحظه‌ای» — <?php echo esc_html(CPTT_Finance::fa_date($now)); ?> · همه‌ی اعداد فقط‌خواندنی و از همان دفتر/فاکتور/چک موجود محاسبه می‌شوند (اسناد برگشتی خنثی‌اند).</small>
		<a class="cpttf-btn cpttf-btn--ghost no-print" target="_blank" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-reports&rpt=print')); ?>"><?php // v9.4.0 — سند چاپی مستقلِ برنددار؛ به‌جای window.print از روی صفحه‌ی ادمین ?>🖨 نسخه‌ی چاپی گزارش</a>
	</div>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4">
		<?php
		echo $k('📈','جمع مطالبات از اشخاص', CPTT_Finance::fmt($sum_receiv) . ' <small>' . esc_html($cur) . '</small>', '#b45309', count($debtors) . ' شخص بدهکار');
		echo $k('📉','جمع بدهی ما به اشخاص', CPTT_Finance::fmt($sum_payable) . ' <small>' . esc_html($cur) . '</small>', '#6d28d9', count($creditors) . ' شخص بستانکار');
		echo $k('🧾','مانده‌ی فاکتورهای باز', CPTT_Finance::fmt($aging['totals']['total']) . ' <small>' . esc_html($cur) . '</small>', '#7c3aed', count($aging['rows']) . ' طرف‌حساب');
		echo $k('💰','تراز خزانه (مانده‌ی حساب‌ها)', CPTT_Finance::fmt($treasury_sum) . ' <small>' . esc_html($cur) . '</small>', '#059669', count($treasury) . ' حساب فعال');
		echo $k('🏦','چک‌های در راه (دریافت − پرداخت)', CPTT_Finance::fmt((float)$chq_kpi['pend_in'] - (float)$chq_kpi['pend_out']) . ' <small>' . esc_html($cur) . '</small>', '#0ea5e9', CPTT_Finance::fmt($chq_kpi['pend_n']) . ' سند در انتظار');
		echo $k('🔥','فاکتورهای سررسید گذشته', CPTT_Finance::fmt(count($overdue) > 0 ? array_sum(array_map(function($oi){ return (float)$oi->remain; }, $overdue)) : 0) . ' <small>' . esc_html($cur) . '</small>', '#dc2626', count($overdue) . ' فاکتور نیازمند پیگیری');
		?>
	</div>

	<div class="cpttf-grid cpttf-grid--2">
		<?php // ── 💰 تراز خزانه ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>💰 تراز خزانه <small style="font-weight:500;color:#64748b;">(مانده‌ی لحظه‌ای حساب‌های بانکی/صندوق)</small></h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($treasury)): ?><p class="cpttf-empty">حسابی تعریف نشده است.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>حساب</th><th class="cpttf-num">مانده</th></tr></thead>
					<tbody>
					<?php foreach ($treasury as $t): ?>
						<tr>
							<td><?php echo esc_html($t['name']); ?></td>
							<td class="cpttf-num"><b style="color:<?php echo $t['balance'] >= 0 ? '#059669' : '#dc2626'; ?>;"><?php echo CPTT_Finance::fmt($t['balance']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot><tr style="background:#f8fafc;font-weight:900;"><td>جمع</td><td class="cpttf-num"><b><?php echo CPTT_Finance::fmt($treasury_sum); ?> <?php echo esc_html($cur); ?></b></td></tr></tfoot>
				</table></div>
				<?php endif; ?>
			</div>
		</section>

		<?php // ── 📆 گردش ۶ ماه اخیر ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>📆 گردش مالی ۶ ماه اخیر</h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($monthly)): ?><p class="cpttf-empty">داده‌ای نیست.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>ماه</th><th class="cpttf-num">درآمد</th><th class="cpttf-num">هزینه</th><th class="cpttf-num">خالص</th></tr></thead>
					<tbody>
					<?php foreach ($monthly as $m): $net = (float)$m['income'] - (float)$m['expense']; ?>
						<tr>
							<td><b><?php echo esc_html($m['label']); ?></b></td>
							<td class="cpttf-num cpttf-text-success"><?php echo (float)$m['income'] > 0 ? CPTT_Finance::fmt($m['income']) : '—'; ?></td>
							<td class="cpttf-num cpttf-text-danger"><?php echo (float)$m['expense'] > 0 ? CPTT_Finance::fmt($m['expense']) : '—'; ?></td>
							<td class="cpttf-num"><b style="color:<?php echo $net >= 0 ? '#059669' : '#dc2626'; ?>;"><?php echo CPTT_Finance::fmt($net); ?></b></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>
	</div>

	<?php // ── گزارش سنی مطالبات ── ?>
	<section class="cpttf-card">
		<header class="cpttf-card__head">
			<div>
				<h2>📅 گزارش سنی مطالبات</h2>
				<small style="color:#64748b;font-size:12px;">مانده‌ی فاکتورهای فروشِ باز، به‌تفکیک روزهای گذشته از سررسید — مبنای پیگیری وصول</small>
			</div>
		</header>
		<div class="cpttf-card__body">
			<?php if (empty($aging['rows'])): ?>
				<p class="cpttf-empty">فاکتور فروشِ بازی وجود ندارد 🎉</p>
			<?php else: ?>
			<div class="cpttf-table-wrap">
				<table class="cpttf-table cpttf-aging-table">
					<thead><tr><th>شخص</th><?php echo $bucket_head; ?><th class="cpttf-num">جمع مانده</th></tr></thead>
					<tbody>
					<?php foreach ($aging['rows'] as $r): ?>
						<tr>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$r['person_id'])); ?>"><b><?php echo esc_html($r['name']); ?></b></a></td>
							<?php echo $bucket_cells($r); ?>
							<td class="cpttf-num"><b style="color:#b45309;"><?php echo CPTT_Finance::fmt($r['total']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot>
						<tr style="background:#f8fafc;font-weight:900;">
							<td>جمع کل</td>
							<?php echo $bucket_cells($aging['totals']); ?>
							<td class="cpttf-num"><b><?php echo CPTT_Finance::fmt($aging['totals']['total']); ?> <?php echo esc_html($cur); ?></b></td>
						</tr>
					</tfoot>
				</table>
			</div>
			<?php endif; ?>
		</div>
	</section>

	<div class="cpttf-grid cpttf-grid--2">
		<?php // ── 🔥 فاکتورهای سررسید گذشته ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>🔥 فاکتورهای سررسید گذشته <small style="font-weight:500;color:#64748b;">(فروشِ باز — فوریت پیگیری)</small></h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($overdue)): ?><p class="cpttf-empty">فاکتور سررسید گذشته‌ای نیست 🎉</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>شماره</th><th>شخص</th><th>سررسید</th><th>تاخیر</th><th class="cpttf-num">مانده</th></tr></thead>
					<tbody>
					<?php foreach ($overdue as $oi): ?>
						<tr>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&fperson=' . (int)$oi->person_id)); ?>" style="font-family:ui-monospace,monospace;"><b><?php echo esc_html($oi->invoice_no); ?></b></a></td>
							<td><?php echo esc_html($oi->person_name); ?></td>
							<td style="color:#dc2626;font-weight:700;"><?php echo esc_html(cpttf_rpt_jdate((int)$oi->due_ts)); ?></td>
							<td><span style="display:inline-block;background:#fee2e2;color:#b91c1c;border-radius:999px;padding:1px 8px;font-size:11px;font-weight:700;"><?php echo esc_html(CPTT_Finance::fmt($oi->days_late)); ?> روز</span></td>
							<td class="cpttf-num"><b style="color:#b45309;"><?php echo CPTT_Finance::fmt($oi->remain); ?></b></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>

		<?php // ── 🏦 چک‌های سررسید نزدیک ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>🏦 چک‌های سررسید نزدیک <small style="font-weight:500;color:#64748b;">(در انتظار — تا ۱۴ روز آینده)</small></h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($chq_upcoming)): ?><p class="cpttf-empty">چکِ سررسید نزدیکِ در انتظاری نیست.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>شماره چک</th><th>شخص</th><th>جهت</th><th>سررسید</th><th class="cpttf-num">مبلغ</th></tr></thead>
					<tbody>
					<?php foreach ($chq_upcoming as $c):
						$cin = (int)$c->direction >= 0;
						$cno = (string)$c->cheque_no !== '' ? (string)$c->cheque_no : ('#' . (int)$c->id);
					?>
						<tr>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-cheques&fstatus=pending')); ?>" style="font-family:ui-monospace,monospace;"><b><?php echo esc_html($cno); ?></b></a></td>
							<td><?php echo esc_html($c->person_name); ?></td>
							<td><?php echo $cin ? '<span style="color:#059669;font-weight:700;">دریافتنی</span>' : '<span style="color:#dc2626;font-weight:700;">پرداختنی</span>'; ?></td>
							<td style="<?php echo (int)$c->due_ts < $now ? 'color:#dc2626;font-weight:700;' : ''; ?>"><?php echo esc_html(cpttf_rpt_jdate((int)$c->due_ts)); ?></td>
							<td class="cpttf-num"><b><?php echo CPTT_Finance::fmt($c->amount); ?></b></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>
	</div>

	<div class="cpttf-grid cpttf-grid--2">
		<?php // ── بدهکاران ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>📈 بیشترین بدهکاران</h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($debtors)): ?><p class="cpttf-empty">بدهکاری نیست.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>#</th><th>شخص</th><th class="cpttf-num">مانده (بدهکار)</th></tr></thead>
					<tbody>
					<?php $i = 1; foreach (array_slice($debtors, 0, 10) as $p): ?>
						<tr>
							<td><?php echo $i++; ?></td>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$p['id'])); ?>"><?php echo esc_html($p['name']); ?></a></td>
							<td class="cpttf-num"><b style="color:#b45309;"><?php echo CPTT_Finance::fmt($p['bal']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>

		<?php // ── بستانکاران ── ?>
		<section class="cpttf-card">
			<header class="cpttf-card__head"><h2>📉 بیشترین بستانکاران <small style="font-weight:500;color:#64748b;">(مازاد پرداخت — ما بدهکاریم)</small></h2></header>
			<div class="cpttf-card__body">
				<?php if (empty($creditors)): ?><p class="cpttf-empty">بستانکاری نیست.</p><?php else: ?>
				<div class="cpttf-table-wrap"><table class="cpttf-table">
					<thead><tr><th>#</th><th>شخص</th><th class="cpttf-num">مانده (بستانکار)</th></tr></thead>
					<tbody>
					<?php $i = 1; foreach (array_slice($creditors, 0, 10) as $p): ?>
						<tr>
							<td><?php echo $i++; ?></td>
							<td><a href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons&pid=' . (int)$p['id'])); ?>"><?php echo esc_html($p['name']); ?></a></td>
							<td class="cpttf-num"><b style="color:#6d28d9;"><?php echo CPTT_Finance::fmt(-$p['bal']); ?></b> <small><?php echo esc_html($cur); ?></small></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
				<?php endif; ?>
			</div>
		</section>
	</div>

	<?php // ── آخرین اسناد ── ?>
	<section class="cpttf-card">
		<header class="cpttf-card__head"><h2>📄 آخرین اسناد دفتر</h2></header>
		<div class="cpttf-card__body">
			<?php if (empty($recent)): ?><p class="cpttf-empty">سندی نیست.</p><?php else: ?>
			<div class="cpttf-table-wrap"><table class="cpttf-table">
				<thead><tr><th>شماره سند</th><th>تاریخ</th><th>نوع</th><th class="cpttf-num">واریز</th><th class="cpttf-num">برداشت</th><th>وضعیت</th></tr></thead>
				<tbody>
				<?php foreach ($recent as $v):
					$vd = (int)$v->direction >= 0 ? 1 : -1;
					$vnt = CPTT_Finance::is_row_neutral($v);
					$vno = (string)$v->voucher_no !== '' ? $v->voucher_no : ('#' . (int)$v->id);
				?>
					<tr class="<?php echo $vnt ? 'is-reversed' : ''; ?>">
						<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($vno); ?></b></td>
						<td><?php echo esc_html($v->date_fa); ?></td>
						<td><?php echo esc_html(CPTT_Finance::voucher_label($v)); ?></td>
						<td class="cpttf-num cpttf-text-success"><?php echo $vd > 0 ? '<b>' . CPTT_Finance::fmt($v->amount) . '</b>' : '—'; ?></td>
						<td class="cpttf-num cpttf-text-danger"><?php echo $vd < 0 ? '<b>' . CPTT_Finance::fmt($v->amount) . '</b>' : '—'; ?></td>
						<td><?php echo $vnt ? '⚪ خنثی' : 'فعال'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
			<?php endif; ?>
		</div>
	</section>

	<?php // ── دسترسی سریع ── ?>
	<section class="cpttf-card no-print">
		<header class="cpttf-card__head"><h2>🔗 دسترسی سریع</h2></header>
		<div class="cpttf-card__body" style="display:flex;flex-wrap:wrap;gap:8px;">
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-persons')); ?>">🪪 اشخاص</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&fstatus=open')); ?>">🧾 فاکتورهای باز</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-invoices&foverdue=1')); ?>">⚠️ فاکتورهای سررسید گذشته</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-cheques&fstatus=pending')); ?>">🏦 چک‌های در انتظار</a>
			<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-ledger')); ?>">📑 گردش حساب</a>
		</div>
	</section>
	<?php
}

/* ──────────────────────────── نسخه‌ی چاپی مستقل (v9.4.0) ──────────────────────────── */
function cpttf_reports_print(){
	require_once CPTT_PATH . 'includes/finance/print-brand.php';
	$brand = cpttf_brand();
	$paper = (isset($_GET['paper']) && sanitize_key($_GET['paper']) === 'a5') ? 'a5' : 'a4';
	$d = cpttf_reports_data();
	extract($d, EXTR_SKIP);
	$cur = CPTT_Finance::currency_label();

	$meta = 'تاریخ صدور: ' . esc_html(CPTT_Finance::fa_date($now)) . '<br>کاغذ: ' . esc_html(strtoupper($paper));
	if (!empty($fperson_label) && (string)$fperson_label !== '') $meta .= '<br>👤 فیلتر شخص: ' . esc_html($fperson_label); // v9.9.0
	?><!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>گزارش مالی مدیریتی — <?php echo esc_html($brand['brand_name']); ?></title>
<style><?php echo cpttf_print_core_css($paper); ?><?php echo cpttf_brand_block_css(); ?></style></head>
<body class="<?php echo esc_attr($paper); ?>">
<div class="no-print">
	<form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
		<input type="hidden" name="page" value="cptt-finance-reports">
		<input type="hidden" name="rpt" value="print">
		<?php if (!empty($f_person)): ?><input type="hidden" name="fperson" value="<?php echo (int)$f_person; ?>"><?php endif; ?>
		<label>کاغذ
			<select name="paper" onchange="this.form.submit()">
				<option value="a4" <?php selected($paper, 'a4'); ?>>A4</option>
				<option value="a5" <?php selected($paper, 'a5'); ?>>A5</option>
			</select>
		</label>
		<noscript><button type="submit" class="ghost">اعمال</button></noscript>
		<button type="button" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
		<button type="button" class="ghost" onclick="window.close()">بستن</button>
	</form>
</div>

<?php echo cpttf_brand_head_html($brand, 'گزارش مالی مدیریتی (لحظه‌ای)', $meta); ?>

<div class="pb-kpis">
	<div class="pb-kpi"><small>جمع مطالبات</small><b style="color:#b45309;"><?php echo CPTT_Finance::fmt($sum_receiv); ?></b> <small><?php echo esc_html($cur); ?></small></div>
	<div class="pb-kpi"><small>جمع بدهی ما</small><b style="color:#6d28d9;"><?php echo CPTT_Finance::fmt($sum_payable); ?></b> <small><?php echo esc_html($cur); ?></small></div>
	<div class="pb-kpi"><small>مانده‌ی فاکتورهای باز</small><b style="color:#7c3aed;"><?php echo CPTT_Finance::fmt($aging['totals']['total']); ?></b> <small><?php echo esc_html($cur); ?></small></div>
	<div class="pb-kpi"><small>تراز خزانه</small><b style="color:#059669;"><?php echo CPTT_Finance::fmt($treasury_sum); ?></b> <small><?php echo esc_html($cur); ?></small></div>
	<div class="pb-kpi"><small>چک‌های در راه (دریافت−پرداخت)</small><b style="color:#0ea5e9;"><?php echo CPTT_Finance::fmt((float)$chq_kpi['pend_in'] - (float)$chq_kpi['pend_out']); ?></b> <small><?php echo esc_html($cur); ?></small></div>
</div>

<h2>📅 گزارش سنی مطالبات</h2>
<?php if (empty($aging['rows'])): ?>
	<p style="color:#64748b;">فاکتور فروشِ بازی وجود ندارد.</p>
<?php else: ?>
<table>
	<thead><tr><th>شخص</th><th class="num">سررسید نرسیده</th><th class="num">۱–۳۰ روز</th><th class="num">۳۱–۶۰ روز</th><th class="num">۶۱–۹۰ روز</th><th class="num">+۹۰ روز</th><th class="num">جمع مانده</th></tr></thead>
	<tbody>
	<?php foreach ($aging['rows'] as $r): ?>
		<tr>
			<td><b><?php echo esc_html($r['name']); ?></b></td>
			<?php foreach (['cur','b30','b60','b90','b90p'] as $b): ?><td class="num"><?php echo (float)$r[$b] > 0 ? CPTT_Finance::fmt($r[$b]) : '—'; ?></td><?php endforeach; ?>
			<td class="num"><b><?php echo CPTT_Finance::fmt($r['total']); ?></b></td>
		</tr>
	<?php endforeach; ?>
	<tr class="tot">
		<td>جمع کل</td>
		<?php foreach (['cur','b30','b60','b90','b90p'] as $b): ?><td class="num"><b><?php echo (float)$aging['totals'][$b] > 0 ? CPTT_Finance::fmt($aging['totals'][$b]) : '—'; ?></b></td><?php endforeach; ?>
		<td class="num"><b><?php echo CPTT_Finance::fmt($aging['totals']['total']); ?> <?php echo esc_html($cur); ?></b></td>
	</tr>
	</tbody>
</table>
<?php endif; ?>

<div class="pb-cols">
	<div>
		<h2>💰 تراز خزانه</h2>
		<table>
			<thead><tr><th>حساب</th><th class="num">مانده</th></tr></thead>
			<tbody>
			<?php foreach ($treasury as $t): ?>
				<tr><td><?php echo esc_html($t['name']); ?></td><td class="num"><b><?php echo CPTT_Finance::fmt($t['balance']); ?></b></td></tr>
			<?php endforeach; ?>
			<tr class="tot"><td>جمع</td><td class="num"><b><?php echo CPTT_Finance::fmt($treasury_sum); ?> <?php echo esc_html($cur); ?></b></td></tr>
			</tbody>
		</table>
	</div>
	<div>
		<h2>📆 گردش ۶ ماه اخیر</h2>
		<table>
			<thead><tr><th>ماه</th><th class="num">درآمد</th><th class="num">هزینه</th><th class="num">خالص</th></tr></thead>
			<tbody>
			<?php foreach ((array)$monthly as $m): ?>
				<tr>
					<td><b><?php echo esc_html($m['label']); ?></b></td>
					<td class="num"><?php echo (float)$m['income'] > 0 ? CPTT_Finance::fmt($m['income']) : '—'; ?></td>
					<td class="num"><?php echo (float)$m['expense'] > 0 ? CPTT_Finance::fmt($m['expense']) : '—'; ?></td>
					<td class="num"><b><?php echo CPTT_Finance::fmt((float)$m['income'] - (float)$m['expense']); ?></b></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>

<?php if (!empty($overdue)): ?>
<h2>🔥 فاکتورهای سررسید گذشته</h2>
<table>
	<thead><tr><th>شماره</th><th>شخص</th><th>سررسید</th><th>تاخیر (روز)</th><th class="num">مانده</th></tr></thead>
	<tbody>
	<?php foreach ($overdue as $oi): ?>
		<tr>
			<td style="font-family:ui-monospace,monospace;"><b><?php echo esc_html($oi->invoice_no); ?></b></td>
			<td><?php echo esc_html($oi->person_name); ?></td>
			<td><?php echo esc_html(cpttf_rpt_jdate((int)$oi->due_ts)); ?></td>
			<td><?php echo esc_html(CPTT_Finance::fmt($oi->days_late)); ?></td>
			<td class="num"><b><?php echo CPTT_Finance::fmt($oi->remain); ?></b></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<?php endif; ?>

<?php if (!empty($chq_upcoming)): ?>
<h2>🏦 چک‌های سررسید نزدیک (در انتظار)</h2>
<table>
	<thead><tr><th>شماره چک</th><th>شخص</th><th>جهت</th><th>سررسید</th><th class="num">مبلغ</th></tr></thead>
	<tbody>
	<?php foreach ($chq_upcoming as $c):
		$cno = (string)$c->cheque_no !== '' ? (string)$c->cheque_no : ('#' . (int)$c->id);
	?>
		<tr>
			<td style="font-family:ui-monospace,monospace;"><b><?php echo esc_html($cno); ?></b></td>
			<td><?php echo esc_html($c->person_name); ?></td>
			<td><?php echo (int)$c->direction >= 0 ? 'دریافتنی' : 'پرداختنی'; ?></td>
			<td><?php echo esc_html(cpttf_rpt_jdate((int)$c->due_ts)); ?></td>
			<td class="num"><b><?php echo CPTT_Finance::fmt($c->amount); ?></b></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<?php endif; ?>

<div class="pb-cols">
	<div>
		<h2>📈 بیشترین بدهکاران</h2>
		<table>
			<thead><tr><th>#</th><th>شخص</th><th class="num">مانده</th></tr></thead>
			<tbody>
			<?php $i = 1; foreach (array_slice($debtors, 0, 8) as $p): ?>
				<tr><td><?php echo $i++; ?></td><td><?php echo esc_html($p['name']); ?></td><td class="num"><b><?php echo CPTT_Finance::fmt($p['bal']); ?></b></td></tr>
			<?php endforeach; ?>
			<?php if (empty($debtors)): ?><tr><td colspan="3" style="color:#94a3b8;">بدهکاری نیست.</td></tr><?php endif; ?>
			</tbody>
		</table>
	</div>
	<div>
		<h2>📉 بیشترین بستانکاران</h2>
		<table>
			<thead><tr><th>#</th><th>شخص</th><th class="num">مانده</th></tr></thead>
			<tbody>
			<?php $i = 1; foreach (array_slice($creditors, 0, 8) as $p): ?>
				<tr><td><?php echo $i++; ?></td><td><?php echo esc_html($p['name']); ?></td><td class="num"><b><?php echo CPTT_Finance::fmt(-$p['bal']); ?></b></td></tr>
			<?php endforeach; ?>
			<?php if (empty($creditors)): ?><tr><td colspan="3" style="color:#94a3b8;">بستانکاری نیست.</td></tr><?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<?php
	echo cpttf_brand_bank_html($brand);
	echo cpttf_brand_signfoot_html($brand);
?>
</body></html><?php
}
