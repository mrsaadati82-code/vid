<?php
if (!defined('ABSPATH')) exit;

/**
 * v9.4.0 — برندینگ مشترک خروجی‌های چاپی مالی (صورتحساب / فاکتور / مرکز گزارشات)
 *
 * منبع تنظیمات: همان «cptt_branding» که در تنظیمات ← برندینگ ست می‌شود؛
 * اگر کلاس تنظیمات در دسترس نباشد با دیفالت‌های امن کار می‌کند تا هیچ
 * خروجی چاپی‌ای نشکند (سازگار با هارنس/محیط‌های بدون کلاس).
 */

if (!function_exists('cpttf_brand')):

/** خوانایی تنظیمات برند (+ فیلدهای بانکی جدید) */
function cpttf_brand(){
	$d = [
		'brand_name'    => function_exists('get_bloginfo') ? (string)get_bloginfo('name') : '',
		'primary_color' => '#6366f1',
		'footer_text'   => '',
		'logo_id'       => 0,
		'sign_id'       => 0,
		'stamp_id'      => 0,
		'manager_name'  => '',
		'manager_title' => '',
		'bank_holder'   => '',
		'bank_name'     => '',
		'bank_account'  => '',
		'bank_card'     => '',
		'bank_iban'     => '',
	];
	if (class_exists('CPTT_Settings')) {
		$s = CPTT_Settings::get();
		if (is_array($s)) $d = array_merge($d, $s);
	}
	foreach (['logo_id','sign_id','stamp_id'] as $k) $d[$k] = (int)($d[$k] ?? 0);
	foreach (['brand_name','primary_color','footer_text','manager_name','manager_title','bank_holder','bank_name','bank_account','bank_card','bank_iban'] as $k) $d[$k] = trim((string)($d[$k] ?? ''));
	if (!preg_match('/^#[0-9a-f]{3,8}$/i', $d['primary_color'])) $d['primary_color'] = '#6366f1';
	if ($d['brand_name'] === '') $d['brand_name'] = function_exists('get_bloginfo') ? (string)get_bloginfo('name') : '—';
	return $d;
}

/** URL امن تصویر برند (لوگو/امضا/مهر) — '' اگر نبود */
function cpttf_brand_img_url($id){
	$id = (int)$id;
	if ($id <= 0 || !function_exists('wp_get_attachment_image_url')) return '';
	$u = wp_get_attachment_image_url($id, 'medium');
	return $u ? (string)$u : '';
}

/** هدر برند: لوگو/نشان + نام برند + نوار رنگی برند */
function cpttf_brand_head_html($brand, $title = '', $meta_html = ''){
	$color = esc_attr($brand['primary_color']);
	$logo  = cpttf_brand_img_url($brand['logo_id']);
	$h  = '<div class="pb-brand"><div class="pb-brand__id">';
	if ($logo !== '') {
		$h .= '<img class="pb-brand__logo" src="' . esc_url($logo) . '" alt="">';
	} else {
		$init = function_exists('mb_substr') ? mb_substr($brand['brand_name'], 0, 1, 'UTF-8') : substr($brand['brand_name'], 0, 1);
		$h .= '<div class="pb-brand__mark" style="background:' . $color . ';">' . esc_html($init) . '</div>';
	}
	$h .= '</div><div class="pb-brand__txt"><b>' . esc_html($brand['brand_name']) . '</b>';
	if ($title !== '') $h .= '<span>' . esc_html($title) . '</span>';
	$h .= '</div><div class="pb-brand__meta">' . $meta_html . '</div></div>';
	$h .= '<div class="pb-brand__bar" style="background:' . $color . ';"></div>';
	return $h;
}

/** باکس «اطلاعات واریز» — فقط اگر دست‌کم یک فیلد بانکی ست شده باشد */
function cpttf_brand_bank_html($brand){
	$rows = [];
	if ($brand['bank_holder']  !== '') $rows[] = ['صاحب حساب', $brand['bank_holder']]; // v9.7.0
	if ($brand['bank_name']    !== '') $rows[] = ['بانک', $brand['bank_name']];
	if ($brand['bank_account'] !== '') $rows[] = ['شماره حساب', $brand['bank_account']];
	if ($brand['bank_card']    !== '') $rows[] = ['شماره کارت', $brand['bank_card']];
	if ($brand['bank_iban']    !== '') $rows[] = ['شماره شبا', $brand['bank_iban']];
	if (!$rows) return '';
	$h = '<div class="pb-bank"><div class="pb-bank__t">💳 اطلاعات واریز</div><div class="pb-bank__grid">';
	foreach ($rows as $r) $h .= '<div class="pb-bank__r"><span>' . esc_html($r[0]) . ':</span> <b style="font-family:ui-monospace,monospace;">' . esc_html($r[1]) . '</b></div>';
	$h .= '</div></div>';
	return $h;
}

/** امضا/مهر (اگر تصویر ست شده) + متن فوتر */
function cpttf_brand_signfoot_html($brand){
	$sign  = cpttf_brand_img_url($brand['sign_id']);
	$stamp = cpttf_brand_img_url($brand['stamp_id']);
	$h = '';
	if ($sign !== '' || $stamp !== '') {
		$who = trim($brand['manager_name'] . ' ' . $brand['manager_title']);
		$h .= '<div class="pb-signs">';
		$h .= '<div class="pb-signs__cell">' . ($stamp !== '' ? '<img src="' . esc_url($stamp) . '" alt="مهر">' : '') . '<i>مهر</i></div>';
		$h .= '<div class="pb-signs__cell">' . ($sign !== '' ? '<img src="' . esc_url($sign) . '" alt="امضا">' : '') . '<i>' . esc_html($who !== '' ? $who : 'امضا') . '</i></div>';
		$h .= '</div>';
	}
	if ($brand['footer_text'] !== '') $h .= '<div class="pb-footer">' . esc_html($brand['footer_text']) . '</div>';
	return $h;
}

/** CSS مشترک بلوک‌های برند — همه‌ی اسناد چاپی مالی از آن استفاده می‌کنند */
function cpttf_brand_block_css(){
	return '.pb-brand{display:flex;align-items:center;gap:10px;}'
		. '.pb-brand__logo{max-height:46px;max-width:120px;border-radius:8px;}'
		. '.pb-brand__mark{width:46px;height:46px;border-radius:12px;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:20px;}'
		. '.pb-brand__txt{display:flex;flex-direction:column;line-height:1.5;}'
		. '.pb-brand__txt b{font-size:15px;}'
		. '.pb-brand__txt span{font-size:11px;color:#64748b;}'
		. '.pb-brand__meta{margin-inline-start:auto;text-align:left;font-size:10px;color:#475569;line-height:1.8;}'
		. '.pb-brand__bar{height:3.5px;border-radius:99px;margin:6px 0 12px;}'
		. '.pb-bank{border:1.5px dashed #94a3b8;border-radius:10px;padding:8px 12px;margin-top:12px;}'
		. '.pb-bank__t{font-weight:700;font-size:11px;margin-bottom:4px;}'
		. '.pb-bank__grid{display:flex;flex-wrap:wrap;gap:4px 18px;font-size:11px;}'
		. '.pb-bank__r span{color:#64748b;}'
		. '.pb-signs{display:flex;justify-content:space-between;gap:24px;margin-top:26px;}'
		. '.pb-signs__cell{flex:1;text-align:center;min-height:64px;position:relative;}'
		. '.pb-signs__cell img{max-height:60px;max-width:130px;display:block;margin:0 auto 2px;}'
		. '.pb-signs__cell i{display:block;font-style:normal;font-size:10px;color:#475569;border-top:1px dashed #94a3b8;padding-top:4px;margin-top:4px;}'
		. '.pb-footer{margin-top:14px;border-top:1px solid #e2e8f0;padding-top:8px;text-align:center;font-size:10px;color:#94a3b8;}';
}

/** CSS هسته‌ی سند چاپی (برای فاکتور/گزارشات که صفحه‌ی مستقل‌اند) */
function cpttf_print_core_css($paper = 'a4', $base_font_size = '10.5px'){
	$fonts = CPTT_URL . 'assets/fonts/';
	$o  = "@font-face{font-family:'Vazirmatn';font-style:normal;font-weight:400;font-display:swap;src:url('" . esc_url($fonts . 'Vazirmatn-Regular.woff2') . "') format('woff2');}";
	$o .= "@font-face{font-family:'Vazirmatn';font-style:normal;font-weight:500;font-display:swap;src:url('" . esc_url($fonts . 'Vazirmatn-Medium.woff2') . "') format('woff2');}";
	$o .= "@font-face{font-family:'Vazirmatn';font-style:normal;font-weight:700;font-display:swap;src:url('" . esc_url($fonts . 'Vazirmatn-Bold.woff2') . "') format('woff2');}";
	$o .= '@page{size:' . ($paper === 'a5' ? 'A5 portrait' : 'A4 portrait') . ';margin:' . ($paper === 'a5' ? '8mm' : '11mm') . ';}';
	$o .= '*{box-sizing:border-box;}';
	$o .= "body{font-family:'Vazirmatn',Tahoma,Arial,sans-serif;color:#0f172a;margin:14px auto;max-width:" . ($paper === 'a5' ? '140mm' : '190mm') . ';font-size:' . ($paper === 'a5' ? '9px' : $base_font_size) . ';line-height:1.75;background:#fff;}';
	$o .= 'h1{font-size:' . ($paper === 'a5' ? '14px' : '18px') . ';margin:0;font-weight:700;}';
	$o .= 'h2{font-size:13px;margin:16px 0 6px;font-weight:700;}';
	$o .= 'table{width:100%;border-collapse:collapse;margin-top:6px;}';
	$o .= 'th,td{border:1px solid #cbd5e1;padding:4px 6px;text-align:right;vertical-align:top;overflow-wrap:anywhere;}';
	$o .= 'th{background:#f1f5f9;font-size:.92em;font-weight:700;}';
	$o .= 'td.num,th.num{text-align:left;direction:ltr;white-space:nowrap;font-variant-numeric:tabular-nums;}';
	$o .= 'tr.tot td{font-weight:700;background:#f8fafc;}';
	$o .= '.pb-kpis{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 4px;}';
	$o .= '.pb-kpi{flex:1 1 30%;border:1px solid #cbd5e1;border-radius:10px;padding:6px 10px;text-align:center;}';
	$o .= '.pb-kpi>small{display:block;color:#64748b;font-size:.82em;}';
	$o .= '.pb-kpi b{font-size:1.15em;}';
	$o .= '.pb-cols{display:flex;gap:12px;}';
	$o .= '.pb-cols>div{flex:1;min-width:0;}';
	$o .= '.no-print{position:sticky;top:0;background:#fff;border-bottom:1px solid #e2e8f0;padding:8px 0 12px;margin-bottom:12px;z-index:5;}';
	$o .= '.no-print form{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end;}';
	$o .= '.no-print label{font-size:.82em;color:#475569;display:flex;flex-direction:column;gap:3px;font-weight:500;}';
	$o .= '.no-print select{font-family:inherit;font-size:.95em;padding:5px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;}';
	$o .= '.no-print button{font-family:inherit;padding:7px 16px;border-radius:8px;border:1.5px solid #1e293b;background:#1e293b;color:#fff;cursor:pointer;font-weight:700;font-size:.92em;}';
	$o .= '.no-print button.ghost{background:#fff;color:#1e293b;}';
	$o .= '@media print{ .no-print{display:none!important;} body{margin:0 auto;max-width:none;} }';
	return $o;
}

endif;
