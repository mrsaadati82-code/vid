<?php
if (!defined('ABSPATH')) exit;

/**
 * Cheques (اسناد و چک‌ها) — v9.3.0 (فاز ۳ از نقشه‌ی طرف‌حساب)
 *
 * این صفحه «اسناد در راه» (چک‌های دریافتی/پرداختی و سفته‌ها) را مدیریت می‌کند:
 *  - چک فقط یک سند پیگیری است؛ هیچ اثری روی مانده‌ها ندارد تا وقتی «وصول/پاس» شود.
 *  - با دکمه‌ی «✅ وصول/پاس» یک سند واقعی (دریافتی/پرداختی) در همان دفتر مالی ثبت
 *    می‌شود (ref_type=cheque_clear)؛ پس همه‌ی حساب‌ها از همان منبع رسمی قبلی می‌آیند.
 *  - «برگشت چک» فقط وضعیت را عوض می‌کند (اثر مالی ندارد). ابطال/حذف فقط برای چک در انتظار.
 *  - اگر سند دفتریِ «وصول چک» بعداً برگشت زده شود، چک خودکار به «در انتظار» برمی‌گردد.
 */

if (!function_exists('cpttf_cheque_status_chip')) {
	function cpttf_cheque_status_chip($status){
		$v = CPTT_Finance::cheque_status_vocab();
		$status = (string)$status;
		$label = isset($v[$status]) ? $v[$status] : $status;
		return '<span class="cpttf-chq-status cpttf-chq-status--' . esc_attr($status) . '">' . esc_html($label) . '</span>';
	}
}

/** انتخاب‌گر پروژه (نسخه‌ی محلی — مستقل از صفحه‌ی فاکتورها تا وابستگی‌متقابل پیش نیاید) */
if (!function_exists('cpttf_cheque_project_options')) {
	function cpttf_cheque_project_options($selected = 0){
		$selected = (int)$selected;
		$out = '<option value="0">— بدون پروژه —</option>';
		$args = ['post_type' => 'cptt_project', 'post_status' => 'any', 'numberposts' => 400, 'orderby' => 'date', 'order' => 'DESC'];
		foreach (get_posts($args) as $p) {
			$t = get_the_title($p) ?: ('#' . $p->ID);
			$cid = (int)get_post_meta($p->ID, '_cptt_client_user_id', true); // v9.4.0 — کسکید شخص→پروژه
			$out .= '<option value="' . (int)$p->ID . '" data-person="' . $cid . '"' . selected($selected, $p->ID, false) . '>' . esc_html($t) . '</option>';
		}
		return $out;
	}
}

/** تاریخ شمسی «فقط روز» */
if (!function_exists('cpttf_cheque_jdate')) {
	function cpttf_cheque_jdate($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		$full = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($ts) : date('Y-m-d H:i', $ts);
		$parts = preg_split('/\s+/', (string)$full);
		return (string)($parts[0] ?? $full);
	}
}

function cpttf_render_cheques(){
	$cur = CPTT_Finance::currency_label();

	/* فیلترها */
	$f_dir    = isset($_GET['fdir'])    ? (int)$_GET['fdir'] : 0; // 1 دریافتی / -1 پرداختی
	$f_status = isset($_GET['fstatus']) ? sanitize_key($_GET['fstatus']) : '';
	$f_person = isset($_GET['fperson']) ? (int)$_GET['fperson'] : 0;
	$f_from   = isset($_GET['ffrom'])   ? sanitize_text_field(wp_unslash($_GET['ffrom'])) : '';
	$f_to     = isset($_GET['fto'])     ? sanitize_text_field(wp_unslash($_GET['fto']))   : '';
	$f_q      = isset($_GET['fq'])      ? sanitize_text_field(wp_unslash($_GET['fq']))    : '';
	$statuses = CPTT_Finance::cheque_status_vocab();
	if ($f_status !== '' && !isset($statuses[$f_status])) $f_status = '';

	$args = [];
	if ($f_dir !== 0) $args['direction'] = $f_dir > 0 ? 1 : -1;
	if ($f_status !== '') $args['status'] = $f_status;
	if ($f_person > 0) $args['person_id'] = $f_person;
	if ($f_from !== '') $args['from'] = CPTT_Finance::parse_jalali_local($f_from);
	if ($f_to !== '')   $args['to']   = CPTT_Finance::parse_jalali_local($f_to . ' 23:59');
	if ($f_q !== '')    $args['q'] = $f_q;
	// v9.9.5 — صفحه‌بندی چک‌ها
	$per    = isset($_GET['fperpage']) ? (int)$_GET['fperpage'] : 10; // v9.9.6 — ۱۰/۲۵/۵۰/۱۰۰
	if (!in_array($per, [10, 25, 50, 100], true)) $per = 10;
	$fpaged = isset($_GET['fpaged']) ? max(1, (int)$_GET['fpaged']) : 1;
	$total  = (int)CPTT_Finance::get_cheques_count($args);
	$pages  = max(1, (int)ceil(max($total, 1) / $per));
	$fpaged = min($fpaged, $pages);
	$args['limit']  = $per;
	$args['offset'] = ($fpaged - 1) * $per;
	$rows = CPTT_Finance::get_cheques($args);

	$kp = CPTT_Finance::cheque_kpis();
	$q_new    = !empty($_GET['new']);
	$q_dir    = isset($_GET['dir']) ? (((int)$_GET['dir'] >= 0) ? 1 : -1) : 1;
	$q_person = isset($_GET['person']) ? (int)$_GET['person'] : 0;

	$k = function($icon,$label,$value,$color='',$sub=''){
		return '<div class="cpttf-kpi" style="--c:' . esc_attr($color ?: '#64748b') . '"><div class="cpttf-kpi__icon">' . $icon . '</div><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">' . esc_html($label) . '</span><strong class="cpttf-kpi__value">' . $value . '</strong>' . ($sub !== '' ? '<small class="cpttf-kpi__sub">' . $sub . '</small>' : '') . '</div></div>';
	};
	?>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4">
		<?php
		echo $k('📥','چک‌های در راه (دریافتی)', CPTT_Finance::fmt($kp['pend_in']) . ' <small>' . esc_html($cur) . '</small>', '#16a34a', 'در انتظار وصول');
		echo $k('📤','چک‌های در راه (پرداختی)', CPTT_Finance::fmt($kp['pend_out']) . ' <small>' . esc_html($cur) . '</small>', '#ef4444', 'در انتظار پاس/تسویه');
		echo $k('⏰','سررسید نزدیک (۷ روز آینده)', CPTT_Finance::fmt($kp['due7_amt']) . ' <small>' . esc_html($cur) . '</small>', '#f59e0b', CPTT_Finance::fmt($kp['due7_n']) . ' سند');
		echo $k('⚠️','برگشت‌خورده‌ها', CPTT_Finance::fmt($kp['bounced_n']) . ' <small>سند</small>', $kp['bounced_n'] > 0 ? '#dc2626' : '#94a3b8', 'چک برگشتی اثر مالی ندارد');
		?>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>🏦 اسناد و چک‌ها</h2>
				<small style="color:#64748b;font-size:12px;">چک تا «وصول/پاس» نشود هیچ اثری روی مانده‌ها ندارد؛ با وصول، یک سند واقعی در دفتر مالی ثبت می‌شود</small>
			</div>
			<div class="cpttf-card__actions">
				<button class="cpttf-btn cpttf-btn--primary" type="button" data-cpttf-chq-new>+ چک/سفته جدید</button>
			</div>
		</header>
		<div class="cpttf-card__body">
			<form class="cpttf-filters" method="get" action="">
				<input type="hidden" name="page" value="cptt-finance-cheques">
				<label><span>جستجو</span><input type="search" name="fq" value="<?php echo esc_attr($f_q); ?>" placeholder="شماره چک، بانک یا یادداشت…"></label>
				<label><span>جهت</span>
					<select name="fdir">
						<option value="0">همه</option>
						<option value="1" <?php selected($f_dir, 1); ?>>📥 دریافتی (از شخص)</option>
						<option value="-1" <?php selected($f_dir, -1); ?>>📤 پرداختی (به شخص)</option>
					</select>
				</label>
				<label><span>وضعیت</span>
					<select name="fstatus">
						<option value="">همه</option>
						<?php foreach ($statuses as $kk => $ll): ?><option value="<?php echo esc_attr($kk); ?>" <?php selected($f_status, $kk); ?>><?php echo esc_html($ll); ?></option><?php endforeach; ?>
					</select>
				</label>
								<?php CPTT_Finance::render_person_combo($f_person); // v9.9.0 — کمبوی جستجوی اشخاص ?>
				<label><span>سررسید از</span><input type="text" class="cpttf-jdate" name="ffrom" value="<?php echo esc_attr($f_from); ?>" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
				<label><span>تا</span><input type="text" class="cpttf-jdate" name="fto" value="<?php echo esc_attr($f_to); ?>" placeholder="۱۴۰۵/۱۲/۲۹" autocomplete="off"></label>
				<div class="cpttf-filters__actions">
					<button class="cpttf-btn cpttf-btn--primary" type="submit">فیلتر</button>
					<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-cheques')); ?>">پاک‌سازی</a>
				</div>
			</form>
		<?php CPTT_Finance::person_combo_assets(); // v9.9.0 ?>

			<?php if (empty($rows)): ?>
				<p class="cpttf-empty">چکی با این فیلترها یافت نشد. با دکمه‌ی «+ چک/سفته جدید» شروع کنید.</p>
			<?php else: ?>
			<div class="cpttf-table-wrap">
				<table class="cpttf-table cpttf-chq-table">
					<thead><tr>
						<th style="width:56px;">جهت</th><th>شماره سند</th><th>شخص</th><th>بانک/شعبه</th>
						<th>سررسید</th><th class="cpttf-num">مبلغ</th><th>وضعیت</th><th>پروژه</th><th style="width:230px;">اقدامات</th>
					</tr></thead>
					<tbody>
					<?php foreach ($rows as $r):
						$is_in = ((int)$r->direction >= 0);
						$st = (string)$r->status;
						$late = $st === 'pending' && (int)$r->due_ts > 0 && (int)$r->due_ts < (int)current_time('timestamp', true);
						$desc = trim((string)$r->note);
					?>
						<tr class="cpttf-chq-row<?php echo $late ? ' is-late' : ''; ?>" data-id="<?php echo (int)$r->id; ?>">
							<td><?php echo $is_in ? '<span title="دریافتی از شخص">📥</span>' : '<span title="پرداختی به شخص">📤</span>'; ?></td>
							<td>
								<b style="font-family:ui-monospace,monospace;"><?php echo esc_html($r->cheque_no); ?></b>
								<?php if ($desc !== ''): ?><div style="font-size:11px;color:#94a3b8;"><?php echo esc_html(mb_strimwidth($desc, 0, 60, '…')); ?></div><?php endif; ?>
								<?php if ($st === 'cleared' && (int)$r->ledger_id > 0): ?><div style="font-size:11px;color:#059669;">سند دفتر #<?php echo (int)$r->ledger_id; ?></div><?php endif; ?>
							</td>
							<td><b><?php echo esc_html($r->person_name); ?></b></td>
							<td><?php echo esc_html(trim((string)$r->bank . (($r->bank !== '' && $r->branch !== '') ? ' / ' : '') . (string)$r->branch)) ?: '—'; ?></td>
							<td style="white-space:nowrap;"><?php echo esc_html(cpttf_cheque_jdate((int)$r->due_ts)); ?><?php echo $late ? ' <span style="color:#dc2626;font-weight:800;" title="سررسید گذشته">⏰</span>' : ''; ?></td>
							<td class="cpttf-num"><b><?php echo CPTT_Finance::fmt($r->amount); ?></b> <small><?php echo esc_html($cur); ?></small></td>
							<td><?php echo cpttf_cheque_status_chip($st); ?></td>
							<td><?php echo $r->project_title !== '' ? '<span style="font-size:11.5px;">📁 ' . esc_html($r->project_title) . '</span>' : '—'; ?></td>
							<td style="white-space:nowrap;">
								<?php if (in_array($st, ['pending','bounced'], true)): ?>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" data-cpttf-chq-act="cleared" data-id="<?php echo (int)$r->id; ?>">✅ وصول/پاس</button>
								<?php endif; ?>
								<?php if ($st === 'pending'): ?>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--danger" data-cpttf-chq-act="bounced" data-id="<?php echo (int)$r->id; ?>">⚠️ برگشت</button>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" data-cpttf-chq-edit="<?php echo (int)$r->id; ?>">✏️</button>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" data-cpttf-chq-del="<?php echo (int)$r->id; ?>">🗑</button>
								<?php endif; ?>
								<?php if ($st === 'bounced'): ?>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--ghost" data-cpttf-chq-act="pending" data-id="<?php echo (int)$r->id; ?>">↩ بازگشت به انتظار</button>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php echo CPTT_Finance::pager_html('cptt-finance-cheques', $total, $per, $fpaged, ['fdir' => $f_dir, 'fstatus' => $f_status, 'fperson' => $f_person, 'ffrom' => $f_from, 'fto' => $f_to, 'fq' => $f_q]); // v9.9.5 ?>
			<?php endif; ?>
		</div>
	</section>

	<?php // ── مدال ثبت/ویرایش چک ── ?>
	<div class="cpttf-modal" id="cpttf-chq-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-chq-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3 id="cpttf-chq-title">🏦 چک/سفته جدید</h3>
				<button type="button" class="cpttf-modal__close" data-cpttf-chq-close>×</button>
			</header>
			<form id="cpttf-chq-form" class="cpttf-modal__body">
				<input type="hidden" name="id" id="cpttf-chq-id" value="0">
				<div class="cpttf-form-grid">
					<label><span>جهت</span>
						<select name="direction" id="cpttf-chq-dir">
							<option value="1">📥 چک دریافتی (از شخص می‌گیریم)</option>
							<option value="-1">📤 چک پرداختی (به شخص می‌دهیم)</option>
						</select>
					</label>
					<label><span>شخص</span>
						<select name="person_id" id="cpttf-chq-person">
							<option value="0">— انتخاب شخص —</option>
							<?php foreach (CPTT_Finance::get_person_options_list() as $p): ?><option value="<?php echo (int)$p['id']; ?>"><?php echo esc_html($p['label']); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label><span>پروژه (اختیاری)</span>
						<select name="project_id" id="cpttf-chq-project"><?php echo cpttf_cheque_project_options(0); ?></select>
					</label>
					<label><span>شماره چک/سفته</span><input type="text" name="cheque_no" id="cpttf-chq-no" dir="ltr" placeholder="مثلاً ۱۲۳۴۵۶۷۸۹"></label>
					<label><span>بانک</span><input type="text" name="bank" id="cpttf-chq-bank" placeholder="مثلاً ملی، ملت…"></label>
					<label><span>شعبه</span><input type="text" name="branch" id="cpttf-chq-branch" placeholder="اختیاری"></label>
					<label><span>سررسید</span><input type="text" class="cpttf-jdate" name="due" id="cpttf-chq-due" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off"></label>
					<label><span>مبلغ (<?php echo esc_html($cur); ?>)</span><input type="text" name="amount" id="cpttf-chq-amount" dir="ltr" inputmode="numeric" placeholder="0"></label>
					<label class="cpttf-full"><span>یادداشت</span><input type="text" name="note" id="cpttf-chq-note" placeholder="اختیاری — مثلاً بابت تسویه پروژه…"></label>
				</div>
				<p class="cpttf-modal__msg" id="cpttf-chq-msg" style="margin:10px 0 0;font-size:12.5px;color:#dc2626;"></p>
			</form>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-chq-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--primary" id="cpttf-chq-save">💾 ثبت چک</button>
			</footer>
		</div>
	</div>

	<?php // داده‌های چک‌ها برای ویرایش (JSON) ?>
	<script type="application/json" id="cpttf-chq-data"><?php
		$js = [];
		foreach ($rows as $r) {
			$js[(int)$r->id] = [
				'id'=>(int)$r->id,'direction'=>(int)$r->direction,'person_id'=>(int)$r->person_id,'project_id'=>(int)$r->project_id,
				'cheque_no'=>(string)$r->cheque_no,'bank'=>(string)$r->bank,'branch'=>(string)$r->branch,
				'due'=>cpttf_cheque_jdate((int)$r->due_ts),'amount'=>(float)$r->amount,'note'=>(string)$r->note,
			];
		}
		echo wp_json_encode($js);
	?></script>

	<script>
	(function(){
		function boot(){
			if (window.__cpttfChqBound) return; // ثبت یک‌باره (مهم برای پنل توکار)
			window.__cpttfChqBound = true;
			var CFG = window.CPTT_FIN || { ajax:'', nonce:'' };
			var modal = document.getElementById('cpttf-chq-modal');
			var data = {};
			try { data = JSON.parse(document.getElementById('cpttf-chq-data').textContent || '{}'); } catch(_){}
			function $(id){ return document.getElementById(id); }
			function openModal(prefill){
				if (!modal) return;
				$('cpttf-chq-id').value = prefill.id || 0;
				$('cpttf-chq-title').textContent = prefill.id ? '✏️ ویرایش چک' : '🏦 چک/سفته جدید';
				$('cpttf-chq-dir').value = String(prefill.direction || 1);
				$('cpttf-chq-person').value = String(prefill.person_id || 0);
				$('cpttf-chq-project').value = String(prefill.project_id || 0);
				$('cpttf-chq-no').value = prefill.cheque_no || '';
				$('cpttf-chq-bank').value = prefill.bank || '';
				$('cpttf-chq-branch').value = prefill.branch || '';
				$('cpttf-chq-due').value = prefill.due || '';
				$('cpttf-chq-amount').value = prefill.amount ? String(prefill.amount) : '';
				$('cpttf-chq-note').value = prefill.note || '';
				$('cpttf-chq-msg').textContent = '';
				if (typeof chqCascade === 'function') chqCascade();
				modal.hidden = false;
			}
			function closeModal(){ if (modal) modal.hidden = true; }
			function post(action, fd, onOk){
				fd.append('action', action);
				fd.append('nonce', CFG.nonce);
				var x = new XMLHttpRequest();
				x.open('POST', CFG.ajax);
				x.onload = function(){
					var r = null; try { r = JSON.parse(x.responseText); } catch(_){}
					if (r && r.success) { onOk(r); }
					else { window.alert((r && r.data) ? r.data : 'خطا در انجام عملیات'); }
				};
				x.onerror = function(){ window.alert('خطای ارتباط با سرور'); };
				x.send(fd);
			}
			function reloadNow(){ if (window.cpttfReload) window.cpttfReload(); else window.location.reload(); }

			document.addEventListener('click', function(e){
				var t = e.target;
				if (t.closest && t.closest('[data-cpttf-chq-new]')) { e.preventDefault(); openModal({direction: window.__cpttfChqDir || 1, person_id: window.__cpttfChqPerson || 0}); return; }
				if (t.closest && t.closest('[data-cpttf-chq-close]')) { e.preventDefault(); closeModal(); return; }
				var eb = t.closest && t.closest('[data-cpttf-chq-edit]');
				if (eb) {
					e.preventDefault();
					var row = data[eb.getAttribute('data-cpttf-chq-edit')];
					if (row) openModal(row);
					return;
				}
				var db = t.closest && t.closest('[data-cpttf-chq-del]');
				if (db) {
					e.preventDefault();
					if (!window.confirm('این چک حذف شود؟ (چک در انتظار/باطل فقط قابل حذف است؛ اثر مالی ندارد)')) return;
					var fd = new FormData(); fd.append('id', db.getAttribute('data-cpttf-chq-del'));
					post('cptt_fin_cheque_delete', fd, reloadNow);
					return;
				}
				var ab = t.closest && t.closest('[data-cpttf-chq-act]');
				if (ab) {
					e.preventDefault();
					var to = ab.getAttribute('data-cpttf-chq-act');
					var id = ab.getAttribute('data-id');
					var msg = to === 'cleared'
						? 'چک «وصول/پاس» شود؟ یک سند واقعی دریافت/پرداخت در دفتر مالی ثبت می‌شود و وارد مانده‌ها می‌شود.'
						: (to === 'bounced' ? 'چک «برگشت خورده» ثبت شود؟ (اثر مالی ندارد)' : 'چک به «در انتظار» بازگردد؟');
					if (!window.confirm(msg)) return;
					ab.disabled = true;
					var fd2 = new FormData(); fd2.append('id', id); fd2.append('to', to);
					post('cptt_fin_cheque_status', fd2, reloadNow);
					return;
				}
			});

			// v9.4.0 — فیلتر لیست پروژه‌ها بر اساس شخص انتخاب‌شده
			var personEl = $('cpttf-chq-person'), projectEl = $('cpttf-chq-project');
			function chqCascade(){
				if (!personEl || !projectEl) return;
				var pid = String(personEl.value || '0');
				Array.prototype.forEach.call(projectEl.options, function(o){
					var own = o.getAttribute('data-person');
					o.hidden = !(o.value === '0' || pid === '0' || String(own) === pid);
				});
				var cur = projectEl.options[projectEl.selectedIndex];
				if (cur && cur.hidden) projectEl.value = '0';
			}
			if (personEl) personEl.addEventListener('change', chqCascade);

			var saveBtn = $('cpttf-chq-save');
			if (saveBtn) saveBtn.addEventListener('click', function(){
				var fd = new FormData($('cpttf-chq-form'));
				if ((fd.get('person_id')|0) <= 0) { $('cpttf-chq-msg').textContent = 'شخص طرف چک را انتخاب کنید.'; return; }
				if (!String(fd.get('cheque_no') || '').trim()) { $('cpttf-chq-msg').textContent = 'شماره چک/سفته را بنویسید.'; return; }
				saveBtn.disabled = true;
				post('cptt_fin_cheque_save', fd, function(){ reloadNow(); });
				setTimeout(function(){ saveBtn.disabled = false; }, 4000);
			});
		}
		if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
	})();
	</script>
	<?php if ($q_new): ?>
	<script>
	(function(){ // ورود با ?new=1 یا ?person=N (مثل از پرونده‌ی شخص) — بازشدن خودکار مدال
		function auto(){
			window.__cpttfChqDir = <?php echo (int)$q_dir; ?>;
			window.__cpttfChqPerson = <?php echo (int)$q_person; ?>;
			var b = document.querySelector('[data-cpttf-chq-new]');
			if (b) b.click();
		}
		if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(auto, 60); }); else setTimeout(auto, 60);
	})();
	</script>
	<?php endif; ?>
	<?php
}
