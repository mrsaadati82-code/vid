<?php
if (!defined('ABSPATH')) exit;

/**
 * Expert payouts page — v9.2.15
 *
 * - Only steps where expert is assigned ON THE STEP (no project-wide fallback)
 * - Suggested amount from expert_share_percent / expert_share (editable before confirm)
 * - Multi-expert safe shared pool remaining
 * - Treasury account picker
 * - Search/filter toolbar
 * - History edit/delete reopens correctly
 */
function cpttf_render_payouts(){
	$cur = 'ریال';
	$accounts = CPTT_Finance::get_accounts(true);
	$default_account = CPTT_Finance::default_cash_account_id();

	$step_settlement_rows = [];
	$seen_step_paid = [];
	$sum_to_expert = 0;
	$sum_to_admin = 0;
	$sum_unsettled_partial = 0;

	$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
	foreach ($projects as $proj) {
		$stps = get_post_meta($proj->ID, '_cptt_steps', true);
		if (!is_array($stps)) continue;

		// project-level experts only used as soft fallback when step has NO assignment list at all
		// User asked: only show steps where expert is a member of THAT step.
		// So NO project fallback.

		foreach ($stps as $sk => $st) {
			$paid = (float)($st['paid'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ef) $paid += (float)($ef['paid'] ?? 0);
			}
			if ($paid <= 0) continue;

			$assigned_ids = [];
			if (isset($st['assigned_expert_ids']) && is_array($st['assigned_expert_ids'])) {
				$assigned_ids = array_values(array_filter(array_unique(array_map('intval', $st['assigned_expert_ids']))));
			}
			if (empty($assigned_ids) && !empty($st['assigned_expert_id'])) {
				$assigned_ids = [(int)$st['assigned_expert_id']];
			}
			// v9.2.16 — ONLY explicit step assignees. No project-wide fallback.
			if (empty($assigned_ids)) continue;

			$per_expert = (isset($st['expert_settlements']) && is_array($st['expert_settlements'])) ? $st['expert_settlements'] : [];
			$primary_id = !empty($st['assigned_expert_id']) ? (int)$st['assigned_expert_id'] : (int)$assigned_ids[0];

			if (empty($per_expert) && ((float)($st['expert_paid'] ?? 0) > 0 || !empty($st['step_settled']))) {
				$per_expert[(string)$primary_id] = [
					'expert_paid' => (float)($st['expert_paid'] ?? 0),
					'admin_received' => (float)($st['admin_received'] ?? 0),
					'step_settled' => !empty($st['step_settled']) ? 1 : 0,
					'settle_at_fa' => (string)($st['settle_at_fa'] ?? ''),
				];
			}

			$pool_paid_to_experts = 0.0;
			foreach ($per_expert as $_er) {
				if (is_array($_er)) $pool_paid_to_experts += (float)($_er['expert_paid'] ?? 0);
			}
			$pool_remaining = max(0, $paid - $pool_paid_to_experts);

			$step_id = isset($st['id']) ? (string)$st['id'] : (string)$sk;
			$step_title = (string)($st['title'] ?? '—');
			$step_key = $proj->ID . ':' . $step_id;
			if (!isset($seen_step_paid[$step_key])) $seen_step_paid[$step_key] = $paid;

			// legacy single-expert suggested share/percent (applies to each assigned unless per-expert override exists)
			$legacy_share = (float)($st['expert_share'] ?? 0);
			$legacy_pct = isset($st['expert_share_percent']) ? (float)$st['expert_share_percent'] : 0;
			if ($legacy_pct <= 0 && $legacy_share > 0 && $paid > 0) $legacy_pct = (float)round(($legacy_share / $paid) * 100);

			// multi-expert: optional map expert_shares[eid] = ['percent'=>, 'share'=>]
			$share_map = (isset($st['expert_shares']) && is_array($st['expert_shares'])) ? $st['expert_shares'] : [];

			foreach ($assigned_ids as $ae_id) {
				if (!$ae_id) continue;
				$key = (string)$ae_id;
				$has_own = isset($per_expert[$key]) && is_array($per_expert[$key]);
				$exp_to_expert = $has_own ? (float)($per_expert[$key]['expert_paid'] ?? 0) : 0;
				$admin_received = $has_own ? (float)($per_expert[$key]['admin_received'] ?? 0) : 0;
				$settled = $has_own ? (!empty($per_expert[$key]['step_settled']) ? 1 : 0) : 0;
				$settle_at_fa = $has_own ? (string)($per_expert[$key]['settle_at_fa'] ?? '') : '';

				$other_paid = max(0, $pool_paid_to_experts - $exp_to_expert);
				$other_names = [];
				foreach ($assigned_ids as $_oid) {
					if ((int)$_oid === (int)$ae_id) continue;
					if ((float)($per_expert[(string)$_oid]['expert_paid'] ?? 0) > 0) {
						$_ou = get_user_by('id', (int)$_oid);
						$other_names[] = $_ou ? $_ou->display_name : ('#'.(int)$_oid);
					}
				}
				$other_label = $other_paid > 0
					? ('پرداخت‌شده به ' . (!empty($other_names) ? implode('، ', $other_names) : 'دیگران'))
					: 'پرداخت‌شده به دیگران';

				if ($settled) { $sum_to_expert += $exp_to_expert; $sum_to_admin += $admin_received; }
				else { $sum_unsettled_partial += $exp_to_expert; }

				// suggested percent/amount for THIS expert
				$sug_pct = 0.0; $sug_amt = 0.0;
				$user_pct = (float) get_user_meta($ae_id, 'cptt_expert_share_percent', true);
				if (isset($share_map[$key]) && is_array($share_map[$key])) {
					$sug_pct = (float)($share_map[$key]['percent'] ?? 0);
					$sug_amt = (float)($share_map[$key]['share'] ?? 0);
				} elseif (isset($per_expert[$key]['expert_share_percent'])) {
					$sug_pct = (float)$per_expert[$key]['expert_share_percent'];
					$sug_amt = (float)($per_expert[$key]['expert_share'] ?? 0);
				} elseif ($user_pct > 0) {
					$sug_pct = (float)round($user_pct);
					$sug_amt = round($paid * $sug_pct / 100);
				} else {
					// fallback: legacy step fields or equal split
					$n = max(1, count($assigned_ids));
					if ($n === 1) {
						$sug_pct = $legacy_pct;
						$sug_amt = $legacy_share > 0 ? $legacy_share : ($legacy_pct > 0 ? round($paid * $legacy_pct / 100) : 0);
					} else {
						$sug_pct = $legacy_pct > 0 ? (float)round($legacy_pct / $n) : 0.0;
						$sug_amt = $sug_pct > 0 ? round($paid * $sug_pct / 100) : 0;
					}
				}
				if ($sug_pct <= 0 && $sug_amt > 0 && $paid > 0) $sug_pct = (float)round(($sug_amt / $paid) * 100);
				$sug_pct = (float)round($sug_pct);
				if ($sug_amt <= 0 && $sug_pct > 0) $sug_amt = round($paid * $sug_pct / 100);

				// suggested payout now = min(suggested total - already paid to this expert, pool remaining)
				$sug_now = max(0, $sug_amt - $exp_to_expert);
				if ($sug_now > $pool_remaining) $sug_now = $pool_remaining;
				// if no suggestion, default to full remaining for convenience
				if ($sug_now <= 0 && !$settled) $sug_now = $pool_remaining;

				$expert_remain = $settled ? 0 : $pool_remaining;

				$u = get_user_by('id', $ae_id);
				$step_settlement_rows[] = [
					'project_id' => (int)$proj->ID,
					'project_title' => get_the_title($proj),
					'step_id' => $step_id,
					'step_title' => $step_title,
					'expert_id' => $ae_id,
					'expert_name' => $u ? $u->display_name : ('#'.$ae_id),
					'paid' => $paid,
					'exp_to_expert' => $exp_to_expert,
					'admin_received' => $admin_received,
					'pool_paid_to_experts' => $pool_paid_to_experts,
					'pool_remaining' => $pool_remaining,
					'expert_remain' => $expert_remain,
					'suggested_amount' => $sug_now,
					'suggested_percent' => $sug_pct,
					'suggested_total' => $sug_amt,
					'other_paid' => $other_paid,
					'other_label' => $other_label,
					'settled' => $settled,
					'settle_at_fa' => $settle_at_fa,
					'search' => mb_strtolower(get_the_title($proj).' '.$step_title.' '.($u ? $u->display_name : '')),
				];
			}
		}
	}

	$sum_paid = array_sum($seen_step_paid);

	// v9.2.18 — show ALL experts (role cptt_expert + admins who appear in rows), even if remain=0
	$settle_experts = [];
	foreach (get_users(['role__in'=>['cptt_expert','administrator'], 'orderby'=>'display_name','order'=>'ASC']) as $_eu) {
		$settle_experts[(int)$_eu->ID] = [
			'name' => $_eu->display_name,
			'count' => 0,
			'remain' => 0,
			'paid_steps' => 0.0, // sum of step paid for open rows
			'to_expert_settled' => 0.0,
			'to_admin_settled' => 0.0,
			'partial' => 0.0,
		];
	}
	// ensure experts that only appear in rows are included
	foreach ($step_settlement_rows as $_sr) {
		$eid = (int)$_sr['expert_id'];
		if (!$eid) continue;
		if (!isset($settle_experts[$eid])) {
			$u = get_user_by('id', $eid);
			$settle_experts[$eid] = ['name'=>$u?$u->display_name:$_sr['expert_name'],'count'=>0,'remain'=>0,'paid_steps'=>0.0,'to_expert_settled'=>0.0,'to_admin_settled'=>0.0,'partial'=>0.0];
		}
	}
	$expert_step_counted = [];
	$expert_paid_counted = [];
	foreach ($step_settlement_rows as $_sr) {
		$eid = (int)$_sr['expert_id'];
		if (!$eid || !isset($settle_experts[$eid])) continue;
		if (!empty($_sr['settled'])) {
			$settle_experts[$eid]['to_expert_settled'] += (float)$_sr['exp_to_expert'];
			$settle_experts[$eid]['to_admin_settled'] += (float)$_sr['admin_received'];
			continue;
		}
		$settle_experts[$eid]['count']++;
		$settle_experts[$eid]['partial'] += (float)$_sr['exp_to_expert'];
		$ck = $eid.':'.$_sr['project_id'].':'.$_sr['step_id'];
		if (!isset($expert_step_counted[$ck])) {
			$settle_experts[$eid]['remain'] += max(0, (float)$_sr['expert_remain']);
			$expert_step_counted[$ck] = 1;
		}
		if (!isset($expert_paid_counted[$ck])) {
			$settle_experts[$eid]['paid_steps'] += (float)$_sr['paid'];
			$expert_paid_counted[$ck] = 1;
		}
	}
	uasort($settle_experts, function($a,$b){
		$cr = ((float)$b['remain'] <=> (float)$a['remain']);
		if ($cr !== 0) return $cr;
		return strcasecmp($a['name'], $b['name']);
	});
	$sum_remain = array_sum(array_map(function($e){ return (float)$e['remain']; }, $settle_experts));
	// KPI payload for JS (all + per expert)
	$kpi_all = [
		'paid' => (float)$sum_paid,
		'to_admin' => (float)$sum_to_admin,
		'to_expert' => (float)$sum_to_expert,
		'partial' => (float)$sum_unsettled_partial,
		'remain' => (float)$sum_remain,
		'waiting' => (int)count(array_filter($settle_experts, function($e){ return (int)$e['count'] > 0; })),
	];
	$kpi_by_expert = [];
	foreach ($settle_experts as $eid=>$sx) {
		$kpi_by_expert[(string)$eid] = [
			'paid' => (float)$sx['paid_steps'],
			'to_admin' => (float)$sx['to_admin_settled'],
			'to_expert' => (float)$sx['to_expert_settled'],
			'partial' => (float)$sx['partial'],
			'remain' => (float)$sx['remain'],
		'waiting' => (int)$sx['count'],
		];
	}

	$settled_history = [];
	foreach ($step_settlement_rows as $rr) {
		if (!empty($rr['settled'])) $settled_history[] = $rr;
	}
	global $wpdb;
	$manuals = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cptt_ledger WHERE type='expert_manual_payout' ORDER BY created_at DESC LIMIT 100");
	if (is_array($manuals)) {
		foreach ($manuals as $m) {
			$u = get_user_by('id', $m->user_id);
			$settled_history[] = [
				'project_id' => 0,
				'project_title' => '💸 پرداخت دستی',
				'step_id' => 'manual_'.$m->id,
				'step_title' => $m->note ?: 'بدون توضیح',
				'expert_id' => (int)$m->user_id,
				'expert_name' => $u ? $u->display_name : '—',
				'exp_to_expert' => abs((float)$m->amount),
				'admin_received' => 0,
				'settle_at_fa' => class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime(strtotime($m->created_at)) : $m->created_at,
				'is_manual' => true,
				'ledger_id' => $m->id,
				'settled' => 1,
				'search' => mb_strtolower('پرداخت دستی '.($u?$u->display_name:'').' '.($m->note?:'')),
			];
		}
	}

	$all_experts = [];
	foreach (get_users(['role__in'=>['cptt_expert','administrator']]) as $_eu) {
		$all_experts[(int)$_eu->ID] = $_eu->display_name;
	}

	// account options html
	$acc_opts = '';
	foreach ($accounts as $a) {
		$sel = ((int)$a->id === (int)$default_account) ? ' selected' : '';
		$bal = class_exists('CPTT_Finance') ? CPTT_Finance::account_balance((int)$a->id) : 0;
		$acc_opts .= '<option value="'.(int)$a->id.'"'.$sel.'>'.esc_html($a->icon.' '.$a->name.' — موجودی: '.CPTT_Finance::fmt($bal).' ریال').'</option>';
	}
	?>
	<script type="application/json" id="cpttf-payout-kpi-data"><?php echo wp_json_encode(['all'=>$kpi_all,'experts'=>$kpi_by_expert], JSON_UNESCAPED_UNICODE); ?></script>
	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--4" id="cpttf-payout-kpis">
		<div class="cpttf-kpi" style="--c:#0ea5e9">
			<div class="cpttf-kpi__icon">📥</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع دریافتی مراحل (قابل تسویه)</span>
				<strong class="cpttf-kpi__value"><span id="cpttf-kpi-paid"><?php echo CPTT_Finance::fmt($sum_paid); ?></span> <small>ریال</small></strong>
			</div>
		</div>
		<div class="cpttf-kpi" style="--c:#16a34a">
			<div class="cpttf-kpi__icon">🏦</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">سهم تسویه‌شده به مدیر</span>
				<strong class="cpttf-kpi__value"><span id="cpttf-kpi-admin"><?php echo CPTT_Finance::fmt($sum_to_admin); ?></span> <small>ریال</small></strong>
			</div>
		</div>
		<div class="cpttf-kpi" style="--c:#2563eb">
			<div class="cpttf-kpi__icon">👤</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">سهم تسویه‌شده به کارشناسان</span>
				<strong class="cpttf-kpi__value"><span id="cpttf-kpi-expert"><?php echo CPTT_Finance::fmt($sum_to_expert); ?></span> <small>ریال</small></strong>
				<small class="cpttf-kpi__sub" id="cpttf-kpi-partial"><?php echo $sum_unsettled_partial > 0 ? ('+ جزئیِ باز: ' . CPTT_Finance::fmt($sum_unsettled_partial)) : ''; ?></small>
			</div>
		</div>
		<div class="cpttf-kpi" style="--c:#f59e0b">
			<div class="cpttf-kpi__icon">💼</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">کل مانده تسویه</span>
				<strong class="cpttf-kpi__value"><span id="cpttf-kpi-remain"><?php echo CPTT_Finance::fmt($sum_remain); ?></span> <small>ریال</small></strong>
				<small class="cpttf-kpi__sub"><span id="cpttf-kpi-waiting"><?php echo CPTT_Finance::fmt($kpi_all['waiting']); ?></span> مرحله/کارشناس منتظر</small>
			</div>
		</div>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>💼 تسویه مراحل با کارشناسان</h2>
				<small style="color:#64748b;font-size:12px;display:block;margin-top:4px;line-height:1.7;max-width:720px;">
					فقط مراحلی که کارشناس <b>عضو همان مرحله</b> است. مبلغ پیشنهادی از <b>درصد/سهم</b> تعریف‌شده در پروژه می‌آید؛ قبل از تایید قابل اصلاح است.
					درصد ↔ مبلغ در پاپ‌آپ همگام‌اند. با چند کارشناس، مانده از <b>کیسه مشترک مرحله</b> کم می‌شود.
				</small>
			</div>
			<div class="cpttf-card__actions">
				<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--primary" id="cpttf-bulk-settle-selected">✓ تسویه یکجای انتخاب‌شده‌ها</button>
				<button type="button" class="cpttf-btn cpttf-btn--sm" id="cpttf-manual-payment-open">➕ پرداخت دستی</button>
				<button type="button" class="cpttf-btn cpttf-btn--sm" id="cpttf-settled-history-open" style="background:#0f172a;color:#fff;border-color:#0f172a;">📜 تسویه‌های انجام‌شده</button>
			</div>
		</header>
		<div class="cpttf-card__body">
			<div class="cpttf-expert-cards" id="cpttf-expert-cards">
					<button type="button" class="cpttf-expert-card is-active" data-expert=""
						data-remain="<?php echo esc_attr($sum_remain); ?>" data-count="<?php echo esc_attr($kpi_all['waiting']); ?>">
						<span style="width:40px;height:40px;border-radius:50%;background:#eef2ff;display:flex;align-items:center;justify-content:center;font-weight:900;color:#4f46e5;">همه</span>
						<span><b>همه کارشناسان</b><small><?php echo number_format(count($settle_experts)); ?> نفر — مانده <span class="cpttf-card-remain"><?php echo CPTT_Finance::fmt($sum_remain); ?></span> ریال</small></span>
					</button>
					<?php foreach ($settle_experts as $eid => $sx):
						$av_id = (int) get_user_meta($eid, 'cptt_expert_avatar_id', true);
						$av = $av_id ? wp_get_attachment_image_url($av_id, 'thumbnail') : get_avatar_url($eid, ['size'=>64]);
						$zero = ((int)$sx['count'] <= 0 && (float)$sx['remain'] <= 0);
					?>
						<button type="button" class="cpttf-expert-card<?php echo $zero ? ' is-zero' : ''; ?>" data-expert="<?php echo esc_attr($eid); ?>"
							data-remain="<?php echo esc_attr($sx['remain']); ?>" data-count="<?php echo esc_attr($sx['count']); ?>">
							<img src="<?php echo esc_url($av); ?>" alt="">
							<span>
								<b><?php echo esc_html($sx['name']); ?></b>
								<small><?php echo $zero ? 'بدون مانده' : (number_format((int)$sx['count']) . ' مرحله — مانده ' . CPTT_Finance::fmt($sx['remain']) . ' ریال'); ?></small>
							</span>
						</button>
					<?php endforeach; ?>
				</div>

				<div class="cpttf-settle-filters">
					<input type="search" id="cpttf-settle-search" class="cpttf-recv-search" placeholder="جستجو: پروژه، مرحله، کارشناس…">
					<select id="cpttf-settle-status" class="cpttf-recv-select">
						<option value="open">باز / تسویه‌نشده</option>
						<option value="partial">فقط پرداخت جزئی</option>
						<option value="all">همه (شامل صفرمانده)</option>
					</select>
					<span class="cpttf-settle-hint" id="cpttf-settle-hint">—</span>
				</div>

				<div class="cpttf-table-wrap">
					<table class="cpttf-table" id="cpttf-step-settle-table">
						<thead>
							<tr>
								<th style="width:34px;text-align:center;"><input type="checkbox" id="cpttf-settle-check-all" title="انتخاب همهٔ نمایش‌داده‌شده" aria-label="انتخاب همهٔ نمایش‌داده‌شده"></th><?php // v9.5.0 — چک‌باکس انتخاب همه به هدر ستون منتقل شد (استاندارد UX؛ متن فقط روی هاور) ?>
								<th>پروژه / مرحله</th>
								<th>کارشناس</th>
								<th>دریافتی</th>
								<th>پیشنهاد (٪)</th>
								<th>قبلاً پرداخت</th>
								<th>مانده</th>
								<th>وضعیت</th>
								<th style="width:120px">عملیات</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$has_unsettled = false;
						foreach ($step_settlement_rows as $rr):
							if (!empty($rr['settled'])) continue;
							$has_unsettled = true;
							$remain_paid = max(0, (float)$rr['expert_remain']);
							$status = $rr['exp_to_expert'] > 0 ? 'partial' : 'open';
							$status_html = $status === 'partial'
								? '<span class="cpttf-chip cpttf-chip--warn">⏳ پرداخت جزئی</span>'
								: '<span class="cpttf-chip cpttf-chip--muted">تسویه نشده</span>';
						?>
							<tr class="cpttf-step-settle-row"
								data-expert="<?php echo esc_attr($rr['expert_id']); ?>"
								data-status="<?php echo esc_attr($status); ?>"
								data-search="<?php echo esc_attr($rr['search']); ?>"
								data-remain="<?php echo esc_attr($remain_paid); ?>">
								<td>
									<input type="checkbox" class="cpttf-settle-row-check"
										data-project-id="<?php echo esc_attr($rr['project_id']); ?>"
										data-step-id="<?php echo esc_attr($rr['step_id']); ?>"
										data-expert-id="<?php echo esc_attr($rr['expert_id']); ?>"
										data-amount="<?php echo esc_attr((float)$rr['suggested_amount']); ?>"
						data-percent="<?php echo esc_attr((float)$rr['suggested_percent']); ?>"
						data-paid="<?php echo esc_attr((float)$rr['paid']); ?>"
						data-remain="<?php echo esc_attr((float)$remain_paid); ?>"
										data-project-title="<?php echo esc_attr($rr['project_title']); ?>"
										data-step-title="<?php echo esc_attr($rr['step_title']); ?>">
								</td>
								<td>
									<a href="<?php echo esc_url(get_edit_post_link($rr['project_id'])); ?>" target="_blank" style="font-weight:800;color:#0f172a;text-decoration:none;"><?php echo esc_html($rr['project_title']); ?></a>
									<div style="color:#64748b;font-size:11.5px;">مرحله: <?php echo esc_html($rr['step_title']); ?></div>
								</td>
								<td><?php echo esc_html($rr['expert_name']); ?></td>
								<td><b><?php echo CPTT_Finance::fmt($rr['paid']); ?></b></td>
								<td>
									<span class="cpttf-text-info"><b><?php echo esc_html((string)(int)round((float)$rr['suggested_percent'])); ?>٪</b></span>
									<div style="font-size:11px;color:#94a3b8;"><?php echo CPTT_Finance::fmt($rr['suggested_amount']); ?> پیشنهاد</div>
								</td>
								<td class="cpttf-text-info"><b><?php echo CPTT_Finance::fmt($rr['exp_to_expert']); ?></b></td>
								<td class="cpttf-text-danger"><b><?php echo CPTT_Finance::fmt($remain_paid); ?></b></td>
								<td><?php echo $status_html; ?></td>
								<td>
									<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--primary cpttf-step-settle-btn"
										data-project-id="<?php echo esc_attr($rr['project_id']); ?>"
										data-step-id="<?php echo esc_attr($rr['step_id']); ?>"
										data-step-title="<?php echo esc_attr($rr['step_title']); ?>"
										data-project-title="<?php echo esc_attr($rr['project_title']); ?>"
										data-paid="<?php echo esc_attr($rr['paid']); ?>"
										data-already-paid="<?php echo esc_attr((float)($rr['other_paid'] ?? 0)); ?>"
										data-self-paid="<?php echo esc_attr((float)$rr['exp_to_expert']); ?>"
										data-remain="<?php echo esc_attr($remain_paid); ?>"
										data-suggested="<?php echo esc_attr((float)$rr['suggested_amount']); ?>"
										data-suggested-percent="<?php echo esc_attr((float)$rr['suggested_percent']); ?>"
										data-other-label="<?php echo esc_attr($rr['other_label']); ?>"
										data-expert-id="<?php echo esc_attr($rr['expert_id']); ?>"
										data-expert-name="<?php echo esc_attr($rr['expert_name']); ?>">💳 تسویه</button>
								</td>
							</tr>
						<?php endforeach;
						if (!$has_unsettled): ?>
							<tr><td colspan="9" class="cpttf-empty">هیچ مرحله‌ای برای تسویه باقی نمانده.</td></tr>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
		</div>
	</section>

	<!-- settle modal -->
	<div class="cpttf-modal" id="cpttf-step-settle-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-close></div>
		<div class="cpttf-modal__dialog" style="max-width:520px;">
			<header class="cpttf-modal__head">
				<h3>💳 تسویه مرحله با کارشناس</h3>
				<button class="cpttf-modal__close" data-cpttf-close>×</button>
			</header>
			<div class="cpttf-modal__body">
				<p id="cpttf-step-settle-info" style="margin:0 0 12px;color:#475569;font-size:12.5px;line-height:1.8;"></p>
				<div class="cpttf-settle-summary">
					<div><span>دریافتی این مرحله:</span><b id="cpttf-step-settle-paid">0</b></div>
					<div><span>قبلاً به همین کارشناس:</span><b id="cpttf-step-settle-self" class="cpttf-text-info">0</b></div>
					<div><span id="cpttf-step-settle-already-label">پرداخت‌شده به دیگران:</span><b id="cpttf-step-settle-already">0</b></div>
					<div><span>مانده کیسه مرحله:</span><b id="cpttf-step-settle-remain" class="cpttf-text-danger">0</b></div>
				</div>
				<div class="cpttf-form-grid" style="margin-top:14px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">
					<label><span>درصد از دریافتی مرحله</span>
						<input type="number" step="1" min="0" max="100" id="cpttf-step-settle-percent" style="width:100%;margin-top:6px;">
					</label>
					<label><span>مبلغ این پرداخت (<?php echo 'ریال'; ?>)</span>
						<input type="text" id="cpttf-step-settle-amount" class="cpttf-money" inputmode="numeric" style="width:100%;margin-top:6px;">
					</label>
					<label class="cpttf-full" style="grid-column:1/-1;"><span>حساب خزانه (برداشت)</span>
						<select id="cpttf-step-settle-account" style="width:100%;margin-top:6px;"><?php echo $acc_opts; ?></select>
					</label>
				</div>
				<p style="margin:8px 0 0;font-size:11.5px;color:#64748b;line-height:1.6;">
					با تغییر درصد، مبلغ عوض می‌شود و برعکس (نسبت به دریافتی مرحله). سقف پرداخت = مانده کیسه.
					«تسویه نهایی» ردیف را می‌بندد و باقی‌مانده سهم مدیر می‌شود. «ثبت پرداختی» فقط پرداخت جزئی است.
				</p>
				<div id="cpttf-step-settle-msg" style="margin-top:10px;font-size:12px;text-align:center;"></div>
			</div>
			<footer class="cpttf-modal__foot" style="flex-wrap:wrap;gap:8px;">
				<button type="button" class="cpttf-btn cpttf-btn--success" id="cpttf-step-settle-final">✓ تایید تسویه نهایی</button>
				<button type="button" class="cpttf-btn cpttf-btn--warn" id="cpttf-step-settle-partial">⏳ ثبت پرداختی (معلق)</button>
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-close>انصراف</button>
			</footer>
		</div>
	</div>

	<!-- bulk -->
	<div class="cpttf-modal" id="cpttf-bulk-settle-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-close></div>
		<div class="cpttf-modal__dialog" style="max-width:680px;">
			<header class="cpttf-modal__head"><h3>📦 تسویه یکجای انتخاب‌شده‌ها</h3><button class="cpttf-modal__close" data-cpttf-close>×</button></header>
			<div class="cpttf-modal__body">
				<label style="display:block;margin-bottom:10px;"><span>حساب خزانه</span>
					<select id="cpttf-bulk-settle-account" style="width:100%;margin-top:6px;"><?php echo $acc_opts; ?></select>
				</label>
				<div id="cpttf-bulk-settle-list" class="cpttf-bulk-list"></div>
				<div class="cpttf-settle-summary" style="margin-top:12px;"><div><span>جمع کل:</span><b id="cpttf-bulk-settle-total">0</b></div></div>
				<div id="cpttf-bulk-settle-msg" style="margin-top:10px;font-size:12px;text-align:center;"></div>
			</div>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--success" id="cpttf-bulk-settle-confirm">✓ تایید نهایی همه</button>
			</footer>
		</div>
	</div>

	<!-- manual -->
	<div class="cpttf-modal" id="cpttf-manual-payment-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-close></div>
		<div class="cpttf-modal__dialog" style="max-width:460px;">
			<header class="cpttf-modal__head"><h3>➕ پرداخت دستی</h3><button class="cpttf-modal__close" data-cpttf-close>×</button></header>
			<div class="cpttf-modal__body">
				<p style="margin:0 0 12px;color:#64748b;font-size:12px;">به مرحله وصل نیست؛ فقط تاریخچه/خزانه.</p>
				<label style="display:block;margin-bottom:10px;"><span>کارشناس</span>
					<select id="cpttf-manual-payment-expert" style="width:100%;margin-top:6px;">
						<?php foreach ($all_experts as $eid=>$name): ?><option value="<?php echo esc_attr($eid); ?>"><?php echo esc_html($name); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label style="display:block;margin-bottom:10px;"><span>مبلغ (<?php echo 'ریال'; ?>)</span>
					<input type="text" id="cpttf-manual-payment-amount" class="cpttf-money" style="width:100%;margin-top:6px;">
				</label>
				<label style="display:block;margin-bottom:10px;"><span>حساب خزانه</span>
					<select id="cpttf-manual-payment-account" style="width:100%;margin-top:6px;"><?php echo $acc_opts; ?></select>
				</label>
				<label style="display:block;"><span>توضیح</span><textarea id="cpttf-manual-payment-note" rows="2" style="width:100%;margin-top:6px;"></textarea></label>
			</div>
			<footer class="cpttf-modal__foot">
				<button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-close>انصراف</button>
				<button type="button" class="cpttf-btn cpttf-btn--primary" id="cpttf-manual-payment-save">ثبت پرداخت</button>
			</footer>
		</div>
	</div>

	<!-- history -->
	<div class="cpttf-modal" id="cpttf-settled-history-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-close></div>
		<div class="cpttf-modal__dialog" style="max-width:980px;width:96%;">
			<header class="cpttf-modal__head"><h3>📜 تسویه‌های انجام‌شده</h3><button class="cpttf-modal__close" data-cpttf-close>×</button></header>
			<div class="cpttf-modal__body">
				<input type="search" id="cpttf-settled-history-search" class="cpttf-recv-search" style="max-width:100%;margin-bottom:12px;" placeholder="جستجو…">
				<div style="overflow:auto;max-height:60vh;">
					<table class="cpttf-table">
						<thead><tr><th>پروژه / مرحله</th><th>کارشناس</th><th>پرداخت</th><th>سهم مدیر</th><th>تاریخ</th><th style="width:160px">عملیات</th></tr></thead>
						<tbody>
						<?php if (empty($settled_history)): ?>
							<tr><td colspan="6" class="cpttf-empty">خالی</td></tr>
						<?php else: foreach ($settled_history as $rr):
							$is_manual = !empty($rr['is_manual']);
							$srch = $rr['search'] ?? mb_strtolower(($rr['project_title']??'').' '.($rr['step_title']??'').' '.($rr['expert_name']??''));
						?>
							<tr class="cpttf-settled-history-row" data-expert="<?php echo esc_attr((int)$rr['expert_id']); ?>" data-search="<?php echo esc_attr($srch); ?>">
								<td><b><?php echo esc_html($rr['project_title']); ?></b><div style="color:#64748b;font-size:11.5px;"><?php echo esc_html($rr['step_title']); ?></div></td>
								<td><?php echo esc_html($rr['expert_name']); ?></td>
								<td><input type="text" class="cpttf-money <?php echo $is_manual?'cpttf-manual-edit-amount':'cpttf-settle-edit-amount'; ?>" value="<?php echo esc_attr(number_format((float)$rr['exp_to_expert'])); ?>" style="width:120px;"></td>
								<td><?php echo CPTT_Finance::fmt($rr['admin_received'] ?? 0); ?></td>
								<td><?php echo esc_html($rr['settle_at_fa'] ?? '—'); ?></td>
								<td>
									<?php if ($is_manual): ?>
										<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-manual-edit" data-ledger-id="<?php echo esc_attr($rr['ledger_id']); ?>">ذخیره</button>
										<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--danger cpttf-manual-delete" data-ledger-id="<?php echo esc_attr($rr['ledger_id']); ?>">حذف</button>
									<?php else: ?>
										<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-settle-edit" data-project-id="<?php echo esc_attr($rr['project_id']); ?>" data-step-id="<?php echo esc_attr($rr['step_id']); ?>" data-expert-id="<?php echo esc_attr((int)$rr['expert_id']); ?>">ذخیره</button>
										<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--danger cpttf-settle-delete" data-project-id="<?php echo esc_attr($rr['project_id']); ?>" data-step-id="<?php echo esc_attr($rr['step_id']); ?>" data-expert-id="<?php echo esc_attr((int)$rr['expert_id']); ?>">حذف</button>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; endif; ?>
						</tbody>
					</table>
				</div>
			</div>
			<footer class="cpttf-modal__foot"><button type="button" class="cpttf-btn cpttf-btn--ghost" data-cpttf-close>بستن</button></footer>
		</div>
	</div>

	<script>
	(function(){
		function $(s,c){ return (c||document).querySelector(s); }
		function $$(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); }
		function fmt(n){ return Math.round(+n||0).toLocaleString('en-US'); }
		function toNum(v){ return parseFloat(String(v||'').replace(/[^\d.\-]/g,'')) || 0; }
		function currency(){ return 'ریال'; }
		function adminNonce(){ return (window.CPTT_FIN && CPTT_FIN.admin_nonce) || ''; }
		function ajaxUrl(){ return (window.CPTT_FIN && CPTT_FIN.ajax) || (typeof ajaxurl!=='undefined'?ajaxurl:''); }
		function openModal(id){ var m=document.getElementById(id); if(m) m.hidden=false; }
		function postForm(action, fields){
			var fd=new FormData(); fd.append('action',action); fd.append('nonce',adminNonce());
			for (var k in fields) if (Object.prototype.hasOwnProperty.call(fields,k)) fd.append(k, fields[k]);
			return fetch(ajaxUrl(),{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();});
		}

		var activeExpert = '';
		var lockSync = false;

		function applyFilters(){
			var q = (($('#cpttf-settle-search')||{}).value||'').toLowerCase().trim();
			var st = (($('#cpttf-settle-status')||{}).value||'open');
			var shown=0;
			$$('.cpttf-step-settle-row').forEach(function(r){
				var okE = !activeExpert || String(r.dataset.expert)===activeExpert;
				var okS = true;
				if (st==='open') okS = r.dataset.status==='open' || r.dataset.status==='partial';
				if (st==='partial') okS = r.dataset.status==='partial';
				var okQ = !q || (r.dataset.search||'').indexOf(q)!==-1;
				var show = okE && okS && okQ;
				r.style.display = show ? '' : 'none';
				if (show) shown++;
			});
			var hint=$('#cpttf-settle-hint');
			if (hint) hint.textContent = shown + ' ردیف';
		}

		var KPI = {all:{}, experts:{}};
		try {
			var raw = document.getElementById('cpttf-payout-kpi-data');
			if (raw) KPI = JSON.parse(raw.textContent || '{}') || KPI;
		} catch(_){}
		function faNum(n){
			var s = Math.round(+n||0).toLocaleString('en-US');
			var fa=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
			return String(s).replace(/[0-9]/g,function(d){return fa[+d];});
		}
		function updateKpis(eid){
			var k = (!eid) ? (KPI.all||{}) : ((KPI.experts&&KPI.experts[eid]) ? KPI.experts[eid] : {paid:0,to_admin:0,to_expert:0,partial:0,remain:0,waiting:0});
			var map = {
				'cpttf-kpi-paid': k.paid,
				'cpttf-kpi-admin': k.to_admin,
				'cpttf-kpi-expert': k.to_expert,
				'cpttf-kpi-remain': k.remain,
				'cpttf-kpi-waiting': k.waiting
			};
			Object.keys(map).forEach(function(id){ var el=document.getElementById(id); if(el) el.textContent = faNum(map[id]); });
			var p = document.getElementById('cpttf-kpi-partial');
			if (p) p.textContent = (+k.partial > 0) ? ('+ جزئیِ باز: ' + faNum(k.partial)) : '';
		}
		document.addEventListener('click', function(e){
			var card=e.target.closest('.cpttf-expert-card');
			if(!card) return;
			$$('.cpttf-expert-card').forEach(function(x){x.classList.remove('is-active');});
			card.classList.add('is-active');
			activeExpert = String(card.dataset.expert||'');
			var chk=$('#cpttf-settle-check-all'); if(chk) chk.checked=false;
			$$('.cpttf-settle-row-check').forEach(function(ch){ch.checked=false;});
			updateKpis(activeExpert);
			applyFilters();
		});
		updateKpis('');
		var srch=$('#cpttf-settle-search'); if(srch) srch.addEventListener('input', applyFilters);
		var stEl=$('#cpttf-settle-status'); if(stEl) stEl.addEventListener('change', applyFilters);
		var chkAll=$('#cpttf-settle-check-all');
		if(chkAll) chkAll.addEventListener('change', function(){
			$$('.cpttf-settle-row-check').forEach(function(ch){
				var row=ch.closest('.cpttf-step-settle-row');
				ch.checked = (row && row.style.display!=='none') ? chkAll.checked : false;
			});
		});
		// show all by default
		$$('.cpttf-step-settle-row').forEach(function(r){ r.style.display=''; });
		applyFilters();

		// percent <-> amount
		var ctx={};
		function setAmountFromPercent(){
			if (lockSync) return; lockSync=true;
			var pct = Math.max(0, Math.min(100, Math.round(toNum($('#cpttf-step-settle-percent').value))));
			$('#cpttf-step-settle-percent').value = pct;
			var amt = Math.round(ctx.paid * pct / 100);
			// this payment = suggested total for percent minus already self-paid? 
			// User wants percent of step paid for THIS payment amount relative to step paid.
			// Simpler UX: percent maps directly to the amount being paid now, relative to step paid.
			// Cap by remain.
			if (amt > ctx.remain) amt = ctx.remain;
			$('#cpttf-step-settle-amount').value = fmt(amt);
			lockSync=false;
		}
		function setPercentFromAmount(){
			if (lockSync) return; lockSync=true;
			var amt = toNum($('#cpttf-step-settle-amount').value);
			if (amt > ctx.remain) { amt = ctx.remain; $('#cpttf-step-settle-amount').value = fmt(amt); }
			var pct = ctx.paid > 0 ? Math.round((amt / ctx.paid) * 100) : 0;
			$('#cpttf-step-settle-percent').value = pct;
			lockSync=false;
		}
		var pctEl=$('#cpttf-step-settle-percent');
		var amtEl=$('#cpttf-step-settle-amount');
		if(pctEl) pctEl.addEventListener('input', setAmountFromPercent);
		if(amtEl) amtEl.addEventListener('input', setPercentFromAmount);

		function openSettleModal(d){
			ctx=d;
			$('#cpttf-step-settle-info').innerHTML='پروژه: <b>'+d.projectTitle+'</b><br>مرحله: <b>'+d.stepTitle+'</b><br>کارشناس: <b>'+d.expertName+'</b>';
			$('#cpttf-step-settle-paid').textContent=fmt(d.paid);
			$('#cpttf-step-settle-self').textContent=fmt(d.selfPaid||0);
			var al=$('#cpttf-step-settle-already-label'); if(al) al.textContent=d.otherLabel||'پرداخت‌شده به دیگران:';
			$('#cpttf-step-settle-already').textContent=fmt(d.already);
			$('#cpttf-step-settle-remain').textContent=fmt(d.remain);
			var sug = (d.suggested!=null && d.suggested!=='') ? toNum(d.suggested) : d.remain;
			if (sug > d.remain) sug = d.remain;
			lockSync=true;
			$('#cpttf-step-settle-amount').value = fmt(sug);
			$('#cpttf-step-settle-percent').value = d.paid>0 ? Math.round((sug/d.paid)*100) : 0;
			lockSync=false;
			$('#cpttf-step-settle-msg').textContent='';
			openModal('cpttf-step-settle-modal');
		}
		document.addEventListener('click', function(e){
			var btn=e.target.closest('.cpttf-step-settle-btn'); if(!btn) return;
			openSettleModal({
				projectId:btn.dataset.projectId, projectTitle:btn.dataset.projectTitle,
				stepId:btn.dataset.stepId, stepTitle:btn.dataset.stepTitle,
				expertId:btn.dataset.expertId, expertName:btn.dataset.expertName,
				paid:toNum(btn.dataset.paid), already:toNum(btn.dataset.alreadyPaid),
				selfPaid:toNum(btn.dataset.selfPaid), remain:toNum(btn.dataset.remain),
				suggested:toNum(btn.dataset.suggested), otherLabel:btn.dataset.otherLabel||''
			});
		});
		function submitSettle(mode){
			var amount=toNum($('#cpttf-step-settle-amount').value);
			var msg=$('#cpttf-step-settle-msg');
			if(amount<0){ msg.style.color='#dc2626'; msg.textContent='مبلغ منفی مجاز نیست.'; return; }
			if(amount>ctx.remain+0.001){ msg.style.color='#dc2626'; msg.textContent='از مانده بیشتر است.'; return; }
			if(mode==='partial' && amount<=0){ msg.style.color='#dc2626'; msg.textContent='برای پرداخت جزئی مبلغ را وارد کنید.'; return; }
			var btnF=$('#cpttf-step-settle-final'), btnP=$('#cpttf-step-settle-partial');
			btnF.disabled=btnP.disabled=true; msg.style.color='#475569'; msg.textContent='در حال ذخیره…';
			postForm('cptt_step_settle', {
				project_id:ctx.projectId, step_id:ctx.stepId, expert_id:ctx.expertId,
				amount:String(amount), mode:mode,
				account_id: $('#cpttf-step-settle-account').value
			}).then(function(j){
				btnF.disabled=btnP.disabled=false;
				if(j&&j.success){ msg.style.color='#059669'; msg.textContent='✅ ذخیره شد…'; setTimeout(function(){(window.cpttfReload ? cpttfReload() : location.reload());},600); }
				else { msg.style.color='#dc2626'; msg.textContent=(j&&j.data)?j.data:'خطا'; }
			}).catch(function(){ btnF.disabled=btnP.disabled=false; msg.style.color='#dc2626'; msg.textContent='خطای شبکه'; });
		}
		var btnF=$('#cpttf-step-settle-final'); if(btnF) btnF.addEventListener('click', function(){ submitSettle('final'); });
		var btnP=$('#cpttf-step-settle-partial'); if(btnP) btnP.addEventListener('click', function(){ submitSettle('partial'); });

		// bulk
		var bulkBtn=$('#cpttf-bulk-settle-selected'), bulkList=$('#cpttf-bulk-settle-list'), bulkTotal=$('#cpttf-bulk-settle-total'), bulkConfirm=$('#cpttf-bulk-settle-confirm'), bulkMsg=$('#cpttf-bulk-settle-msg');
		function bulkRows(){ return $$('.cpttf-bulk-row', bulkList); }
		function updateBulkRowsFromPercent(){
			var pctEl=$('#cpttf-bulk-global-percent'), amountEl=$('#cpttf-bulk-global-amount');
			var pct=Math.max(0,Math.min(100,toNum(pctEl&&pctEl.value)));
			var total=0;
			bulkRows().forEach(function(r){ var base=toNum(r.dataset.paid), remain=toNum(r.dataset.remain); var amount=Math.min(remain, Math.round(base*pct/100)); r.dataset.amount=String(amount); var a=r.querySelector('.cpttf-bulk-row-amount'); if(a) a.textContent=fmt(amount)+' '+currency(); total+=amount; });
			if(amountEl) amountEl.value=fmt(total); if(bulkTotal) bulkTotal.textContent=fmt(total)+' '+currency();
		}
		function updateBulkRowsFromAmount(){
			var pctEl=$('#cpttf-bulk-global-percent'), amountEl=$('#cpttf-bulk-global-amount');
			var selectedTotal=0; bulkRows().forEach(function(r){ selectedTotal += toNum(r.dataset.paid); });
			var requested=toNum(amountEl&&amountEl.value);
			var pct=selectedTotal>0 ? (requested/selectedTotal)*100 : 0;
			if(pctEl) pctEl.value=Math.round(pct);
			var total=0;
			bulkRows().forEach(function(r){ var base=toNum(r.dataset.paid), remain=toNum(r.dataset.remain); var amount=Math.min(remain, Math.round(base*pct/100)); r.dataset.amount=String(amount); var a=r.querySelector('.cpttf-bulk-row-amount'); if(a) a.textContent=fmt(amount)+' '+currency(); total+=amount; });
			if(bulkTotal) bulkTotal.textContent=fmt(total)+' '+currency();
		}
		if(bulkBtn) bulkBtn.addEventListener('click', function(){
			var checked=$$('.cpttf-settle-row-check:checked').filter(function(ch){ var row=ch.closest('.cpttf-step-settle-row'); return row&&row.style.display!=='none'; });
			if(!checked.length){ alert('ردیفی انتخاب نشده'); return; }
			var totalBase=0, avgPct=0; checked.forEach(function(ch){ totalBase+=toNum(ch.dataset.paid); avgPct=Math.max(avgPct,toNum(ch.dataset.percent)); });
			var html='<div class="cpttf-bulk-global" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;padding:12px;border:1px solid #e2e8f0;border-radius:14px;background:#f8fafc;"><label><span>مبلغ کل انتخاب‌شده</span><input type="text" id="cpttf-bulk-global-amount" class="cpttf-money" style="width:100%;margin-top:6px;"></label><label><span>درصد از جمع کل</span><input type="number" min="0" max="100" step="1" id="cpttf-bulk-global-percent" value="'+Math.round(avgPct||0)+'" style="width:100%;margin-top:6px;"></label><div style="grid-column:1/-1;font-size:11.5px;color:#64748b;">جمع مبنای انتخاب‌شده: '+fmt(totalBase)+' '+currency()+'</div></div>';
			checked.forEach(function(ch){ var pct=toNum(ch.dataset.percent||avgPct||0), amount=Math.min(toNum(ch.dataset.remain), Math.round(toNum(ch.dataset.paid)*pct/100)); html+='<div class="cpttf-bulk-row" data-pid="'+ch.dataset.projectId+'" data-sid="'+ch.dataset.stepId+'" data-eid="'+ch.dataset.expertId+'" data-paid="'+(ch.dataset.paid||0)+'" data-remain="'+(ch.dataset.remain||0)+'" data-amount="'+amount+'">'+'<div><div style="font-weight:800;font-size:12.5px;">'+(ch.dataset.projectTitle||'')+'</div><div style="font-size:11.5px;color:#64748b;">'+(ch.dataset.stepTitle||'')+'</div></div>'+'<div style="font-weight:900;color:#0f172a;" class="cpttf-bulk-row-amount">'+fmt(amount)+' '+currency()+'</div></div>'; });
			bulkList.innerHTML=html; updateBulkRowsFromPercent(); if(bulkMsg) bulkMsg.textContent=''; openModal('cpttf-bulk-settle-modal');
		});
		if(bulkList) bulkList.addEventListener('input', function(e){ if(e.target.id==='cpttf-bulk-global-percent') updateBulkRowsFromPercent(); if(e.target.id==='cpttf-bulk-global-amount') updateBulkRowsFromAmount(); });
		if(bulkConfirm) bulkConfirm.addEventListener('click', async function(){
			var rows=bulkRows(); if(!rows.length) return;
			bulkConfirm.disabled=true; if(bulkMsg){bulkMsg.style.color='#475569'; bulkMsg.textContent='…';}
			var acc=$('#cpttf-bulk-settle-account').value;
			for(var i=0;i<rows.length;i++){
				var r=rows[i]; var amount=toNum(r.dataset.amount); if(amount<=0) continue;
				if(bulkMsg) bulkMsg.textContent='('+(i+1)+'/'+rows.length+')';
				try{ await postForm('cptt_step_settle',{project_id:r.dataset.pid,step_id:r.dataset.sid,expert_id:r.dataset.eid,amount:String(amount),mode:'final',account_id:acc}); }catch(_){}
			}
			if(bulkMsg){bulkMsg.style.color='#059669'; bulkMsg.textContent='✅';} setTimeout(function(){(window.cpttfReload ? cpttfReload() : location.reload());},700);
		});

		// manual
		var mpo=$('#cpttf-manual-payment-open');
		if(mpo) mpo.addEventListener('click', function(){
			var active=$('.cpttf-expert-card.is-active'); var sel=$('#cpttf-manual-payment-expert');
			if(active && active.dataset.expert && sel) sel.value=active.dataset.expert;
			openModal('cpttf-manual-payment-modal');
		});
		var mps=$('#cpttf-manual-payment-save');
		if(mps) mps.addEventListener('click', function(){
			mps.disabled=true; mps.textContent='…';
			postForm('cptt_manual_expert_payment',{
				expert_id:$('#cpttf-manual-payment-expert').value,
				amount:$('#cpttf-manual-payment-amount').value,
				note:$('#cpttf-manual-payment-note').value,
				account_id:$('#cpttf-manual-payment-account').value
			}).then(function(j){ mps.disabled=false; mps.textContent='ثبت پرداخت'; if(j&&j.success) (window.cpttfReload ? cpttfReload() : location.reload()); else alert((j&&j.data)?j.data:'خطا'); })
			.catch(function(){ mps.disabled=false; mps.textContent='ثبت پرداخت'; alert('خطای شبکه'); });
		});

		// history
		var histOpen=$('#cpttf-settled-history-open');
		if(histOpen) histOpen.addEventListener('click', function(){
			var eid=activeExpert||'';
			$$('.cpttf-settled-history-row').forEach(function(r){ r.style.display=(!eid||String(r.dataset.expert||'')===eid)?'':'none'; });
			var box=$('#cpttf-settled-history-modal'); if(box) box.dataset.activeExpert=eid;
			openModal('cpttf-settled-history-modal');
		});
		var hSearch=$('#cpttf-settled-history-search');
		if(hSearch) hSearch.addEventListener('input', function(){
			var q=this.value.toLowerCase(); var box=$('#cpttf-settled-history-modal'); var eid=box?(box.dataset.activeExpert||''):'';
			$$('.cpttf-settled-history-row').forEach(function(r){
				var okE=!eid||String(r.dataset.expert||'')===eid;
				var okS=((r.dataset.search||'').toLowerCase().indexOf(q)>-1);
				r.style.display=(okE&&okS)?'':'none';
			});
		});

		document.addEventListener('click', function(e){
			var eb=e.target.closest('.cpttf-settle-edit,.cpttf-settle-delete');
			if(eb){
				if(eb.classList.contains('cpttf-settle-delete') && !confirm('حذف تسویه و باز شدن مجدد مرحله؟')) return;
				var tr=eb.closest('tr'); var fields={project_id:eb.dataset.projectId,step_id:eb.dataset.stepId,expert_id:eb.dataset.expertId||'',mode:eb.classList.contains('cpttf-settle-delete')?'delete':'edit'};
				if(tr){ var inp=tr.querySelector('.cpttf-settle-edit-amount'); if(inp) fields.amount=inp.value; }
				eb.disabled=true;
				postForm('cptt_step_settlement_adjust', fields).then(function(j){ if(j&&j.success) (window.cpttfReload ? cpttfReload() : location.reload()); else { eb.disabled=false; alert((j&&j.data)?j.data:'خطا'); } })
				.catch(function(){ eb.disabled=false; alert('خطای شبکه'); });
				return;
			}
			var mb=e.target.closest('.cpttf-manual-edit,.cpttf-manual-delete');
			if(mb){
				if(mb.classList.contains('cpttf-manual-delete') && !confirm('حذف پرداخت دستی؟')) return;
				var tr2=mb.closest('tr'); var fields2={ledger_id:mb.dataset.ledgerId, mode:mb.classList.contains('cpttf-manual-delete')?'delete':'edit'};
				if(tr2){ var inp2=tr2.querySelector('.cpttf-manual-edit-amount'); if(inp2) fields2.amount=inp2.value; }
				mb.disabled=true;
				postForm('cptt_manual_expert_payment_adjust', fields2).then(function(j){ if(j&&j.success) (window.cpttfReload ? cpttfReload() : location.reload()); else { mb.disabled=false; alert((j&&j.data)?j.data:'خطا'); } })
				.catch(function(){ mb.disabled=false; alert('خطای شبکه'); });
			}
		});
	})();
	</script>
	<?php
}
