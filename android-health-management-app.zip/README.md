# همراه سلامت و سبک زندگی (Fereshteh Personal Health & Lifestyle Companion)

یک اپلیکیشن اندرویدی/وب کاملاً حرفه‌ای، مدرن، Data-Driven، Local-First و کاملاً راست‌چین (RTL) به زبان فارسی برای مدیریت کامل:
1. **رژیم غذایی و برنامه هفتگی** (شنبه تا جمعه)
2. **سهمیه‌های روزانه** (آب، میوه، لبنیات، پیاده‌روی ۳۵ دقیقه‌ای و مکمل‌ها)
3. **چرخه قاعدگی و تقویم پریود** (Period & Cycle Tracker، علائم PMS، خلق‌وخو و باروری)
4. **گزارش‌های پیشرفت** (روند وزن، پایبندی رژیم، نقشه ثبات و تحلیل‌های هوشمند)
5. **آشپزخانه و دستور پخت رژیمی** (انواع سوپ، غذاهای رژیمی و میان‌وعده‌ها)
6. **مدیریت یادآوری‌ها و تنظیمات** (تقویم شمسی/میلادی، خروجی داده‌ها)

---

## 🏗 معماری پروژه (Architecture)

پروژه بر پایه اصول **Separation of Concerns** و معماری لایه‌ای استاندارد طراحی شده است:

```
┌─────────────────────────────────────────────────────────┐
│                    UI Layer (React 19)                  │
│   Components / Tabs / Modals / Custom Persian Controls │
└────────────────────────────┬────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────┐
│                  Domain & API Layer                     │
│         Next.js App Router API Routes (/api/*)          │
│   Jalali Calendar Helper Module & Cycle Calculations    │
└────────────────────────────┬────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────┐
│                     Data Layer                          │
│            Drizzle ORM & PostgreSQL Models              │
│       Data Seeder (/lib/seed.ts) & Local Backup         │
└─────────────────────────────────────────────────────────┘
```

---

## 📁 ساختار پوشه‌ها (Folder Structure)

```text
├── src/
│   ├── app/
│   │   ├── api/                  # API Route Handlers (Next.js App Router)
│   │   │   ├── cycle/            # مدیریت پریود و علائم چرخه
│   │   │   ├── data/             # پشتیبان‌گیری JSON و بازنشانی
│   │   │   ├── goals/            # بروزرسانی سهمیه‌های روزانه
│   │   │   ├── init/             # راه‌اندازی اولیه و Seeding
│   │   │   ├── meals/            # ثبت و مدیریت وعده‌های غذایی
│   │   │   ├── mood/             # ثبت خلق‌وخو، استرس و خواب
│   │   │   ├── notifications/    # مدیریت یادآوری‌ها
│   │   │   ├── recipes/          # کتابخانه دستور پخت آشپزخانه
│   │   │   ├── symptoms/         # ثبت علائم PMS
│   │   │   ├── user/             # اطلاعات کاربر و تنظیمات
│   │   │   ├── violations/       # ثبت تخلفات غذایی
│   │   │   └── weight/           # ثبت و نمودار تغییرات وزن
│   │   ├── globals.css           # متغیرهای CSS، Vazirmatn Font و انیمیشن‌ها
│   │   ├── layout.tsx            # HTML Root Layout با RTL و زبان fa
│   │   └── page.tsx              # صفحه اصلی اپلیکیشن و state manager
│   ├── components/
│   │   ├── Header.tsx            # نوار بالای صفحه با اطلاعات کاربر و تم
│   │   ├── BottomNav.tsx         # ناوبری اصلی پایین ۵ تب
│   │   ├── tabs/
│   │   │   ├── TodayTab.tsx      # داشبورد اصلی امروز
│   │   │   ├── DietTab.tsx       # برنامه غذایی شنبه تا جمعه
│   │   │   ├── CycleTab.tsx      # پیگیری چرخه قاعدگی و PMS
│   │   │   ├── ReportsTab.tsx    # نمودارها و تحلیل‌ها (Recharts)
│   │   │   └── MoreTab.tsx       # آشپزخانه، قوانین، یادآوری‌ها، تنظیمات
│   │   └── modals/
│   │       ├── QuickCheckInModal.tsx # چک‌این سریع ۳۰ ثانیه‌ای
│   │       ├── WalkingTimerModal.tsx # تایمر زنده پیاده‌روی ۳۵ دقیقه‌ای
│   │       ├── WeightEntryModal.tsx  # ثبت وزن جدید
│   │       └── FruitModal.tsx        # ثبت سهمیه میوه
│   ├── db/
│   │   ├── index.ts              # اتصال به دیتابیس PostgreSQL
│   │   └── schema.ts             # مدل‌های Drizzle ORM (Users, Meals, Cycles...)
│   └── lib/
│       ├── jalali.ts             # محاسبات تقویم شمسی، اعداد فارسی و فازهای چرخه
│       └── seed.ts               # اطلاعات اولیه رژیم، دستور پخت‌ها و قوانین
├── drizzle.config.json           # پیکربندی Drizzle Kit
├── tailwind.config.ts            # تنظیمات Tailwind CSS
├── tsconfig.json                 # تنظیمات TypeScript
└── README.md                     # راهنمای جامع توسعه‌دهنده
```

---

## 🚀 نحوه اجرای پروژه توسط توسعه‌دهنده (Developer Setup)

### ۱. نصب Dependencyها
```bash
npm install
```

### ۲. اتصال به دیتابیس و اعمال Schema
مطمئن شوید دیتابیس PostgreSQL روشن است و متغیر `DATABASE_URL` در فایل `.env` تعریف شده است:
```env
DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:5432/app_db"
```
سپس دستور زیر را برای اعمال جدول‌ها اجرا کنید:
```bash
npx drizzle-kit push
```

### ۳. اجرای محیط توسعه
```bash
npm run dev
```
برنامه در آدرس `http://localhost:3000` قابل دسترسی است.

---

## 🎨 نحوه تغییر Theme (تم و رنگ‌ها)

تم و رنگ‌های اصلی برنامه در فایل `src/app/globals.css` و کلاس‌های Tailwind تنظیم شده‌اند:

* **رژیم و سلامت**: سبز زمرّدی (`emerald-600`, `#10b981`)
* **چرخه قاعدگی**: صورتی/رز گرم (`rose-600`, `#f43f5e`)
* **Dark Mode**: با اضافه شدن کلاس `.dark` به تگ `<html>` فعال می‌شود.

برای تغییر پلت رنگی کافیست متغیرهای گرادیان را در `src/app/globals.css` تغییر دهید.

---

## 🔤 نحوه تغییر فونت فارسی

فونت پیش‌فرض برنامه **Vazirmatn (وزیرمتن)** است که به صورت CDN/Local متصل شده است.

برای تغییر فونت:
1. فونت جدید را در پوشه `public/fonts/` قرار دهید.
2. آدرس `@font-face` را در `src/app/globals.css` ویرایش کنید:
```css
@font-face {
  font-family: 'MyFont';
  src: url('/fonts/MyFont.woff2') format('woff2');
}

body {
  font-family: 'MyFont', sans-serif;
}
```

---

## 🍱 نحوه اضافه کردن غذای جدید به دیتابیس

برای اضافه کردن غذای جدید به **آشپزخانه**، فایل `src/lib/seed.ts` را باز کرده و به آرایه `initialRecipes` مورد جدید اضافه کنید:

```typescript
{
  title: "نام غذای جدید",
  category: "lunch", // 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'soup' | 'diet_special'
  prepTimeMinutes: 25,
  calories: 300,
  imageUrl: "https://...",
  ingredients: [
    { name: "نام ماده اولیه", amount: "مقدار" }
  ],
  steps: [
    "مرحله اول پخت...",
    "مرحله دوم پخت..."
  ],
  suitableMeals: ["ناهار", "شام"]
}
```

---

## 📅 نحوه اضافه کردن رژیم یا روز جدید

برنامه غذایی هفته (شنبه تا جمعه) در فایل `src/lib/seed.ts` در آرایه `mealTemplates` تعریف شده است.
هر روز شامل چهار وعده است:
* `breakfast` (صبحانه)
* `lunch` (ناهار)
* `snack` (عصرانه)
* `dinner` (شام)

میتوانید جدول `diet_plans` در `src/db/schema.ts` را گسترش دهید تا از رژیم‌های چنددوره‌ای، فازهای مختلف رژیم (مثلا فاز تثبیت) یا کاربرهای مختلف پشتیبانی کند.

---

## 🔔 نحوه اضافه کردن Reminder (یادآوری جدید)

برای ایجاد یادآوری جدید:
1. در فایل `src/lib/seed.ts` به آرایه `initialNotifications` آیتم جدید اضافه کنید.
2. یا از طریق API route به آدرس `/api/notifications` متد `POST` ارسال نمایید:

```json
{
  "category": "diet",
  "title": "میان‌وعده عصر",
  "body": "وقت نوش جان کردن میوه یا مغزهاست! 🍎",
  "time": "۱۷:۰۰",
  "isActive": true
}
```

---

## 🌸 نحوه اضافه کردن بخش یا علامت جدید به Period Tracker

برای اضافه کردن علائم جدید PMS:
1. فایل `src/components/tabs/CycleTab.tsx` را باز کنید.
2. به آرایه `symptomsList` علامت جدید اضافه کنید:

```typescript
{ id: "my_new_symptom", label: "عنوان علامت جدید" }
```

3. در صورت نیاز به افزودن فاز جدید یا فرمول جدید برای پیش‌بینی سیکل، توابع موجود در `src/lib/jalali.ts` تابع `calculateCycleInfo` را ویرایش فرمایید.

---

## 📄 مجوز و قابلیت توسعه
این پروژه به صورت Source Code کامل، تمیز، کاملاً ماژولار و قابل توسعه تحویل شده است تا توسعه‌دهندگان، AI Agentها یا تیم‌های فنی بتوانند به راحتی ویژگی‌های جدید به آن اضافه کنند.
