"use client";

import React, { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { BottomNav, TabType } from "@/components/BottomNav";
import { TodayTab } from "@/components/tabs/TodayTab";
import { DietTab } from "@/components/tabs/DietTab";
import { CycleTab } from "@/components/tabs/CycleTab";
import { ReportsTab } from "@/components/tabs/ReportsTab";
import { MoreTab } from "@/components/tabs/MoreTab";

import { QuickCheckInModal } from "@/components/modals/QuickCheckInModal";
import { WalkingTimerModal } from "@/components/modals/WalkingTimerModal";
import { WeightEntryModal } from "@/components/modals/WeightEntryModal";
import { FruitModal } from "@/components/modals/FruitModal";

import { getTodayJalaliString, getCurrentPersianWeekday } from "@/lib/jalali";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabType>("today");
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // App Payload Data
  const [user, setUser] = useState<any>(null);
  const [goals, setGoals] = useState<any>(null);
  const [meals, setMeals] = useState<any[]>([]);
  const [supplements, setSupplements] = useState<any[]>([]);
  const [cycleInfo, setCycleInfo] = useState<any>(null);
  const [notificationsList, setNotificationsList] = useState<any[]>([]);

  const [recipesList, setRecipesList] = useState<any[]>([]);
  const [dietRulesList, setDietRulesList] = useState<any[]>([]);
  const [weightLogsList, setWeightLogsList] = useState<any[]>([]);
  const [symptomLogsList, setSymptomLogsList] = useState<any[]>([]);
  const [moodLogsList, setMoodLogsList] = useState<any[]>([]);
  const [violationsList, setViolationsList] = useState<any[]>([]);

  // Selected day for Diet Tab week selector
  const [selectedWeekday, setSelectedWeekday] = useState<string>(getCurrentPersianWeekday());

  // Modal States
  const [isCheckInOpen, setIsCheckInOpen] = useState(false);
  const [isWalkingOpen, setIsWalkingOpen] = useState(false);
  const [isWeightOpen, setIsWeightOpen] = useState(false);
  const [isFruitOpen, setIsFruitOpen] = useState(false);

  // Bootstrap initial data
  useEffect(() => {
    fetchInitData();
  }, []);

  const fetchInitData = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/init");
      const data = await res.json();

      if (data.success) {
        setUser(data.user);
        setGoals(data.goals);
        setMeals(data.meals);
        setSupplements(data.supplements);
        setCycleInfo(data.cycleInfo);
        setNotificationsList(data.notifications || []);
        if (data.user?.theme === "dark") {
          setIsDarkMode(true);
          document.documentElement.classList.add("dark");
        }
      }

      // Fetch supplementary collections
      fetchRecipes();
      fetchWeightLogs();
      fetchViolations();
    } catch (error) {
      console.error("Error initializing app:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecipes = async () => {
    try {
      const res = await fetch("/api/recipes");
      const data = await res.json();
      if (data.success) setRecipesList(data.recipes);
    } catch (e) {}
  };

  const fetchWeightLogs = async () => {
    try {
      const res = await fetch("/api/weight");
      const data = await res.json();
      if (data.success) setWeightLogsList(data.logs);
    } catch (e) {}
  };

  const fetchViolations = async () => {
    try {
      const res = await fetch("/api/violations");
      const data = await res.json();
      if (data.success) setViolationsList(data.violations);
    } catch (e) {}
  };

  const handleToggleDarkMode = () => {
    const nextMode = !isDarkMode;
    setIsDarkMode(nextMode);
    if (nextMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  // Actions
  const handleToggleMeal = async (mealType: string, isCompleted: boolean) => {
    // Optimistic UI update
    setMeals((prev) =>
      prev.map((m) => (m.mealType === mealType ? { ...m, isCompleted } : m))
    );

    try {
      await fetch("/api/meals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dayOfWeek: selectedWeekday,
          mealType,
          isCompleted,
        }),
      });
    } catch (e) {}
  };

  const handleToggleWaterGlass = async (glassIdx: number) => {
    const currentGlasses = goals?.waterGlasses || 0;
    const newCount = currentGlasses === glassIdx ? glassIdx - 1 : glassIdx;

    setGoals((prev: any) => ({ ...prev, waterGlasses: newCount }));

    try {
      const res = await fetch("/api/goals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ waterGlasses: newCount }),
      });
      const data = await res.json();
      if (data.success) setGoals(data.goals);
    } catch (e) {}
  };

  const handleSaveFruitGrams = async (grams: number) => {
    setGoals((prev: any) => ({ ...prev, fruitGrams: grams }));

    try {
      const res = await fetch("/api/goals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fruitGrams: grams }),
      });
      const data = await res.json();
      if (data.success) setGoals(data.goals);
    } catch (e) {}
  };

  const handleSaveWalkingMinutes = async (minutes: number) => {
    const currentMin = goals?.walkingMinutes || 0;
    const updated = currentMin + minutes;

    setGoals((prev: any) => ({ ...prev, walkingMinutes: updated }));

    try {
      const res = await fetch("/api/goals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ walkingMinutes: updated }),
      });
      const data = await res.json();
      if (data.success) setGoals(data.goals);
    } catch (e) {}
  };

  const handleToggleSupplement = (suppId: number) => {
    setSupplements((prev) =>
      prev.map((s) => (s.id === suppId ? { ...s, isTaken: !s.isTaken } : s))
    );
  };

  const handleSaveWeight = async (weight: number, notes: string) => {
    try {
      const res = await fetch("/api/weight", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ weight, notes }),
      });
      const data = await res.json();
      if (data.success) {
        setUser((prev: any) => ({ ...prev, currentWeight: weight }));
        fetchWeightLogs();
      }
    } catch (e) {}
  };

  const handleLogPeriodStart = async (flowIntensity: string) => {
    try {
      const res = await fetch("/api/cycle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "start_period", flowIntensity }),
      });
      const data = await res.json();
      if (data.success) fetchInitData();
    } catch (e) {}
  };

  const handleLogPeriodEnd = async () => {
    try {
      const res = await fetch("/api/cycle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "end_period" }),
      });
      const data = await res.json();
      if (data.success) fetchInitData();
    } catch (e) {}
  };

  const handleSaveSymptoms = async (symptoms: string[], severities: Record<string, string>) => {
    try {
      await fetch("/api/symptoms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symptoms, severities }),
      });
    } catch (e) {}
  };

  const handleSaveMood = async (mood: string, stressLevel: number, energyLevel: number) => {
    try {
      await fetch("/api/mood", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mood, stressLevel, energyLevel }),
      });
    } catch (e) {}
  };

  const handleLogViolation = async (v: any) => {
    try {
      const res = await fetch("/api/violations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(v),
      });
      const data = await res.json();
      if (data.success) fetchViolations();
    } catch (e) {}
  };

  const handleToggleNotification = async (id: number, isActive: boolean) => {
    setNotificationsList((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isActive } : n))
    );

    try {
      await fetch("/api/notifications", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, isActive }),
      });
    } catch (e) {}
  };

  const handleExportBackup = async () => {
    try {
      const res = await fetch("/api/data");
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fereshteh-health-backup-${getTodayJalaliString().replace(/\//g, "-")}.json`;
      a.click();
    } catch (e) {}
  };

  const handleResetData = async () => {
    if (confirm("آیا از بازنشانی تمام داده‌ها اطمینان دارید؟")) {
      try {
        await fetch("/api/data", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "reset" }),
        });
        fetchInitData();
      } catch (e) {}
    }
  };

  const handleSelectWeekday = async (day: string) => {
    setSelectedWeekday(day);
    try {
      const res = await fetch(`/api/meals?dayOfWeek=${encodeURIComponent(day)}`);
      const data = await res.json();
      if (data.success) setMeals(data.meals);
    } catch (e) {}
  };

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors ${isDarkMode ? "dark" : ""}`}>
      {/* Header */}
      <Header
        userName={user?.name || "فرشته"}
        dietDay={user?.dietCurrentDay || 12}
        dietTotalDays={user?.dietTotalDays || 21}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
        onOpenCheckIn={() => setIsCheckInOpen(true)}
        onOpenNotifications={() => setActiveTab("more")}
      />

      {/* Main Container */}
      <main className="max-w-4xl mx-auto px-4 pt-5 pb-8">
        {loading ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-3 text-slate-400">
            <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs font-bold">در حال بارگذاری همراه سلامت فرشته...</p>
          </div>
        ) : (
          <>
            {activeTab === "today" && (
              <TodayTab
                user={user}
                goals={goals}
                meals={meals}
                supplements={supplements}
                cycleInfo={cycleInfo}
                onOpenWalkingTimer={() => setIsWalkingOpen(true)}
                onOpenWaterModal={() => {}}
                onOpenFruitModal={() => setIsFruitOpen(true)}
                onOpenCheckIn={() => setIsCheckInOpen(true)}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onToggleWaterGlass={handleToggleWaterGlass}
              />
            )}

            {activeTab === "diet" && (
              <DietTab
                currentWeekday={getCurrentPersianWeekday()}
                meals={meals}
                goals={goals}
                supplements={supplements}
                onToggleMeal={handleToggleMeal}
                onToggleWaterGlass={handleToggleWaterGlass}
                onToggleDairy={(val) => {}}
                onToggleSupplement={handleToggleSupplement}
                onOpenWalkingTimer={() => setIsWalkingOpen(true)}
                onOpenFruitModal={() => setIsFruitOpen(true)}
                onSelectWeekday={handleSelectWeekday}
                selectedDay={selectedWeekday}
              />
            )}

            {activeTab === "cycle" && (
              <CycleTab
                cycleInfo={cycleInfo}
                user={user}
                recentDays={[]}
                symptomLogsList={symptomLogsList}
                moodLogsList={moodLogsList}
                onLogPeriodStart={handleLogPeriodStart}
                onLogPeriodEnd={handleLogPeriodEnd}
                onSaveSymptoms={handleSaveSymptoms}
                onSaveMood={handleSaveMood}
                onSaveSleep={() => {}}
              />
            )}

            {activeTab === "reports" && (
              <ReportsTab
                user={user}
                weightLogsList={weightLogsList}
                goals={goals}
                symptomLogsList={symptomLogsList}
                moodLogsList={moodLogsList}
                violationsList={violationsList}
                onOpenWeightModal={() => setIsWeightOpen(true)}
              />
            )}

            {activeTab === "more" && (
              <MoreTab
                user={user}
                recipesList={recipesList}
                dietRulesList={dietRulesList}
                notificationsList={notificationsList}
                onToggleNotification={handleToggleNotification}
                onLogViolation={handleLogViolation}
                onUpdateUserSettings={() => {}}
                onExportBackup={handleExportBackup}
                onResetData={handleResetData}
                isDarkMode={isDarkMode}
                onToggleDarkMode={handleToggleDarkMode}
              />
            )}
          </>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        isPeriodActive={cycleInfo?.isPeriod}
      />

      {/* Modals */}
      <QuickCheckInModal
        isOpen={isCheckInOpen}
        onClose={() => setIsCheckInOpen(false)}
        onSaveCheckIn={(payload) => {
          if (payload.isPeriod) handleLogPeriodStart(payload.flow);
          handleSaveMood(payload.mood, payload.stress, payload.energy);
        }}
      />

      <WalkingTimerModal
        isOpen={isWalkingOpen}
        onClose={() => setIsWalkingOpen(false)}
        onSaveMinutes={handleSaveWalkingMinutes}
      />

      <WeightEntryModal
        isOpen={isWeightOpen}
        onClose={() => setIsWeightOpen(false)}
        onSaveWeight={handleSaveWeight}
        currentWeight={user?.currentWeight}
      />

      <FruitModal
        isOpen={isFruitOpen}
        onClose={() => setIsFruitOpen(false)}
        onSaveGrams={handleSaveFruitGrams}
        currentGrams={goals?.fruitGrams}
      />
    </div>
  );
}
