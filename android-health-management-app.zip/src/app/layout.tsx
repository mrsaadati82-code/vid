import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "همراه سلامت و سبک زندگی | Fereshteh Companion",
  description: "اپلیکیشن کامل مدیریت رژیم غذایی، سلامت روزانه، سبک زندگی و چرخه قاعدگی (Period Tracker)",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 antialiased font-sans selection:bg-emerald-500 selection:text-white">
        {children}
      </body>
    </html>
  );
}
