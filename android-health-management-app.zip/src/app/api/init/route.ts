import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  dietPlans,
  dailyGoals,
  supplements,
  supplementLogs,
  mealLogs,
  periodCycles,
  notifications,
} from "@/db/schema";
import { ensureDataSeeded } from "@/lib/seed";
import { getTodayJalaliString, calculateCycleInfo, getCurrentPersianWeekday } from "@/lib/jalali";
import { eq, and } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDataSeeded();

    const todayJalali = getTodayJalaliString();
    const currentWeekday = getCurrentPersianWeekday();

    // 1. Fetch User
    const userList = await db.select().from(users).limit(1);
    const user = userList[0] || null;

    // 2. Fetch or create Today's Goals
    let goalsList = await db.select().from(dailyGoals).where(eq(dailyGoals.date, todayJalali)).limit(1);
    let todayGoal = goalsList[0];

    if (!todayGoal) {
      const inserted = await db
        .insert(dailyGoals)
        .values({
          date: todayJalali,
          waterGlasses: 0,
          waterGoal: 4,
          fruitGrams: 0,
          fruitGoal: 500,
          walkingMinutes: 0,
          walkingGoal: 35,
          dairyGlasses: 0,
          dairyGoal: 1,
          dietScore: 0,
        })
        .returning();
      todayGoal = inserted[0];
    }

    // 3. Fetch Today's Meal Plan for current day of week
    const todayMealsSchedule = await db
      .select()
      .from(dietPlans)
      .where(eq(dietPlans.dayOfWeek, currentWeekday));

    // Fetch meal completion status for today
    const todayMealLogsList = await db
      .select()
      .from(mealLogs)
      .where(eq(mealLogs.date, todayJalali));

    // Merge completion status
    const meals = todayMealsSchedule.map((meal) => {
      const logged = todayMealLogsList.find((l) => l.mealType === meal.mealType);
      return {
        ...meal,
        isCompleted: logged ? logged.isCompleted : false,
      };
    });

    // 4. Supplements & today's logs
    const activeSupplements = await db.select().from(supplements).where(eq(supplements.isActive, true));
    const suppLogsToday = await db.select().from(supplementLogs).where(eq(supplementLogs.date, todayJalali));

    const supplementsWithStatus = activeSupplements.map((supp) => {
      const log = suppLogsToday.find((l) => l.supplementId === supp.id);
      return {
        ...supp,
        isTaken: log ? log.isTaken : false,
      };
    });

    // 5. Calculate Period Cycle Info
    const cycleInfo = calculateCycleInfo(
      user?.lastPeriodStart || "1403/11/15",
      user?.cycleAvgLength || 28,
      user?.periodAvgLength || 6
    );

    // 6. Fetch Active Notifications
    const activeNotifications = await db.select().from(notifications);

    return NextResponse.json({
      success: true,
      todayDate: todayJalali,
      weekday: currentWeekday,
      user,
      goals: todayGoal,
      meals,
      supplements: supplementsWithStatus,
      cycleInfo,
      notifications: activeNotifications,
    });
  } catch (error: any) {
    console.error("Init Error:", error);
    return NextResponse.json({ success: false, error: error?.message || "Internal server error" }, { status: 500 });
  }
}
