import { NextResponse } from "next/server";
import { db } from "@/db";
import { foodViolations } from "@/db/schema";
import { getTodayJalaliString } from "@/lib/jalali";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db.select().from(foodViolations).orderBy(desc(foodViolations.date));
    return NextResponse.json({ success: true, violations: list });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch food violations" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { foodItem, portion, time, reason, notes = "", date = getTodayJalaliString() } = body;

    if (!foodItem || !portion || !reason) {
      return NextResponse.json({ success: false, error: "لطفاً موارد ضروری را وارد کنید" }, { status: 400 });
    }

    const inserted = await db
      .insert(foodViolations)
      .values({
        date,
        foodItem,
        portion,
        time: time || "۱۶:۰۰",
        reason,
        notes,
      })
      .returning();

    return NextResponse.json({ success: true, violation: inserted[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to log violation" }, { status: 500 });
  }
}
