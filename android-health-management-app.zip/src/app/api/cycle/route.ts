import { NextResponse } from "next/server";
import { db } from "@/db";
import { periodCycles, periodDays, users } from "@/db/schema";
import { getTodayJalaliString, calculateCycleInfo } from "@/lib/jalali";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const userList = await db.select().from(users).limit(1);
    const user = userList[0];

    const cycles = await db.select().from(periodCycles).orderBy(desc(periodCycles.startDate));
    const recentDays = await db.select().from(periodDays).limit(30);

    const cycleInfo = calculateCycleInfo(
      user?.lastPeriodStart || "1403/11/15",
      user?.cycleAvgLength || 28,
      user?.periodAvgLength || 6
    );

    return NextResponse.json({
      success: true,
      cycleInfo,
      cycles,
      recentDays,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch cycle info" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { action, startDate, endDate, flowIntensity, isSpotting, date = getTodayJalaliString() } = body;

    const userList = await db.select().from(users).limit(1);
    const user = userList[0];

    if (action === "start_period") {
      // Create new period cycle
      const inserted = await db
        .insert(periodCycles)
        .values({
          startDate: startDate || date,
          cycleLength: user?.cycleAvgLength || 28,
          periodLength: user?.periodAvgLength || 6,
        })
        .returning();

      // Update user's lastPeriodStart
      if (user) {
        await db
          .update(users)
          .set({ lastPeriodStart: startDate || date })
          .where(eq(users.id, user.id));
      }

      // Log flow day
      await db.insert(periodDays).values({
        date: startDate || date,
        flowIntensity: flowIntensity || "medium",
        isSpotting: !!isSpotting,
      });

      return NextResponse.json({ success: true, cycle: inserted[0] });
    }

    if (action === "end_period") {
      const activeCycle = await db
        .select()
        .from(periodCycles)
        .orderBy(desc(periodCycles.startDate))
        .limit(1);

      if (activeCycle.length > 0) {
        await db
          .update(periodCycles)
          .set({ endDate: endDate || date })
          .where(eq(periodCycles.id, activeCycle[0].id));
      }

      return NextResponse.json({ success: true });
    }

    if (action === "log_flow") {
      const existingFlow = await db.select().from(periodDays).where(eq(periodDays.date, date)).limit(1);

      if (existingFlow.length > 0) {
        await db
          .update(periodDays)
          .set({
            flowIntensity: flowIntensity || "medium",
            isSpotting: !!isSpotting,
          })
          .where(eq(periodDays.id, existingFlow[0].id));
      } else {
        await db.insert(periodDays).values({
          date,
          flowIntensity: flowIntensity || "medium",
          isSpotting: !!isSpotting,
        });
      }

      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Cycle operation failed" }, { status: 500 });
  }
}
