import { NextResponse } from "next/server";
import { db } from "@/db";
import { symptomLogs } from "@/db/schema";
import { getTodayJalaliString } from "@/lib/jalali";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const logs = await db.select().from(symptomLogs).orderBy(desc(symptomLogs.date)).limit(30);
    return NextResponse.json({ success: true, logs });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch symptoms" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { symptoms = [], severities = {}, notes = "", date = getTodayJalaliString() } = body;

    const existing = await db.select().from(symptomLogs).where(eq(symptomLogs.date, date)).limit(1);

    if (existing.length > 0) {
      const updated = await db
        .update(symptomLogs)
        .set({
          symptoms,
          severities,
          notes,
        })
        .where(eq(symptomLogs.id, existing[0].id))
        .returning();

      return NextResponse.json({ success: true, log: updated[0] });
    } else {
      const inserted = await db
        .insert(symptomLogs)
        .values({
          date,
          symptoms,
          severities,
          notes,
        })
        .returning();

      return NextResponse.json({ success: true, log: inserted[0] });
    }
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to log symptoms" }, { status: 500 });
  }
}
