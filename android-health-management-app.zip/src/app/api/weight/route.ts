import { NextResponse } from "next/server";
import { db } from "@/db";
import { weightLogs, users } from "@/db/schema";
import { getTodayJalaliString } from "@/lib/jalali";
import { eq, desc, asc } from "drizzle-orm";

export async function GET() {
  try {
    const logs = await db.select().from(weightLogs).orderBy(asc(weightLogs.date));
    const userList = await db.select().from(users).limit(1);
    const user = userList[0];

    return NextResponse.json({
      success: true,
      logs,
      user,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch weight logs" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { weight, notes = "", date = getTodayJalaliString() } = body;

    if (!weight || isNaN(weight)) {
      return NextResponse.json({ success: false, error: "وزن نامعتبر است" }, { status: 400 });
    }

    const inserted = await db
      .insert(weightLogs)
      .values({
        date,
        weight: parseFloat(weight),
        notes,
      })
      .returning();

    // Also update current weight on user profile
    const userList = await db.select().from(users).limit(1);
    if (userList.length > 0) {
      await db
        .update(users)
        .set({ currentWeight: parseFloat(weight) })
        .where(eq(users.id, userList[0].id));
    }

    return NextResponse.json({ success: true, log: inserted[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to log weight" }, { status: 500 });
  }
}
