import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const userList = await db.select().from(users).limit(1);
    return NextResponse.json({ success: true, user: userList[0] || null });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch user" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const userList = await db.select().from(users).limit(1);
    
    if (userList.length === 0) {
      return NextResponse.json({ success: false, error: "کاربر یافت نشد" }, { status: 404 });
    }

    const userId = userList[0].id;
    const updated = await db
      .update(users)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();

    return NextResponse.json({ success: true, user: updated[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to update user profile" }, { status: 500 });
  }
}
