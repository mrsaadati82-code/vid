import { NextResponse } from "next/server";
import { db } from "@/db";
import { dietPlans, mealLogs } from "@/db/schema";
import { getTodayJalaliString } from "@/lib/jalali";
import { eq, and } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const dayOfWeek = searchParams.get("dayOfWeek") || "شنبه";
    const date = searchParams.get("date") || getTodayJalaliString();

    const planMeals = await db.select().from(dietPlans).where(eq(dietPlans.dayOfWeek, dayOfWeek));
    const logs = await db.select().from(mealLogs).where(eq(mealLogs.date, date));

    const meals = planMeals.map((meal) => {
      const log = logs.find((l) => l.mealType === meal.mealType);
      return {
        ...meal,
        isCompleted: log ? log.isCompleted : false,
      };
    });

    return NextResponse.json({ success: true, meals, dayOfWeek, date });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch meals" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { dayOfWeek, mealType, isCompleted, date = getTodayJalaliString() } = body;

    const existingLog = await db
      .select()
      .from(mealLogs)
      .where(and(eq(mealLogs.date, date), eq(mealLogs.mealType, mealType)))
      .limit(1);

    if (existingLog.length > 0) {
      await db
        .update(mealLogs)
        .set({
          isCompleted,
          completedAt: isCompleted ? new Date() : null,
        })
        .where(eq(mealLogs.id, existingLog[0].id));
    } else {
      await db.insert(mealLogs).values({
        date,
        dayOfWeek,
        mealType,
        isCompleted,
        completedAt: isCompleted ? new Date() : null,
      });
    }

    return NextResponse.json({ success: true, mealType, isCompleted });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to update meal" }, { status: 500 });
  }
}
