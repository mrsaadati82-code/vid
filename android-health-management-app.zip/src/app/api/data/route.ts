import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  dietPlans,
  dailyGoals,
  weightLogs,
  moodLogs,
  sleepLogs,
  periodCycles,
  periodDays,
  symptomLogs,
  foodViolations,
} from "@/db/schema";
import { ensureDataSeeded } from "@/lib/seed";

export async function GET() {
  try {
    const userList = await db.select().from(users);
    const goals = await db.select().from(dailyGoals);
    const weights = await db.select().from(weightLogs);
    const moods = await db.select().from(moodLogs);
    const sleeps = await db.select().from(sleepLogs);
    const cycles = await db.select().from(periodCycles);
    const cycleDaysList = await db.select().from(periodDays);
    const symptoms = await db.select().from(symptomLogs);
    const violations = await db.select().from(foodViolations);

    const backupData = {
      exportDate: new Date().toISOString(),
      version: "1.0.0",
      user: userList[0] || null,
      goals,
      weights,
      moods,
      sleeps,
      cycles,
      cycleDaysList,
      symptoms,
      violations,
    };

    return NextResponse.json(backupData);
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Export failed" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === "reset") {
      await db.delete(dailyGoals);
      await db.delete(weightLogs);
      await db.delete(moodLogs);
      await db.delete(sleepLogs);
      await db.delete(periodCycles);
      await db.delete(periodDays);
      await db.delete(symptomLogs);
      await db.delete(foodViolations);
      await db.delete(users);

      await ensureDataSeeded();
      return NextResponse.json({ success: true, message: "اطلاعات با موفقیت بازنشانی گردید" });
    }

    return NextResponse.json({ success: false, error: "عملیات غیرمجاز" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Data operation failed" }, { status: 500 });
  }
}
