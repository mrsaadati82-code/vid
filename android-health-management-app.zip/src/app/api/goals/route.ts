import { NextResponse } from "next/server";
import { db } from "@/db";
import { dailyGoals } from "@/db/schema";
import { getTodayJalaliString } from "@/lib/jalali";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const date = body.date || getTodayJalaliString();

    const existing = await db.select().from(dailyGoals).where(eq(dailyGoals.date, date)).limit(1);

    let current = existing[0];
    if (!current) {
      const inserted = await db
        .insert(dailyGoals)
        .values({
          date,
          waterGlasses: 0,
          waterGoal: 4,
          fruitGrams: 0,
          fruitGoal: 500,
          walkingMinutes: 0,
          walkingGoal: 35,
          dairyGlasses: 0,
          dairyGoal: 1,
          dietScore: 0,
        })
        .returning();
      current = inserted[0];
    }

    const waterGlasses = body.waterGlasses !== undefined ? body.waterGlasses : current.waterGlasses;
    const fruitGrams = body.fruitGrams !== undefined ? body.fruitGrams : current.fruitGrams;
    const walkingMinutes = body.walkingMinutes !== undefined ? body.walkingMinutes : current.walkingMinutes;
    const dairyGlasses = body.dairyGlasses !== undefined ? body.dairyGlasses : current.dairyGlasses;

    // Calculate score out of 100
    const waterScore = Math.min(100, (waterGlasses / (current.waterGoal || 4)) * 100);
    const fruitScore = Math.min(100, (fruitGrams / (current.fruitGoal || 500)) * 100);
    const walkingScore = Math.min(100, (walkingMinutes / (current.walkingGoal || 35)) * 100);
    const dairyScore = Math.min(100, (dairyGlasses / (current.dairyGoal || 1)) * 100);

    const calculatedScore = Math.round((waterScore + fruitScore + walkingScore + dairyScore) / 4);

    const updated = await db
      .update(dailyGoals)
      .set({
        waterGlasses,
        fruitGrams,
        walkingMinutes,
        dairyGlasses,
        dietScore: calculatedScore,
      })
      .where(eq(dailyGoals.id, current.id))
      .returning();

    return NextResponse.json({ success: true, goals: updated[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to update goals" }, { status: 500 });
  }
}
