import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db.select().from(notifications);
    return NextResponse.json({ success: true, notifications: list });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch notifications" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { id, isActive, time, snoozeMinutes } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "شناسه یادآوری نامشخص است" }, { status: 400 });
    }

    const updated = await db
      .update(notifications)
      .set({
        isActive: isActive !== undefined ? isActive : true,
        time: time !== undefined ? time : "۰۸:۰۰",
        snoozeMinutes: snoozeMinutes !== undefined ? snoozeMinutes : 10,
      })
      .where(eq(notifications.id, id))
      .returning();

    return NextResponse.json({ success: true, notification: updated[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to update notification" }, { status: 500 });
  }
}
