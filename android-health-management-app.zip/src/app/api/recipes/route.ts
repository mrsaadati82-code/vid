import { NextResponse } from "next/server";
import { db } from "@/db";
import { recipes } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");

    let query = db.select().from(recipes);
    if (category && category !== "all") {
      const list = await db.select().from(recipes).where(eq(recipes.category, category));
      return NextResponse.json({ success: true, recipes: list });
    }

    const list = await query;
    return NextResponse.json({ success: true, recipes: list });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch recipes" }, { status: 500 });
  }
}
