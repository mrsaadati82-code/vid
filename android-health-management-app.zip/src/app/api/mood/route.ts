import { NextResponse } from "next/server";
import { db } from "@/db";
import { moodLogs, sleepLogs } from "@/db/schema";
import { getTodayJalaliString } from "@/lib/jalali";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const moods = await db.select().from(moodLogs).orderBy(desc(moodLogs.date)).limit(30);
    const sleeps = await db.select().from(sleepLogs).orderBy(desc(sleepLogs.date)).limit(30);

    return NextResponse.json({ success: true, moods, sleeps });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to fetch mood/sleep logs" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { mood, stressLevel, energyLevel, notes, sleepDuration, sleepQuality, date = getTodayJalaliString() } = body;

    // Mood Log
    if (mood) {
      const existingMood = await db.select().from(moodLogs).where(eq(moodLogs.date, date)).limit(1);
      if (existingMood.length > 0) {
        await db
          .update(moodLogs)
          .set({
            mood,
            stressLevel: stressLevel !== undefined ? stressLevel : existingMood[0].stressLevel,
            energyLevel: energyLevel !== undefined ? energyLevel : existingMood[0].energyLevel,
            notes: notes !== undefined ? notes : existingMood[0].notes,
          })
          .where(eq(moodLogs.id, existingMood[0].id));
      } else {
        await db.insert(moodLogs).values({
          date,
          mood,
          stressLevel: stressLevel || 3,
          energyLevel: energyLevel || 3,
          notes: notes || "",
        });
      }
    }

    // Sleep Log
    if (sleepDuration !== undefined) {
      const existingSleep = await db.select().from(sleepLogs).where(eq(sleepLogs.date, date)).limit(1);
      if (existingSleep.length > 0) {
        await db
          .update(sleepLogs)
          .set({
            durationHours: sleepDuration,
            quality: sleepQuality || "good",
          })
          .where(eq(sleepLogs.id, existingSleep[0].id));
      } else {
        await db.insert(sleepLogs).values({
          date,
          durationHours: sleepDuration,
          quality: sleepQuality || "good",
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || "Failed to log mood/sleep" }, { status: 500 });
  }
}
