"use client";

import React from "react";
import { LayoutDashboard, UtensilsCrossed, CalendarHeart, BarChart3, MoreHorizontal } from "lucide-react";

export type TabType = "today" | "diet" | "cycle" | "reports" | "more";

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  isPeriodActive?: boolean;
}

export function BottomNav({ activeTab, onTabChange, isPeriodActive }: BottomNavProps) {
  const tabs = [
    {
      id: "today" as TabType,
      label: "امروز",
      icon: LayoutDashboard,
    },
    {
      id: "diet" as TabType,
      label: "رژیم من",
      icon: UtensilsCrossed,
    },
    {
      id: "cycle" as TabType,
      label: "چرخه من",
      icon: CalendarHeart,
      badge: isPeriodActive ? "پریود" : null,
    },
    {
      id: "reports" as TabType,
      label: "گزارش من",
      icon: BarChart3,
    },
    {
      id: "more" as TabType,
      label: "بیشتر",
      icon: MoreHorizontal,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 glass-card border-t border-slate-200/80 dark:border-slate-800 px-2 py-2 transition-colors">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          // Color customization per tab
          let activeColorClass = "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/80";
          if (tab.id === "cycle") {
            activeColorClass = "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/80";
          }

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-3 rounded-2xl transition-all duration-200 ${
                isActive
                  ? `${activeColorClass} font-bold scale-105 shadow-2xs`
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium"
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? "stroke-[2.5]" : "stroke-[1.8]"}`} />
                {tab.badge && (
                  <span className="absolute -top-1.5 -right-3 px-1 py-0.2 bg-rose-500 text-white text-[9px] font-bold rounded-full animate-pulse">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] mt-1 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
