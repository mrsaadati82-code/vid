"use client";

import React, { useState } from "react";
import {
  Utensils,
  BookOpen,
  AlertOctagon,
  Bell,
  Settings,
  Search,
  ChevronLeft,
  Clock,
  Flame,
  CheckCircle2,
  XCircle,
  Droplet,
  Apple,
  Milk,
  Footprints,
  Sparkles,
  Pill,
  Moon,
  Database,
  Download,
  RotateCcw,
  Check,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

interface MoreTabProps {
  user: any;
  recipesList: any[];
  dietRulesList: any[];
  notificationsList: any[];
  onToggleNotification: (id: number, isActive: boolean) => void;
  onLogViolation: (violation: any) => void;
  onUpdateUserSettings: (settings: any) => void;
  onExportBackup: () => void;
  onResetData: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export function MoreTab({
  user,
  recipesList,
  dietRulesList,
  notificationsList,
  onToggleNotification,
  onLogViolation,
  onUpdateUserSettings,
  onExportBackup,
  onResetData,
  isDarkMode,
  onToggleDarkMode,
}: MoreTabProps) {
  const [subSection, setSubSection] = useState<"menu" | "kitchen" | "rules" | "violation" | "notifications" | "settings">("menu");

  // Kitchen State
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeRecipe, setActiveRecipe] = useState<any>(null);

  // Violation Form State
  const [vFood, setVFood] = useState("");
  const [vPortion, setVPortion] = useState("");
  const [vTime, setVTime] = useState("۱۶:۰۰");
  const [vReason, setVReason] = useState("هوس");
  const [vNotes, setVNotes] = useState("");
  const [vSuccess, setVSuccess] = useState(false);

  // Settings State
  const [calendarType, setCalendarType] = useState(user?.calendarType || "shamsi");
  const [usePersianNums, setUsePersianNums] = useState(user?.usePersianNumbers ?? true);
  const [cycleAvgLength, setCycleAvgLength] = useState(user?.cycleAvgLength || 28);
  const [periodAvgLength, setPeriodAvgLength] = useState(user?.periodAvgLength || 6);

  const categories = [
    { id: "all", label: "همه" },
    { id: "breakfast", label: "صبحانه" },
    { id: "lunch", label: "ناهار" },
    { id: "dinner", label: "شام" },
    { id: "soup", label: "سوپ" },
    { id: "diet_special", label: "رژیمی" },
  ];

  const filteredRecipes = recipesList?.filter((r) => {
    const matchesCat = selectedCategory === "all" || r.category === selectedCategory;
    const matchesSearch = !searchQuery || r.title.includes(searchQuery);
    return matchesCat && matchesSearch;
  });

  const handleViolationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vFood || !vPortion) return;

    onLogViolation({
      foodItem: vFood,
      portion: vPortion,
      time: vTime,
      reason: vReason,
      notes: vNotes,
    });

    setVFood("");
    setVPortion("");
    setVNotes("");
    setVSuccess(true);
    setTimeout(() => setVSuccess(false), 3000);
  };

  const handleSaveSettings = () => {
    onUpdateUserSettings({
      calendarType,
      usePersianNumbers: usePersianNums,
      cycleAvgLength: Number(cycleAvgLength),
      periodAvgLength: Number(periodAvgLength),
    });
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Navigation Header if in sub-section */}
      {subSection !== "menu" && (
        <button
          onClick={() => setSubSection("menu")}
          className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
        >
          <ChevronLeft className="w-4 h-4 rotate-180" />
          <span>بازگشت به منوی بیشتر</span>
        </button>
      )}

      {/* Main Menu Grid */}
      {subSection === "menu" && (
        <div className="space-y-5">
          <div>
            <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100">
              امکانات و ابزارها 🛠
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              آشپزخانه رژیمی، قوانین من، ثبت تخلف، اعلان‌ها و تنظیمات
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Kitchen */}
            <div
              onClick={() => setSubSection("kitchen")}
              className="glass-card rounded-2xl p-4 cursor-pointer hover:border-emerald-400 transition-all flex items-center justify-between border border-slate-200/80 dark:border-slate-800 shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                  <Utensils className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    🍳 آشپزخانه و دستور غذاها
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    فرنی، زرشک‌پلو، کتلت، سوپ جو و...
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            </div>

            {/* Diet Rules */}
            <div
              onClick={() => setSubSection("rules")}
              className="glass-card rounded-2xl p-4 cursor-pointer hover:border-emerald-400 transition-all flex items-center justify-between border border-slate-200/80 dark:border-slate-800 shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    📜 قوانین من
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    غذاهای مجاز، ممنوع، آب، میوه و وعده آزاد
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            </div>

            {/* Food Violations */}
            <div
              onClick={() => setSubSection("violation")}
              className="glass-card rounded-2xl p-4 cursor-pointer hover:border-amber-400 transition-all flex items-center justify-between border border-slate-200/80 dark:border-slate-800 shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
                  <AlertOctagon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    🍕 ثبت تخلف غذایی
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    امروز خارج از برنامه چی خوردی؟
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            </div>

            {/* Notification Center */}
            <div
              onClick={() => setSubSection("notifications")}
              className="glass-card rounded-2xl p-4 cursor-pointer hover:border-blue-400 transition-all flex items-center justify-between border border-slate-200/80 dark:border-slate-800 shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    🔔 مرکز یادآوری‌ها
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    تنظیم ساعت اعلان رژیم، آب، پریود و...
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            </div>

            {/* Settings */}
            <div
              onClick={() => setSubSection("settings")}
              className="col-span-1 sm:col-span-2 glass-card rounded-2xl p-4 cursor-pointer hover:border-purple-400 transition-all flex items-center justify-between border border-slate-200/80 dark:border-slate-800 shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    ⚙️ تنظیمات و پشتیبان‌گیری
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    تقویم شمسی/میلادی، خروجی JSON، بازنشانی داده‌ها
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </div>
      )}

      {/* SECTION 1: Kitchen Recipes */}
      {subSection === "kitchen" && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 dark:text-slate-100">
              آشپزخانه رژیمی 🍳
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              دستور پخت غذای رژیمی همراه با مواد اولیه و مراحل پخت
            </p>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            <input
              type="text"
              placeholder="جستجوی غذا یا مواد اولیه..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 focus:outline-none"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 ${
                  selectedCategory === c.id
                    ? "bg-amber-500 text-white shadow-xs"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          {/* Recipe Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
            {filteredRecipes && filteredRecipes.length > 0 ? (
              filteredRecipes.map((r) => (
                <div
                  key={r.id}
                  onClick={() => setActiveRecipe(r)}
                  className="glass-card rounded-2xl overflow-hidden cursor-pointer hover:shadow-md transition-all border border-slate-200/80 dark:border-slate-800"
                >
                  {r.imageUrl && (
                    <div className="h-32 w-full overflow-hidden relative">
                      <img
                        src={r.imageUrl}
                        alt={r.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                      <span className="absolute top-2 right-2 px-2 py-0.5 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold rounded-md">
                        {toPersianDigits(r.calories || 300)} کالری
                      </span>
                    </div>
                  )}
                  <div className="p-3.5 space-y-1.5">
                    <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                      {r.title}
                    </h3>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-500" />
                        {toPersianDigits(r.prepTimeMinutes)} دقیقه
                      </span>
                      <span>•</span>
                      <span>وعده: {r.suitableMeals?.join("، ")}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400 py-6 text-center col-span-2">
                غذایی یافت نشد.
              </p>
            )}
          </div>

          {/* Recipe Detail Modal */}
          {activeRecipe && (
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="glass-card bg-white dark:bg-slate-900 rounded-3xl p-5 max-w-lg w-full max-h-[85vh] overflow-y-auto space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    {activeRecipe.title}
                  </h3>
                  <button
                    onClick={() => setActiveRecipe(null)}
                    className="p-1 rounded-full text-slate-400 hover:text-slate-600"
                  >
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>

                {activeRecipe.imageUrl && (
                  <img
                    src={activeRecipe.imageUrl}
                    alt={activeRecipe.title}
                    className="w-full h-44 object-cover rounded-2xl"
                  />
                )}

                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400">
                    مواد اولیه:
                  </h4>
                  <ul className="grid grid-cols-2 gap-2 text-xs">
                    {activeRecipe.ingredients?.map((ing: any, i: number) => (
                      <li
                        key={i}
                        className="bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-slate-700 dark:text-slate-200 flex justify-between"
                      >
                        <span>• {ing.name}</span>
                        <span className="font-bold text-emerald-600">
                          {toPersianDigits(ing.amount)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                    مراحل پخت:
                  </h4>
                  <ol className="space-y-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {activeRecipe.steps?.map((step: string, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold flex items-center justify-center shrink-0">
                          {toPersianDigits(i + 1)}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: Diet Rules */}
      {subSection === "rules" && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 dark:text-slate-100">
              قوانین من (Diet Rules) 📜
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              دستورالعمل‌ها، خوراکی‌های مجاز و ممنوع
            </p>
          </div>

          <div className="space-y-3">
            {dietRulesList &&
              dietRulesList.map((rule) => (
                <div
                  key={rule.id}
                  className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-1.5"
                >
                  <div className="flex items-center gap-2">
                    {rule.category === "allowed" && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                    {rule.category === "forbidden" && <XCircle className="w-4 h-4 text-rose-500" />}
                    {rule.category === "water" && <Droplet className="w-4 h-4 text-blue-500" />}
                    {rule.category === "fruit" && <Apple className="w-4 h-4 text-red-500" />}
                    {rule.category === "dairy" && <Milk className="w-4 h-4 text-cyan-500" />}
                    {rule.category === "walking" && <Footprints className="w-4 h-4 text-emerald-500" />}
                    {rule.category === "free_meal" && <Sparkles className="w-4 h-4 text-amber-500" />}
                    {rule.category === "supplements" && <Pill className="w-4 h-4 text-purple-500" />}

                    <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                      {rule.title}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed pr-6">
                    {rule.content}
                  </p>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* SECTION 3: Food Violation */}
      {subSection === "violation" && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 dark:text-slate-100">
              ثبت تخلف غذایی 🍕
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              امروز خارج از برنامه غذایی چیزی خوردی؟ صبورانه ثبت کن
            </p>
          </div>

          <form onSubmit={handleViolationSubmit} className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                نام ماده غذایی:
              </label>
              <input
                type="text"
                placeholder="مثلاً: کیک شکلاتی، چیپس، نوشابه..."
                value={vFood}
                onChange={(e) => setVFood(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 focus:outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  مقدار مصرف:
                </label>
                <input
                  type="text"
                  placeholder="مثلاً: ۱ اسلایس، ۱ لیوان"
                  value={vPortion}
                  onChange={(e) => setVPortion(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  زمان مصرف:
                </label>
                <input
                  type="text"
                  value={vTime}
                  onChange={(e) => setVTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                دلیل اصلی تخلف:
              </label>
              <select
                value={vReason}
                onChange={(e) => setVReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 focus:outline-none"
              >
                <option value="گرسنگی">گرسنگی شدید</option>
                <option value="هوس">هوس غذایی</option>
                <option value="استرس">استرس یا هیجان</option>
                <option value="مهمانی">مهمانی و دورهمی</option>
                <option value="بی‌حوصلگی">بی‌حوصلگی</option>
                <option value="سایر">سایر موارد</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 text-white text-xs font-bold shadow-md shadow-amber-500/20 hover:bg-amber-600 transition-all"
            >
              ثبت تخلف
            </button>

            {vSuccess && (
              <p className="text-xs text-emerald-600 dark:text-emerald-400 font-bold text-center">
                ✓ تخلف با موفقیت ثبت شد.
              </p>
            )}
          </form>
        </div>
      )}

      {/* SECTION 4: Notification Center */}
      {subSection === "notifications" && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 dark:text-slate-100">
              مرکز یادآوری‌ها 🔔
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              مدیریت ساعت و فعال‌سازی اعلان‌های روزانه
            </p>
          </div>

          <div className="space-y-2.5">
            {notificationsList &&
              notificationsList.map((n) => (
                <div
                  key={n.id}
                  className="glass-card rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                      {n.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {n.body}
                    </p>
                    <span className="inline-block text-[10px] font-bold text-blue-600 dark:text-blue-400">
                      ساعت {toPersianDigits(n.time)}
                    </span>
                  </div>

                  <button
                    onClick={() => onToggleNotification(n.id, !n.isActive)}
                    className="p-1 text-slate-600 dark:text-slate-300"
                  >
                    {n.isActive ? (
                      <ToggleRight className="w-8 h-8 text-emerald-500" />
                    ) : (
                      <ToggleLeft className="w-8 h-8 text-slate-400" />
                    )}
                  </button>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* SECTION 5: Settings & Backup */}
      {subSection === "settings" && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 dark:text-slate-100">
              تنظیمات و پشتیبان‌گیری ⚙️
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              شخصی‌سازی تقویم، فونت، تم و خروجی داده‌ها
            </p>
          </div>

          <div className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-4">
            {/* Theme */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                حالت تاریک (Dark Mode):
              </span>
              <button
                onClick={onToggleDarkMode}
                className="px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-bold"
              >
                {isDarkMode ? "فعال 🌙" : "غیرفعال ☀️"}
              </button>
            </div>

            {/* Calendar Switch */}
            <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-3">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                نوع تقویم:
              </span>
              <select
                value={calendarType}
                onChange={(e) => {
                  setCalendarType(e.target.value);
                  handleSaveSettings();
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700"
              >
                <option value="shamsi">تقویم شمسی (Jalali)</option>
                <option value="gregorian">تقویم میلادی</option>
              </select>
            </div>

            {/* Numbers */}
            <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-3">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                نمایش اعداد فارسی:
              </span>
              <button
                onClick={() => {
                  setUsePersianNums(!usePersianNums);
                  handleSaveSettings();
                }}
                className="px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-bold"
              >
                {usePersianNums ? "فارسی (۱۲۳)" : "انگلیسی (123)"}
              </button>
            </div>

            {/* Data Backup & Restore */}
            <div className="border-t border-slate-100 dark:border-slate-800 pt-3 space-y-2">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-purple-500" />
                <span>حریم خصوصی و داده‌های Local-First</span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                تمام داده‌های شما محرمانه و روی دستگاه ذخیره می‌شود.
              </p>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={onExportBackup}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-purple-600 text-white text-xs font-bold shadow-xs hover:bg-purple-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>دانلود خروجی JSON</span>
                </button>

                <button
                  onClick={onResetData}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-xs font-bold hover:bg-rose-200"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>بازنشانی داده‌ها</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
