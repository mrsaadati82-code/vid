"use client";

import React from "react";
import {
  Utensils,
  Droplet,
  Apple,
  Milk,
  Footprints,
  Pill,
  TrendingDown,
  Award,
  Sparkles,
  ChevronLeft,
  Calendar,
  Flame,
  Plus,
} from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

interface TodayTabProps {
  user: any;
  goals: any;
  meals: any[];
  supplements: any[];
  cycleInfo: any;
  onOpenWalkingTimer: () => void;
  onOpenWaterModal: () => void;
  onOpenFruitModal: () => void;
  onOpenCheckIn: () => void;
  onNavigateTab: (tab: string) => void;
  onToggleWaterGlass: (index: number) => void;
}

export function TodayTab({
  user,
  goals,
  meals,
  supplements,
  cycleInfo,
  onOpenWalkingTimer,
  onOpenWaterModal,
  onOpenFruitModal,
  onOpenCheckIn,
  onNavigateTab,
  onToggleWaterGlass,
}: TodayTabProps) {
  const currentWeight = user?.currentWeight || 69.2;
  const startWeight = user?.startWeight || 74.5;
  const targetWeight = user?.targetWeight || 62.0;

  const totalToLose = Math.max(0.1, startWeight - targetWeight);
  const totalLost = Math.max(0, startWeight - currentWeight);
  const progressPercent = Math.min(100, Math.round((totalLost / totalToLose) * 100));

  const completedMealsCount = meals?.filter((m) => m.isCompleted).length || 0;
  const totalMealsCount = meals?.length || 4;

  const waterGlasses = goals?.waterGlasses || 0;
  const waterGoal = goals?.waterGoal || 4;

  const fruitGrams = goals?.fruitGrams || 0;
  const fruitGoal = goals?.fruitGoal || 500;

  const walkingMinutes = goals?.walkingMinutes || 0;
  const walkingGoal = goals?.walkingGoal || 35;

  const dairyGlasses = goals?.dairyGlasses || 0;
  const dairyGoal = goals?.dairyGoal || 1;

  const takenSupplementsCount = supplements?.filter((s) => s.isTaken).length || 0;
  const totalSupplementsCount = supplements?.length || 4;

  const dietScore = goals?.dietScore || 85;

  return (
    <div className="space-y-5 pb-24 animate-in fade-in duration-300">
      {/* 1. Main Progress Summary Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-800 text-white p-5 shadow-xl shadow-emerald-900/20">
        <div className="absolute -top-12 -left-12 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -right-10 w-36 h-36 bg-amber-400/20 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Progress Ring Graphic */}
          <div className="relative flex items-center justify-center w-36 h-36 shrink-0">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="10"
                className="text-white/20"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="10"
                className="text-amber-300 transition-all duration-1000 ease-out"
                fill="transparent"
                strokeDasharray="251.2"
                strokeDashoffset={251.2 - (251.2 * progressPercent) / 100}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-black tracking-tight">{toPersianDigits(progressPercent)}٪</span>
              <span className="text-[10px] text-emerald-100 font-medium">پیشرفت رژیم</span>
            </div>
          </div>

          {/* Details & Metrics */}
          <div className="flex-1 text-center md:text-right space-y-3 w-full">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold text-emerald-100 border border-white/20">
                <Flame className="w-3.5 h-3.5 text-amber-300" />
                روز {toPersianDigits(user?.dietCurrentDay || 12)} از {toPersianDigits(user?.dietTotalDays || 21)}
              </span>

              <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-200">
                <Award className="w-4 h-4 text-amber-300" />
                امتیاز امروز: {toPersianDigits(dietScore)} از ۱۰۰
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 bg-black/15 backdrop-blur-md rounded-2xl p-3 border border-white/10">
              <div className="text-center">
                <span className="block text-[10px] text-emerald-100 font-medium">وزن فعلی</span>
                <span className="text-sm font-bold text-white">{toPersianDigits(currentWeight)} کیلو</span>
              </div>
              <div className="text-center border-x border-white/15">
                <span className="block text-[10px] text-emerald-100 font-medium">کاهش تا امروز</span>
                <span className="text-sm font-bold text-emerald-200 flex items-center justify-center gap-0.5">
                  <TrendingDown className="w-3 h-3 text-emerald-300" />
                  {toPersianDigits(totalLost.toFixed(1))} کیلو
                </span>
              </div>
              <div className="text-center">
                <span className="block text-[10px] text-emerald-100 font-medium">وزن هدف</span>
                <span className="text-sm font-bold text-amber-200">{toPersianDigits(targetWeight)} کیلو</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Cycle Quick Status Banner */}
      <div
        onClick={() => onNavigateTab("cycle")}
        className="glass-card rounded-2xl p-4 cursor-pointer hover:border-rose-300 dark:hover:border-rose-800 transition-all flex items-center justify-between border-l-4 border-l-rose-500 shadow-xs"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/80 flex items-center justify-center text-rose-600 dark:text-rose-400 font-bold shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                وضعیت چرخه: {cycleInfo?.phaseTitle}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950 text-[10px] font-bold text-rose-600 dark:text-rose-300">
                روز {toPersianDigits(cycleInfo?.cycleDay || 1)}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              {cycleInfo?.daysUntilNextPeriod > 0
                ? `${toPersianDigits(cycleInfo.daysUntilNextPeriod)} روز تا پریود بعدی (تخمینی: ${toPersianDigits(cycleInfo.nextPeriodDate)})`
                : "دوران خونریزی فعلی"}
            </p>
          </div>
        </div>

        <ChevronLeft className="w-5 h-5 text-slate-400 dark:text-slate-500" />
      </div>

      {/* 3. Section Title: "امروز چقدر خوب پیش رفتی؟" */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h2 className="text-base font-extrabold text-slate-800 dark:text-slate-100">
            امروز چقدر خوب پیش رفتی؟ 🌟
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            سهمیه‌ها و وعده‌های روزانه‌ات را لمس و ثبت کن
          </p>
        </div>

        <button
          onClick={onOpenCheckIn}
          className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
        >
          <Sparkles className="w-3.5 h-3.5" />
          چک‌این روزانه
        </button>
      </div>

      {/* 4. Grid of Daily Trackers */}
      <div className="grid grid-cols-2 gap-3.5">
        {/* Meals Card */}
        <div
          onClick={() => onNavigateTab("diet")}
          className="glass-card rounded-2xl p-4 cursor-pointer hover:shadow-md transition-all space-y-2 border border-slate-200/80 dark:border-slate-800"
        >
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Utensils className="w-4 h-4" />
            </div>
            <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
              {toPersianDigits(completedMealsCount)} از {toPersianDigits(totalMealsCount)}
            </span>
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">🍽 وعده‌های غذایی</h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
              صبحانه، ناهار، عصرانه، شام
            </p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${(completedMealsCount / totalMealsCount) * 100}%` }}
            />
          </div>
        </div>

        {/* Water Card */}
        <div className="glass-card rounded-2xl p-4 space-y-2 border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Droplet className="w-4 h-4" />
            </div>
            <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
              {toPersianDigits(waterGlasses)} از {toPersianDigits(waterGoal)} لیوان
            </span>
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">💧 مصرف آب</h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">برای هیدراته ماندن بدن</p>
          </div>
          {/* Interactive Glasses */}
          <div className="flex items-center justify-between pt-1">
            {[1, 2, 3, 4].map((glassIdx) => {
              const isFilled = waterGlasses >= glassIdx;
              return (
                <button
                  key={glassIdx}
                  onClick={() => onToggleWaterGlass(glassIdx)}
                  className={`w-7 h-8 rounded-lg flex items-center justify-center border transition-all ${
                    isFilled
                      ? "bg-blue-500 text-white border-blue-600 scale-105 shadow-xs"
                      : "bg-slate-50 dark:bg-slate-800/80 text-slate-300 dark:text-slate-600 border-slate-200 dark:border-slate-700 hover:border-blue-300"
                  }`}
                  title={`لیوان ${toPersianDigits(glassIdx)}`}
                >
                  <Droplet className={`w-4 h-4 ${isFilled ? "fill-current" : ""}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Fruit Card */}
        <div
          onClick={onOpenFruitModal}
          className="glass-card rounded-2xl p-4 cursor-pointer hover:shadow-md transition-all space-y-2 border border-slate-200/80 dark:border-slate-800"
        >
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-xl bg-red-100 dark:bg-red-950/80 text-red-600 dark:text-red-400 flex items-center justify-center">
              <Apple className="w-4 h-4" />
            </div>
            <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
              {toPersianDigits(fruitGrams)} / {toPersianDigits(fruitGoal)} گرم
            </span>
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">🍎 مصرف میوه</h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">سهمیه ویتامین روزانه</p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-red-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (fruitGrams / fruitGoal) * 100)}%` }}
            />
          </div>
        </div>

        {/* Dairy Card */}
        <div className="glass-card rounded-2xl p-4 space-y-2 border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div className="w-8 h-8 rounded-xl bg-cyan-100 dark:bg-cyan-950/80 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <Milk className="w-4 h-4" />
            </div>
            <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
              {toPersianDigits(dairyGlasses)} از {toPersianDigits(dairyGoal)} لیوان
            </span>
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">🥛 مصرف لبنیات</h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">شیر یا ماست کم‌چرب</p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-cyan-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (dairyGlasses / dairyGoal) * 100)}%` }}
            />
          </div>
        </div>

        {/* Walking Card with Live Timer Launcher */}
        <div
          onClick={onOpenWalkingTimer}
          className="col-span-2 glass-card rounded-2xl p-4 cursor-pointer hover:shadow-md transition-all flex items-center justify-between border-2 border-emerald-500/30 bg-emerald-50/30 dark:bg-emerald-950/20"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-500/20">
              <Footprints className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">🚶‍♀️ پیاده‌روی روزانه</h3>
                <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold rounded-full">
                  تایمر زنده
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                ثبت‌شده: {toPersianDigits(walkingMinutes)} از {toPersianDigits(walkingGoal)} دقیقه
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
              شروع تمرین ⏱
            </span>
            <ChevronLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
        </div>

        {/* Supplements Card */}
        <div
          onClick={() => onNavigateTab("diet")}
          className="col-span-2 glass-card rounded-2xl p-4 cursor-pointer hover:shadow-md transition-all flex items-center justify-between border border-slate-200/80 dark:border-slate-800"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
              <Pill className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">💊 مکمل‌ها و داروها</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                مصرف‌شده: {toPersianDigits(takenSupplementsCount)} از {toPersianDigits(totalSupplementsCount)} مورد
              </p>
            </div>
          </div>

          <ChevronLeft className="w-4 h-4 text-slate-400 dark:text-slate-500" />
        </div>
      </div>
    </div>
  );
}
