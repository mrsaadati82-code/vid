"use client";

import React, { useState } from "react";
import {
  CheckCircle2,
  Circle,
  Clock,
  Droplet,
  Apple,
  Milk,
  Footprints,
  Pill,
  ChevronLeft,
  Info,
  Play,
  Calendar,
} from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

interface DietTabProps {
  currentWeekday: string;
  meals: any[];
  goals: any;
  supplements: any[];
  onToggleMeal: (mealType: string, isCompleted: boolean) => void;
  onToggleWaterGlass: (index: number) => void;
  onToggleDairy: (glasses: number) => void;
  onToggleSupplement: (suppId: number) => void;
  onOpenWalkingTimer: () => void;
  onOpenFruitModal: () => void;
  onSelectWeekday: (day: string) => void;
  selectedDay: string;
}

export function DietTab({
  currentWeekday,
  meals,
  goals,
  supplements,
  onToggleMeal,
  onToggleWaterGlass,
  onToggleDairy,
  onToggleSupplement,
  onOpenWalkingTimer,
  onOpenFruitModal,
  onSelectWeekday,
  selectedDay,
}: DietTabProps) {
  const weekdays = [
    { id: "شنبه", short: "ش" },
    { id: "یکشنبه", short: "ی" },
    { id: "دوشنبه", short: "د" },
    { id: "سه‌شنبه", short: "س" },
    { id: "چهارشنبه", short: "چ" },
    { id: "پنجشنبه", short: "پ" },
    { id: "جمعه", short: "ج" },
  ];

  const waterGlasses = goals?.waterGlasses || 0;
  const waterGoal = goals?.waterGoal || 4;

  const fruitGrams = goals?.fruitGrams || 0;
  const fruitGoal = goals?.fruitGoal || 500;

  const walkingMinutes = goals?.walkingMinutes || 0;
  const walkingGoal = goals?.walkingGoal || 35;

  const dairyGlasses = goals?.dairyGlasses || 0;

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Page Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100">
          برنامه رژیم غذایی من 🥗
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          روز مورد نظر را انتخاب و وعده‌ها و سهمیه‌های روزانه خود را ثبت کنید
        </p>
      </div>

      {/* Week Selector */}
      <div className="glass-card rounded-2xl p-2.5 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-1 shadow-xs">
        {weekdays.map((day) => {
          const isSelected = selectedDay === day.id;
          const isToday = currentWeekday === day.id;

          return (
            <button
              key={day.id}
              onClick={() => onSelectWeekday(day.id)}
              className={`flex-1 flex flex-col items-center justify-center py-2.5 rounded-xl transition-all ${
                isSelected
                  ? "bg-emerald-600 text-white font-bold shadow-md shadow-emerald-600/20 scale-105"
                  : "bg-transparent text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium"
              }`}
            >
              <span className="text-[10px] opacity-80">{day.short}</span>
              <span className="text-xs mt-0.5 tracking-tight">{day.id}</span>
              {isToday && (
                <span className={`w-1.5 h-1.5 rounded-full mt-1 ${isSelected ? "bg-amber-300" : "bg-emerald-500"}`} />
              )}
            </button>
          );
        })}
      </div>

      {/* Meal Cards List */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
          <span>وعده‌های روز {selectedDay}</span>
          {selectedDay === currentWeekday && (
            <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold rounded-full">
              امروز
            </span>
          )}
        </h3>

        {meals && meals.length > 0 ? (
          meals.map((meal) => {
            const isCompleted = meal.isCompleted;

            return (
              <div
                key={meal.id || meal.mealType}
                className={`glass-card rounded-2xl p-4 transition-all border ${
                  isCompleted
                    ? "border-emerald-300 dark:border-emerald-900 bg-emerald-50/20 dark:bg-emerald-950/10 opacity-90"
                    : "border-slate-200/80 dark:border-slate-800"
                }`}
              >
                <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-lg">
                      {meal.mealType === "breakfast" && "🍳"}
                      {meal.mealType === "lunch" && "🍗"}
                      {meal.mealType === "snack" && "🍎"}
                      {meal.mealType === "dinner" && "🍲"}
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                        {meal.title}
                      </h4>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <Clock className="w-3 h-3 text-emerald-500" />
                        <span>ساعت پیشنهادی: {toPersianDigits(meal.recommendedTime)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Completion Toggle */}
                  <button
                    onClick={() => onToggleMeal(meal.mealType, !isCompleted)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-2xs ${
                      isCompleted
                        ? "bg-emerald-600 text-white shadow-emerald-600/20"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 hover:text-emerald-600"
                    }`}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>انجام شد</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-4 h-4" />
                        <span>ثبت انجام</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Foods List */}
                <div className="pt-3 space-y-1.5">
                  <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                    اقلام وعده:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {meal.foods &&
                      meal.foods.map((food: any, idx: number) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50/80 dark:bg-slate-800/50 text-xs border border-slate-100 dark:border-slate-800"
                        >
                          <span className="font-medium text-slate-800 dark:text-slate-200">
                            • {food.name}
                          </span>
                          <span className="font-bold text-emerald-600 dark:text-emerald-400">
                            {toPersianDigits(food.amount)} {food.unit}
                          </span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="glass-card rounded-2xl p-6 text-center text-slate-500 dark:text-slate-400 text-xs">
            در حال بارگذاری برنامه غذایی...
          </div>
        )}
      </div>

      {/* Daily Quotas (سهمیه‌های روزانه) */}
      <div className="space-y-4 pt-2">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
          سهمیه‌ها و پیگیری روزانه 🎯
        </h3>

        {/* Water Tracker */}
        <div className="glass-card rounded-2xl p-4 space-y-3 border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Droplet className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  سهمیه آب روزانه (۴ لیوان)
                </h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  هر لیوان = ۲۵۰ سی‌سی
                </p>
              </div>
            </div>

            <span className="text-xs font-black text-blue-600 dark:text-blue-400">
              {toPersianDigits(waterGlasses)} / {toPersianDigits(waterGoal)}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2 pt-1">
            {[1, 2, 3, 4].map((glassIdx) => {
              const isFilled = waterGlasses >= glassIdx;
              return (
                <button
                  key={glassIdx}
                  onClick={() => onToggleWaterGlass(glassIdx)}
                  className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1 border transition-all ${
                    isFilled
                      ? "bg-blue-500 text-white border-blue-600 shadow-sm shadow-blue-500/20"
                      : "bg-slate-50 dark:bg-slate-800/80 text-slate-400 border-slate-200 dark:border-slate-700 hover:border-blue-300"
                  }`}
                >
                  <Droplet className={`w-5 h-5 ${isFilled ? "fill-current" : ""}`} />
                  <span className="text-[10px] font-bold">لیوان {toPersianDigits(glassIdx)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Fruit Tracker */}
        <div
          onClick={onOpenFruitModal}
          className="glass-card rounded-2xl p-4 cursor-pointer hover:shadow-md transition-all space-y-2 border border-slate-200/80 dark:border-slate-800"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 flex items-center justify-center">
                <Apple className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  سهمیه میوه روزانه (۵۰۰ گرم)
                </h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  ثبت مقدار مصرف‌شده با لمس این کارت
                </p>
              </div>
            </div>

            <span className="text-xs font-black text-red-600 dark:text-red-400">
              {toPersianDigits(fruitGrams)} / {toPersianDigits(fruitGoal)} گرم
            </span>
          </div>

          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-red-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (fruitGrams / fruitGoal) * 100)}%` }}
            />
          </div>
        </div>

        {/* Walking Timer Card */}
        <div
          onClick={onOpenWalkingTimer}
          className="glass-card rounded-2xl p-4 cursor-pointer hover:shadow-md transition-all flex items-center justify-between border-2 border-emerald-500/30 bg-emerald-50/20 dark:bg-emerald-950/20"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
              <Footprints className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                پیاده‌روی ۳۵ دقیقه‌ای
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                تمرین انجام‌شده: {toPersianDigits(walkingMinutes)} از {toPersianDigits(walkingGoal)} دقیقه
              </p>
            </div>
          </div>

          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-xs">
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>شروع تایمر</span>
          </button>
        </div>

        {/* Prescribed Supplements */}
        <div className="glass-card rounded-2xl p-4 space-y-3 border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                <Pill className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                مکمل‌ها و داروهای تجویز شده
              </h4>
            </div>

            <span className="text-xs font-bold text-purple-600 dark:text-purple-400">
              {toPersianDigits(supplements?.filter((s) => s.isTaken).length || 0)} از{" "}
              {toPersianDigits(supplements?.length || 0)}
            </span>
          </div>

          <div className="space-y-2">
            {supplements &&
              supplements.map((supp) => (
                <div
                  key={supp.id}
                  onClick={() => onToggleSupplement(supp.id)}
                  className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer border transition-all ${
                    supp.isTaken
                      ? "bg-purple-50/50 dark:bg-purple-950/20 border-purple-300 dark:border-purple-800 text-purple-900 dark:text-purple-200"
                      : "bg-slate-50/80 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-200"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <button className="text-purple-600 dark:text-purple-400">
                      {supp.isTaken ? (
                        <CheckCircle2 className="w-4 h-4 fill-purple-600 text-white dark:fill-purple-400" />
                      ) : (
                        <Circle className="w-4 h-4" />
                      )}
                    </button>
                    <div>
                      <span className="text-xs font-bold">{supp.name}</span>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        {supp.instructions}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300">
                    ساعت {toPersianDigits(supp.timeOfDay)}
                  </span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
