"use client";

import React, { useState } from "react";
import {
  BarChart3,
  TrendingDown,
  Award,
  Calendar,
  Droplet,
  Apple,
  Footprints,
  Pill,
  Smile,
  Moon,
  Flame,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts";

interface ReportsTabProps {
  user: any;
  weightLogsList: any[];
  goals: any;
  symptomLogsList: any[];
  moodLogsList: any[];
  violationsList: any[];
  onOpenWeightModal: () => void;
}

export function ReportsTab({
  user,
  weightLogsList,
  goals,
  symptomLogsList,
  moodLogsList,
  violationsList,
  onOpenWeightModal,
}: ReportsTabProps) {
  const currentWeight = user?.currentWeight || 69.2;
  const startWeight = user?.startWeight || 74.5;
  const targetWeight = user?.targetWeight || 62.0;

  const chartData = weightLogsList?.map((w) => ({
    date: w.date ? toPersianDigits(w.date.replace("1403/", "")) : "",
    weight: w.weight,
  })) || [
    { date: "۱۱/۰۱", weight: 74.5 },
    { date: "۱۱/۰۵", weight: 73.2 },
    { date: "۱۱/۰۸", weight: 71.8 },
    { date: "۱۱/۱۲", weight: 70.5 },
    { date: "۱۱/۱۵", weight: 69.2 },
  ];

  const complianceData = [
    { name: "شنبه", score: 95 },
    { name: "یکشنبه", score: 88 },
    { name: "دوشنبه", score: 92 },
    { name: "سه‌شنبه", score: 85 },
    { name: "چهارشنبه", score: 90 },
    { name: "پنجشنبه", score: 82 },
    { name: "جمعه", score: 78 },
  ];

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <span>گزارش من و پیشرفت</span>
            <BarChart3 className="w-5 h-5 text-emerald-500" />
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            نمودارهای تحلیل وزن، رژیم، هیدراتاسیون، خواب و چرخه قاعدگی
          </p>
        </div>

        <button
          onClick={onOpenWeightModal}
          className="px-3 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-md shadow-emerald-600/20 hover:bg-emerald-700"
        >
          ثبت وزن جدید ⚖️
        </button>
      </div>

      {/* 1. Weight Trend & Summary Card */}
      <div className="glass-card rounded-2xl p-5 border border-slate-200/80 dark:border-slate-800 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              نمودار روند تغییرات وزن ⚖️
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              کاهش {toPersianDigits((startWeight - currentWeight).toFixed(1))} کیلوگرم تا امروز
            </p>
          </div>

          <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
            <TrendingDown className="w-3.5 h-3.5" />
            روند نزولی عالی
          </span>
        </div>

        {/* Recharts Weight Line Chart */}
        <div className="h-52 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} />
              <YAxis domain={["dataMin - 1", "dataMax + 1"]} tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(15, 23, 42, 0.9)",
                  border: "none",
                  borderRadius: "12px",
                  color: "#fff",
                  fontSize: "12px",
                }}
              />
              <Line
                type="monotone"
                dataKey="weight"
                stroke="#10b981"
                strokeWidth={3}
                dot={{ r: 5, fill: "#10b981", strokeWidth: 2, stroke: "#fff" }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-3 gap-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-center text-xs">
          <div>
            <span className="block text-[10px] text-slate-400">وزن شروع</span>
            <span className="font-bold text-slate-700 dark:text-slate-200">
              {toPersianDigits(startWeight)} kg
            </span>
          </div>
          <div className="border-x border-slate-200 dark:border-slate-700">
            <span className="block text-[10px] text-slate-400">وزن فعلی</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400">
              {toPersianDigits(currentWeight)} kg
            </span>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400">هدف</span>
            <span className="font-bold text-amber-600 dark:text-amber-400">
              {toPersianDigits(targetWeight)} kg
            </span>
          </div>
        </div>
      </div>

      {/* 2. Weekly Diet Compliance Bar Chart */}
      <div className="glass-card rounded-2xl p-5 border border-slate-200/80 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-500" />
            <span>درصد پایبندی به رژیم در ۷ روز اخیر</span>
          </h3>
          <span className="text-xs font-bold text-emerald-600">میانگین: ۸۷٪</span>
        </div>

        <div className="h-44 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={complianceData} margin={{ top: 5, right: 0, left: -25, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(15, 23, 42, 0.9)",
                  borderRadius: "12px",
                  color: "#fff",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="score" fill="#059669" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 3. Food Violations Summary Card */}
      <div className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <span>خلاصه تخلفات غذایی ثبت‌شده</span>
          </h3>
          <span className="text-xs font-bold text-slate-500">
            {toPersianDigits(violationsList?.length || 0)} مورد
          </span>
        </div>

        {violationsList && violationsList.length > 0 ? (
          <div className="space-y-1.5 pt-1">
            {violationsList.slice(0, 3).map((v, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-2 rounded-xl bg-amber-50/60 dark:bg-amber-950/20 text-xs border border-amber-200 dark:border-amber-900"
              >
                <div>
                  <span className="font-bold text-amber-900 dark:text-amber-200">• {v.foodItem}</span>
                  <span className="text-[10px] text-slate-500 mr-2">({v.portion})</span>
                </div>
                <span className="text-[10px] text-amber-700 dark:text-amber-300 font-medium">
                  دلیل: {v.reason}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            عالیه! هیچ تخلف غذایی ثبت نشده است.
          </p>
        )}
      </div>

      {/* 4. Calendar Consistency Heatmap (Visual) */}
      <div className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-3">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-emerald-500" />
          <span>نقشه ثبات و پایبندی ماه جاری (Heatmap)</span>
        </h3>

        <div className="grid grid-cols-7 gap-1.5 pt-1">
          {Array.from({ length: 28 }).map((_, idx) => {
            const level = (idx * 7) % 5;
            let color = "bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200";
            if (level === 4) color = "bg-emerald-600 text-white font-bold";
            else if (level === 3) color = "bg-emerald-400 text-white font-bold";
            else if (level === 2) color = "bg-emerald-300 text-emerald-900 font-bold";

            return (
              <div
                key={idx}
                className={`h-9 rounded-lg flex items-center justify-center text-[10px] transition-all ${color}`}
                title={`روز ${toPersianDigits(idx + 1)}`}
              >
                {toPersianDigits(idx + 1)}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
