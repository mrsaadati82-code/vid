"use client";

import React, { useState } from "react";
import {
  CalendarHeart,
  Droplets,
  Sparkles,
  Calendar as CalendarIcon,
  Smile,
  AlertCircle,
  Activity,
  HeartPulse,
  Flame,
  ChevronLeft,
  ChevronRight,
  Clock,
  Moon,
  Zap,
  Info,
} from "lucide-react";
import { toPersianDigits, getTodayJalaliString } from "@/lib/jalali";

interface CycleTabProps {
  cycleInfo: any;
  user: any;
  recentDays: any[];
  symptomLogsList: any[];
  moodLogsList: any[];
  onLogPeriodStart: (flow: string) => void;
  onLogPeriodEnd: () => void;
  onSaveSymptoms: (symptoms: string[], severities: Record<string, string>) => void;
  onSaveMood: (mood: string, stress: number, energy: number) => void;
  onSaveSleep: (duration: number, quality: string) => void;
}

export function CycleTab({
  cycleInfo,
  user,
  recentDays,
  symptomLogsList,
  moodLogsList,
  onLogPeriodStart,
  onLogPeriodEnd,
  onSaveSymptoms,
  onSaveMood,
  onSaveSleep,
}: CycleTabProps) {
  const [selectedFlow, setSelectedFlow] = useState<string>("medium");
  const [showSymptomForm, setShowSymptomForm] = useState<boolean>(false);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [symptomSeverities, setSymptomSeverities] = useState<Record<string, string>>({});
  const [selectedMood, setSelectedMood] = useState<string>("good");
  const [stressLevel, setStressLevel] = useState<number>(2);
  const [energyLevel, setEnergyLevel] = useState<number>(4);
  const [sleepHours, setSleepHours] = useState<number>(7.5);
  const [sleepQuality, setSleepQuality] = useState<string>("good");

  const symptomsList = [
    { id: "abdominal_pain", label: "درد شکم" },
    { id: "backache", label: "کمردرد" },
    { id: "headache", label: "سردرد" },
    { id: "migraine", label: "میگرن" },
    { id: "bloating", label: "نفخ" },
    { id: "nausea", label: "حالت تهوع" },
    { id: "cramps", label: "گرفتگی عضلات" },
    { id: "breast_tenderness", label: "حساسیت سینه" },
    { id: "fatigue", label: "خستگی" },
    { id: "dizziness", label: "سرگیجه" },
    { id: "acne", label: "جوش" },
    { id: "appetite_change", label: "تغییر اشتها" },
    { id: "food_craving", label: "افزایش میل غذایی" },
    { id: "sweet_craving", label: "هوس شیرینی" },
    { id: "constipation", label: "یبوست" },
    { id: "diarrhea", label: "اسهال" },
  ];

  const moodOptions = [
    { id: "excellent", label: "عالی", emoji: "😊" },
    { id: "good", label: "خوب", emoji: "🙂" },
    { id: "normal", label: "معمولی", emoji: "😐" },
    { id: "sad", label: "ناراحت", emoji: "😔" },
    { id: "anxious", label: "مضطرب", emoji: "😣" },
    { id: "irritable", label: "تحریک‌پذیر", emoji: "😡" },
    { id: "tired", label: "خسته", emoji: "😴" },
  ];

  const toggleSymptom = (symptomId: string) => {
    if (selectedSymptoms.includes(symptomId)) {
      setSelectedSymptoms(selectedSymptoms.filter((id) => id !== symptomId));
      const copy = { ...symptomSeverities };
      delete copy[symptomId];
      setSymptomSeverities(copy);
    } else {
      setSelectedSymptoms([...selectedSymptoms, symptomId]);
      setSymptomSeverities({ ...symptomSeverities, [symptomId]: "medium" });
    }
  };

  const handleSymptomSubmit = () => {
    onSaveSymptoms(selectedSymptoms, symptomSeverities);
    setShowSymptomForm(false);
  };

  const cycleDay = cycleInfo?.cycleDay || 1;
  const cycleAvgLength = user?.cycleAvgLength || 28;
  const periodAvgLength = user?.periodAvgLength || 6;
  const daysUntilNext = cycleInfo?.daysUntilNextPeriod || 14;

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Page Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <span>چرخه من (Period Tracker)</span>
          <span className="text-rose-500">🌸</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          مدیریت هوشمند پریود، علائم PMS، خلق‌وخو و باروری
        </p>
      </div>

      {/* 1. Interactive Cycle Visualization Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-rose-500 via-pink-600 to-rose-700 text-white p-6 shadow-xl shadow-rose-900/20">
        <div className="absolute -top-10 -left-10 w-36 h-36 bg-white/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Wheel Graphic */}
          <div className="relative flex items-center justify-center w-40 h-40 shrink-0">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="8"
                className="text-white/20"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="10"
                className="text-amber-300 transition-all duration-1000"
                fill="transparent"
                strokeDasharray="251.2"
                strokeDashoffset={251.2 - (251.2 * cycleDay) / cycleAvgLength}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-xs text-rose-100 font-medium">امروز</span>
              <span className="text-2xl font-black">روز {toPersianDigits(cycleDay)}</span>
              <span className="text-[10px] text-amber-200 font-bold">از {toPersianDigits(cycleAvgLength)} روز</span>
            </div>
          </div>

          {/* Phase Details */}
          <div className="flex-1 space-y-3 text-center md:text-right w-full">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold text-white border border-white/20">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{cycleInfo?.phaseTitle || "فاز فولیکولار"}</span>
            </div>

            <p className="text-xs text-rose-100 leading-relaxed">
              {cycleInfo?.phaseDescription || "توضیحات فاز جاری چرخه"}
            </p>

            <div className="grid grid-cols-2 gap-2 bg-black/15 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-xs">
              <div>
                <span className="block text-[10px] text-rose-200">تا پریود بعدی (تخمینی)</span>
                <span className="font-bold text-amber-300 text-sm">
                  {toPersianDigits(daysUntilNext)} روز
                </span>
              </div>
              <div>
                <span className="block text-[10px] text-rose-200">احتمال باروری</span>
                <span className="font-bold text-white text-sm">
                  {cycleInfo?.chanceOfPregnancy || "کم"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-4 pt-3 border-t border-white/15 flex items-start gap-1.5 text-[10px] text-rose-100/90">
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-200" />
          <span>
            توجه: تمام پیش‌بینی‌ها به عنوان تخمینی نمایش داده می‌شوند و نباید به عنوان تشخیص پزشکی یا پیش‌بینی قطعی استفاده شوند.
          </span>
        </div>
      </div>

      {/* 2. Period Log Quick Action Card */}
      <div className="glass-card rounded-2xl p-4 border border-rose-200 dark:border-rose-900/60 bg-rose-50/20 dark:bg-rose-950/10 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplets className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              ثبت وضعیت پریود (خونریزی)
            </h3>
          </div>

          {cycleInfo?.isPeriod ? (
            <button
              onClick={onLogPeriodEnd}
              className="px-3 py-1.5 rounded-full bg-slate-800 text-white text-xs font-bold shadow-xs hover:bg-slate-700"
            >
              پایان پریود
            </button>
          ) : (
            <span className="text-[11px] text-slate-500 font-medium">پریود نیستی؟</span>
          )}
        </div>

        <div className="flex items-center justify-between gap-2 pt-1">
          <span className="text-xs font-medium text-slate-600 dark:text-slate-300">شدت خونریزی:</span>
          <div className="flex items-center gap-1.5">
            {[
              { id: "light", label: "کم" },
              { id: "medium", label: "متوسط" },
              { id: "heavy", label: "زیاد" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFlow(f.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedFlow === f.id
                    ? "bg-rose-600 text-white shadow-xs"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-rose-100"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => onLogPeriodStart(selectedFlow)}
            className="px-3 py-1.5 rounded-full bg-rose-600 text-white text-xs font-bold shadow-md shadow-rose-600/20 hover:bg-rose-700"
          >
            شروع پریود 🩸
          </button>
        </div>
      </div>

      {/* 3. Symptoms & PMS Logger */}
      <div className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-rose-500" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              ثبت علائم روزانه و PMS
            </h3>
          </div>

          <button
            onClick={() => setShowSymptomForm(!showSymptomForm)}
            className="text-xs text-rose-600 dark:text-rose-400 font-bold hover:underline"
          >
            {showSymptomForm ? "بستن فرم" : "ویرایش علائم ✍️"}
          </button>
        </div>

        {showSymptomForm ? (
          <div className="space-y-4 pt-2">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              علائمی که امروز احساس می‌کنی را لمس کن:
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {symptomsList.map((sym) => {
                const isSelected = selectedSymptoms.includes(sym.id);
                return (
                  <button
                    key={sym.id}
                    onClick={() => toggleSymptom(sym.id)}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-right ${
                      isSelected
                        ? "bg-rose-50 dark:bg-rose-950/60 border-rose-400 dark:border-rose-700 text-rose-700 dark:text-rose-300"
                        : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-rose-200"
                    }`}
                  >
                    • {sym.label}
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleSymptomSubmit}
              className="w-full py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs shadow-md shadow-rose-600/20"
            >
              ذخیره علائم امروز
            </button>
          </div>
        ) : (
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {selectedSymptoms.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {selectedSymptoms.map((symId) => {
                  const obj = symptomsList.find((s) => s.id === symId);
                  return (
                    <span
                      key={symId}
                      className="px-2.5 py-1 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold"
                    >
                      {obj?.label || symId}
                    </span>
                  );
                })}
              </div>
            ) : (
              <p>امروز هنوز علائمی ثبت نکرده‌ای.</p>
            )}
          </div>
        )}
      </div>

      {/* 4. Mood & Energy Logger */}
      <div className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-3">
        <div className="flex items-center gap-2">
          <Smile className="w-5 h-5 text-amber-500" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
            حال روحی (Mood) و سطح انرژی
          </h3>
        </div>

        <div className="flex items-center justify-between gap-1 overflow-x-auto py-1">
          {moodOptions.map((m) => {
            const isSelected = selectedMood === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setSelectedMood(m.id);
                  onSaveMood(m.id, stressLevel, energyLevel);
                }}
                className={`flex-1 min-w-[50px] flex flex-col items-center justify-center p-2 rounded-xl transition-all border ${
                  isSelected
                    ? "bg-amber-100 dark:bg-amber-950/60 border-amber-400 text-amber-900 dark:text-amber-200 font-bold scale-105 shadow-xs"
                    : "bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400"
                }`}
              >
                <span className="text-xl">{m.emoji}</span>
                <span className="text-[10px] mt-1">{m.label}</span>
              </button>
            );
          })}
        </div>

        {/* Stress & Energy sliders */}
        <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
          <div>
            <div className="flex justify-between font-bold text-slate-700 dark:text-slate-300">
              <span>میزان استرس:</span>
              <span className="text-amber-600">{toPersianDigits(stressLevel)} از ۵</span>
            </div>
            <input
              type="range"
              min="1"
              max="5"
              value={stressLevel}
              onChange={(e) => {
                const val = Number(e.target.value);
                setStressLevel(val);
                onSaveMood(selectedMood, val, energyLevel);
              }}
              className="w-full accent-amber-500 mt-1"
            />
          </div>

          <div>
            <div className="flex justify-between font-bold text-slate-700 dark:text-slate-300">
              <span>سطح انرژی:</span>
              <span className="text-emerald-600">{toPersianDigits(energyLevel)} از ۵</span>
            </div>
            <input
              type="range"
              min="1"
              max="5"
              value={energyLevel}
              onChange={(e) => {
                const val = Number(e.target.value);
                setEnergyLevel(val);
                onSaveMood(selectedMood, stressLevel, val);
              }}
              className="w-full accent-emerald-500 mt-1"
            />
          </div>
        </div>
      </div>

      {/* 5. Cycle Legend Calendar */}
      <div className="glass-card rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-rose-500" />
            <span>تقویم چرخه و راهنما</span>
          </h3>
          <span className="text-xs text-slate-500">{getTodayJalaliString()}</span>
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-semibold pt-1">
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
            <span>🩸</span>
            <span>دوران پریود</span>
          </div>
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-pink-50 dark:bg-pink-950 text-pink-700 dark:text-pink-300">
            <span>🌸</span>
            <span>روزهای باروری</span>
          </div>
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
            <span>✨</span>
            <span>تخمک‌گذاری</span>
          </div>
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            <span>⚪</span>
            <span>روزهای عادی</span>
          </div>
        </div>
      </div>

      {/* 6. Smart Diet & Cycle Correlation Insight Card */}
      <div className="glass-card rounded-2xl p-4 border-2 border-emerald-400/40 bg-gradient-to-r from-emerald-50/30 to-rose-50/30 dark:from-emerald-950/20 dark:to-rose-950/20 space-y-2">
        <div className="flex items-center gap-2">
          <HeartPulse className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100">
            تحلیل هوشمند ارتباط رژیم و چرخه 💡
          </h3>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          «در روزهای قبل از پریود، میزان اشتهای ثبت‌شده شما بیشتر بوده است. پیشنهاد می‌شود از میوه‌های با اندیس گلایسمی پایین و دمنوش‌های گرم استفاده کنید.»
        </p>
        <span className="block text-[10px] text-slate-400 mt-1">
          * این تحلیل صرفاً بر اساس داده‌های ثبت‌شده شخص شماست و جنبه تشخیص پزشکی ندارد.
        </span>
      </div>
    </div>
  );
}
