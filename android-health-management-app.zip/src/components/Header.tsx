"use client";

import React from "react";
import { Sparkles, Moon, Sun, Bell, CheckCircle2 } from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

interface HeaderProps {
  userName: string;
  dietDay: number;
  dietTotalDays: number;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenCheckIn: () => void;
  onOpenNotifications: () => void;
  usePersianNumbers?: boolean;
}

export function Header({
  userName,
  dietDay,
  dietTotalDays,
  isDarkMode,
  onToggleDarkMode,
  onOpenCheckIn,
  onOpenNotifications,
  usePersianNumbers = true,
}: HeaderProps) {
  const dayStr = usePersianNumbers ? toPersianDigits(dietDay) : String(dietDay);
  const totalStr = usePersianNumbers ? toPersianDigits(dietTotalDays) : String(dietTotalDays);

  return (
    <header className="sticky top-0 z-30 w-full glass-card border-b border-slate-200/80 dark:border-slate-800 px-4 py-3 shadow-xs transition-colors">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        {/* User Info Greeting */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 text-white font-bold text-lg shadow-md shadow-emerald-500/20">
            {userName.charAt(0)}
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 border-2 border-white dark:border-slate-900 rounded-full" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold text-slate-800 dark:text-slate-100">
                سلام {userName}
              </h1>
              <span className="text-lg">👋</span>
            </div>
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              امروز روز {dayStr} از {totalStr} رژیم شماست
            </p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-2">
          {/* Quick Check-In CTA */}
          <button
            onClick={onOpenCheckIn}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-semibold hover:bg-emerald-100 dark:hover:bg-emerald-900 transition-all border border-emerald-200 dark:border-emerald-800 shadow-2xs"
            title="ثبت سریع روزانه"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
            <span className="hidden sm:inline">ثبت سریع</span>
          </button>

          {/* Notifications button */}
          <button
            onClick={onOpenNotifications}
            className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative"
            title="اعلان‌ها"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full" />
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isDarkMode ? "حالت روشن" : "حالت تاریک"}
          >
            {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-600" />}
          </button>
        </div>
      </div>
    </header>
  );
}
