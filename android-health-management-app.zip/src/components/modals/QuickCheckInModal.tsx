"use client";

import React, { useState } from "react";
import { X, Sparkles, CheckCircle2 } from "lucide-react";
import { toPersianDigits, getTodayJalaliString } from "@/lib/jalali";

interface QuickCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveCheckIn: (payload: any) => void;
}

export function QuickCheckInModal({ isOpen, onClose, onSaveCheckIn }: QuickCheckInModalProps) {
  const [isPeriod, setIsPeriod] = useState(false);
  const [flow, setFlow] = useState("medium");
  const [mood, setMood] = useState("good");
  const [energy, setEnergy] = useState(4);
  const [stress, setStress] = useState(2);
  const [sleep, setSleep] = useState(8);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveCheckIn({
      isPeriod,
      flow,
      mood,
      energy,
      stress,
      sleep,
      date: getTodayJalaliString(),
    });

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="glass-card bg-white dark:bg-slate-900 rounded-3xl p-5 max-w-md w-full space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-500" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              ثبت سریع روزانه (Quick Check-in) ⏱
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-2">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
            <p className="text-sm font-bold text-slate-800 dark:text-slate-100">
              ثبت وضعیت امروز با موفقیت انجام شد!
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Period Question */}
            <div className="p-3 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-rose-900 dark:text-rose-200">آیا امروز پریود هستید؟</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPeriod(true)}
                    className={`px-3 py-1 rounded-lg font-bold transition-all ${
                      isPeriod ? "bg-rose-600 text-white" : "bg-white dark:bg-slate-800 text-slate-600"
                    }`}
                  >
                    بله
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsPeriod(false)}
                    className={`px-3 py-1 rounded-lg font-bold transition-all ${
                      !isPeriod ? "bg-slate-700 text-white" : "bg-white dark:bg-slate-800 text-slate-600"
                    }`}
                  >
                    خیر
                  </button>
                </div>
              </div>

              {isPeriod && (
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-rose-700 dark:text-rose-300">شدت خونریزی:</span>
                  <div className="flex gap-1">
                    {["کم", "متوسط", "زیاد"].map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setFlow(f)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          flow === f ? "bg-rose-600 text-white" : "bg-rose-100 dark:bg-rose-900 text-rose-800"
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Mood Picker */}
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                خلق‌وخوی امروز:
              </label>
              <div className="flex justify-between gap-1">
                {[
                  { id: "excellent", label: "عالی", emoji: "😊" },
                  { id: "good", label: "خوب", emoji: "🙂" },
                  { id: "normal", label: "معمولی", emoji: "😐" },
                  { id: "sad", label: "ناراحت", emoji: "😔" },
                  { id: "tired", label: "خسته", emoji: "😴" },
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setMood(m.id)}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      mood === m.id
                        ? "bg-amber-100 dark:bg-amber-950 border-amber-400 font-bold scale-105"
                        : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                    }`}
                  >
                    <span className="text-lg block">{m.emoji}</span>
                    <span className="text-[9px] block">{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Sleep duration */}
            <div>
              <div className="flex justify-between font-bold text-slate-700 dark:text-slate-300">
                <span>ساعات خواب دیشب:</span>
                <span className="text-emerald-600">{toPersianDigits(sleep)} ساعت</span>
              </div>
              <input
                type="range"
                min="4"
                max="12"
                step="0.5"
                value={sleep}
                onChange={(e) => setSleep(Number(e.target.value))}
                className="w-full accent-emerald-500 mt-1"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md shadow-emerald-600/20 hover:bg-emerald-700 transition-all"
            >
              ثبت و ذخیره سریع ✨
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
