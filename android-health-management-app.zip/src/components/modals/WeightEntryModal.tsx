"use client";

import React, { useState } from "react";
import { X, Scale } from "lucide-react";
import { getTodayJalaliString } from "@/lib/jalali";

interface WeightEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveWeight: (weight: number, notes: string) => void;
  currentWeight?: number;
}

export function WeightEntryModal({
  isOpen,
  onClose,
  onSaveWeight,
  currentWeight = 69.2,
}: WeightEntryModalProps) {
  const [weight, setWeight] = useState(String(currentWeight));
  const [notes, setNotes] = useState("");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(weight);
    if (!isNaN(val) && val > 30 && val < 250) {
      onSaveWeight(val, notes);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="glass-card bg-white dark:bg-slate-900 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
            <Scale className="w-5 h-5" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              ثبت وزن جدید ⚖️
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              وزن امروز (کیلوگرم):
            </label>
            <input
              type="number"
              step="0.1"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm font-bold text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 text-center"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              یادداشت یا توضیحات:
            </label>
            <input
              type="text"
              placeholder="مثلاً: ناشتا / بعد از تمرین..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md shadow-emerald-600/20 hover:bg-emerald-700"
          >
            ذخیره وزن
          </button>
        </form>
      </div>
    </div>
  );
}
