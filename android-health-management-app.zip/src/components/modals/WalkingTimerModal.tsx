"use client";

import React, { useState, useEffect } from "react";
import { X, Play, Pause, RotateCcw, Footprints, Award, CheckCircle2 } from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";
import confetti from "canvas-confetti";

interface WalkingTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveMinutes: (minutes: number) => void;
  initialGoalMinutes?: number;
}

export function WalkingTimerModal({
  isOpen,
  onClose,
  onSaveMinutes,
  initialGoalMinutes = 35,
}: WalkingTimerModalProps) {
  const [totalSeconds, setTotalSeconds] = useState(initialGoalMinutes * 60);
  const [remainingSeconds, setRemainingSeconds] = useState(initialGoalMinutes * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isRunning && remainingSeconds > 0) {
      interval = setInterval(() => {
        setRemainingSeconds((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            setIsCompleted(true);
            triggerConfetti();
            onSaveMinutes(initialGoalMinutes);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isRunning, remainingSeconds, initialGoalMinutes, onSaveMinutes]);

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (e) {
      // Fallback
    }
  };

  if (!isOpen) return null;

  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  const progressPercent = Math.round(((totalSeconds - remainingSeconds) / totalSeconds) * 100);

  const formatTwoDigits = (num: number) => (num < 10 ? `۰${toPersianDigits(num)}` : toPersianDigits(num));

  const handleReset = () => {
    setIsRunning(false);
    setRemainingSeconds(totalSeconds);
    setIsCompleted(false);
  };

  const handleManualComplete = () => {
    setIsRunning(false);
    setRemainingSeconds(0);
    setIsCompleted(true);
    triggerConfetti();
    onSaveMinutes(initialGoalMinutes);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="glass-card bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-sm w-full space-y-5 text-center shadow-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
            <Footprints className="w-5 h-5" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              تایمر پیاده‌روی ۳۵ دقیقه‌ای
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Circular Countdown Progress */}
        <div className="relative flex items-center justify-center w-48 h-48 mx-auto my-2">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="42"
              stroke="currentColor"
              strokeWidth="8"
              className="text-slate-100 dark:text-slate-800"
              fill="transparent"
            />
            <circle
              cx="50"
              cy="50"
              r="42"
              stroke="currentColor"
              strokeWidth="8"
              className="text-emerald-500 transition-all duration-1000 ease-linear"
              fill="transparent"
              strokeDasharray="263.8"
              strokeDashoffset={263.8 - (263.8 * (totalSeconds - remainingSeconds)) / totalSeconds}
              strokeLinecap="round"
            />
          </svg>

          <div className="absolute flex flex-col items-center justify-center">
            <span className="text-3xl font-black text-slate-800 dark:text-slate-100 tracking-tight dir-ltr">
              {formatTwoDigits(minutes)}:{formatTwoDigits(seconds)}
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 font-medium">
              {isCompleted ? "تمرین تکمیل شد! 🎉" : `${toPersianDigits(progressPercent)}٪ سپری شده`}
            </span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            onClick={handleReset}
            className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
            title="بازنشانی"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={() => setIsRunning(!isRunning)}
            className="px-6 py-3 rounded-2xl bg-emerald-600 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 hover:bg-emerald-700 flex items-center gap-2"
          >
            {isRunning ? (
              <>
                <Pause className="w-5 h-5 fill-current" />
                <span>توقف</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" />
                <span>{remainingSeconds < totalSeconds ? "ادامه" : "شروع پیاده‌روی"}</span>
              </>
            )}
          </button>

          <button
            onClick={handleManualComplete}
            className="p-3 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 hover:bg-amber-200"
            title="ثبت کامل مستقیم"
          >
            <CheckCircle2 className="w-5 h-5" />
          </button>
        </div>

        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          💡 پیاده‌روی منظم سوخت‌وساز بدن را فعال و انگیزه شما را مضاعف می‌کند.
        </p>
      </div>
    </div>
  );
}
