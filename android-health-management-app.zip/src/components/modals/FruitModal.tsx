"use client";

import React, { useState } from "react";
import { X, Apple } from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

interface FruitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveGrams: (grams: number) => void;
  currentGrams?: number;
}

export function FruitModal({ isOpen, onClose, onSaveGrams, currentGrams = 320 }: FruitModalProps) {
  const [grams, setGrams] = useState(currentGrams);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveGrams(Number(grams));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="glass-card bg-white dark:bg-slate-900 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
            <Apple className="w-5 h-5" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              ثبت میزان مصرف میوه 🍎
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <div className="flex justify-between font-bold text-slate-700 dark:text-slate-300 mb-1">
              <span>مقدار مصرف امروز:</span>
              <span className="text-red-600 font-extrabold">{toPersianDigits(grams)} گرم</span>
            </div>
            <input
              type="range"
              min="0"
              max="500"
              step="20"
              value={grams}
              onChange={(e) => setGrams(Number(e.target.value))}
              className="w-full accent-red-500 mt-2"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>۰ گرم</span>
              <span>۲۵۰ گرم</span>
              <span>۵۰۰ گرم (سقف سهمیه)</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[100, 250, 500].map((quickVal) => (
              <button
                key={quickVal}
                type="button"
                onClick={() => setGrams(quickVal)}
                className="py-1.5 px-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold hover:bg-red-50"
              >
                +{toPersianDigits(quickVal)} گرم
              </button>
            ))}
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-red-600 text-white font-bold text-xs shadow-md shadow-red-600/20 hover:bg-red-700"
          >
            ثبت سهمیه میوه
          </button>
        </form>
      </div>
    </div>
  );
}
