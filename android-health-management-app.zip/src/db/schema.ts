import { pgTable, serial, text, integer, real, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

// User Profile
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("فرشته"),
  startWeight: real("start_weight").notNull().default(74.5),
  currentWeight: real("current_weight").notNull().default(69.2),
  targetWeight: real("target_weight").notNull().default(62.0),
  height: integer("height").default(168), // cm
  dietStartDay: text("diet_start_day").notNull().default("1403/11/01"),
  dietCurrentDay: integer("diet_current_day").notNull().default(12),
  dietTotalDays: integer("diet_total_days").notNull().default(21),
  cycleAvgLength: integer("cycle_avg_length").notNull().default(28),
  periodAvgLength: integer("period_avg_length").notNull().default(6),
  lastPeriodStart: text("last_period_start").default("1403/11/15"),
  theme: text("theme").notNull().default("light"), // 'light' | 'dark'
  calendarType: text("calendar_type").notNull().default("shamsi"), // 'shamsi' | 'gregorian'
  usePersianNumbers: boolean("use_persian_numbers").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Diet Weekly Schedule Template (Saturday to Friday)
export const dietPlans = pgTable("diet_plans", {
  id: serial("id").primaryKey(),
  dayOfWeek: text("day_of_week").notNull(), // 'شنبه' | 'یکشنبه' | 'دوشنبه' | 'سه‌شنبه' | 'چهارشنبه' | 'پنجشنبه' | 'جمعه'
  mealType: text("meal_type").notNull(), // 'breakfast' | 'lunch' | 'snack' | 'dinner'
  title: text("title").notNull(),
  foods: jsonb("foods").$type<Array<{ name: string; amount: string; unit: string; calories?: number; image?: string }>>().notNull(),
  recommendedTime: text("recommended_time").notNull(),
  calories: integer("calories").default(350),
  notes: text("notes"),
});

// Meal Log (Daily tracking)
export const mealLogs = pgTable("meal_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY/MM/DD in Jalali format
  dayOfWeek: text("day_of_week").notNull(),
  mealType: text("meal_type").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
});

// Daily Goals & Quotas
export const dailyGoals = pgTable("daily_goals", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY/MM/DD
  waterGlasses: integer("water_glasses").notNull().default(0),
  waterGoal: integer("water_goal").notNull().default(4),
  fruitGrams: integer("fruit_grams").notNull().default(0),
  fruitGoal: integer("fruit_goal").notNull().default(500),
  walkingMinutes: integer("walking_minutes").notNull().default(0),
  walkingGoal: integer("walking_goal").notNull().default(35),
  dairyGlasses: integer("dairy_glasses").notNull().default(0),
  dairyGoal: integer("dairy_goal").notNull().default(1),
  dietScore: integer("diet_score").default(0),
});

// Water Log details
export const waterLogs = pgTable("water_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  glassIndex: integer("glass_index").notNull(), // 1, 2, 3, 4
  loggedAt: text("logged_at").notNull(),
});

// Fruit Log details
export const fruitLogs = pgTable("fruit_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  grams: integer("grams").notNull(),
  fruitType: text("fruit_type"),
  loggedAt: text("logged_at").notNull(),
});

// Walking Session Logs
export const walkingLogs = pgTable("walking_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  loggedAt: text("logged_at").notNull(),
});

// Supplements Prescribed
export const supplements = pgTable("supplements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  timeOfDay: text("time_of_day").notNull(), // e.g. '09:00', '21:00'
  instructions: text("instructions"),
  isActive: boolean("is_active").notNull().default(true),
});

// Supplement Daily Log
export const supplementLogs = pgTable("supplement_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  supplementId: integer("supplement_id").notNull(),
  supplementName: text("supplement_name").notNull(),
  isTaken: boolean("is_taken").notNull().default(false),
  takenAt: text("taken_at"),
});

// Weight Log
export const weightLogs = pgTable("weight_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  weight: real("weight").notNull(),
  notes: text("notes"),
  loggedAt: timestamp("logged_at").defaultNow(),
});

// Mood & Mental State Log
export const moodLogs = pgTable("mood_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  mood: text("mood").notNull(), // 'excellent' | 'good' | 'normal' | 'sad' | 'anxious' | 'irritable' | 'tired'
  stressLevel: integer("stress_level").notNull().default(3), // 1 to 5
  energyLevel: integer("energy_level").notNull().default(3), // 1 to 5
  notes: text("notes"),
  loggedAt: timestamp("logged_at").defaultNow(),
});

// Sleep Log
export const sleepLogs = pgTable("sleep_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  sleepTime: text("sleep_time"), // '23:30'
  wakeTime: text("wake_time"), // '07:30'
  durationHours: real("duration_hours").notNull().default(8),
  quality: text("quality").notNull().default("good"), // 'excellent' | 'good' | 'normal' | 'poor'
  notes: text("notes"),
});

// Period Cycles History
export const periodCycles = pgTable("period_cycles", {
  id: serial("id").primaryKey(),
  startDate: text("start_date").notNull(), // YYYY/MM/DD
  endDate: text("end_date"), // YYYY/MM/DD
  cycleLength: integer("cycle_length").default(28),
  periodLength: integer("period_length").default(6),
  notes: text("notes"),
});

// Period Daily Flow Log
export const periodDays = pgTable("period_days", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  flowIntensity: text("flow_intensity").notNull(), // 'none' | 'light' | 'medium' | 'heavy'
  isSpotting: boolean("is_spotting").notNull().default(false),
  notes: text("notes"),
});

// PMS & Cycle Symptoms Log
export const symptomLogs = pgTable("symptom_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  symptoms: jsonb("symptoms").$type<string[]>().notNull(), // array of symptom keys
  severities: jsonb("severities").$type<Record<string, string>>().notNull(), // symptom -> 'none'|'light'|'medium'|'heavy'|'severe'
  notes: text("notes"),
});

// Food Violations Log
export const foodViolations = pgTable("food_violations", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  foodItem: text("food_item").notNull(),
  portion: text("portion").notNull(),
  time: text("time").notNull(),
  reason: text("reason").notNull(), // 'hungriness' | 'craving' | 'stress' | 'party' | 'boredom' | 'other'
  notes: text("notes"),
});

// Recipe Kitchen Database
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'soup' | 'salad' | 'diet_special'
  prepTimeMinutes: integer("prep_time_minutes").notNull().default(20),
  calories: integer("calories").default(300),
  imageUrl: text("image_url"),
  ingredients: jsonb("ingredients").$type<Array<{ name: string; amount: string }>>().notNull(),
  steps: jsonb("steps").$type<string[]>().notNull(),
  suitableMeals: jsonb("suitable_meals").$type<string[]>().notNull(),
  isDietApproved: boolean("is_diet_approved").notNull().default(true),
});

// Diet Rules
export const dietRules = pgTable("diet_rules", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // 'allowed' | 'forbidden' | 'water' | 'fruit' | 'dairy' | 'walking' | 'free_meal' | 'supplements'
  title: text("title").notNull(),
  content: text("content").notNull(),
  icon: text("icon"),
});

// Reminders & Notifications
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // 'diet' | 'water' | 'activity' | 'supplement' | 'cycle' | 'sleep' | 'checkin'
  title: text("title").notNull(),
  body: text("body").notNull(),
  time: text("time").notNull(), // '08:00'
  isActive: boolean("is_active").notNull().default(true),
  snoozeMinutes: integer("snooze_minutes").default(10),
  daysOfWeek: jsonb("days_of_week").$type<string[]>().default(["all"]),
});
