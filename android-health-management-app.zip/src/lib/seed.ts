import { db } from "@/db";
import {
  users,
  dietPlans,
  recipes,
  dietRules,
  supplements,
  notifications,
  dailyGoals,
  weightLogs,
  periodCycles,
  periodDays,
  symptomLogs,
  moodLogs,
  mealLogs,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { getTodayJalaliString } from "./jalali";

export async function ensureDataSeeded() {
  try {
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      return; // Already seeded
    }

    console.log("Seeding database with default diet, user, recipes, and rules...");

    // 1. User Profile
    await db.insert(users).values({
      name: "فرشته",
      startWeight: 74.5,
      currentWeight: 69.2,
      targetWeight: 62.0,
      height: 168,
      dietStartDay: "1403/11/01",
      dietCurrentDay: 12,
      dietTotalDays: 21,
      cycleAvgLength: 28,
      periodAvgLength: 6,
      lastPeriodStart: "1403/11/15",
      theme: "light",
      calendarType: "shamsi",
      usePersianNumbers: true,
    });

    // 2. Weekly Diet Plan (Saturday to Friday)
    const days = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];

    const mealTemplates = [
      {
        dayOfWeek: "شنبه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه انرژی‌بخش شنبه",
            recommendedTime: "۰۸:۳۰",
            foods: [
              { name: "نان سنگک یا جو", amount: "۲", unit: "کف دست" },
              { name: "پنیر کم‌چرب", amount: "۳۰", unit: "گرم" },
              { name: "گردو", amount: "۲", unit: "عدد" },
              { name: "چای سبز یا سیاه بدون قند", amount: "۱", unit: "فنجان" },
            ],
            calories: 310,
          },
          {
            mealType: "lunch",
            title: "ناهار پروتئینی شنبه",
            recommendedTime: "۱۳:۳۰",
            foods: [
              { name: "زرشک پلو با مرغ (بدون روغن اضافه)", amount: "۶", unit: "قاشق غذاخوری" },
              { name: "سینه مرغ آب‌پز یا گریل", amount: "۱۲۰", unit: "گرم" },
              { name: "سالاد شیرازی با آبغوره", amount: "۱", unit: "کاسه متوسط" },
            ],
            calories: 480,
          },
          {
            mealType: "snack",
            title: "عصرانه سبُک شنبه",
            recommendedTime: "۱۷:۰۰",
            foods: [
              { name: "سیب یا پرتقال", amount: "۱", unit: "عدد" },
              { name: "مغز بادام خام", amount: "۸", unit: "عدد" },
            ],
            calories: 160,
          },
          {
            mealType: "dinner",
            title: "شام رژیمی شنبه",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "سوپ جو پرک با سبزیجات", amount: "۱.۵", unit: "لیوان" },
              { name: "تخم‌مرغ آب‌پز", amount: "۱", unit: "عدد" },
              { name: "لیمو ترش تازه", amount: "۱", unit: "عدد" },
            ],
            calories: 290,
          },
        ],
      },
      {
        dayOfWeek: "یکشنبه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه مقوی یکشنبه",
            recommendedTime: "۰۸:۳۰",
            foods: [
              { name: "ارده شیره (شیره انگور)", amount: "۱.۵", unit: "قاشق غذاخوری" },
              { name: "نان جو یا سنگک", amount: "۲", unit: "کف دست" },
              { name: "شیر کم‌چرب گرم", amount: "۱", unit: "استکان" },
            ],
            calories: 340,
          },
          {
            mealType: "lunch",
            title: "ناهار یکشنبه - کتلت رژیمی",
            recommendedTime: "۱۳:۳۰",
            foods: [
              { name: "کتلت گوشت کم‌چرب (پخته در فر یا هواپز)", amount: "۲", unit: "عدد" },
              { name: "نان سنگک", amount: "۱.۵", unit: "کف دست" },
              { name: "گوجه‌فرنگی و خیارشور کم‌نمک", amount: "به مقدار دلخواه", unit: "-" },
            ],
            calories: 450,
          },
          {
            mealType: "snack",
            title: "عصرانه یکشنبه",
            recommendedTime: "۱۷:۰۰",
            foods: [
              { name: "خیار و هویج تازه", amount: "۲", unit: "عدد" },
              { name: "ماست یونانی کم‌چرب", amount: "۳", unit: "قاشق غذاخوری" },
            ],
            calories: 120,
          },
          {
            mealType: "dinner",
            title: "شام یکشنبه - خوراک قارچ و سبزیجات",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "خوراک قارچ و فلفل دلمه‌ای و هویج بخارپز", amount: "۲", unit: "لیوان" },
              { name: "پنیر لاکتیکی", amount: "۲۰", unit: "گرم" },
            ],
            calories: 220,
          },
        ],
      },
      {
        dayOfWeek: "دوشنبه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه دوشنبه - تخم‌مرغ آب‌پز",
            recommendedTime: "۰۸:۳۰",
            foods: [
              { name: "تخم‌مرغ آب‌پز عسلی/سفت", amount: "۲", unit: "عدد" },
              { name: "گوجه و خیار", amount: "۱", unit: "بشقاب" },
              { name: "نان سنگک", amount: "۱.۵", unit: "کف دست" },
            ],
            calories: 310,
          },
          {
            mealType: "lunch",
            title: "ناهار دوشنبه - استانبولی پلو",
            recommendedTime: "۱۳:۳۰",
            foods: [
              { name: "استانبولی پلو با گوشت چرخ‌کرده کم‌چرب", amount: "۷", unit: "قاشق غذاخوری" },
              { name: "ماست کم‌چرب یا بورانی اسفناج", amount: "۱", unit: "پیاله" },
            ],
            calories: 460,
          },
          {
            mealType: "snack",
            title: "عصرانه دوشنبه",
            recommendedTime: "۱۷:۰۰",
            foods: [
              { name: "موز کوچک", amount: "۱", unit: "عدد" },
              { name: "چای دموغ با دارچین", amount: "۱", unit: "فنجان" },
            ],
            calories: 110,
          },
          {
            mealType: "dinner",
            title: "شام دوشنبه - سالاد سیب‌زمینی و پنیر",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "سالاد سیب‌زمینی آب‌پز با پنیر کم‌چرب و شوید", amount: "۱", unit: "کاسه" },
              { name: "روغن زیتون بکر", amount: "۱", unit: "قاشق مرباخوری" },
            ],
            calories: 270,
          },
        ],
      },
      {
        dayOfWeek: "سه‌شنبه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه سه‌شنبه - فرنی رژیمی",
            recommendedTime: "۰۸:۳۰",
            foods: [
              { name: "فرنی با آرد برنج و شیر کم‌چرب و هل (کم‌شیرین)", amount: "۱.۵", unit: "پیاله" },
              { name: "دارچین تازه", amount: "۱", unit: "قاشق چایخوری" },
            ],
            calories: 280,
          },
          {
            mealType: "lunch",
            title: "ناهار سه‌شنبه - خوراک مرغ و سبزیجات",
            recommendedTime: "۱۳:۳۰",
            foods: [
              { name: "خوراک مرغ رژیمی با کدو و هویج", amount: "۱.۵", unit: "لیوان" },
              { name: "نان جو", amount: "۲", unit: "کف دست" },
              { name: "زیتون پرورده رژیمی", amount: "۵", unit: "عدد" },
            ],
            calories: 420,
          },
          {
            mealType: "snack",
            title: "عصرانه سه‌شنبه",
            recommendedTime: "۱۷:۰۰",
            foods: [
              { name: "انار یا نارنگی", amount: "۱", unit: "عدد" },
              { name: "مغز پسته خام", amount: "۱۰", unit: "عدد" },
            ],
            calories: 140,
          },
          {
            mealType: "dinner",
            title: "شام سه‌شنبه - سوپ رشته رژیمی",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "سوپ رشته فرنگی با مرغ ریش‌ریش", amount: "۱.۵", unit: "لیوان" },
              { name: "سبزی خوردن تازه", amount: "۱", unit: "بشقاب" },
            ],
            calories: 260,
          },
        ],
      },
      {
        dayOfWeek: "چهارشنبه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه چهارشنبه - نان و پنیر و سبزی",
            recommendedTime: "۰۸:۳۰",
            foods: [
              { name: "نان سنگک", amount: "۲", unit: "کف دست" },
              { name: "پنیر کم‌چرب", amount: "۳۵", unit: "گرم" },
              { name: "سبزی خوردن تازه و خیار", amount: "۱", unit: "بشقاب" },
            ],
            calories: 290,
          },
          {
            mealType: "lunch",
            title: "ناهار چهارشنبه - کوکو سبزی کم‌روغن",
            recommendedTime: "۱۳:۳۰",
            foods: [
              { name: "کوکو سبزی (پخته در فر/هواپز)", amount: "۲", unit: "برش متوسط" },
              { name: "نان جو یا سنگک", amount: "۲", unit: "کف دست" },
              { name: "گوجه‌فرنگی و گوجه گیلاسی", amount: "۱", unit: "کاسه" },
            ],
            calories: 410,
          },
          {
            mealType: "snack",
            title: "عصرانه چهارشنبه",
            recommendedTime: "۱۷:۰۰",
            foods: [
              { name: "شیر کم‌چرب ولرم", amount: "۱", unit: "لیوان" },
              { name: "خرما", amount: "۲", unit: "عدد" },
            ],
            calories: 170,
          },
          {
            mealType: "dinner",
            title: "شام چهارشنبه - خوراک لوبیا/قارچ",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "خوراک قارچ و سبزیجات بخارپز", amount: "۱.۵", unit: "لیوان" },
              { name: "تخم‌مرغ آب‌پز", amount: "۱", unit: "عدد" },
            ],
            calories: 240,
          },
        ],
      },
      {
        dayOfWeek: "پنجشنبه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه پنجشنبه",
            recommendedTime: "۰۸:۳۰",
            foods: [
              { name: "ارده و عسل طبیعی", amount: "۱", unit: "قاشق غذاخوری" },
              { name: "نان سنگک", amount: "۲", unit: "کف دست" },
              { name: "چای گیاهی بابونه", amount: "۱", unit: "فنجان" },
            ],
            calories: 320,
          },
          {
            mealType: "lunch",
            title: "ناهار پنجشنبه - پلو خورشت دلخواه رژیمی",
            recommendedTime: "۱۳:۳۰",
            foods: [
              { name: "پلو (کته کم‌روغن)", amount: "۶", unit: "قاشق غذاخوری" },
              { name: "خورشت قیمه یا قورمه‌سبزی کم‌چرب", amount: "۱", unit: "کاسه کوچک" },
              { name: "سالاد فصل با سرکه سیب", amount: "۱", unit: "کاسه" },
            ],
            calories: 490,
          },
          {
            mealType: "snack",
            title: "عصرانه پنجشنبه",
            recommendedTime: "۱۷:۰۰",
            foods: [
              { name: "میکس میوه‌های فصل", amount: "۲۰۰", unit: "گرم" },
              { name: "گردو", amount: "۱", unit: "عدد" },
            ],
            calories: 150,
          },
          {
            mealType: "dinner",
            title: "شام پنجشنبه - سوپ جو رژیمی",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "سوپ جو با سبزیجات و لیمو", amount: "۲", unit: "لیوان" },
              { name: "نان جو خشک", amount: "۱", unit: "عدد" },
            ],
            calories: 230,
          },
        ],
      },
      {
        dayOfWeek: "جمعه",
        meals: [
          {
            mealType: "breakfast",
            title: "صبحانه جمعه - ویژه آدینه",
            recommendedTime: "۰۹:۰۰",
            foods: [
              { name: "املت گوجه‌فرنگی با حداقل روغن زیتون", amount: "۱", unit: "بشقاب" },
              { name: "نان سنگک تازه", amount: "۲.۵", unit: "کف دست" },
              { name: "چای تازه دم با هل", amount: "۱", unit: "فنجان" },
            ],
            calories: 360,
          },
          {
            mealType: "lunch",
            title: "ناهار جمعه - وعده آزاد / دلخواه مدیریت‌شده",
            recommendedTime: "۱۴:۰۰",
            foods: [
              { name: "غذا یا خورشت دلخواه خانواده (پیمانه کنترل‌شده)", amount: "۱", unit: "پرس استاندارد" },
              { name: "سالاد تازه فراوان", amount: "۱", unit: "کاسه بزرگ" },
            ],
            calories: 580,
          },
          {
            mealType: "snack",
            title: "عصرانه جمعه",
            recommendedTime: "۱۷:۳۰",
            foods: [
              { name: "چای سبُک + انار یا سیب", amount: "۱", unit: "عدد" },
            ],
            calories: 100,
          },
          {
            mealType: "dinner",
            title: "شام سبک جمعه",
            recommendedTime: "۲۰:۳۰",
            foods: [
              { name: "ماست و خیار و نعنا و شوید با گردو", amount: "۱", unit: "کاسه بزرگ" },
              { name: "نان جو", amount: "۱", unit: "کف دست" },
            ],
            calories: 210,
          },
        ],
      },
    ];

    for (const t of mealTemplates) {
      for (const m of t.meals) {
        await db.insert(dietPlans).values({
          dayOfWeek: t.dayOfWeek,
          mealType: m.mealType,
          title: m.title,
          recommendedTime: m.recommendedTime,
          foods: m.foods,
          calories: m.calories,
        });
      }
    }

    // 3. Recipes Kitchen Database
    const initialRecipes = [
      {
        title: "فرنی رژیمی با آرد برنج و هل",
        category: "breakfast",
        prepTimeMinutes: 15,
        calories: 220,
        imageUrl: "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "آرد برنج", amount: "۲ قاشق غذاخوری" },
          { name: "شیر کم‌چرب", amount: "۱.۵ لیوان" },
          { name: "گلاب و پودر هل", amount: "۱ قاشق چایخوری" },
          { name: "عسل یا شیره انگور", amount: "۱ قاشق مرباخوری" },
        ],
        steps: [
          "آرد برنج را در شیر سرد حل کنید تا کاملاً یکدست شود.",
          "قابلمه را روی حرارت ملایم بگذارید و مدام هم بزنید تا غلیظ شود.",
          "در ۵ دقیقه پایانی، هل و گلاب را اضافه کنید.",
          "پس از خاموش کردن، عسل را اضافه کرده و سرو نمایید.",
        ],
        suitableMeals: ["صبحانه", "عصرانه"],
      },
      {
        title: "زرشک پلو با مرغ رژیمی بدون روغن",
        category: "lunch",
        prepTimeMinutes: 45,
        calories: 450,
        imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "سینه مرغ", amount: "۱۵۰ گرم" },
          { name: "برنج ایرانی کته", amount: "۶ قاشق غذاخوری" },
          { name: "زرشک تفت داده شده با عسل", amount: "۱ قاشق غذاخوری" },
          { name: "زعفران دم‌کرده و پیاز", amount: "به مقدار لازم" },
        ],
        steps: [
          "سینه مرغ را با پیاز، زردچوبه، زعفران و نمک در آب کم بپزید.",
          "برنج را به صورت کته کم‌نمک آماده کنید.",
          "زرشک را با چند قطره آب و نیم قاشق چایخوری عسل گرم کنید.",
          "مرغ را کنار برنج و زرشک تزئین و سرو کنید.",
        ],
        suitableMeals: ["ناهار"],
      },
      {
        title: "سالاد سیب‌زمینی و پنیر و شوید",
        category: "dinner",
        prepTimeMinutes: 20,
        calories: 260,
        imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "سیب‌زمینی آب‌پز متوسط", amount: "۱ عدد" },
          { name: "پنیر کم‌چرب یا لاکتیکی", amount: "۳۰ گرم" },
          { name: "شوید تازه خردشده", amount: "۲ قاشق غذاخوری" },
          { name: "روغن زیتون و آب‌لیمو", amount: "۱ قاشق مرباخوری" },
        ],
        steps: [
          "سیب‌زمینی آب‌پز را مکعبی خرد کنید.",
          "پنیر را رنده یا له کنید و با شوید و روغن زیتون مخلوط سازید.",
          "مواد را با هم ترکیب کرده و ۱۰ دقیقه در یخچال استراحت دهید.",
        ],
        suitableMeals: ["شام", "عصرانه"],
      },
      {
        title: "کتلت کم‌چرب فر/هواپز",
        category: "lunch",
        prepTimeMinutes: 35,
        calories: 380,
        imageUrl: "https://images.unsplash.com/photo-1529042410759-befb1204b468?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "گوشت چرخ‌کرده کم‌چرب", amount: "۱۰۰ گرم" },
          { name: "سیب‌زمینی رنده شده و آب‌گرفته", amount: "۱ عدد کوچک" },
          { name: "پیاز رنده شده", amount: "۱ عدد" },
          { name: "ادویه (زردچوبه، فلفل، ادویه کتلت)", amount: "۱ قاشق چایخوری" },
        ],
        steps: [
          "تمام مواد را ورز دهید تا یکدست شوند.",
          "کتلت‌ها را شکل داده و روی کاغذ روغن‌گیر در فر یا هواپز با دمای ۱۸۰ درجه پخت کنید.",
        ],
        suitableMeals: ["ناهار", "شام"],
      },
      {
        title: "خوراک مرغ و سبزیجات بخارپز",
        category: "diet_special",
        prepTimeMinutes: 30,
        calories: 320,
        imageUrl: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "فیله مرغ", amount: "۱۲۰ گرم" },
          { name: "کدو سبز و هویج و قارچ", amount: "۱.۵ لیوان" },
          { name: "روغن زیتون و آب لیموترش", amount: "۱ قاشق غذاخوری" },
        ],
        steps: [
          "فیله مرغ و سبزیجات را تکه‌تکه کنید.",
          "در سبد بخارپز بگذارید تا ۲۰ دقیقه مغزپخت شوند.",
          "با روغن زیتون، نمک دریا و آب لیموترش چاشنی‌زدایی کنید.",
        ],
        suitableMeals: ["ناهار", "شام"],
      },
      {
        title: "تخم‌مرغ آب‌پز با سبزیجات تازه",
        category: "breakfast",
        prepTimeMinutes: 10,
        calories: 180,
        imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "تخم‌مرغ ارگانیک", amount: "۲ عدد" },
          { name: "گوجه‌فرنگی و خیار و ریحان", amount: "۱ بشقاب" },
          { name: "سیاه‌دانه یا کنجد", amount: "نصف قاشق چایخوری" },
        ],
        steps: [
          "تخم‌مرغ‌ها را ۱۰ دقیقه در آب جوش بپزید.",
          "پوست کنده و همراه با گوجه، خیار و سبزی تازه سرو کنید.",
        ],
        suitableMeals: ["صبحانه", "شام"],
      },
      {
        title: "سوپ جو رژیمی با سبزیجات",
        category: "soup",
        prepTimeMinutes: 40,
        calories: 210,
        imageUrl: "https://images.unsplash.com/photo-1547592180-85f173990554?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "جو پوست‌کنده یا پرک", amount: "نصف لیوان" },
          { name: "هویج نگینی و جعفری", amount: "۱ لیوان" },
          { name: "عصاره طبیعی مرغ یا سبزیجات", amount: "۲ لیوان" },
        ],
        steps: [
          "جو و هویج را با عصاره مرغ بپزید تا لعاب بیندازد.",
          "جعفری خردشده و آب‌لیمو را در آخر اضافه کرده و گرم نوش جان کنید.",
        ],
        suitableMeals: ["شام", "پیش‌غذا"],
      },
      {
        title: "خوراک قارچ و فلفل دلمه‌ای",
        category: "dinner",
        prepTimeMinutes: 15,
        calories: 190,
        imageUrl: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "قارچ اسلایس شده", amount: "۲۰۰ گرم" },
          { name: "فلفل دلمه‌ای رنگی", amount: "۱ عدد" },
          { name: "پیازچه و سیر خردشده", amount: "۲ قاشق غذاخوری" },
        ],
        steps: [
          "قارچ و فلفل دلمه‌ای را با ۱ قاشق مرباخوری روغن زیتون با حرارت بالا تفت دهید.",
          "سیر و آب‌لیمو و آویشن را اضافه کرده و میل نمایید.",
        ],
        suitableMeals: ["شام"],
      },
      {
        title: "ارده شیره مقوی سنتی",
        category: "breakfast",
        prepTimeMinutes: 5,
        calories: 250,
        imageUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "ارده خالص کنجد", amount: "۱ قاشق غذاخوری" },
          { name: "شیره انگور یا خرما", amount: "۱ قاشق مرباخوری" },
        ],
        steps: [
          "ارده و شیره را در ظرف کوچکی ترکیب کرده و با نان سنگک یا جو میل کنید.",
        ],
        suitableMeals: ["صبحانه"],
      },
      {
        title: "استانبولی پلو با گوشت کم‌چرب",
        category: "lunch",
        prepTimeMinutes: 40,
        calories: 430,
        imageUrl: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "برنج ایرانی", amount: "۷ قاشق غذاخوری" },
          { name: "گوجه‌فرنگی پوره شده", amount: "۲ عدد" },
          { name: "گوشت چرخ‌کرده کم‌چرب", amount: "۷۰ گرم" },
          { name: "سیب‌زمینی نگینی کوچک", amount: "۱ عدد" },
        ],
        steps: [
          "گوشت و پیاز را تفت دهید، پوره گوجه و سیب‌زمینی را اضافه کنید.",
          "برنج را اضافه کرده و به صورت کته خوش‌عطر بپزید.",
        ],
        suitableMeals: ["ناهار"],
      },
      {
        title: "کوکو سبزی رژیمی کم‌روغن",
        category: "lunch",
        prepTimeMinutes: 25,
        calories: 330,
        imageUrl: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "سبزی کوکویی تازه‌خردشده", amount: "۲ لیوان" },
          { name: "تخم‌مرغ", amount: "۲ عدد" },
          { name: "زرشک و گردو خردشده", amount: "۱ قاشق مرباخوری" },
        ],
        steps: [
          "سبزی، تخم‌مرغ و ادویه‌ها را خوب هم بزنید.",
          "در ماهیتابه رژیمی با چند قطره روغن یا در فر با دما ۱۸۰ درجه مغزپخت کنید.",
        ],
        suitableMeals: ["ناهار", "شام"],
      },
      {
        title: "پلو خورشت قورمه‌سبزی رژیمی",
        category: "lunch",
        prepTimeMinutes: 60,
        calories: 470,
        imageUrl: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "سبزی قورمه سرخ‌نشده (تفت‌آبی)", amount: "۲ لیوان" },
          { name: "گوشت گوساله لذیذ کم‌چرب", amount: "۸۰ گرم" },
          { name: "لوبیا قرمز یا چیتی", amount: "۲ قاشق غذاخوری" },
          { name: "برنج کته", amount: "۶ قاشق غذاخوری" },
        ],
        steps: [
          "گوشت، پیاز و لوبیا را بپزید.",
          "سبزی را بدون سرخ کردن عمیق اضافه کنید و با لیمو عمانی جا بیندازید.",
        ],
        suitableMeals: ["ناهار"],
      },
      {
        title: "سوپ رشته فرنگی با مرغ و سبزیجات",
        category: "soup",
        prepTimeMinutes: 30,
        calories: 250,
        imageUrl: "https://images.unsplash.com/photo-1511910849309-0dcdb8f87e46?w=600&auto=format&fit=crop&q=80",
        ingredients: [
          { name: "سینه مرغ ریش‌ریش", amount: "۶۰ گرم" },
          { name: "رشته سوپی", amount: "۱/۳ لیوان" },
          { name: "هویج، نخودفرنگی و گوجه رنده‌شده", amount: "۱ لیوان" },
        ],
        steps: [
          "مرغ را بپزید و ریش‌ریش کنید.",
          "سبزیجات و رشته سوپی را اضافه کنید تا پخته و جا افتاده شود.",
        ],
        suitableMeals: ["شام"],
      },
    ];

    for (const r of initialRecipes) {
      await db.insert(recipes).values({
        title: r.title,
        category: r.category,
        prepTimeMinutes: r.prepTimeMinutes,
        calories: r.calories,
        imageUrl: r.imageUrl,
        ingredients: r.ingredients,
        steps: r.steps,
        suitableMeals: r.suitableMeals,
        isDietApproved: true,
      });
    }

    // 4. Diet Rules
    const rulesList = [
      {
        category: "allowed",
        title: "غذاهای مجاز و آزاد",
        content: "سبزیجات برگی تازه (کاهو، خیار، سبزی خوردن)، چای و دمنوش‌های بدون قند، لیموترش تازه، سرکه سیب و آب گوجه‌فرنگی بدون محدودیت کالری قابل مصرف هستند.",
        icon: "CheckCircle",
      },
      {
        category: "forbidden",
        title: "غذاهای ممنوع در طول دوره",
        content: "نوشابه‌های گازدار، شیرینی‌جات مصنوعی، فست‌فود، سس‌های مایونز، چیپس، پفک، روغن‌های جامد و سرخ‌کردنی‌های سنگین اکیداً ممنوع می‌باشند.",
        icon: "XCircle",
      },
      {
        category: "water",
        title: "قوانین مصرف آب (۴ لیوان روزانه)",
        content: "حداقل ۴ لیوان آب بزرگ (معادل ۱ لیتر) در طول روز بنوشید. یک لیوان ناشتا نیم‌ساعت قبل از صبحانه و یک لیوان قبل از هر وعده اصلی توصیه می‌شود.",
        icon: "Droplet",
      },
      {
        category: "fruit",
        title: "سهمیه میوه (۵۰۰ گرم روزانه)",
        content: "سهمیه میوه روزانه ۵۰۰ گرم است. ترجیحاً از میوه‌های با اندیس گلایسمی پایین مانند سیب، انار، پرتقال و خیار استفاده شود. از مصرف میوه در اواخر شب پرهیز کنید.",
        icon: "Apple",
      },
      {
        category: "dairy",
        title: "قوانین لبنیات (۱ لیوان شیر یا ماست)",
        content: "روزانه ۱ لیوان شیر کم‌چرب (زیر ۱.۵٪) یا ۱ لیوان ماست کم‌چرب یا ماست یونانی کم‌چرب حتماً میل شود. لبنیات به تحکیم استخوان‌ها و آرامش اعصاب کمک می‌کند.",
        icon: "Milk",
      },
      {
        category: "walking",
        title: "پیاده‌روی روزانه (۳۵ دقیقه)",
        content: "پیاده‌روی با سرعت متوسط تا تند به مدت ۳۵ دقیقه پیوسته الزام‌آور است. تایمر اختصاصی برنامه‌ریزی را ساده‌تر می‌کند. زمان مناسب: عصرها یا ۱ ساعت بعد از ناهار.",
        icon: "Footprints",
      },
      {
        category: "free_meal",
        title: "قوانین وعده آزاد (Cheat Meal)",
        content: "جمعه‌ها ناهار به عنوان وعده آزاد در نظر گرفته شده است. در این وعده می‌توانید غذای دلخواه را میل کنید اما کنترل مقدار و عدم پرخوری شدید شرط اساسی است.",
        icon: "Sparkles",
      },
      {
        category: "supplements",
        title: "قوانین مکمل‌ها و داروها",
        content: "مکمل‌های تجویز شده (مولتی‌ویتامین، آهن، کلسیم د۳) باید طبق زمان‌بندی دقیق و همراه آب کافی مصرف شوند. تغییر دوز داروها نیازمند مشورت پزشک است.",
        icon: "Pill",
      },
    ];

    for (const rule of rulesList) {
      await db.insert(dietRules).values(rule);
    }

    // 5. Prescribed Supplements
    const initialSupplements = [
      { name: "مولتی ویتامین + مینرال", dosage: "۱ قرص", timeOfDay: "۰۹:۰۰", instructions: "بعد از صبحانه همراه ۱ لیوان آب" },
      { name: "کلسیم + ویتامین د۳", dosage: "۱ قرص", timeOfDay: "۱۳:۰۰", instructions: "همراه ناهار" },
      { name: "آهن + اسید فولیک", dosage: "۱ کپسول", timeOfDay: "۲۱:۰۰", instructions: "قبل از خواب با آب مرکبات یا آب" },
      { name: "امگا ۳ (کپسول روغن ماهی)", dosage: "۱ کپسول", timeOfDay: "۱۴:۰۰", instructions: "همراه یا بلافاصله بعد از ناهار" },
    ];

    for (const s of initialSupplements) {
      await db.insert(supplements).values(s);
    }

    // 6. Notifications Preset
    const initialNotifications = [
      { category: "diet", title: "وعده صبحانه", body: "وقت نوش جان کردن صبحانه رژیمی و انرژی‌بخش شماست! 🍳", time: "۰۸:۳۰" },
      { category: "water", title: "یادآوری نوشیدن آب", body: "یک لیوان آب خنک و گوارا بنوش تا بدنت هیدراته بمونه! 💧", time: "۱۱:۰۰" },
      { category: "diet", title: "وعده ناهار", body: "زمان ناهار رژیمی رسید! نوش جان! 🥗", time: "۱۳:۳۰" },
      { category: "activity", title: "پیاده‌روی ۳۵ دقیقه‌ای", body: "وقتشه کفشاتو بپوشی و ۳۵ دقیقه پیاده‌روی شاداب داشته باشی! 🚶‍♀️", time: "۱۶:۳۰" },
      { category: "supplement", title: "مصرف مکمل قرص آهن", body: "یادت نره مکمل شبانه‌ت رو همراه آب بنوشی 💊", time: "۲۱:۰۰" },
      { category: "cycle", title: "یادآوری چرخه و علائم", body: "وضعیت امروز چرخه، خلق‌وخو و علائم روزانه‌ت رو ثبت کن ✨", time: "۲۱:۳۰" },
    ];

    for (const n of initialNotifications) {
      await db.insert(notifications).values({
        category: n.category,
        title: n.title,
        body: n.body,
        time: n.time,
        isActive: true,
        daysOfWeek: ["all"],
      });
    }

    // 7. Seed initial weight logs
    const weightHistory = [
      { date: "1403/11/01", weight: 74.5, notes: "شروع دوره ۲۱ روزه رژیم" },
      { date: "1403/11/05", weight: 73.2, notes: "احساس سبک‌تر شدن و انرژی بیشتر" },
      { date: "1403/11/08", weight: 71.8, notes: "پایبندی عالی به پیاده‌روی" },
      { date: "1403/11/12", weight: 70.5, notes: "کاهش ۴ کیلوگرمی تا اینجا" },
      { date: "1403/11/15", weight: 69.2, notes: "وزن فعلی - عالی پیش می‌ری!" },
    ];

    for (const w of weightHistory) {
      await db.insert(weightLogs).values(w);
    }

    // 8. Seed Period Cycle History
    await db.insert(periodCycles).values({
      startDate: "1403/10/18",
      endDate: "1403/10/24",
      cycleLength: 28,
      periodLength: 6,
      notes: "سیکل قبلی منظم و بدون مشکل شدید",
    });

    await db.insert(periodCycles).values({
      startDate: "1403/11/15",
      endDate: "1403/11/21",
      cycleLength: 28,
      periodLength: 6,
      notes: "سیکل جاری - شروع با لکه‌بینی خفیف",
    });

    // 9. Today's Daily Goals default init
    const todayJalali = getTodayJalaliString();
    await db.insert(dailyGoals).values({
      date: todayJalali,
      waterGlasses: 3,
      waterGoal: 4,
      fruitGrams: 320,
      fruitGoal: 500,
      walkingMinutes: 25,
      walkingGoal: 35,
      dairyGlasses: 1,
      dairyGoal: 1,
      dietScore: 88,
    });

    // Seed initial sample symptom & mood logs
    await db.insert(moodLogs).values({
      date: todayJalali,
      mood: "good",
      stressLevel: 2,
      energyLevel: 4,
      notes: "احساس شادابی و انگیزه بالایی برای ادامه رژیم دارم",
    });

    await db.insert(symptomLogs).values({
      date: todayJalali,
      symptoms: ["headache", "sweet_craving"],
      severities: { headache: "light", sweet_craving: "medium" },
      notes: "کمی هوس شیرینی در عصر داشتم که با خرما مدیریت شد",
    });

    console.log("Database successfully seeded!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
