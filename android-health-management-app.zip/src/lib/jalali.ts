// Jalali Date and Persian Number Helpers

const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
const PERSIAN_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد",
  "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر",
  "دی", "بهمن", "اسفند"
];

const PERSIAN_WEEKDAYS = [
  "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"
];

/**
 * Convert English digits to Persian digits
 */
export function toPersianDigits(num: number | string | null | undefined): string {
  if (num === null || num === undefined) return "";
  return String(num).replace(/\d/g, (digit) => PERSIAN_DIGITS[parseInt(digit, 10)]);
}

/**
 * Simple Jalali converter from Gregorian Date
 */
export function getJalaliDate(date: Date = new Date()): { year: number; month: number; day: number; monthName: string; dayName: string } {
  let g_y = date.getFullYear();
  let g_m = date.getMonth() + 1;
  let g_d = date.getDate();

  let g_days_in_month = [31, (g_y % 4 === 0 && g_y % 100 !== 0) || g_y % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

  let gy = g_y - 1600;
  let gm = g_m - 1;
  let gd = g_d - 1;

  let g_day_no = 365 * gy + Math.floor((gy + 3) / 4) - Math.floor((gy + 99) / 100) + Math.floor((gy + 399) / 400);

  for (let i = 0; i < gm; ++i) g_day_no += g_days_in_month[i];
  g_day_no += gd;

  let j_day_no = g_day_no - 79;

  let j_np = Math.floor(j_day_no / 12053);
  j_day_no %= 12053;

  let jy = 979 + 33 * j_np + 4 * Math.floor(j_day_no / 1461);
  j_day_no %= 1461;

  if (j_day_no >= 366) {
    jy += Math.floor((j_day_no - 1) / 365);
    j_day_no = (j_day_no - 1) % 365;
  }

  let i = 0;
  for (i = 0; i < 11 && j_day_no >= j_days_in_month[i]; ++i) {
    j_day_no -= j_days_in_month[i];
  }
  let jm = i + 1;
  let jd = j_day_no + 1;

  let dayOfWeekIdx = date.getDay(); // 0 is Sunday
  let dayName = PERSIAN_WEEKDAYS[dayOfWeekIdx];

  return {
    year: jy,
    month: jm,
    day: jd,
    monthName: PERSIAN_MONTHS[jm - 1],
    dayName,
  };
}

/**
 * Format today's Jalali string "1403/11/18"
 */
export function getTodayJalaliString(): string {
  const j = getJalaliDate(new Date());
  const m = j.month < 10 ? `0${j.month}` : `${j.month}`;
  const d = j.day < 10 ? `0${j.day}` : `${j.day}`;
  return `${j.year}/${m}/${d}`;
}

/**
 * Format full human readable Jalali string e.g., "پنجشنبه ۱۸ بهمن ۱۴۰۳"
 */
export function formatJalaliFull(date: Date = new Date(), usePersian: boolean = true): string {
  const j = getJalaliDate(date);
  const dayStr = usePersian ? toPersianDigits(j.day) : String(j.day);
  const yearStr = usePersian ? toPersianDigits(j.year) : String(j.year);
  return `${j.dayName} ${dayStr} ${j.monthName} ${yearStr}`;
}

/**
 * Get current week day in Persian name (e.g. "شنبه")
 */
export function getCurrentPersianWeekday(): string {
  const j = getJalaliDate();
  return j.dayName;
}

/**
 * Calculate Cycle Phase & Predictions based on cycle start and length
 */
export interface CycleInfo {
  cycleDay: number; // e.g. Day 14 of 28
  phase: "period" | "follicular" | "ovulation" | "luteal" | "pms";
  phaseTitle: string;
  phaseDescription: string;
  daysUntilNextPeriod: number;
  nextPeriodDate: string;
  isFertile: boolean;
  isOvulationDay: boolean;
  isPeriod: boolean;
  chanceOfPregnancy: "کم" | "متوسط" | "بالا";
}

export function calculateCycleInfo(
  lastPeriodStartJalali: string = "1403/11/15",
  avgCycleLength: number = 28,
  avgPeriodLength: number = 6
): CycleInfo {
  // Simple day offset calculation
  const todayStr = getTodayJalaliString();
  
  // Convert Jalali string YYYY/MM/DD to approximate days relative
  function jalaliToApproxDays(jStr: string) {
    const parts = jStr.split("/").map(Number);
    if (parts.length < 3) return 0;
    return parts[0] * 365 + parts[1] * 30 + parts[2];
  }

  const startDays = jalaliToApproxDays(lastPeriodStartJalali);
  const todayDays = jalaliToApproxDays(todayStr);

  let diff = todayDays - startDays;
  if (diff < 0) diff = 0;

  const cycleDay = (diff % avgCycleLength) + 1;
  const daysUntilNextPeriod = avgCycleLength - cycleDay + 1;

  let phase: CycleInfo["phase"] = "follicular";
  let phaseTitle = "فاز فولیکولار";
  let phaseDescription = "سطح انرژی شما رو به افزایش است. بهترین زمان برای شروع تمرینات روحی و بدنی.";
  let isFertile = false;
  let isOvulationDay = false;
  let isPeriod = false;
  let chanceOfPregnancy: CycleInfo["chanceOfPregnancy"] = "کم";

  if (cycleDay <= avgPeriodLength) {
    phase = "period";
    phaseTitle = "دوران خونریزی (پریود)";
    phaseDescription = "بدن شما نیاز به استراحت، غذای گرم، نوشیدن آب کافی و تمرینات سبک دارد.";
    isPeriod = true;
    chanceOfPregnancy = "کم";
  } else if (cycleDay >= 12 && cycleDay <= 16) {
    if (cycleDay === 14) {
      phase = "ovulation";
      phaseTitle = "تخمک‌گذاری (احتمالی)";
      phaseDescription = "اوج باروری و انرژی در طول سیکل. پوست شفاف‌تر و انگیزه بالا.";
      isOvulationDay = true;
    } else {
      phase = "follicular";
      phaseTitle = "پنجره باروری (احتمالی)";
      phaseDescription = "احتمال باروری در این چند روز بالاترین میزان است.";
    }
    isFertile = true;
    chanceOfPregnancy = "بالا";
  } else if (cycleDay > avgCycleLength - 7) {
    phase = "pms";
    phaseTitle = "فاز لوتئال / نزدیک به پریود (PMS)";
    phaseDescription = "ممکن است هوس شیرینی، کمی نفخ یا افت انرژی داشته باشید. صبور و مهربان باشید.";
    chanceOfPregnancy = "کم";
  } else {
    phase = "luteal";
    phaseTitle = "فاز لوتئال";
    phaseDescription = "میزان پروژسترون افزایش می‌یابد. هیدراتاسیون و خواب کافی اهمیت زیادی دارد.";
    chanceOfPregnancy = "کم";
  }

  // Calculate approximate next period string
  const nextParts = lastPeriodStartJalali.split("/").map(Number);
  let nextDay = nextParts[2] + avgCycleLength;
  let nextMonth = nextParts[1];
  let nextYear = nextParts[0];

  while (nextDay > 30) {
    nextDay -= 30;
    nextMonth += 1;
    if (nextMonth > 12) {
      nextMonth = 1;
      nextYear += 1;
    }
  }

  const mStr = nextMonth < 10 ? `0${nextMonth}` : `${nextMonth}`;
  const dStr = nextDay < 10 ? `0${nextDay}` : `${nextDay}`;
  const nextPeriodDate = `${nextYear}/${mStr}/${dStr}`;

  return {
    cycleDay,
    phase,
    phaseTitle,
    phaseDescription,
    daysUntilNextPeriod,
    nextPeriodDate,
    isFertile,
    isOvulationDay,
    isPeriod,
    chanceOfPregnancy,
  };
}
