export type MoodType = 'excellent' | 'good' | 'normal' | 'tired' | 'anxious' | 'stressed' | 'emotional_eating';

export type SnackOption = {
  id: string;
  name: string;
  portion: string;
  calories?: number;
  description?: string;
  icon?: string;
};

export type MealItem = {
  id: string;
  title: string; // 'breakfast' | 'lunch' | 'dinner'
  persianTitle: string;
  timeSlot: string; // e.g. "۰۸:۳۰"
  foodName: string;
  portion: string;
  calories?: number;
  image: string;
  ingredients: string[];
  recipeId?: string;
  isCompleted: boolean;
};

export type SupplementItem = {
  id: string;
  name: string; // e.g. "ففول", "سبوس برنج", "ترکیب سیاهدانه و عسل", "ویتامین D"
  time: string; // e.g. "همراه با صبحانه"
  dosage: string;
  isCompleted: boolean;
  notes?: string;
};

export type ReminderSetting = {
  id: string;
  title: string;
  time: string;
  enabled: boolean;
  sound: string;
};

export type CheatLog = {
  id: string;
  date: string;
  foodName: string;
  portion: string;
  time: string;
  reason: 'hunger' | 'craving' | 'stress' | 'party' | 'other';
  reasonPersian: string;
  notes?: string;
};

export type DayPlan = {
  dayNumber: number; // 1 to 21
  datePersian: string; // e.g. "جمعه ۷ اردیبهشت"
  dayOfWeek: string; // 'شنبه' | 'یکشنبه' | ...
  meals: MealItem[];
  snackOptions: SnackOption[];
  selectedSnackId?: string;
  isSnackCompleted: boolean;
  isFreeMealDay: boolean;
  freeMealDetails?: {
    windowMinutes: number;
    remainingMinutes: number;
    isActive: boolean;
    description: string;
  };
  quotas: {
    waterGlasses: number; // target 4
    waterLogged: number; // 0 to 4
    fruitGramsTarget: number; // 500
    fruitGramsLogged: number; // 0 to 500
    dairyCupsTarget: number; // 1
    dairyCupsLogged: number; // 0 or 1
    walkMinutesTarget: number; // 35
    walkMinutesLogged: number; // 0 to 35
    isWalkCompleted: boolean;
  };
  supplements: SupplementItem[];
  reminders: {
    id: string;
    text: string;
    completed: boolean;
  }[];
  weightKg?: number;
  mood?: MoodType;
  moodNote?: string;
  cheats: CheatLog[];
  dietScore: number; // 0 - 100
};

export type UserProfile = {
  name: string;
  fileNumber: string;
  startDate: string;
  durationDays: number;
  startWeight: number;
  currentWeight: number;
  targetWeight: number;
  heightCm: number;
  bmi: number;
  bmiCategory: string;
};

export type Recipe = {
  id: string;
  title: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'salad' | 'soup' | 'diet_dish';
  categoryPersian: string;
  image: string;
  prepTimeMinutes: number;
  calories: number;
  portion: string;
  ingredients: string[];
  instructions: string[];
  allowedMeals: string[];
};

export type ForbiddenCategory = {
  title: string;
  items: string[];
  rules: string[];
};
