import React, { useState } from 'react';
import { useDiet } from '../../context/DietContext';
import { RECIPES } from '../../data/mockDietData';
import { Flame, Clock, CheckCircle2, ChevronLeft, Sparkles, Utensils, Ban, AlertCircle } from 'lucide-react';

export const MealPlanView: React.FC = () => {
  const {
    currentDayNumber,
    setCurrentDayNumber,
    days,
    toggleMealCompletion,
    selectSnack,
    toggleSnackCompletion,
    setSelectedRecipe,
    setRecipeModalOpen,
  } = useDiet();

  const activeDay = days.find((d) => d.dayNumber === currentDayNumber) || days[0];

  // Free meal timer simulation state
  const [freeMealActive, setFreeMealActive] = useState(false);
  const [freeMealSecsLeft] = useState(3600); // 60 mins

  const startFreeMealTimer = () => {
    setFreeMealActive(true);
  };

  const openRecipe = (recipeId?: string) => {
    if (!recipeId) return;
    const found = RECIPES.find((r) => r.id === recipeId);
    if (found) {
      setSelectedRecipe(found);
      setRecipeModalOpen(true);
    }
  };

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* 1. 21-DAY HORIZONTAL CALENDAR / WEEK SELECTOR */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <span>تقویم برنامه ۲۱ روزه</span>
          </h2>
          <span className="text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-0.5 rounded-lg">
            روز {activeDay.dayNumber} - {activeDay.dayOfWeek}
          </span>
        </div>

        {/* Days Horizontal Slider */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 pt-1">
          {days.map((day) => {
            const isSelected = day.dayNumber === currentDayNumber;
            const isToday = day.dayNumber === 7;
            const allMealsCompleted = day.meals.every((m) => m.isCompleted);

            return (
              <button
                key={day.dayNumber}
                onClick={() => setCurrentDayNumber(day.dayNumber)}
                className={`flex flex-col items-center justify-between p-2.5 min-w-[3.5rem] rounded-2xl border transition-all ${
                  isSelected
                    ? 'bg-emerald-500 text-white border-emerald-600 shadow-lg shadow-emerald-500/25 scale-105'
                    : isToday
                    ? 'bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border-amber-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 border-slate-100 dark:border-slate-800 hover:bg-slate-100'
                }`}
              >
                <span className="text-[10px] font-bold opacity-80">{day.dayOfWeek}</span>
                <span className="text-base font-black my-0.5">{day.dayNumber}</span>
                <span className="text-[9px]">
                  {allMealsCompleted ? '✅' : day.isFreeMealDay ? '🎉' : '•'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. FREE MEAL (وعده آزاد) UI OVERLAY IF APPLICABLE */}
      {activeDay.isFreeMealDay && (
        <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white shadow-xl shadow-amber-500/20 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🎉</span>
              <div>
                <h3 className="text-sm font-black">امروز وعده آزاد داری!</h3>
                <p className="text-xs text-amber-100">یک وعده دلخواه در پنجره ۱ ساعته</p>
              </div>
            </div>

            <span className="text-[10px] font-extrabold px-2.5 py-1 rounded-xl bg-white/20 backdrop-blur-md">
              روز {activeDay.dayNumber} ویژه
            </span>
          </div>

          {/* 1-Hour Free Meal Timer Bar */}
          <div className="bg-black/20 p-3 rounded-2xl space-y-2">
            <div className="flex justify-between items-center text-xs font-bold">
              <span>پنجره ۱ ساعته وعده آزاد</span>
              <span>{Math.floor(freeMealSecsLeft / 60)}:۰۰ دقیقه باقی‌مانده</span>
            </div>

            <div className="w-full h-2 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-500"
                style={{ width: freeMealActive ? `${(freeMealSecsLeft / 3600) * 100}%` : '100%' }}
              />
            </div>

            {!freeMealActive ? (
              <button
                onClick={startFreeMealTimer}
                className="w-full py-2 bg-white text-amber-900 font-extrabold text-xs rounded-xl shadow hover:bg-amber-50 transition-colors mt-1"
              >
                شروع تایمر ۱ ساعته وعده آزاد
              </button>
            ) : (
              <div className="text-[11px] text-amber-100 text-center font-medium">
                تایمر فعال است • با خیال راحت از وعده خود لذت ببرید!
              </div>
            )}
          </div>

          {/* Forbidden Items List in Free Meal */}
          <div className="bg-white/10 p-3 rounded-2xl border border-white/20 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-100">
              <Ban className="w-4 h-4 text-white" />
              <span>موارد همچنان ممنوع در وعده آزاد:</span>
            </div>
            <p className="text-[11px] text-white/90 leading-relaxed font-medium">
              شیرینی، شکلات، نوشابه، دسر، سس سفید و آجیل (برای جلوگیری از بازگشت وزن).
            </p>
          </div>
        </div>
      )}

      {/* 3. THREE MAIN MEALS LIST */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-900 dark:text-white px-1 flex items-center gap-1.5">
          <Utensils className="w-4 h-4 text-emerald-500" />
          <span>وعده‌های غذایی روز {activeDay.dayNumber}</span>
        </h3>

        {activeDay.meals.map((meal) => (
          <div
            key={meal.id}
            className={`p-4 rounded-3xl border transition-all ${
              meal.isCompleted
                ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800'
                : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-sm'
            }`}
          >
            <div className="flex gap-3">
              <img
                src={meal.image}
                alt={meal.foodName}
                className="w-20 h-20 rounded-2xl object-cover shrink-0 shadow-sm"
              />

              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                    {meal.persianTitle} ({meal.timeSlot})
                  </span>

                  {meal.calories && (
                    <span className="text-[10px] text-slate-400 font-medium flex items-center gap-0.5">
                      <Flame className="w-3 h-3 text-amber-500" />
                      {meal.calories} kcal
                    </span>
                  )}
                </div>

                <h4 className="text-xs font-extrabold text-slate-900 dark:text-white truncate">
                  {meal.foodName}
                </h4>

                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  سهمیه: {meal.portion}
                </p>

                {/* Ingredients tag preview */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {meal.ingredients.slice(0, 3).map((ing, i) => (
                    <span
                      key={i}
                      className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                    >
                      {ing}
                    </span>
                  ))}
                  {meal.ingredients.length > 3 && (
                    <span className="text-[9px] text-slate-400">+...</span>
                  )}
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              {meal.recipeId ? (
                <button
                  onClick={() => openRecipe(meal.recipeId)}
                  className="text-xs text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
                >
                  <span>مشاهده دستور پخت</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
              ) : (
                <span className="text-[11px] text-slate-400">دستور پخت ساده</span>
              )}

              <button
                onClick={() => toggleMealCompletion(activeDay.dayNumber, meal.id)}
                className={`text-xs px-4 py-1.5 rounded-xl font-bold transition-all ${
                  meal.isCompleted
                    ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    : 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20 hover:bg-emerald-600'
                }`}
              >
                {meal.isCompleted ? 'تکمیل شد ✅' : 'ثبت انجام شده'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* 4. PERMITTED AFTERNOON SNACKS CARDS */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div>
          <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-500" />
            <span>گزینه‌های مجاز عصرانه (فقط یک مورد در روز)</span>
          </h3>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            از بین ۴ گزینه زیر، ۱ مورد را برای ثبت انتخاب کنید:
          </p>
        </div>

        <div className="grid grid-cols-1 gap-2">
          {activeDay.snackOptions.map((snack) => {
            const isSelected = activeDay.selectedSnackId === snack.id;
            return (
              <div
                key={snack.id}
                onClick={() => selectSnack(activeDay.dayNumber, snack.id)}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-amber-500 text-white border-amber-600 shadow-md shadow-amber-500/20'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:bg-amber-50/50'
                }`}
              >
                <div>
                  <h4 className="text-xs font-bold">{snack.name}</h4>
                  <p className="text-[11px] opacity-80 mt-0.5">{snack.portion} • {snack.description}</p>
                </div>

                <div className="shrink-0">
                  {isSelected ? (
                    <span className="p-1.5 rounded-xl bg-white/20 text-white font-extrabold text-[10px] flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      انتخاب شد
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-slate-400 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
                      انتخاب
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {activeDay.selectedSnackId && (
          <div className="pt-2 flex justify-end">
            <button
              onClick={() => toggleSnackCompletion(activeDay.dayNumber)}
              className="text-xs font-bold px-4 py-2 rounded-xl bg-emerald-500 text-white shadow-md shadow-emerald-500/20"
            >
              {activeDay.isSnackCompleted ? 'عصرانه مصرف شد ✅' : 'علامت مصرف عصرانه'}
            </button>
          </div>
        )}
      </div>

      {/* DIET ADVICE CARD */}
      <div className="p-4 rounded-3xl bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
        <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
          <AlertCircle className="w-4 h-4 text-emerald-500" />
          <span>توصیه متخصص تغذیه برای این روز:</span>
        </div>
        <p className="leading-relaxed">
          نوشیدن آب کافی بین وعده‌ها باعث بهبود سوخت‌وساز و هضم سریع‌تر پروتیین‌ها می‌شود. از جابجایی وعده‌های اصلی با یکدیگر بپرهیزید.
        </p>
      </div>
    </div>
  );
};
