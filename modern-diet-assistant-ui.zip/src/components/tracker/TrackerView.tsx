import React, { useState } from 'react';
import { useDiet } from '../../context/DietContext';
import { MoodType } from '../../types/diet';
import {
  Flame,
  Droplets,
  Apple,
  Footprints,
  Pill,
  Scale,
  Smile,
  CheckCircle2,
  Circle,
  Plus,
  Minus,
  AlertTriangle,
  Milk,
  Save
} from 'lucide-react';

export const TrackerView: React.FC = () => {
  const {
    currentDayNumber,
    days,
    userProfile,
    toggleMealCompletion,
    incrementWater,
    decrementWater,
    updateFruitGrams,
    updateWalkMinutes,
    toggleSupplement,
    toggleSnackCompletion,
    updateWeight,
    updateMood,
    setCheatModalOpen,
  } = useDiet();

  const currentDayPlan = days.find((d) => d.dayNumber === currentDayNumber) || days[0];

  // Weight Form
  const [weightInput, setWeightInput] = useState<string>(
    (currentDayPlan.weightKg || userProfile.currentWeight).toString()
  );

  // Mood Form
  const [selectedMood, setSelectedMood] = useState<MoodType>(
    currentDayPlan.mood || 'good'
  );
  const [moodNote, setMoodNote] = useState<string>(currentDayPlan.moodNote || '');

  // Dairy Log local toggle state
  const [dairyCompleted, setDairyCompleted] = useState<boolean>(
    currentDayPlan.quotas.dairyCupsLogged > 0
  );

  const handleWeightSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(weightInput);
    if (!isNaN(val) && val > 30 && val < 200) {
      updateWeight(currentDayNumber, val);
    }
  };

  const handleMoodSubmit = () => {
    updateMood(currentDayNumber, selectedMood, moodNote);
  };

  const moodsList: { id: MoodType; label: string; icon: string; color: string }[] = [
    { id: 'excellent', label: 'عالی', icon: '😄', color: 'border-emerald-500 bg-emerald-50 text-emerald-800' },
    { id: 'good', label: 'خوب', icon: '😊', color: 'border-teal-500 bg-teal-50 text-teal-800' },
    { id: 'normal', label: 'معمولی', icon: '😐', color: 'border-slate-400 bg-slate-50 text-slate-800' },
    { id: 'tired', label: 'خسته', icon: '🥱', color: 'border-amber-500 bg-amber-50 text-amber-800' },
    { id: 'anxious', label: 'مضطرب', icon: '😰', color: 'border-indigo-500 bg-indigo-50 text-indigo-800' },
    { id: 'stressed', label: 'استرس', icon: '😣', color: 'border-rose-500 bg-rose-50 text-rose-800' },
    { id: 'emotional_eating', label: 'پرخوری عصبی', icon: '🍩', color: 'border-purple-500 bg-purple-50 text-purple-800' },
  ];

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* Title */}
      <div className="p-4 rounded-3xl bg-slate-900 text-white shadow-xl flex items-center justify-between">
        <div>
          <h2 className="text-sm font-black flex items-center gap-2">
            <Scale className="w-5 h-5 text-emerald-400" />
            <span>مرکز ثبت پیگیری روزانه (روز {currentDayNumber})</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">تمام فعالیت‌های روزانه خود را سریع ثبت کنید</p>
        </div>

        <button
          onClick={() => setCheatModalOpen(true)}
          className="text-xs font-bold px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 flex items-center gap-1 hover:bg-amber-400 transition-colors"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>تخلف غذایی</span>
        </button>
      </div>

      {/* 1. FOOD LOGGING SECTION */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
          <Flame className="w-4 h-4 text-amber-500" />
          <span>ثبت وعده‌های غذایی</span>
        </h3>

        <div className="grid grid-cols-2 gap-2">
          {currentDayPlan.meals.map((meal) => (
            <button
              key={meal.id}
              onClick={() => toggleMealCompletion(currentDayNumber, meal.id)}
              className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between h-24 ${
                meal.isCompleted
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                  : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  {meal.persianTitle}
                </span>
                {meal.isCompleted ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <Circle className="w-4 h-4 text-slate-300" />
                )}
              </div>

              <div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{meal.foodName}</p>
                <span className="text-[10px] text-slate-400 font-medium">
                  {meal.isCompleted ? 'ثبت شد ✅' : 'برای ثبت کلیک کنید'}
                </span>
              </div>
            </button>
          ))}

          {/* Afternoon Snack */}
          <button
            onClick={() => toggleSnackCompletion(currentDayNumber)}
            className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between h-24 ${
              currentDayPlan.isSnackCompleted
                ? 'bg-amber-500 text-white border-amber-600 shadow-md'
                : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white/20 text-slate-800 dark:text-slate-200">
                عصرانه
              </span>
              {currentDayPlan.isSnackCompleted ? (
                <CheckCircle2 className="w-4 h-4 text-white" />
              ) : (
                <Circle className="w-4 h-4 text-slate-300" />
              )}
            </div>

            <div>
              <p className="text-xs font-bold truncate">
                {currentDayPlan.selectedSnackId ? 'عصرانه انتخابی' : 'انتخاب نشده'}
              </p>
              <span className="text-[10px] opacity-80 font-medium">
                {currentDayPlan.isSnackCompleted ? 'مصرف شد ✅' : 'لمس برای ثبت'}
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* 2. WATER & FRUIT & DAIRY TRACKING */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Water */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold flex items-center gap-1 text-sky-600 dark:text-sky-400">
              <Droplets className="w-4 h-4" />
              آب (هدف ۴)
            </span>
            <span className="text-xs font-black">{currentDayPlan.quotas.waterLogged} لیوان</span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={() => decrementWater(currentDayNumber)}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              {currentDayPlan.quotas.waterLogged} از ۴
            </span>
            <button
              onClick={() => incrementWater(currentDayNumber)}
              className="p-2 rounded-xl bg-sky-500 text-white shadow hover:bg-sky-600"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Fruit */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold flex items-center gap-1 text-rose-600 dark:text-rose-400">
              <Apple className="w-4 h-4" />
              میوه (۵۰۰ گرم)
            </span>
            <span className="text-xs font-black">{currentDayPlan.quotas.fruitGramsLogged} گرم</span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={() => updateFruitGrams(currentDayNumber, Math.max(0, currentDayPlan.quotas.fruitGramsLogged - 100))}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              {currentDayPlan.quotas.fruitGramsLogged}g
            </span>
            <button
              onClick={() => updateFruitGrams(currentDayNumber, Math.min(500, currentDayPlan.quotas.fruitGramsLogged + 100))}
              className="p-2 rounded-xl bg-rose-500 text-white shadow hover:bg-rose-600"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dairy */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold flex items-center gap-1 text-blue-600 dark:text-blue-400">
              <Milk className="w-4 h-4" />
              لبنیات کم‌چرب
            </span>
            <span className="text-xs font-black">۱ لیوان</span>
          </div>

          <button
            onClick={() => setDairyCompleted(!dairyCompleted)}
            className={`w-full py-2 rounded-xl text-xs font-bold transition-all ${
              dairyCompleted
                ? 'bg-blue-500 text-white shadow'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
            }`}
          >
            {dairyCompleted ? 'شیر/ماست مصرف شد ✅' : 'ثبت مصرف لبنیات'}
          </button>
        </div>
      </div>

      {/* 3. WALKING LOGGING */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold flex items-center gap-1.5 text-slate-900 dark:text-white">
            <Footprints className="w-4 h-4 text-emerald-500" />
            <span>ثبت پیاده‌روی روزانه (هدف ۳۵ دقیقه)</span>
          </span>
          <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
            {currentDayPlan.quotas.walkMinutesLogged} دقیقه
          </span>
        </div>

        <div className="flex items-center gap-2">
          {[15, 25, 35, 45].map((mins) => (
            <button
              key={mins}
              onClick={() => updateWalkMinutes(currentDayNumber, mins, mins >= 35)}
              className={`flex-1 py-2 text-xs rounded-xl font-bold border transition-all ${
                currentDayPlan.quotas.walkMinutesLogged === mins
                  ? 'bg-emerald-500 text-white border-emerald-600 shadow'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
              }`}
            >
              {mins} دقیقه
            </button>
          ))}
        </div>
      </div>

      {/* 4. SUPPLEMENTS TRACKER */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
          <Pill className="w-4 h-4 text-purple-500" />
          <span>مکمل‌ها و توصیه‌های روزانه</span>
        </h3>

        <div className="space-y-2">
          {currentDayPlan.supplements.map((supp) => (
            <div
              key={supp.id}
              onClick={() => toggleSupplement(currentDayNumber, supp.id)}
              className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                supp.isCompleted
                  ? 'bg-purple-50/60 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800'
                  : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-800'
              }`}
            >
              <div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">{supp.name}</h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{supp.time} • دوز: {supp.dosage}</p>
              </div>

              <div
                className={`w-6 h-6 rounded-xl flex items-center justify-center ${
                  supp.isCompleted ? 'bg-purple-500 text-white' : 'border border-slate-300 dark:border-slate-600'
                }`}
              >
                {supp.isCompleted && <CheckCircle2 className="w-4 h-4" />}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. DAILY WEIGHT LOGGER WITH INSTANT WEIGHT HISTORY */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
          <Scale className="w-4 h-4 text-emerald-500" />
          <span>ثبت وزن امروز</span>
        </h3>

        <form onSubmit={handleWeightSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="number"
              step="0.1"
              value={weightInput}
              onChange={(e) => setWeightInput(e.target.value)}
              className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-800 dark:text-slate-200 pl-12"
              placeholder="مثلاً ۶۸.۵"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
              کیلو
            </span>
          </div>

          <button
            type="submit"
            className="px-4 py-2.5 bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-500/20 hover:bg-emerald-600 transition-colors flex items-center gap-1"
          >
            <Save className="w-3.5 h-3.5" />
            <span>ثبت وزن</span>
          </button>
        </form>

        {/* Small Weight sparkline trend */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-slate-400 block">تغییر نسبت به شروع:</span>
            <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
              {(userProfile.startWeight - userProfile.currentWeight).toFixed(1)} کیلوگرم کاهش ✨
            </span>
          </div>
          <div className="text-left font-mono font-bold text-slate-700 dark:text-slate-300">
            {userProfile.startWeight} ➔ {userProfile.currentWeight} kg
          </div>
        </div>
      </div>

      {/* 6. TODAY'S MOOD TRACKER (حال امروز من) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
          <Smile className="w-4 h-4 text-amber-500" />
          <span>حال امروز من (Mood)</span>
        </h3>

        <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
          {moodsList.map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedMood(m.id)}
              className={`p-2 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                selectedMood === m.id
                  ? 'border-2 font-bold shadow-md scale-105 ' + m.color
                  : 'border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
              }`}
            >
              <span className="text-lg">{m.icon}</span>
              <span className="text-[10px]">{m.label}</span>
            </button>
          ))}
        </div>

        <div>
          <textarea
            rows={2}
            value={moodNote}
            onChange={(e) => setMoodNote(e.target.value)}
            placeholder="یادداشت روزانه (مثلاً: احساس سبکی بیشتر داشتم)..."
            className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 resize-none mt-2"
          />
        </div>

        <button
          onClick={handleMoodSubmit}
          className="w-full py-2.5 bg-slate-900 dark:bg-slate-800 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors"
        >
          ثبت حالت روحی و یادداشت
        </button>
      </div>
    </div>
  );
};
