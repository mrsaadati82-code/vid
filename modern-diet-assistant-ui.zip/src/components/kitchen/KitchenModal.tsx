import React, { useState } from 'react';
import { useDiet } from '../../context/DietContext';
import { RECIPES } from '../../data/mockDietData';
import { Recipe } from '../../types/diet';
import { X, Search, Clock, Flame, Utensils, ChevronLeft } from 'lucide-react';

export const KitchenModal: React.FC = () => {
  const { recipeModalOpen, setRecipeModalOpen, selectedRecipe, setSelectedRecipe } = useDiet();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [detailRecipe, setDetailRecipe] = useState<Recipe | null>(selectedRecipe);

  if (!recipeModalOpen) return null;

  const categories = [
    { id: 'all', label: 'همه دستورها' },
    { id: 'breakfast', label: 'صبحانه' },
    { id: 'lunch', label: 'ناهار' },
    { id: 'dinner', label: 'شام' },
    { id: 'soup', label: 'سوپ' },
    { id: 'diet_dish', label: 'رژیمی' },
  ];

  const filteredRecipes = RECIPES.filter((r) => {
    const matchesCat = activeCategory === 'all' || r.category === activeCategory;
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.ingredients.some((i) => i.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 transition-opacity">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 animate-slide-up">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/50">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Utensils className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">آشپزخانه رژیمی سینرژی</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">دستور پخت‌های سالم، لذیذ و آسان</p>
            </div>
          </div>
          <button
            onClick={() => {
              setRecipeModalOpen(false);
              setSelectedRecipe(null);
              setDetailRecipe(null);
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {detailRecipe ? (
          /* Recipe Detail Screen */
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <button
              onClick={() => setDetailRecipe(null)}
              className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1.5 rounded-xl border border-emerald-200 dark:border-emerald-800"
            >
              <ChevronLeft className="w-4 h-4 rotate-180" />
              <span>بازگشت به لیست دستورها</span>
            </button>

            <div className="relative rounded-2xl overflow-hidden h-48 bg-slate-100 dark:bg-slate-800">
              <img
                src={detailRecipe.image}
                alt={detailRecipe.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-3 right-3 left-3 text-white">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500 text-white mb-1 inline-block">
                  {detailRecipe.categoryPersian}
                </span>
                <h3 className="text-base font-bold leading-tight">{detailRecipe.title}</h3>
              </div>
            </div>

            {/* Badges */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                <Clock className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
                <span className="text-slate-500 text-[10px] block">زمان آماده‌سازی</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{detailRecipe.prepTimeMinutes} دقیقه</span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                <Flame className="w-4 h-4 text-amber-500 mx-auto mb-1" />
                <span className="text-slate-500 text-[10px] block">کالری تقریبی</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{detailRecipe.calories} kcal</span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                <Utensils className="w-4 h-4 text-sky-500 mx-auto mb-1" />
                <span className="text-slate-500 text-[10px] block">حجم سهمیه</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 text-[10px]">{detailRecipe.portion}</span>
              </div>
            </div>

            {/* Ingredients */}
            <div className="bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white mb-2">مواد اولیه:</h4>
              <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                {detailRecipe.ingredients.map((ing, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                    <span>{ing}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Preparation Steps */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">مراحل آماده‌سازی:</h4>
              <div className="space-y-2">
                {detailRecipe.instructions.map((step, idx) => (
                  <div key={idx} className="flex gap-2.5 p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-800">
                    <span className="w-5 h-5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Recipes List Screen */
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="جستجوی غذا یا ماده اولیه..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-9 pl-3 py-2 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border-none focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
              />
            </div>

            {/* Categories scroll */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`text-xs px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
                    activeCategory === cat.id
                      ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Recipe Cards List */}
            <div className="space-y-2.5 pt-1">
              {filteredRecipes.map((recipe) => (
                <div
                  key={recipe.id}
                  onClick={() => setDetailRecipe(recipe)}
                  className="flex items-center gap-3 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-emerald-50/50 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800/80 cursor-pointer transition-all hover:border-emerald-300 dark:hover:border-emerald-700"
                >
                  <img
                    src={recipe.image}
                    alt={recipe.title}
                    className="w-16 h-16 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                        {recipe.categoryPersian}
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                        <Clock className="w-3 h-3" />
                        {recipe.prepTimeMinutes} دقیقه
                      </span>
                    </div>
                    <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">{recipe.title}</h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">{recipe.portion}</p>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-400" />
                </div>
              ))}

              {filteredRecipes.length === 0 && (
                <div className="text-center py-8 text-slate-400 text-xs">
                  هیچ دستور پختی یافت نشد.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
