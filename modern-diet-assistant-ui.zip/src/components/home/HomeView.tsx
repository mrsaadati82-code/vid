import React, { useState, useEffect } from 'react';
import { useDiet } from '../../context/DietContext';
import { RECIPES } from '../../data/mockDietData';
import { MealItem } from '../../types/diet';
import {
  Flame,
  Droplets,
  Apple,
  Footprints,
  Pill,
  CheckCircle2,
  Circle,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ChevronLeft,
  X,
  Plus,
  Minus
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const {
    currentDayNumber,
    days,
    userProfile,
    toggleMealCompletion,
    incrementWater,
    decrementWater,
    updateFruitGrams,
    updateWalkMinutes,
    toggleReminder,
    selectSnack,
    toggleSnackCompletion,
    setSelectedRecipe,
    setRecipeModalOpen,
    setCheatModalOpen,
  } = useDiet();

  const currentDayPlan = days.find((d) => d.dayNumber === currentDayNumber) || days[0];

  // Meal Detail Modal state
  const [activeMealDetail, setActiveMealDetail] = useState<MealItem | null>(null);

  // Snack Modal state
  const [snackModalOpen, setSnackModalOpen] = useState(false);

  // Walking Live Timer State
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [walkTimerSeconds, setWalkTimerSeconds] = useState(
    (currentDayPlan.quotas.walkMinutesLogged || 0) * 60
  );

  const targetWalkSeconds = currentDayPlan.quotas.walkMinutesTarget * 60;

  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setWalkTimerSeconds((prev) => {
          const nextSec = prev + 1;
          const currentMins = Math.floor(nextSec / 60);
          updateWalkMinutes(currentDayNumber, currentMins);
          if (nextSec >= targetWalkSeconds) {
            setIsTimerRunning(false);
            updateWalkMinutes(currentDayNumber, currentDayPlan.quotas.walkMinutesTarget, true);
          }
          return nextSec;
        });
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, currentDayNumber]);

  // Sync timer seconds if day plan updates
  useEffect(() => {
    setWalkTimerSeconds((currentDayPlan.quotas.walkMinutesLogged || 0) * 60);
  }, [currentDayPlan.quotas.walkMinutesLogged]);

  // Calculations
  const totalDays = 21;
  const daysLeft = totalDays - currentDayNumber;
  const weightLost = (userProfile.startWeight - userProfile.currentWeight).toFixed(1);
  const progressPercent = Math.min(
    100,
    Math.round((currentDayNumber / totalDays) * 100)
  );

  const completedMealsCount = currentDayPlan.meals.filter((m) => m.isCompleted).length;
  const completedSuppsCount = currentDayPlan.supplements.filter((s) => s.isCompleted).length;

  const currentSnack = currentDayPlan.snackOptions.find(
    (s) => s.id === currentDayPlan.selectedSnackId
  );

  const openRecipeForMeal = (recipeId?: string) => {
    if (!recipeId) return;
    const found = RECIPES.find((r) => r.id === recipeId);
    if (found) {
      setSelectedRecipe(found);
      setRecipeModalOpen(true);
      setActiveMealDetail(null);
    }
  };

  const formatTimerTime = (totalSec: number) => {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m.toString().padStart(2, '۰')}:${s.toString().padStart(2, '۰')}`;
  };

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* 1. PROGRESS RING / OVERALL DIET CARD */}
      <div className="relative overflow-hidden p-5 rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-800 text-white shadow-xl shadow-emerald-600/20">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-teal-300/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between gap-4">
          <div className="space-y-1.5 flex-1">
            <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-emerald-100 inline-block">
              پیشرفت کلی رژیم ۲۱ روزه
            </span>

            <div className="flex items-baseline gap-2 pt-1">
              <span className="text-2xl font-black">روز {currentDayNumber}</span>
              <span className="text-xs text-emerald-100 font-medium">از {totalDays} روز ({daysLeft} روز باقی‌مانده)</span>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3 text-center border-t border-white/15">
              <div>
                <span className="text-[10px] text-emerald-100/80 block">وزن فعلی</span>
                <span className="text-sm font-bold">{userProfile.currentWeight} کیلو</span>
              </div>
              <div>
                <span className="text-[10px] text-emerald-100/80 block">کاهش تا کنون</span>
                <span className="text-sm font-extrabold text-amber-300">-{weightLost} کیلو</span>
              </div>
              <div>
                <span className="text-[10px] text-emerald-100/80 block">وزن هدف</span>
                <span className="text-sm font-bold">{userProfile.targetWeight} کیلو</span>
              </div>
            </div>
          </div>

          {/* Progress Circular Dial */}
          <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-white/20"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-amber-300 transition-all duration-1000 ease-out"
                strokeDasharray={`${progressPercent}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute text-center">
              <span className="text-base font-black leading-none block">{progressPercent}٪</span>
              <span className="text-[9px] text-emerald-100 font-medium mt-0.5 block">تکمیل</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. TODAY'S PROGRESS INDICATOR CARD */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <span>پیشرفت امروز ({currentDayPlan.dayOfWeek})</span>
          </h2>
          <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-0.5 rounded-lg">
            امتیاز: {currentDayPlan.dietScore} از ۱۰۰
          </span>
        </div>

        <div className="space-y-2.5 text-xs">
          {/* Meals */}
          <div>
            <div className="flex justify-between text-slate-700 dark:text-slate-300 font-medium mb-1">
              <span className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                وعده‌های غذایی
              </span>
              <span className="font-bold">{completedMealsCount} از ۳</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${(completedMealsCount / 3) * 100}%` }}
              />
            </div>
          </div>

          {/* Water */}
          <div>
            <div className="flex justify-between text-slate-700 dark:text-slate-300 font-medium mb-1">
              <span className="flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-sky-500" />
                آب مصرفی
              </span>
              <span className="font-bold">{currentDayPlan.quotas.waterLogged} از ۴ لیوان</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-sky-500 rounded-full transition-all duration-500"
                style={{ width: `${(currentDayPlan.quotas.waterLogged / 4) * 100}%` }}
              />
            </div>
          </div>

          {/* Fruit */}
          <div>
            <div className="flex justify-between text-slate-700 dark:text-slate-300 font-medium mb-1">
              <span className="flex items-center gap-1.5">
                <Apple className="w-3.5 h-3.5 text-rose-500" />
                سهمیه میوه
              </span>
              <span className="font-bold">{currentDayPlan.quotas.fruitGramsLogged} از ۵۰۰ گرم</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-rose-500 rounded-full transition-all duration-500"
                style={{ width: `${(currentDayPlan.quotas.fruitGramsLogged / 500) * 100}%` }}
              />
            </div>
          </div>

          {/* Walking */}
          <div>
            <div className="flex justify-between text-slate-700 dark:text-slate-300 font-medium mb-1">
              <span className="flex items-center gap-1.5">
                <Footprints className="w-3.5 h-3.5 text-emerald-500" />
                پیاده‌روی
              </span>
              <span className="font-bold">{currentDayPlan.quotas.walkMinutesLogged} از ۳۵ دقیقه</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${(currentDayPlan.quotas.walkMinutesLogged / 35) * 100}%` }}
              />
            </div>
          </div>

          {/* Supplements */}
          <div>
            <div className="flex justify-between text-slate-700 dark:text-slate-300 font-medium mb-1">
              <span className="flex items-center gap-1.5">
                <Pill className="w-3.5 h-3.5 text-purple-500" />
                مکمل‌ها
              </span>
              <span className="font-bold">{completedSuppsCount} از {currentDayPlan.supplements.length}</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-purple-500 rounded-full transition-all duration-500"
                style={{
                  width: `${(completedSuppsCount / (currentDayPlan.supplements.length || 1)) * 100}%`,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 3. TODAY'S MEAL PLAN (صبحانه، ناهار، شام) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>برنامه غذایی امروز</span>
          </h2>
          <button
            onClick={() => setCheatModalOpen(true)}
            className="text-[11px] text-amber-600 dark:text-amber-400 font-bold bg-amber-50 dark:bg-amber-950/80 hover:bg-amber-100 px-2.5 py-1 rounded-xl border border-amber-200 dark:border-amber-800 transition-colors"
          >
            + ثبت تخلف غذایی
          </button>
        </div>

        <div className="space-y-2.5">
          {currentDayPlan.meals.map((meal) => (
            <div
              key={meal.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                meal.isCompleted
                  ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                  : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <img
                  src={meal.image}
                  alt={meal.foodName}
                  className="w-16 h-16 rounded-xl object-cover shrink-0 cursor-pointer shadow-sm"
                  onClick={() => setActiveMealDetail(meal)}
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {meal.persianTitle} ({meal.timeSlot})
                    </span>
                    {meal.isCompleted ? (
                      <span className="text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/60 px-2 py-0.5 rounded-md">
                        تکمیل شد ✅
                      </span>
                    ) : (
                      <span className="text-[10px] text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-md font-medium">
                        پیش‌رو
                      </span>
                    )}
                  </div>

                  <h3
                    onClick={() => setActiveMealDetail(meal)}
                    className="text-xs font-bold text-slate-900 dark:text-white truncate cursor-pointer hover:text-emerald-600 dark:hover:text-emerald-400"
                  >
                    {meal.foodName}
                  </h3>

                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    {meal.portion} {meal.calories ? `• ${meal.calories} کتن` : ''}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setActiveMealDetail(meal)}
                  className="text-xs text-slate-600 dark:text-slate-300 hover:text-emerald-600 font-medium flex items-center gap-1"
                >
                  <span>جزئیات و مواد اولیه</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => toggleMealCompletion(currentDayNumber, meal.id)}
                  className={`text-xs px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                    meal.isCompleted
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300'
                      : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-500/20 active:scale-95'
                  }`}
                >
                  {meal.isCompleted ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span>انجام شد</span>
                    </>
                  ) : (
                    <>
                      <Circle className="w-3.5 h-3.5" />
                      <span>دکمه انجام شد</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. AFTERNOON SNACK SECTION (عصرانه امروز) */}
      <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-800/60 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
              <Apple className="w-4 h-4 text-amber-500" />
              <span>عصرانه مجاز امروز</span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              یک گزینه مجاز انتخاب فرمایید
            </p>
          </div>

          <button
            onClick={() => setSnackModalOpen(true)}
            className="text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-200/60 dark:bg-amber-900/60 hover:bg-amber-200 px-3 py-1.5 rounded-xl border border-amber-300 dark:border-amber-700 transition-colors"
          >
            {currentSnack ? 'تغییر عصرانه' : 'انتخاب عصرانه'}
          </button>
        </div>

        {currentSnack ? (
          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 flex items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950 px-2 py-0.5 rounded mb-1 inline-block">
                گزینه انتخاب‌شده امروز
              </span>
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">{currentSnack.name}</h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{currentSnack.portion} • {currentSnack.description}</p>
            </div>

            <button
              onClick={() => toggleSnackCompletion(currentDayNumber)}
              className={`p-2 rounded-xl text-xs font-bold shrink-0 transition-all ${
                currentDayPlan.isSnackCompleted
                  ? 'bg-emerald-500 text-white shadow-md'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {currentDayPlan.isSnackCompleted ? 'مصرف شد ✅' : 'ثبت مصرف'}
            </button>
          </div>
        ) : (
          <div
            onClick={() => setSnackModalOpen(true)}
            className="p-3 rounded-xl border-2 border-dashed border-amber-300 dark:border-amber-800/80 text-center cursor-pointer hover:bg-amber-100/30 transition-colors"
          >
            <p className="text-xs text-amber-800 dark:text-amber-300 font-bold">برای مشاهده و انتخاب عصرانه کلیک کنید 🥗</p>
          </div>
        )}
      </div>

      {/* 5. WALKING TIMER CARD (کارت پیاده‌روی ۳۵ دقیقه) */}
      <div className="p-5 rounded-3xl bg-slate-900 text-white shadow-xl space-y-4 relative overflow-hidden border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400">
              <Footprints className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-sm font-black">۳۵ دقیقه پیاده‌روی امروز</h3>
              <p className="text-xs text-slate-400">هدف روزانه سلامت قلب و چربی‌سوزی</p>
            </div>
          </div>

          <span
            className={`text-xs font-bold px-2.5 py-1 rounded-xl ${
              currentDayPlan.quotas.isWalkCompleted
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : isTimerRunning
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            {currentDayPlan.quotas.isWalkCompleted
              ? 'تکمیل شد 🎉'
              : isTimerRunning
              ? 'در حال انجام 🏃‍♀️'
              : 'آماده شروع'}
          </span>
        </div>

        {/* Big Circular Timer Dial */}
        <div className="flex flex-col items-center justify-center py-2 space-y-3">
          <div className="relative w-36 h-36 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-800"
                strokeWidth="3"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-emerald-400 transition-all duration-300"
                strokeDasharray={`${Math.min(100, (walkTimerSeconds / targetWalkSeconds) * 100)}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>

            <div className="absolute text-center space-y-0.5">
              <span className="text-2xl font-black font-mono tracking-wider block">
                {formatTimerTime(walkTimerSeconds)}
              </span>
              <span className="text-[10px] text-slate-400 font-medium block">
                از ۳۵:۰۰ دقیقه
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className={`px-5 py-2.5 rounded-2xl font-extrabold text-xs flex items-center gap-2 shadow-lg transition-all ${
                isTimerRunning
                  ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
              }`}
            >
              {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              <span>{isTimerRunning ? 'توقف موقت' : 'شروع پیاده‌روی'}</span>
            </button>

            <button
              onClick={() => {
                setIsTimerRunning(false);
                setWalkTimerSeconds(0);
                updateWalkMinutes(currentDayNumber, 0, false);
              }}
              title="بازنشانی زمان"
              className="p-2.5 rounded-2xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                setIsTimerRunning(false);
                setWalkTimerSeconds(targetWalkSeconds);
                updateWalkMinutes(currentDayNumber, 35, true);
              }}
              className="text-xs px-3 py-2.5 rounded-2xl bg-emerald-950 text-emerald-300 font-bold border border-emerald-800 hover:bg-emerald-900 transition-colors"
            >
              ثبت کامل ۳۵ دقیقه
            </button>
          </div>
        </div>
      </div>

      {/* 6. WATER & FRUIT TRACKER CARDS (کارت مصرف آب و میوه) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Water Card */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
                <Droplets className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">مصرف آب امروز</h3>
                <p className="text-[10px] text-slate-500">هدف: ۴ لیوان در روز</p>
              </div>
            </div>
            <span className="text-xs font-black text-sky-600 dark:text-sky-400">
              {currentDayPlan.quotas.waterLogged} / ۴
            </span>
          </div>

          {/* 4 Glass Icons */}
          <div className="grid grid-cols-4 gap-2 pt-1">
            {[1, 2, 3, 4].map((glassNum) => {
              const isDrank = glassNum <= currentDayPlan.quotas.waterLogged;
              return (
                <button
                  key={glassNum}
                  onClick={() => {
                    if (isDrank) {
                      decrementWater(currentDayNumber);
                    } else {
                      incrementWater(currentDayNumber);
                    }
                  }}
                  className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1 transition-all border ${
                    isDrank
                      ? 'bg-sky-500 text-white border-sky-400 shadow-md shadow-sky-500/20 scale-105'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-sky-50'
                  }`}
                >
                  <Droplets className={`w-5 h-5 ${isDrank ? 'animate-bounce' : ''}`} />
                  <span className="text-[10px] font-bold">لیوان {glassNum}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Fruit Card */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400">
                <Apple className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">میوه امروز</h3>
                <p className="text-[10px] text-slate-500">هدف: ۵۰۰ گرم در روز</p>
              </div>
            </div>
            <span className="text-xs font-black text-rose-600 dark:text-rose-400">
              {currentDayPlan.quotas.fruitGramsLogged} / ۵۰۰ گرم
            </span>
          </div>

          <div className="space-y-2 pt-1">
            <input
              type="range"
              min="0"
              max="500"
              step="50"
              value={currentDayPlan.quotas.fruitGramsLogged}
              onChange={(e) => updateFruitGrams(currentDayNumber, parseInt(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />

            <div className="flex items-center justify-between gap-1">
              <button
                onClick={() =>
                  updateFruitGrams(
                    currentDayNumber,
                    Math.max(0, currentDayPlan.quotas.fruitGramsLogged - 100)
                  )
                }
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1"
              >
                <Minus className="w-3.5 h-3.5" /> ۱۰۰-
              </button>

              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                {currentDayPlan.quotas.fruitGramsLogged} گرم
              </span>

              <button
                onClick={() =>
                  updateFruitGrams(
                    currentDayNumber,
                    Math.min(500, currentDayPlan.quotas.fruitGramsLogged + 100)
                  )
                }
                className="p-1.5 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> ۱۰۰+
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 7. REMINDERS CHECKLIST CARD (یادآوری‌های امروز) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <h2 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>یادآوری‌های امروز</span>
        </h2>

        <div className="space-y-2">
          {currentDayPlan.reminders.map((rem) => (
            <div
              key={rem.id}
              onClick={() => toggleReminder(currentDayNumber, rem.id)}
              className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                rem.completed
                  ? 'bg-emerald-50/60 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-slate-500 dark:text-slate-400 line-through'
                  : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200'
              }`}
            >
              <span className="text-xs font-medium">{rem.text}</span>
              <div
                className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 ${
                  rem.completed
                    ? 'bg-emerald-500 border-emerald-500 text-white'
                    : 'border-slate-300 dark:border-slate-600'
                }`}
              >
                {rem.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MEAL DETAIL MODAL */}
      {activeMealDetail && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl space-y-4 border border-slate-200 dark:border-slate-800 animate-slide-up">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                {activeMealDetail.persianTitle} ({activeMealDetail.timeSlot})
              </span>
              <button
                onClick={() => setActiveMealDetail(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <img
              src={activeMealDetail.image}
              alt={activeMealDetail.foodName}
              className="w-full h-40 object-cover rounded-2xl"
            />

            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                {activeMealDetail.foodName}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">مقدار سهمیه: {activeMealDetail.portion}</p>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl space-y-1.5">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">ترکیبات و مواد اولیه:</h4>
              <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                {activeMealDetail.ingredients.map((ing, i) => (
                  <li key={i} className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span>{ing}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex gap-2 pt-1">
              {activeMealDetail.recipeId && (
                <button
                  onClick={() => openRecipeForMeal(activeMealDetail.recipeId)}
                  className="flex-1 py-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-xl border border-emerald-200 dark:border-emerald-800"
                >
                  مشاهده دستور پخت 👨‍🍳
                </button>
              )}

              <button
                onClick={() => {
                  toggleMealCompletion(currentDayNumber, activeMealDetail.id);
                  setActiveMealDetail(null);
                }}
                className="flex-1 py-2.5 bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-500/20"
              >
                {activeMealDetail.isCompleted ? 'علامت به عنوان انجام نشده' : 'ثبت انجام این وعده ✅'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SNACK SELECTOR MODAL */}
      {snackModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl space-y-3 border border-slate-200 dark:border-slate-800 animate-slide-up">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">انتخاب عصرانه مجاز امروز</h3>
              <button onClick={() => setSnackModalOpen(false)} className="p-1 text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 max-h-80 overflow-y-auto pt-1">
              {currentDayPlan.snackOptions.map((option) => (
                <div
                  key={option.id}
                  onClick={() => {
                    selectSnack(currentDayNumber, option.id);
                    setSnackModalOpen(false);
                  }}
                  className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                    currentDayPlan.selectedSnackId === option.id
                      ? 'bg-amber-500 text-white border-amber-600 shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:bg-amber-50'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <h4 className="text-xs font-bold">{option.name}</h4>
                    {option.calories && (
                      <span className="text-[10px] opacity-80">{option.calories} kcal</span>
                    )}
                  </div>
                  <p className="text-[11px] opacity-90 mt-1">{option.portion} • {option.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
