import React, { useState } from 'react';
import { useDiet } from '../../context/DietContext';
import { FORBIDDEN_CATEGORIES } from '../../data/mockDietData';
import { X, Search, ShieldAlert, AlertTriangle, CheckCircle, Ban } from 'lucide-react';

export const RulesModal: React.FC = () => {
  const { rulesModalOpen, setRulesModalOpen } = useDiet();
  const [searchQuery, setSearchQuery] = useState('');

  if (!rulesModalOpen) return null;

  const filteredCategories = FORBIDDEN_CATEGORIES.filter((cat) => {
    const matchesTitle = cat.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesItems = cat.items.some((i) => i.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesRules = cat.rules.some((r) => r.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesTitle || matchesItems || matchesRules;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 transition-opacity">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 animate-slide-up">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-red-50/50 dark:bg-red-950/20">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 rounded-xl">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">قوانین و ممنوعیت‌های رژیم ۲۱ روزه</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">راهنمای شفاف کلیدی برای موفقیت ۱۰۰٪</p>
            </div>
          </div>
          <button
            onClick={() => setRulesModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="جستجو در قوانین و موارد ممنوعه (مثلا: شکلات، چای، سس...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-2 bg-white dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {filteredCategories.map((cat, index) => (
            <div
              key={index}
              className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2.5"
            >
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400">
                  <Ban className="w-4 h-4" />
                </span>
                <h3 className="text-xs font-extrabold text-slate-900 dark:text-white">{cat.title}</h3>
              </div>

              {/* Items chips */}
              <div className="flex flex-wrap gap-1.5">
                {cat.items.map((item, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/50 font-medium flex items-center gap-1"
                  >
                    <AlertTriangle className="w-3 h-3 text-rose-500" />
                    {item}
                  </span>
                ))}
              </div>

              {/* Specific Rules */}
              <div className="space-y-1 pt-1">
                {cat.rules.map((rule, rIdx) => (
                  <div key={rIdx} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{rule}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {filteredCategories.length === 0 && (
            <div className="text-center py-10 text-slate-400 text-xs">
              موردی مطابق با جستجوی شما یافت نشد.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
