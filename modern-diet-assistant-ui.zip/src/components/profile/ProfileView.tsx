import React, { useState } from 'react';
import { useDiet } from '../../context/DietContext';
import {
  Bell,
  Utensils,
  BookOpen,
  Volume2,
  Clock,
  RotateCcw
} from 'lucide-react';

export const ProfileView: React.FC = () => {
  const {
    userProfile,
    reminders,
    toggleReminderSetting,
    setRecipeModalOpen,
    setRulesModalOpen,
    resetDataToDefault,
  } = useDiet();

  const [confirmReset, setConfirmReset] = useState(false);

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* 1. USER PROFILE CARD */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white flex items-center justify-center font-black text-2xl shadow-lg shadow-emerald-500/20 shrink-0">
            {userProfile.name.charAt(0)}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                {userProfile.name}
              </h2>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                {userProfile.fileNumber}
              </span>
            </div>

            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-bold mt-0.5">
              رژیم ۲۱ روزه اختصاصی • شروع: {userProfile.startDate}
            </p>
          </div>
        </div>

        {/* 6 Key Stats Grid */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">وزن شروع</span>
            <span className="font-extrabold text-slate-800 dark:text-slate-200">{userProfile.startWeight}kg</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">وزن فعلی</span>
            <span className="font-extrabold text-emerald-600 dark:text-emerald-400">{userProfile.currentWeight}kg</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">وزن هدف</span>
            <span className="font-extrabold text-slate-800 dark:text-slate-200">{userProfile.targetWeight}kg</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">قد</span>
            <span className="font-extrabold text-slate-800 dark:text-slate-200">{userProfile.heightCm}cm</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">شاخص BMI</span>
            <span className="font-extrabold text-teal-600 dark:text-teal-400">{userProfile.bmi}</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">مدت رژیم</span>
            <span className="font-extrabold text-slate-800 dark:text-slate-200">{userProfile.durationDays} روز</span>
          </div>
        </div>

        {/* BMI Category bar */}
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs">
          <span className="text-slate-600 dark:text-slate-300 font-medium">وضعیت شاخص توده بدنی:</span>
          <span className="font-bold text-emerald-700 dark:text-emerald-300">{userProfile.bmiCategory}</span>
        </div>
      </div>

      {/* 2. QUICK MENU ACCESS */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setRecipeModalOpen(true)}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center gap-2 text-right hover:border-emerald-400 transition-all"
        >
          <span className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
            <Utensils className="w-5 h-5" />
          </span>
          <div>
            <h3 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">آشپزخانه رژیمی</h3>
            <span className="text-[10px] text-slate-400">دستور پخت‌های مجاز</span>
          </div>
        </button>

        <button
          onClick={() => setRulesModalOpen(true)}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center gap-2 text-right hover:border-rose-400 transition-all"
        >
          <span className="p-2 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400">
            <BookOpen className="w-5 h-5" />
          </span>
          <div>
            <h3 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">قوانین و ممنوعیت‌ها</h3>
            <span className="text-[10px] text-slate-400">راهنمای کامل رژیم</span>
          </div>
        </button>
      </div>

      {/* 3. NOTIFICATION REMINDER SETTINGS */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-emerald-500" />
            <span>تنظیمات یادآوری و اعلانات</span>
          </h3>
          <span className="text-[10px] text-slate-400">ساعت و صدای اعلانات</span>
        </div>

        <div className="space-y-2">
          {reminders.map((rem) => (
            <div
              key={rem.id}
              className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2"
            >
              <div className="space-y-0.5">
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">{rem.title}</h4>
                <div className="flex items-center gap-3 text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {rem.time}
                  </span>
                  <span className="flex items-center gap-1">
                    <Volume2 className="w-3 h-3" />
                    {rem.sound}
                  </span>
                </div>
              </div>

              {/* Toggle Switch */}
              <button
                onClick={() => toggleReminderSetting(rem.id)}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  rem.enabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    rem.enabled ? 'right-1' : 'right-6'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 4. RESET DATA OPTION */}
      <div className="p-4 rounded-3xl bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2">
        <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
          <RotateCcw className="w-4 h-4 text-rose-500" />
          <span>مدیریت اطلاعات و بازنشانی</span>
        </h3>
        <p className="text-[11px] text-slate-500 leading-relaxed">
          در صورت تمایل می‌توانید تمام ثبت‌های روزانه را به وضعیت پیش‌فرض اولیه بازنشانی فرمایید.
        </p>

        {confirmReset ? (
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => {
                resetDataToDefault();
                setConfirmReset(false);
              }}
              className="flex-1 py-2 bg-rose-500 text-white font-bold text-xs rounded-xl shadow"
            >
              بله، بازنشانی کن
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="flex-1 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl"
            >
              انصراف
            </button>
          </div>
        ) : (
          <button
            onClick={() => setConfirmReset(true)}
            className="text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline pt-1"
          >
            بازنشانی داده‌های رژیم ۲۱ روزه
          </button>
        )}
      </div>
    </div>
  );
};
