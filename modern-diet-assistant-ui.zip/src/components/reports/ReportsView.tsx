import React from 'react';
import { useDiet } from '../../context/DietContext';
import {
  TrendingDown,
  Award,
  Droplets,
  Footprints,
  Pill,
  Calendar,
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { days, userProfile } = useDiet();

  // Computations
  const weightLost = (userProfile.startWeight - userProfile.currentWeight).toFixed(1);
  const weightTargetDiff = (userProfile.currentWeight - userProfile.targetWeight).toFixed(1);

  let totalMeals = 0;
  let completedMeals = 0;
  let fullDaysCount = 0;
  let totalWater = 0;
  let totalWalkMins = 0;
  let walkDaysCount = 0;
  let totalSupps = 0;
  let completedSupps = 0;

  days.forEach((day) => {
    if (day.dayNumber <= 7) {
      totalMeals += day.meals.length;
      completedMeals += day.meals.filter((m) => m.isCompleted).length;
      if (day.dietScore >= 90) fullDaysCount++;

      totalWater += day.quotas.waterLogged;
      if (day.quotas.walkMinutesLogged > 0) {
        walkDaysCount++;
        totalWalkMins += day.quotas.walkMinutesLogged;
      }

      totalSupps += day.supplements.length;
      completedSupps += day.supplements.filter((s) => s.isCompleted).length;
    }
  });

  const incompleteMeals = totalMeals - completedMeals;
  const compliancePercent = totalMeals > 0 ? Math.round((completedMeals / totalMeals) * 100) : 100;
  const avgWalkTime = walkDaysCount > 0 ? Math.round(totalWalkMins / walkDaysCount) : 0;
  const suppPercent = totalSupps > 0 ? Math.round((completedSupps / totalSupps) * 100) : 100;

  // Streak calculation
  const currentStreak = 6; // 🔥 6 days consecutive adherence

  return (
    <div className="space-y-4 pb-24 animate-fade-in">
      {/* STREAK & HEADER CARD */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white shadow-xl shadow-amber-500/20 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-white/20 text-white mb-1 inline-block">
            گزارش و تحلیل عملکرد
          </span>
          <h2 className="text-lg font-black flex items-center gap-1.5">
            <span>🔥 {currentStreak} روز پایبندی متوالی</span>
          </h2>
          <p className="text-xs text-amber-100 mt-0.5">ثبات شما فوق‌العاده است! ادامه دهید 🎉</p>
        </div>

        <div className="p-3 bg-white/20 backdrop-blur-md rounded-2xl text-center">
          <span className="text-xs font-bold block opacity-90">امتیاز میانگین</span>
          <span className="text-xl font-black">۹۱ / ۱۰۰</span>
        </div>
      </div>

      {/* 1. WEIGHT REPORT CARD */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <TrendingDown className="w-4 h-4 text-emerald-500" />
            <span>گزارش تغییرات وزن</span>
          </h3>
          <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-0.5 rounded-lg">
            -{weightLost} کیلوگرم
          </span>
        </div>

        {/* 4 Stats */}
        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">وزن شروع</span>
            <span className="font-extrabold text-slate-800 dark:text-slate-200">{userProfile.startWeight}kg</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">وزن فعلی</span>
            <span className="font-extrabold text-emerald-600 dark:text-emerald-400">{userProfile.currentWeight}kg</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">وزن هدف</span>
            <span className="font-extrabold text-slate-800 dark:text-slate-200">{userProfile.targetWeight}kg</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 block">مانده تا هدف</span>
            <span className="font-extrabold text-amber-500">{weightTargetDiff}kg</span>
          </div>
        </div>

        {/* Custom Visual Bar Chart for Weight Trend */}
        <div className="pt-2 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold block">روند ۷ روز اخیر:</span>
          <div className="h-24 bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-3 flex items-end justify-between gap-2 border border-slate-100 dark:border-slate-800">
            {[72.0, 71.5, 70.8, 70.2, 69.8, 69.1, 68.5].map((w, idx) => {
              const minW = 63.0;
              const maxW = 72.0;
              const heightPct = Math.max(15, Math.min(100, ((w - minW) / (maxW - minW)) * 100));
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-[9px] font-mono text-slate-600 dark:text-slate-300 font-bold">{w}</span>
                  <div
                    className="w-full bg-gradient-to-t from-emerald-500 to-teal-400 rounded-t-lg transition-all duration-500"
                    style={{ height: `${heightPct}%` }}
                  />
                  <span className="text-[9px] text-slate-400 font-medium">روز {idx + 1}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 2. COMPLIANCE REPORT CARD */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Award className="w-4 h-4 text-amber-500" />
            <span>گزارش میزان پایبندی</span>
          </h3>
          <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
            {compliancePercent}٪ پایبندی کلی
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
            <span className="text-[10px] text-slate-500 block">وعده‌های تکمیل</span>
            <span className="font-extrabold text-emerald-700 dark:text-emerald-300">{completedMeals} وعده</span>
          </div>

          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800">
            <AlertCircle className="w-4 h-4 text-rose-500 mx-auto mb-1" />
            <span className="text-[10px] text-slate-500 block">وعده‌های ناقص</span>
            <span className="font-extrabold text-rose-700 dark:text-rose-300">{incompleteMeals} وعده</span>
          </div>

          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
            <Sparkles className="w-4 h-4 text-amber-500 mx-auto mb-1" />
            <span className="text-[10px] text-slate-500 block">روزهای ۱۰۰٪ کامل</span>
            <span className="font-extrabold text-amber-700 dark:text-amber-300">{fullDaysCount} روز</span>
          </div>
        </div>
      </div>

      {/* 3. WATER, WALKING & SUPPLEMENTS STATS GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Water */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1.5">
          <div className="flex items-center gap-1.5 text-sky-600 dark:text-sky-400 font-bold text-xs">
            <Droplets className="w-4 h-4" />
            <span>گزارش مصرف آب</span>
          </div>
          <span className="text-xl font-extrabold text-slate-900 dark:text-white block">{totalWater} لیوان</span>
          <p className="text-[10px] text-slate-400">میانگین ۳.۶ لیوان در روز</p>
        </div>

        {/* Walk */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1.5">
          <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-bold text-xs">
            <Footprints className="w-4 h-4" />
            <span>گزارش پیاده‌روی</span>
          </div>
          <span className="text-xl font-extrabold text-slate-900 dark:text-white block">{walkDaysCount} روز</span>
          <p className="text-[10px] text-slate-400">میانگین {avgWalkTime} دقیقه در هر جلسه</p>
        </div>

        {/* Supps */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-1.5">
          <div className="flex items-center gap-1.5 text-purple-600 dark:text-purple-400 font-bold text-xs">
            <Pill className="w-4 h-4" />
            <span>گزارش مکمل‌ها</span>
          </div>
          <span className="text-xl font-extrabold text-slate-900 dark:text-white block">{suppPercent}٪ منظم</span>
          <p className="text-[10px] text-slate-400">{completedSupps} از {totalSupps} دوز مصرف شد</p>
        </div>
      </div>

      {/* 4. 21-DAY DIET MATRIX CALENDAR (سبز، زرد، قرمز) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-emerald-500" />
            <span>تقویم ۲۱ روزه وضعیت رژیم</span>
          </h3>

          <div className="flex items-center gap-2 text-[9px] font-bold">
            <span className="flex items-center gap-1 text-emerald-600">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> کامل
            </span>
            <span className="flex items-center gap-1 text-amber-600">
              <span className="w-2 h-2 rounded-full bg-amber-500" /> متوسط
            </span>
            <span className="flex items-center gap-1 text-rose-600">
              <span className="w-2 h-2 rounded-full bg-rose-500" /> ضعيف
            </span>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5 pt-1">
          {days.map((day) => {
            let bgColor = 'bg-slate-100 dark:bg-slate-800 text-slate-400';
            if (day.dayNumber <= 7) {
              if (day.dietScore >= 85) {
                bgColor = 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20';
              } else if (day.dietScore >= 60) {
                bgColor = 'bg-amber-500 text-white shadow-md shadow-amber-500/20';
              } else {
                bgColor = 'bg-rose-500 text-white shadow-md shadow-rose-500/20';
              }
            }

            return (
              <div
                key={day.dayNumber}
                className={`p-2 rounded-xl text-center font-bold transition-all ${bgColor}`}
              >
                <span className="text-[9px] block opacity-80">{day.dayOfWeek}</span>
                <span className="text-xs font-black block">{day.dayNumber}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
