import React from 'react';
import { useDiet } from '../../context/DietContext';
import { Play, ChevronLeft, X, Sparkles } from 'lucide-react';

export const DemoScenarioBar: React.FC = () => {
  const { isDemoActive, demoStep, nextDemoStep, exitDemo } = useDiet();

  if (!isDemoActive) return null;

  const stepDescriptions: Record<number, string> = {
    1: 'صفحه خانه را مشاهده کنید. متوجه می‌شوید امروز چه وعده‌ها و اهدافی دارید.',
    2: 'صبحانه امروز را ببینید و آن را به عنوان انجام‌شده ثبت کنید.',
    3: 'یک لیوان آب ثبت کنید (با لمس آیکون لیوان آب).',
    4: 'عصرانه امروز را از میان گزینه‌های مجاز انتخاب کنید.',
    5: 'تایمر پیاده‌روی ۳۵ دقیقه‌ای را شروع و تکمیل نمایید.',
    6: 'وزن امروز خود را وارد کنید.',
    7: 'وارد صفحه گزارش‌ها شده و Diet Score و روند پایبندی خود را ببینید.',
  };

  return (
    <div className="fixed bottom-20 left-4 right-4 z-40 max-w-md mx-auto">
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-3.5 rounded-2xl shadow-2xl border border-emerald-500/30 backdrop-blur-md">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-emerald-300">
              راهنمای تعاملی سناریو - گام {demoStep} از ۷
            </span>
          </div>
          <button
            onClick={exitDemo}
            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-200 mb-3 font-medium leading-relaxed">
          {stepDescriptions[demoStep] || ''}
        </p>

        <div className="flex items-center justify-between gap-2">
          <div className="flex gap-1 flex-1">
            {[1, 2, 3, 4, 5, 6, 7].map((s) => (
              <div
                key={s}
                className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                  s === demoStep
                    ? 'bg-emerald-400 w-full'
                    : s < demoStep
                    ? 'bg-emerald-600/80'
                    : 'bg-slate-700'
                }`}
              />
            ))}
          </div>

          <button
            onClick={nextDemoStep}
            className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs px-3 py-1.5 rounded-xl transition-all shadow-md active:scale-95 shrink-0"
          >
            <span>{demoStep === 7 ? 'پایان تور' : 'گام بعدی'}</span>
            {demoStep === 7 ? <Play className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
