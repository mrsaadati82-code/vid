import React from 'react';
import { useDiet } from '../../context/DietContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useDiet();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4 space-y-2 pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`pointer-events-auto flex items-center justify-between p-3 rounded-2xl shadow-lg border backdrop-blur-md transition-all duration-300 animate-pulse-subtle ${
            toast.type === 'success'
              ? 'bg-emerald-500/90 text-white border-emerald-400'
              : toast.type === 'warning'
              ? 'bg-amber-500/90 text-white border-amber-400'
              : 'bg-slate-800/90 text-white border-slate-700'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />}
            {toast.type === 'warning' && <AlertCircle className="w-5 h-5 text-amber-200 shrink-0" />}
            {toast.type === 'info' && <Info className="w-5 h-5 text-sky-200 shrink-0" />}
            <span className="text-sm font-medium leading-tight">{toast.message}</span>
          </div>
          <button
            onClick={() => removeToast(toast.id)}
            className="p-1 rounded-full hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
