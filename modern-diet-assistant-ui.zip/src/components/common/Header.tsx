import React from 'react';
import { useDiet } from '../../context/DietContext';
import { Moon, Sun, BookOpen, Utensils, PlayCircle } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    userProfile,
    currentDayNumber,
    darkMode,
    setDarkMode,
    setRecipeModalOpen,
    setRulesModalOpen,
    startDemoScenario,
    isDemoActive
  } = useDiet();

  return (
    <header className="sticky top-0 z-30 bg-slate-50/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 px-4 py-3 transition-colors">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Left / Greeting */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-emerald-500/20">
              {userProfile.name.charAt(0)}
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full"></span>
          </div>

          <div>
            <h1 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>سلام {userProfile.name}</span>
              <span className="animate-bounce inline-block">👋</span>
            </h1>
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-0.5">
              امروز روز {currentDayNumber} از ۲۱ رژیم شماست
            </p>
          </div>
        </div>

        {/* Right / Top Actions */}
        <div className="flex items-center gap-1.5">
          {/* Demo Scenario Button */}
          <button
            onClick={startDemoScenario}
            title="اجرای سناریوی نمونه"
            className={`flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-xl font-medium transition-all ${
              isDemoActive
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/30 animate-pulse'
                : 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-200 border border-emerald-200 dark:border-emerald-800'
            }`}
          >
            <PlayCircle className="w-3.5 h-3.5 shrink-0" />
            <span className="hidden sm:inline">تست سناریو</span>
          </button>

          {/* Kitchen Modal Button */}
          <button
            onClick={() => setRecipeModalOpen(true)}
            title="آشپزخانه رژیمی"
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors relative"
          >
            <Utensils className="w-4 h-4" />
          </button>

          {/* Rules Modal Button */}
          <button
            onClick={() => setRulesModalOpen(true)}
            title="قوانین رژیم"
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors"
          >
            <BookOpen className="w-4 h-4" />
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            title={darkMode ? 'حالت روز' : 'حالت شب'}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>
        </div>
      </div>
    </header>
  );
};
