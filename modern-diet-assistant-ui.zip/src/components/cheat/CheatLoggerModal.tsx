import React, { useState } from 'react';
import { useDiet } from '../../context/DietContext';
import { X, AlertCircle, Save } from 'lucide-react';

export const CheatLoggerModal: React.FC = () => {
  const { cheatModalOpen, setCheatModalOpen, currentDayNumber, addCheatLog } = useDiet();

  const [foodName, setFoodName] = useState('');
  const [portion, setPortion] = useState('');
  const [time, setTime] = useState('۱۷:۳۰');
  const [reason, setReason] = useState<'hunger' | 'craving' | 'stress' | 'party' | 'other'>('craving');
  const [notes, setNotes] = useState('');

  if (!cheatModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName.trim()) return;

    const reasonsMap = {
      hunger: 'گرسنگی شدید',
      craving: 'هوس غذایی',
      stress: 'استرس و فشار عصبی',
      party: 'مهمانی یا دورهمی',
      other: 'سایر موارد',
    };

    addCheatLog(currentDayNumber, {
      foodName,
      portion: portion || '۱ سهمیه',
      time: time || '۱۸:۰۰',
      reason,
      reasonPersian: reasonsMap[reason],
      notes,
    });

    setFoodName('');
    setPortion('');
    setNotes('');
    setCheatModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 transition-opacity">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 animate-slide-up">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-amber-50/50 dark:bg-amber-950/20">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 rounded-xl">
              <AlertCircle className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">ثبت تخلف غذایی (خارج از برنامه)</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">به مدیریت بهتر و اصلاح آگاهانه رفتار کمک می‌کند</p>
            </div>
          </div>
          <button
            onClick={() => setCheatModalOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
          {/* Food Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              نام ماده غذایی مصرف‌شده *
            </label>
            <input
              type="text"
              required
              placeholder="مثلاً: ۲ عدد شکلات، ۱ لیوان نوشابه..."
              value={foodName}
              onChange={(e) => setFoodName(e.target.value)}
              className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
            />
          </div>

          {/* Portion & Time */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                مقدار تقریبی
              </label>
              <input
                type="text"
                placeholder="مثلاً: ۵۰ گرم / ۱ عدد"
                value={portion}
                onChange={(e) => setPortion(e.target.value)}
                className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                زمان مصرف
              </label>
              <input
                type="text"
                placeholder="۱۷:۳۰"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200"
              />
            </div>
          </div>

          {/* Reason */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              دلیل اصلی مصرف:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'craving', label: 'هوس غذایی' },
                { id: 'hunger', label: 'گرسنگی شدید' },
                { id: 'stress', label: 'استرس و فشار' },
                { id: 'party', label: 'مهمانی و دورهمی' },
                { id: 'other', label: 'سایر موارد' },
              ].map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setReason(r.id as any)}
                  className={`p-2 text-xs rounded-xl border text-center transition-all ${
                    reason === r.id
                      ? 'bg-amber-500 text-white font-bold border-amber-600 shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              یادداشت یا احساس شما پس از مصرف:
            </label>
            <textarea
              rows={2}
              placeholder="توضیح کوتاه..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 text-xs rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-200 resize-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition-all flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>ثبت تخلف غذایی</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
