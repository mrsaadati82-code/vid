import React from 'react';
import { DietProvider, useDiet } from './context/DietContext';
import { ToastContainer } from './components/common/ToastContainer';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { DemoScenarioBar } from './components/common/DemoScenarioBar';
import { HomeView } from './components/home/HomeView';
import { MealPlanView } from './components/schedule/MealPlanView';
import { TrackerView } from './components/tracker/TrackerView';
import { ReportsView } from './components/reports/ReportsView';
import { ProfileView } from './components/profile/ProfileView';
import { KitchenModal } from './components/kitchen/KitchenModal';
import { RulesModal } from './components/rules/RulesModal';
import { CheatLoggerModal } from './components/cheat/CheatLoggerModal';

const AppContent: React.FC = () => {
  const { activeTab } = useDiet();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col items-center justify-start transition-colors">
      {/* Mobile Frame Container */}
      <div className="w-full max-w-md min-h-screen flex flex-col relative bg-slate-50 dark:bg-slate-950 shadow-2xl">
        {/* Toast Alerts */}
        <ToastContainer />

        {/* Top Header */}
        <Header />

        {/* Main Tab Content View */}
        <main className="flex-1 p-4 overflow-y-auto">
          {activeTab === 'home' && <HomeView />}
          {activeTab === 'schedule' && <MealPlanView />}
          {activeTab === 'tracker' && <TrackerView />}
          {activeTab === 'reports' && <ReportsView />}
          {activeTab === 'profile' && <ProfileView />}
        </main>

        {/* Interactive Scenario Bar */}
        <DemoScenarioBar />

        {/* Bottom Navigation Bar */}
        <BottomNav />

        {/* Global Modals */}
        <KitchenModal />
        <RulesModal />
        <CheatLoggerModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <DietProvider>
      <AppContent />
    </DietProvider>
  );
}
