import React, { createContext, useContext, useState, useEffect } from 'react';
import { DayPlan, UserProfile, Recipe, ReminderSetting, MoodType, CheatLog } from '../types/diet';
import { INITIAL_USER_PROFILE, INITIAL_REMINDERS, generate21DaysData } from '../data/mockDietData';
import confetti from 'canvas-confetti';

interface ToastState {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'warning';
}

interface DietContextType {
  currentDayNumber: number;
  setCurrentDayNumber: (day: number) => void;
  days: DayPlan[];
  userProfile: UserProfile;
  reminders: ReminderSetting[];
  activeTab: 'home' | 'schedule' | 'tracker' | 'reports' | 'profile';
  setActiveTab: (tab: 'home' | 'schedule' | 'tracker' | 'reports' | 'profile') => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  
  // Modals & Bottom Sheets
  recipeModalOpen: boolean;
  setRecipeModalOpen: (open: boolean) => void;
  selectedRecipe: Recipe | null;
  setSelectedRecipe: (recipe: Recipe | null) => void;
  
  rulesModalOpen: boolean;
  setRulesModalOpen: (open: boolean) => void;
  
  cheatModalOpen: boolean;
  setCheatModalOpen: (open: boolean) => void;

  toasts: ToastState[];
  showToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
  removeToast: (id: string) => void;

  // Actions
  toggleMealCompletion: (dayNum: number, mealId: string) => void;
  incrementWater: (dayNum: number) => void;
  decrementWater: (dayNum: number) => void;
  updateFruitGrams: (dayNum: number, grams: number) => void;
  updateWalkMinutes: (dayNum: number, mins: number, isCompleted?: boolean) => void;
  toggleSupplement: (dayNum: number, suppId: string) => void;
  toggleReminder: (dayNum: number, remId: string) => void;
  selectSnack: (dayNum: number, snackId: string) => void;
  toggleSnackCompletion: (dayNum: number) => void;
  updateWeight: (dayNum: number, weightKg: number) => void;
  updateMood: (dayNum: number, mood: MoodType, note?: string) => void;
  addCheatLog: (dayNum: number, cheatData: Omit<CheatLog, 'id' | 'date'>) => void;
  toggleReminderSetting: (id: string) => void;
  
  // Guided Demo Scenario
  demoStep: number;
  isDemoActive: boolean;
  startDemoScenario: () => void;
  nextDemoStep: () => void;
  exitDemo: () => void;
  resetDataToDefault: () => void;
}

const DietContext = createContext<DietContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_DAYS = 'synergy_diet_days_v2';
const LOCAL_STORAGE_KEY_PROFILE = 'synergy_user_profile_v2';
const LOCAL_STORAGE_KEY_REMINDERS = 'synergy_reminders_v2';

export const DietProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentDayNumber, setCurrentDayNumber] = useState<number>(7);
  const [activeTab, setActiveTab] = useState<'home' | 'schedule' | 'tracker' | 'reports' | 'profile'>('home');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_PROFILE);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_USER_PROFILE;
  });

  const [reminders, setReminders] = useState<ReminderSetting[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_REMINDERS);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_REMINDERS;
  });

  const [days, setDays] = useState<DayPlan[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_DAYS);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return generate21DaysData();
  });

  const [recipeModalOpen, setRecipeModalOpen] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [rulesModalOpen, setRulesModalOpen] = useState(false);
  const [cheatModalOpen, setCheatModalOpen] = useState(false);

  const [toasts, setToasts] = useState<ToastState[]>([]);

  // Demo scenario state
  const [isDemoActive, setIsDemoActive] = useState<boolean>(false);
  const [demoStep, setDemoStep] = useState<number>(0);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY_DAYS, JSON.stringify(days));
  }, [days]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY_PROFILE, JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY_REMINDERS, JSON.stringify(reminders));
  }, [reminders]);

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const recalculateDietScore = (day: DayPlan): number => {
    let score = 0;
    // Meals (30 pts max)
    const completedMeals = day.meals.filter((m) => m.isCompleted).length;
    score += Math.round((completedMeals / 3) * 30);

    // Water (20 pts max)
    const waterRatio = Math.min(1, day.quotas.waterLogged / day.quotas.waterGlasses);
    score += Math.round(waterRatio * 20);

    // Fruit (15 pts max)
    const fruitRatio = Math.min(1, day.quotas.fruitGramsLogged / day.quotas.fruitGramsTarget);
    score += Math.round(fruitRatio * 15);

    // Walking (20 pts max)
    const walkRatio = Math.min(1, day.quotas.walkMinutesLogged / day.quotas.walkMinutesTarget);
    score += Math.round(walkRatio * 20);

    // Supplements (15 pts max)
    if (day.supplements.length > 0) {
      const compSupps = day.supplements.filter((s) => s.isCompleted).length;
      score += Math.round((compSupps / day.supplements.length) * 15);
    } else {
      score += 15;
    }

    // Deduct for cheats (-10 each)
    if (day.cheats.length > 0) {
      score = Math.max(0, score - day.cheats.length * 10);
    }

    return Math.min(100, Math.max(0, score));
  };

  const updateDayPlan = (dayNum: number, updater: (prevDay: DayPlan) => DayPlan) => {
    setDays((prevDays) =>
      prevDays.map((d) => {
        if (d.dayNumber === dayNum) {
          const updated = updater(d);
          updated.dietScore = recalculateDietScore(updated);
          return updated;
        }
        return d;
      })
    );
  };

  const toggleMealCompletion = (dayNum: number, mealId: string) => {
    updateDayPlan(dayNum, (day) => {
      let nowCompleted = false;
      const updatedMeals = day.meals.map((m) => {
        if (m.id === mealId) {
          nowCompleted = !m.isCompleted;
          return { ...m, isCompleted: nowCompleted };
        }
        return m;
      });

      if (nowCompleted) {
        showToast(`وعده غذایی با موفقیت ثبت شد 🎉`, 'success');
        confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
      } else {
        showToast(`وضعیت وعده تغییر یافت`, 'info');
      }

      return { ...day, meals: updatedMeals };
    });
  };

  const incrementWater = (dayNum: number) => {
    updateDayPlan(dayNum, (day) => {
      const newLogged = Math.min(day.quotas.waterGlasses, day.quotas.waterLogged + 1);
      if (newLogged === day.quotas.waterGlasses) {
        showToast(`هدف آب امروز تکمیل شد! 💧✨`, 'success');
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
      } else {
        showToast(`یک لیوان آب ثبت شد (کل: ${newLogged} از ${day.quotas.waterGlasses}) 💧`, 'info');
      }
      return {
        ...day,
        quotas: { ...day.quotas, waterLogged: newLogged },
      };
    });
  };

  const decrementWater = (dayNum: number) => {
    updateDayPlan(dayNum, (day) => {
      const newLogged = Math.max(0, day.quotas.waterLogged - 1);
      return {
        ...day,
        quotas: { ...day.quotas, waterLogged: newLogged },
      };
    });
  };

  const updateFruitGrams = (dayNum: number, grams: number) => {
    updateDayPlan(dayNum, (day) => {
      const bounded = Math.min(1000, Math.max(0, grams));
      if (bounded >= day.quotas.fruitGramsTarget) {
        showToast(`سهمیه میوه امروز (${bounded} گرم) کامل شد 🍎`, 'success');
      } else {
        showToast(`سهمیه میوه ثبت شد: ${bounded} گرم`, 'info');
      }
      return {
        ...day,
        quotas: { ...day.quotas, fruitGramsLogged: bounded },
      };
    });
  };

  const updateWalkMinutes = (dayNum: number, mins: number, isCompleted?: boolean) => {
    updateDayPlan(dayNum, (day) => {
      const bounded = Math.min(120, Math.max(0, mins));
      const completed = isCompleted ?? (bounded >= day.quotas.walkMinutesTarget);
      if (completed && !day.quotas.isWalkCompleted) {
        showToast(`آفرین! ۳۵ دقیقه پیاده‌روی امروز تکمیل شد 🏃‍♀️🔥`, 'success');
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 } });
      }
      return {
        ...day,
        quotas: {
          ...day.quotas,
          walkMinutesLogged: bounded,
          isWalkCompleted: completed,
        },
      };
    });
  };

  const toggleSupplement = (dayNum: number, suppId: string) => {
    updateDayPlan(dayNum, (day) => {
      const updated = day.supplements.map((s) => (s.id === suppId ? { ...s, isCompleted: !s.isCompleted } : s));
      showToast(`وضعیت مکمل به‌روزرسانی شد 💊`, 'info');
      return { ...day, supplements: updated };
    });
  };

  const toggleReminder = (dayNum: number, remId: string) => {
    updateDayPlan(dayNum, (day) => {
      const updated = day.reminders.map((r) => (r.id === remId ? { ...r, completed: !r.completed } : r));
      return { ...day, reminders: updated };
    });
  };

  const selectSnack = (dayNum: number, snackId: string) => {
    updateDayPlan(dayNum, (day) => {
      const snackObj = day.snackOptions.find((s) => s.id === snackId);
      showToast(`عصرانه انتخاب شد: ${snackObj?.name || ''} 🥗`, 'success');
      return {
        ...day,
        selectedSnackId: snackId,
        isSnackCompleted: true,
      };
    });
  };

  const toggleSnackCompletion = (dayNum: number) => {
    updateDayPlan(dayNum, (day) => {
      const nextState = !day.isSnackCompleted;
      showToast(nextState ? `عصرانه انجام شد ✅` : `عصرانه به حالت انجام نشده برگشت`, 'info');
      return { ...day, isSnackCompleted: nextState };
    });
  };

  const updateWeight = (dayNum: number, weightKg: number) => {
    updateDayPlan(dayNum, (day) => {
      return { ...day, weightKg };
    });

    // Update current weight in user profile
    setUserProfile((prev) => {
      return {
        ...prev,
        currentWeight: weightKg,
      };
    });

    showToast(`وزن جدید (${weightKg} کیلوگرم) ثبت شد ⚖️`, 'success');
  };

  const updateMood = (dayNum: number, mood: MoodType, note?: string) => {
    updateDayPlan(dayNum, (day) => {
      return { ...day, mood, moodNote: note };
    });
    showToast(`حال امروز شما ثبت گردید 😊`, 'success');
  };

  const addCheatLog = (dayNum: number, cheatData: Omit<CheatLog, 'id' | 'date'>) => {
    updateDayPlan(dayNum, (day) => {
      const newCheat: CheatLog = {
        ...cheatData,
        id: Math.random().toString(36).substring(2, 9),
        date: day.datePersian,
      };
      showToast(`تخلف غذایی ثبت شد. گزارش در بخش گزارش‌ها قابل مشاهده است ⚠️`, 'warning');
      return { ...day, cheats: [...day.cheats, newCheat] };
    });
  };

  const toggleReminderSetting = (id: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
    showToast(`تنظیمات اعلان به‌روز شد 🔔`, 'info');
  };

  const resetDataToDefault = () => {
    localStorage.removeItem(LOCAL_STORAGE_KEY_DAYS);
    localStorage.removeItem(LOCAL_STORAGE_KEY_PROFILE);
    localStorage.removeItem(LOCAL_STORAGE_KEY_REMINDERS);
    setDays(generate21DaysData());
    setUserProfile(INITIAL_USER_PROFILE);
    setReminders(INITIAL_REMINDERS);
    setCurrentDayNumber(7);
    setActiveTab('home');
    showToast(`اطلاعات برنامه به حالت اولیه بازگشت 🔄`, 'info');
  };

  // Guided Prototype Scenario Workflow
  const startDemoScenario = () => {
    setIsDemoActive(true);
    setDemoStep(1);
    setActiveTab('home');
    setCurrentDayNumber(7);
    showToast(`سناریوی راهنما شروع شد! 🚀 گام ۱: مشاهده خانه`, 'info');
  };

  const nextDemoStep = () => {
    const next = demoStep + 1;
    if (next === 2) {
      // Step 2: Observe Breakfast & Mark breakfast complete
      setDemoStep(2);
      showToast(`گام ۲: ثبت صبحانه به‌عنوان انجام‌شده`, 'info');
    } else if (next === 3) {
      // Step 3: Register a glass of water
      setDemoStep(3);
      incrementWater(7);
      showToast(`گام ۳: افزایش و ثبت مصرف یک لیوان آب`, 'info');
    } else if (next === 4) {
      // Step 4: Select Afternoon Snack
      setDemoStep(4);
      selectSnack(7, 'snk_1');
      showToast(`گام ۴: انتخاب گزینه عصرانه امروز`, 'info');
    } else if (next === 5) {
      // Step 5: Start & Finish 35-min Walk
      setDemoStep(5);
      updateWalkMinutes(7, 35, true);
      showToast(`گام ۵: اتمام و ثبت ۳۵ دقیقه پیاده‌روی`, 'success');
    } else if (next === 6) {
      // Step 6: Log Weight
      setDemoStep(6);
      updateWeight(7, 68.2);
      showToast(`گام ۶: ثبت وزن روزانه (۶۸.۲ کیلوگرم)`, 'success');
    } else if (next === 7) {
      // Step 7: Go to Reports and see Score
      setDemoStep(7);
      setActiveTab('reports');
      showToast(`گام ۷: مشاهده گزارش‌ها و امتیاز پیشرفت 🎉`, 'success');
      confetti({ particleCount: 80, spread: 80, origin: { y: 0.6 } });
    } else {
      setIsDemoActive(false);
      setDemoStep(0);
      showToast(`سناریوی نمونه با موفقیت به پایان رسید! ✨`, 'success');
    }
  };

  const exitDemo = () => {
    setIsDemoActive(false);
    setDemoStep(0);
    showToast(`از حالت راهنما خارج شدید`, 'info');
  };

  return (
    <DietContext.Provider
      value={{
        currentDayNumber,
        setCurrentDayNumber,
        days,
        userProfile,
        reminders,
        activeTab,
        setActiveTab,
        darkMode,
        setDarkMode,
        recipeModalOpen,
        setRecipeModalOpen,
        selectedRecipe,
        setSelectedRecipe,
        rulesModalOpen,
        setRulesModalOpen,
        cheatModalOpen,
        setCheatModalOpen,
        toasts,
        showToast,
        removeToast,
        toggleMealCompletion,
        incrementWater,
        decrementWater,
        updateFruitGrams,
        updateWalkMinutes,
        toggleSupplement,
        toggleReminder,
        selectSnack,
        toggleSnackCompletion,
        updateWeight,
        updateMood,
        addCheatLog,
        toggleReminderSetting,
        demoStep,
        isDemoActive,
        startDemoScenario,
        nextDemoStep,
        exitDemo,
        resetDataToDefault,
      }}
    >
      {children}
    </DietContext.Provider>
  );
};

export const useDiet = () => {
  const context = useContext(DietContext);
  if (!context) {
    throw new Error('useDiet must be used within a DietProvider');
  }
  return context;
};
