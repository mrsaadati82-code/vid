import { DayPlan, UserProfile, Recipe, ForbiddenCategory, ReminderSetting } from '../types/diet';

export const INITIAL_USER_PROFILE: UserProfile = {
  name: 'فرشته',
  fileNumber: '۲۱۰۸-F',
  startDate: '۱۴۰۳/۰۲/۰۱',
  durationDays: 21,
  startWeight: 72.0,
  currentWeight: 68.5,
  targetWeight: 63.0,
  heightCm: 168,
  bmi: 24.3,
  bmiCategory: 'وزن نرمال - در محدوده ایده‌آل',
};

export const INITIAL_REMINDERS: ReminderSetting[] = [
  { id: 'rem_b', title: 'یادآوری صبحانه', time: '۰۸:۰۰', enabled: true, sound: 'زنگ ملایم ۱' },
  { id: 'rem_l', title: 'یادآوری ناهار', time: '۱۳:۳۰', enabled: true, sound: 'زنگ ملایم ۲' },
  { id: 'rem_snack', title: 'یادآوری عصرانه', time: '۱۷:۰۰', enabled: true, sound: 'اعلان کوتاه' },
  { id: 'rem_d', title: 'یادآوری شام', time: '۲۰:۳۰', enabled: true, sound: 'زنگ ملایم ۱' },
  { id: 'rem_water', title: 'یادآوری مصرف آب', time: 'هر ۲ ساعت', enabled: true, sound: 'قطره آب' },
  { id: 'rem_fruit', title: 'یادآوری سهمیه میوه', time: '۱۶:۳۰', enabled: true, sound: 'اعلان کوتاه' },
  { id: 'rem_walk', title: 'یادآوری پیاده‌روی', time: '۱۸:۰۰', enabled: true, sound: 'انرژی‌بخش' },
  { id: 'rem_supp', title: 'یادآوری مکمل‌ها (ففول و ویتامین D)', time: '۰۹:۰۰', enabled: true, sound: 'اعلان کوتاه' },
  { id: 'rem_honey', title: 'یادآوری ترکیب سیاهدانه و عسل', time: '۰۷:۳۰ (ناشتا)', enabled: true, sound: 'اعلان کوتاه' },
  { id: 'rem_tips', title: 'توصیه‌های سلامت روزانه', time: '۱۰:۰۰', enabled: true, sound: 'بی‌صدا' },
];

export const RECIPES: Recipe[] = [
  {
    id: 'rec_1',
    title: 'فرنی رژیمی با آرد برنج و شیر کم‌چرب',
    category: 'breakfast',
    categoryPersian: 'صبحانه',
    image: 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 15,
    calories: 180,
    portion: '۱ پیاله (۲۰۰ گرم)',
    ingredients: ['۲ لیوان شیر کم‌چرب (۰.۵٪)', '۲ قاشق غذاخوری آرد برنج', '۱ قاشق چایخوری هل ساییده', '۱ قاشق مرباخوری شیره انگور یا عسل طبیعی', '۱ قاشق غذاخوری گلاب'],
    instructions: [
      'آرد برنج را در شیر سرد حل کنید تا کاملاً یکدست شود.',
      'مخلوط را روی حرارت ملایم قرار داده و مداوم هم بزنید تا غلیظ شود.',
      'هل و گلاب را در ۳ دقیقه پایانی اضافه کنید.',
      'پس از خاموش کردن شعله، عسل یا شیره را افزوده و میل کنید.'
    ],
    allowedMeals: ['صبحانه', 'عصرانه']
  },
  {
    id: 'rec_2',
    title: 'زرشک پلو با مرغ بخارپز رژیمی',
    category: 'lunch',
    categoryPersian: 'ناهار',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 40,
    calories: 380,
    portion: '۱۵۰ گرم سینه مرغ + ۶ قاشق برنج کته بدون روغن',
    ingredients: ['۱۵۰ گرم سینه مرغ بدون پوست', '۶ قاشق غذاخوری برنج کم‌نمک کته', '۲ قاشق غذاخوری زرشک تفت‌داده با ۱ چایخوری روغن زیتون', 'زعفران دم‌کرده و پیاز و زردچوبه'],
    instructions: [
      'سینه مرغ را با پیاز، زردچوبه و هویج آب‌پز یا بخارپز کنید.',
      'زرشک را با مقدار خیلی کم روغن زیتون و آب زعفران کمی تفت دهید.',
      'برنج کته را آماده کرده و زرشک را روی آن بریزید و همراه مرغ میل کنید.'
    ],
    allowedMeals: ['ناهار']
  },
  {
    id: 'rec_3',
    title: 'سالاد سیب‌زمینی و پنیر کم‌چرب',
    category: 'dinner',
    categoryPersian: 'شام',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 20,
    calories: 240,
    portion: '۱ عدد سیب‌زمینی متوسط + ۳۰ گرم پنیر لاکتیکی',
    ingredients: ['۱ عدد سیب‌زمینی آب‌پز متوسط', '۳۰ گرم پنیر کم‌چرب لاکتیکی یا سفید', '۱ لیوان خیار و شويد تازه', '۱ قاشق چایخوری روغن زیتون', 'آبلیمو تازه و شوید خرد شده'],
    instructions: [
      'سیب‌زمینی آب‌پز شده را مکعبی خرد کنید.',
      'پنیر و شوید خرد شده و خیار را به آن اضافه کنید.',
      'روغن زیتون و کمی آبلیمو اضافه کرده و مخلوط نمایید.'
    ],
    allowedMeals: ['شام', 'صبحانه']
  },
  {
    id: 'rec_4',
    title: 'کتلت گوشت لذیذ رژیمی (فر یا تابه رژیمی)',
    category: 'lunch',
    categoryPersian: 'ناهار',
    image: 'https://images.unsplash.com/photo-1529042410759-befb1204b468?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 30,
    calories: 320,
    portion: '۲ عدد کتلت متوسط + ۱ برش نان سنگک',
    ingredients: ['۱۰۰ گرم گوشت چرخ‌کرده کم‌چرب', '۱ عدد سیب‌زمینی کوچک رنده‌شده', '۱ عدد پیاز کوچک رنده‌شده', '۱ عدد تخم‌مرغ', 'ادویه، ادویه کاری و زردچوبه'],
    instructions: [
      'تمام مواد را ورز دهید تا یکدست شود.',
      'کف تابه رژیمی یا سینی فر را با اسپری روغن چرب کنید.',
      'کتلت‌ها را بپزید تا دو طرف آن طلایی شود.'
    ],
    allowedMeals: ['ناهار', 'شام']
  },
  {
    id: 'rec_5',
    title: 'خوراک مرغ و سبزیجات بخارپز',
    category: 'dinner',
    categoryPersian: 'شام',
    image: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 30,
    calories: 260,
    portion: '۱۵۰ گرم مرغ + ۱ لیوان سبزیجات',
    ingredients: ['۱۵۰ گرم سینه مرغ', '۱ عدد هویج', '۱ عدد کدو سبز', 'نصف لیوان قارچ خردشده', '۱ قاشق مرباخوری روغن زیتون و لیمو'],
    instructions: [
      'مرغ و سبزیجات را خرد کرده و در بخارپز یا قابلمه با کمی آب بپزید.',
      'پس از پخت کامل، روغن زیتون و آبلیمو را روی آن بریزید.'
    ],
    allowedMeals: ['شام', 'ناهار']
  },
  {
    id: 'rec_6',
    title: 'تخم‌مرغ آب‌پز با سبزیجات و نان سنگک',
    category: 'breakfast',
    categoryPersian: 'صبحانه',
    image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 10,
    calories: 210,
    portion: '۲ عدد تخم‌مرغ + ۳۰ گرم نان سنگک',
    ingredients: ['۲ عدد تخم‌مرغ سفت آب‌پز', '۳۰ گرم نان سنگک سبوس‌دار', 'گوجه‌فرنگی و خیار و سبزی خوردن'],
    instructions: [
      'تخم‌مرغ‌ها را ۱۰ دقیقه در آب جوش بپزید.',
      'همراه گوجه، خیار و سبزی خوردن و نان سنگک میل کنید.'
    ],
    allowedMeals: ['صبحانه']
  },
  {
    id: 'rec_7',
    title: 'سوپ جو پرک رژیمی با مرغ',
    category: 'soup',
    categoryPersian: 'سوپ',
    image: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 35,
    calories: 190,
    portion: '۱.۵ لیوان سوپ',
    ingredients: ['۴ قاشق غذاخوری جو پرک', '۵۰ گرم سینه مرغ ریش‌شده', '۱ عدد هویج رنده‌شده', '۱ قاشق رب گوجه‌فرنگی خانگی', 'جعفری تازه و لیموترش'],
    instructions: [
      'مرغ را بپزید و ریش‌ریش کنید.',
      'جو پرک و هویج رنده‌شده را به عصاره مرغ اضافه کرده و ۳۰ دقیقه بپزید تا جا بیفتد.',
      'در انتهای پخت جعفری و آبلیمو بیفزایید.'
    ],
    allowedMeals: ['شام', 'پیش‌غذا']
  },
  {
    id: 'rec_8',
    title: 'خوراک قارچ و سبزیجات ورقی',
    category: 'diet_dish',
    categoryPersian: 'غذاهای رژیمی',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 15,
    calories: 160,
    portion: '۲۰۰ گرم خوراک',
    ingredients: ['۲۰۰ گرم قارچ تازه اسلایس شده', '۱ عدد فلفل دلمه‌ای رنگی', '۱ قاشق چایخوری روغن زیتون', 'سیر خردشده، نمک دریا و فلفل سیاه'],
    instructions: [
      'قارچ و فلفل دلمه‌ای را با حرارت بالا تفت دهید تا آب قارچ تبخیر شود.',
      'سیر و ادویه‌ها را بیفزایید و ۲ دقیقه تفت دهید.'
    ],
    allowedMeals: ['شام', 'میان‌وعده']
  },
  {
    id: 'rec_9',
    title: 'ارده و شیره انگور با نان جو',
    category: 'breakfast',
    categoryPersian: 'صبحانه',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 5,
    calories: 250,
    portion: '۱ قاشق غذاخوری ارده + ۱ قاشق مرباخوری شیره',
    ingredients: ['۱ قاشق غذاخوری ارده کنجد خالص', '۱ قاشق مرباخوری شیره انگور یا خرما', '۳۰ گرم نان جو سبوس‌دار'],
    instructions: [
      'ارده و شیره را در ظرف کوچکی مخلوط کنید.',
      'همراه نان جو گرم میل کنید.'
    ],
    allowedMeals: ['صبحانه']
  },
  {
    id: 'rec_10',
    title: 'استانبولی پلو با گوشت چرخ‌کرده و گوجه',
    category: 'lunch',
    categoryPersian: 'ناهار',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 45,
    calories: 360,
    portion: '۶ قاشق استانبولی + ۵۰ گرم گوشت کم‌چرب',
    ingredients: ['۶ قاشق غذاخوری برنج کته', '۵۰ گرم گوشت چرخ‌کرده کم‌چرب', '۲ عدد گوجه‌فرنگی رنده‌شده', '۱ عدد سیب‌زمینی نگینی کوچک'],
    instructions: [
      'گوشت و پیاز را با گوجه رنده‌شده تفت دهید.',
      'سیب‌زمینی را اضافه کرده و با برنج کته مخلوط و دم کنید.'
    ],
    allowedMeals: ['ناهار']
  },
  {
    id: 'rec_11',
    title: 'کوکو سبزی کم‌روغن رژیمی',
    category: 'dinner',
    categoryPersian: 'شام',
    image: 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 25,
    calories: 220,
    portion: '۲ برش کوکو سبزی + نان سنگک',
    ingredients: ['۲۰۰ گرم سبزی کوکویی خردشده', '۲ عدد تخم‌مرغ', '۱ قاشق غذاخوری زرشک و گردوی خردشده (اختیاری)', '۱ قاشق مرباخوری روغن زیتون'],
    instructions: [
      'سبزی و تخم‌مرغ را همراه ادویه هم بزنید.',
      'در تابه نچسب با مقدار بسیار کمی روغن یا در فر بپزید.'
    ],
    allowedMeals: ['شام', 'صبحانه']
  },
  {
    id: 'rec_12',
    title: 'پلو خورشت دلخواه کم‌چرب (قیمه یا قورمه)',
    category: 'lunch',
    categoryPersian: 'ناهار',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 60,
    calories: 390,
    portion: '۶ قاشق برنج + ۴ قاشق خورشت کم‌روغن',
    ingredients: ['۶ قاشق غذاخوری برنج کته', '۴ قاشق غذاخوری خورشت کم‌چرب (قیمه یا قورمه‌سبزی بدون روغن رویی)'],
    instructions: [
      'خورشت را با کمترین میزان روغن تهیه کرده و روغن روی آن را بگیرید.',
      'با برنج کته بدون کره میل کنید.'
    ],
    allowedMeals: ['ناهار']
  },
  {
    id: 'rec_13',
    title: 'سوپ رشته و سبزیجات تازه',
    category: 'soup',
    categoryPersian: 'سوپ',
    image: 'https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?auto=format&fit=crop&w=600&q=80',
    prepTimeMinutes: 25,
    calories: 175,
    portion: '۱.۵ لیوان سوپ',
    ingredients: ['۳۰ گرم رشته سوپی', '۱ لیوان سبزیجات خردشده (هویج، جعفری، گشنیز)', 'عصاره طبیعی مرغ کم‌نمک'],
    instructions: [
      'سبزیجات و عصاره مرغ را بپزید.',
      'در ۱۰ دقیقه پایانی رشته سوپ را اضافه کرده و پس از جا افتادن سرو کنید.'
    ],
    allowedMeals: ['شام', 'پیش‌غذا']
  }
];

export const FORBIDDEN_CATEGORIES: ForbiddenCategory[] = [
  {
    title: 'شیرینی‌جات و مواد قندی',
    items: ['انواع شیرینی قنادی', 'شکلات معمولی و تلخ بالا', 'آبنبات و آبنبات رژیمی', 'دسرها و ژله‌های قنددار', 'مربا و حلوا و زولبیا'],
    rules: [
      'مصرف هرگونه قند و شکر افزوده اکیداً ممنوع است.',
      'آبنبات رژیمی و شکلات تلخ نیز در این ۲۱ روز مجاز نیستند زیرا حس شیرینی‌دوستی را فعال نگه می‌دارند.'
    ]
  },
  {
    title: 'نوشیدنی‌های ممنوعه',
    items: ['نوشابه معمولی و دایت', 'نوشیدنی‌های پرقند صنعتی', 'قهوه و نسکافه', 'چای سبز (به علت تأثیر بر جذب مکمل‌ها)', 'شربت‌ها و دلستر'],
    rules: [
      'قهوه و نسکافه به دلیل تحریک هورمون کورتیزول و ایجاد اشتهای کاذب ممنوع هستند.',
      'چای سبز در این دوره ممنوع است و فقط چای کمرنگ یا دمنوش بابونه مجاز می‌باشد.'
    ]
  },
  {
    title: 'چربی‌ها و سس‌های مضر',
    items: ['سس سفید (مایونز)', 'تنقلات چیپس و پفک', 'غذاهای سرخ‌کرده و فست‌فود', 'آجیل و مغزیجات خام یا شور (مگر در موارد خاص Specified)'],
    rules: [
      'سس مایونز و هرگونه سس تجاری پایه چربی کلاً حذف شوند.',
      'روغن مصرفی فقط به میزان محدود روغن زیتون یا کنجد مجاز است.'
    ]
  },
  {
    title: 'قوانین مصرف میوه',
    items: ['سهمیه ۵۰۰ گرم در روز'],
    rules: [
      'سهمیه روزانه میوه دقیقاً ۵۰۰ گرم است.',
      'ترجیحاً میوه‌های با اندکس گلایسمی پایین مانند سیب، پرتقال، خیار و کیوی استفاده شود.',
      'آبمیوه طبیعی نیز به دلیل حذف فیبر توصیه نمی‌شود و میوه کامل مصرف گردد.'
    ]
  },
  {
    title: 'قوانین مصرف آب',
    items: ['هدف ۴ لیوان (۱ لیتر) حداقل'],
    rules: [
      'نیم ساعت قبل از غذا و ۱ ساعت بعد از غذا آب بنوشید.',
      'از نوشیدن آب یخ همراه با غذا خودداری فرمایید.'
    ]
  },
  {
    title: 'قوانین مصرف لبنیات',
    items: ['۱ لیوان شیر یا ماست کم‌چرب'],
    rules: [
      'فقط لبنیات کم‌چرب (زیر ۱.۵ درصد) مجاز است.',
      'بهتر است شیر را با دارچین یا یک عدد خرما میل کنید.'
    ]
  },
  {
    title: 'قوانین پیاده‌روی',
    items: ['۳۵ دقیقه پیاده‌روی روزانه'],
    rules: [
      'سرعت پیاده‌روی باید متوسط تا تند باشد (حالتی که ضربان قلب کمی بالا برود).',
      'بهتر است پیاده‌روی ۱ ساعت بعد از یک وعده اصلی یا عصر انجام شود.'
    ]
  },
  {
    title: 'قوانین وعده آزاد (Free Meal)',
    items: ['پنجره ۱ ساعته در روز مشخص'],
    rules: [
      'وعده آزاد فقط در روزهای تعیین شده (مانند روز ۷ و ۱۴) و به مدت حداکثر ۱ ساعت فعال است.',
      'موارد ممنوع در وعده آزاد: شیرینی، شکلات، نوشابه، دسر، سس سفید و آجیل.',
      'می‌توانید یک غذای دلخواه خانگی یا سنتی را تا حد سیری معمول میل کنید.'
    ]
  },
  {
    title: 'قوانین مکمل‌ها',
    items: ['ففول، سبوس برنج، سیاهدانه و عسل، ویتامین D'],
    rules: [
      'ترکیب سیاهدانه و عسل ناشتا (۱ چایخوری) مصرف شود.',
      'ففول همراه با یک لیوان آب بعد از غذا میل شود.',
      'ویتامین D طبق دستور هفتگی یا روزانه همراه چربی سالم مصرف شود.'
    ]
  }
];

export const DEFAULT_SNACK_OPTIONS = [
  { id: 'snk_1', name: '۱ عدد سیب درشت + ۵ عدد بادام درختی', portion: '۱۵۰ گرم', calories: 130, description: 'سرشار از فیبر و چربی سالم' },
  { id: 'snk_2', name: '۱ لیوان دمنوش بابونه + ۲ عدد خرمای زاهدی', portion: '۱ لیوان + ۲۰ گرم', calories: 70, description: 'آرامشبخش و تنظیم‌کننده قند' },
  { id: 'snk_3', name: '۱ لیوان ماست پروبیوتیک کم‌چرب + خیار و نعناع', portion: '۲۰۰ گرم', calories: 110, description: 'عالی برای گوارش و هضم' },
  { id: 'snk_4', name: '۱ عدد پرتقال یا خیار + ۳ عدد گردو', portion: '۱۶0 گرم', calories: 140, description: 'ویتامین C و امگا ۳' },
];

export function generate21DaysData(): DayPlan[] {
  const days: DayPlan[] = [];
  const weekDays = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'];

  for (let d = 1; d <= 21; d++) {
    const isToday = d === 7;
    const isFree = d === 7 || d === 14;
    const dayOfWeek = weekDays[(d + 5) % 7];

    const dayObj: DayPlan = {
      dayNumber: d,
      datePersian: `روز ${d} از ۲۱ - ${dayOfWeek}`,
      dayOfWeek: dayOfWeek,
      meals: [
        {
          id: `m_${d}_b`,
          title: 'breakfast',
          persianTitle: 'صبحانه',
          timeSlot: '۰۸:۳۰',
          foodName: d % 2 === 1 ? 'فرنی رژیمی با آرد برنج و شیر' : 'تخم‌مرغ آب‌پز با گوجه و نان سنگک',
          portion: d % 2 === 1 ? '۱ پیاله (۲۰۰ گرم)' : '۲ عدد تخم‌مرغ + ۳۰ گرم نان سنگک',
          calories: d % 2 === 1 ? 180 : 210,
          image: d % 2 === 1 
            ? 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?auto=format&fit=crop&w=600&q=80'
            : 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80',
          ingredients: d % 2 === 1 
            ? ['شیر کم‌چرب', 'آرد برنج', 'گلاب', 'شیره انگور']
            : ['۲ عدد تخم‌مرغ', 'نان سنگک', 'گوجه‌فرنگی و خیار'],
          recipeId: d % 2 === 1 ? 'rec_1' : 'rec_6',
          isCompleted: d <= 7 ? true : false,
        },
        {
          id: `m_${d}_l`,
          title: 'lunch',
          persianTitle: 'ناهار',
          timeSlot: '۱۳:۳۰',
          foodName: isFree 
            ? 'زرشک پلو با مرغ (یا وعده آزاد طبق قوانین)'
            : (d % 3 === 0 ? 'استانبولی پلو با گوشت' : (d % 3 === 1 ? 'زرشک پلو با مرغ بخارپز' : 'کتلت گوشت کم‌چرب')),
          portion: '۶ قاشق برنج + سهمیه پروتئین',
          calories: 380,
          image: d % 3 === 0
            ? 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80'
            : 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
          ingredients: ['سینه مرغ/گوشت کم‌چرب', 'برنج کته', 'زرشک و زعفران', 'سالاد فصل'],
          recipeId: d % 3 === 0 ? 'rec_10' : 'rec_2',
          isCompleted: d < 7 ? true : false, // Day 7 lunch starts uncompleted or ready to complete in scenario
        },
        {
          id: `m_${d}_d`,
          title: 'dinner',
          persianTitle: 'شام',
          timeSlot: '۲۰:۳۰',
          foodName: d % 2 === 0 ? 'سالاد سیب‌زمینی و پنیر' : 'خوراک مرغ و سبزیجات بخارپز',
          portion: '۱ بشقاب مشخص',
          calories: 250,
          image: d % 2 === 0 
            ? 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80'
            : 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=600&q=80',
          ingredients: d % 2 === 0 ? ['سیب‌زمینی آب‌پز', 'پنیر لاکتیکی', 'شوید'] : ['سینه مرغ', 'کدو سبز', 'هویج'],
          recipeId: d % 2 === 0 ? 'rec_3' : 'rec_5',
          isCompleted: d < 7 ? true : false,
        }
      ],
      snackOptions: DEFAULT_SNACK_OPTIONS,
      selectedSnackId: d <= 6 ? 'snk_1' : undefined,
      isSnackCompleted: d <= 6 ? true : false,
      isFreeMealDay: isFree,
      freeMealDetails: isFree ? {
        windowMinutes: 60,
        remainingMinutes: 60,
        isActive: false,
        description: 'شما امروز ۱ ساعت پنجره وعده آزاد دارید. لطفاً قوانین ممنوعه را رعایت فرمایید.'
      } : undefined,
      quotas: {
        waterGlasses: 4,
        waterLogged: isToday ? 3 : (d < 7 ? 4 : 0),
        fruitGramsTarget: 500,
        fruitGramsLogged: isToday ? 320 : (d < 7 ? 500 : 0),
        dairyCupsTarget: 1,
        dairyCupsLogged: isToday ? 1 : (d < 7 ? 1 : 0),
        walkMinutesTarget: 35,
        walkMinutesLogged: isToday ? 25 : (d < 7 ? 35 : 0),
        isWalkCompleted: isToday ? false : (d < 7 ? true : false),
      },
      supplements: [
        { id: `sup_${d}_1`, name: 'ترکیب سیاهدانه و عسل', time: '۰۷:۳۰ ناشتا', dosage: '۱ قاشق چایخوری', isCompleted: d <= 7 },
        { id: `sup_${d}_2`, name: 'ففول (آهن + اسید فولیک)', time: 'همراه با صبحانه', dosage: '۱ کپسول', isCompleted: d <= 7 },
        { id: `sup_${d}_3`, name: 'سبوس برنج', time: 'با ماست یا آب', dosage: '۱ ساشه', isCompleted: d < 7 },
        { id: `sup_${d}_4`, name: 'ویتامین D3', time: 'همراه با غذا', dosage: '۱ عدد', isCompleted: d < 7 }
      ],
      reminders: [
        { id: `rem_${d}_1`, text: 'مصرف ۴ لیوان آب روزانه', completed: isToday ? false : d < 7 },
        { id: `rem_${d}_2`, text: 'مصرف کپسول ففول و سبوس برنج', completed: isToday ? true : d < 7 },
        { id: `rem_${d}_3`, text: '۳۵ دقیقه پیاده‌روی با سرعت مناسب', completed: isToday ? false : d < 7 },
        { id: `rem_${d}_4`, text: 'یک چایخوری سیاهدانه و عسل ناشتا', completed: isToday ? true : d < 7 },
        { id: `rem_${d}_5`, text: 'رعایت سهمیه ۵۰۰ گرم میوه و ۱ لیوان لبنیات', completed: isToday ? false : d < 7 },
      ],
      weightKg: d === 1 ? 72.0 : (d === 3 ? 70.8 : (d === 5 ? 69.8 : (d === 7 ? 68.5 : undefined))),
      mood: d === 7 ? 'excellent' : 'good',
      moodNote: d === 7 ? 'احساس انرژی خوب و کاهش تورم شکمی' : undefined,
      cheats: d === 4 ? [
        { id: 'ch_1', date: 'روز ۴', foodName: 'یک عدد شیرینی کوچک', portion: '۳۰ گرم', time: '۱۶:۰۰', reason: 'craving', reasonPersian: 'هوس غذایی' }
      ] : [],
      dietScore: d === 7 ? 88 : (d < 7 ? (d === 4 ? 78 : 95) : 0),
    };

    days.push(dayObj);
  }

  return days;
}
